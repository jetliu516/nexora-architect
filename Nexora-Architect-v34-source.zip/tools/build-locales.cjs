const fs=require('node:fs');
const maps=JSON.parse(fs.readFileSync('translations/generated.json','utf8'));
// Legacy TSV contains these five explicit languages; newer dictionaries remain in generated.json.
const legacy=['en','ja','de','fr','it'];
for(const row of fs.readFileSync('translations/ui.tsv','utf8').trim().split('\n')){
 const cells=row.split('\t');if(cells.length!==6)throw Error('Expected six TSV columns: '+cells[0]);
 legacy.forEach((lang,i)=>maps[lang][cells[0]]=cells[i+1]);
}
const keys=Object.keys(maps.en);
for(const [lang,dict]of Object.entries(maps)){
 if(keys.some(k=>typeof dict[k]!=='string'||!dict[k].trim()))throw Error('Missing translation for '+lang);
 maps[lang]=Object.fromEntries(keys.map(k=>[k,dict[k]]));
}
fs.writeFileSync('dist/locales.js','window.NexoraLocales='+JSON.stringify(maps)+';\n');
console.log(keys.length+' UI strings × '+Object.keys(maps).length+' translated languages');
