const fs=require('node:fs'),path=require('node:path'),E=require('../dist/geometry.js'),D=require('../dist/drawings.js'),T=require('../dist/template-library.js');
const out=process.argv[2];if(!out)throw Error('output directory required');fs.mkdirSync(out,{recursive:true});
const quote=v=>'"'+String(v).replace(/"/g,'""')+'"',rows=[['ID','Name','Bedrooms','Above-ground stories','Basement','Net living area sq ft','Net living area m2']];let plans=0;
for(const t of T.entries){const p=T.build(t.id);fs.writeFileSync(path.join(out,t.id+'.json'),JSON.stringify(p,null,2));
 for(const f of p.floors){const b=E.bounds(p,f.id),box={x:b.x-1,y:b.y-1,w:b.w+2,h:b.d+3},plan=D.plan(p,{floor:f.id,layers:{rooms:true,walls:true,openings:true,objects:true,labels:true,dimensions:true,annotations:true},roof:false},{print:true});
 const caption=`<text x="${b.x}" y="${b.y+b.d+1}" font-size=".22">${D.esc(t.id+' '+f.name+' — EDITABLE SCHEMATIC / NOT FOR CONSTRUCTION')}</text>`;
 fs.writeFileSync(path.join(out,t.id+'-'+f.name.replace(/\s+/g,'-')+'.svg'),D.svg(plan+caption,box));plans++;
 }
 rows.push([t.id,t.name,t.bedrooms,t.floors,t.basement?'Yes':'No',t.areaSqFt.toFixed(2),t.areaM2.toFixed(2)]);
}
fs.writeFileSync(path.join(out,'Catalog.csv'),'\uFEFF'+rows.map(r=>r.map(quote).join(',')).join('\r\n'));
fs.writeFileSync(path.join(out,'README.txt'),'100 original editable North American home templates. Five styles, 20 each, four room programs per style with five local dimension/garage/outdoor configurations.\nJSON: import into Nexora Architect. SVG: one vector drawing per floor; view or print in a browser.\nEnglish room names, feet/inches, USD illustrative material rates. Net living area is measured inside wall faces, excluding garages, basements, porches, decks and stair openings.\nOriginal project data is preserved when loading a template. Each load creates new IDs.\nThese are schematic starting points, not construction or permit plans. Roof masses are simplified. Structural capacity, local code, accessibility, energy, site and MEP design have not been professionally approved.\nSee Audit.csv and Audit.json for the automated geometry/circulation checks and their limitations.\n');
for(const ext of ['csv','json'])fs.copyFileSync(path.join(__dirname,'../docs/north-america-100-audit.'+ext),path.join(out,'Audit.'+ext));
console.log(`Exported ${T.entries.length} project JSON files + ${plans} floor SVG drawings + catalog and audit records.`);
