const attachmentTypes={pdf:'application/pdf',docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',txt:'text/plain',md:'text/markdown',csv:'text/csv',png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',webp:'image/webp'};
export function publicLink(value){
 if(typeof value!=='string'||value.length>2000)throw Error('链接过长或格式无效');
 let u;try{u=new URL(value)}catch{throw Error('请输入完整 https 网页链接')}
 const host=u.hostname.toLowerCase();
 if(u.protocol!=='https:'||u.username||u.password||(u.port&&u.port!=='443')||!host.includes('.')||/^[\d.]+$/.test(host)||host.includes(':')||/(^|\.)(localhost|local|internal|test|invalid|home|lan)$/.test(host))throw Error('仅支持公开 HTTPS 网页链接');
 u.hash='';return u.href;
}
export function validateAttachments(body){
 const files=body.attachments??[],links=body.links??[];if(!Array.isArray(files)||files.length>3||!Array.isArray(links)||links.length>3)throw Error('最多3个附件和3个链接');
 let total=0;
 const attachments=files.map(f=>{
  if(!f||typeof f.name!=='string'||!f.name.trim()||f.name.length>120||/[\\/\x00-\x1f]/.test(f.name))throw Error('文件名称无效');
  const ext=f.name.split('.').pop().toLowerCase(),mime=attachmentTypes[ext];if(!mime)throw Error('文件格式不支持，请转为 PDF、DOCX、XLSX、TXT、MD、CSV 或图片');
  if(typeof f.data!=='string')throw Error('文件数据无效');const match=f.data.match(/^data:([^;,]+);base64,([A-Za-z0-9+/]+={0,2})$/);
  if(!match||match[1]!==mime||match[2].length%4)throw Error('文件数据格式无效');
  const size=match[2].length*3/4-(match[2].endsWith('==')?2:match[2].endsWith('=')?1:0);total+=size;
  if(size>4*1024*1024||total>8*1024*1024)throw Error('单个文件最多4MB，合计最多8MB');
  const head=atob(match[2].slice(0,Math.min(48,match[2].length)));
  if((ext==='pdf'&&!head.startsWith('%PDF-'))||(['docx','xlsx'].includes(ext)&&!head.startsWith('PK'))||(mime==='image/png'&&!head.startsWith('\x89PNG'))||(mime==='image/jpeg'&&!head.startsWith('\xff\xd8'))||(mime==='image/webp'&&!(head.startsWith('RIFF')&&head.slice(8,12)==='WEBP')))throw Error('文件内容与类型不符');
  return{name:f.name,data:f.data,mime};
 });return{attachments,links:[...new Set(links.map(publicLink))]};
}
export function attachmentInput(input){
 const messages=input.messages.map(m=>({...m}));const last=messages.at(-1),content=[{type:'input_text',text:last.content}];
 for(const f of input.attachments){content.push({type:'input_text',text:'用户提供的参考资料：'+f.name});content.push(f.mime.startsWith('image/')?{type:'input_image',image_url:f.data,detail:'auto'}:{type:'input_file',filename:f.name,file_data:f.data});}
 if(input.links.length)content.push({type:'input_text',text:'请使用网页搜索读取以下公开链接，回答时引用实际获取的来源；若未获取目标页面，必须明确说明，不得声称已经阅读。链接：\n'+input.links.join('\n')});
 if(content.length>1)last.content=content;
 return messages;
}
