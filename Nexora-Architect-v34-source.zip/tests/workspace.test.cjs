const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const E=require('../dist/geometry.js'),W=require('../dist/workspace-model.js');
const clone=E.clone;
function house(){const p=E.newProject('Workspace test');E.addRectangle(p,0,0,6,5,p.floors[0].id);E.opening(p,p.walls[0].id,.4,'door');return E.validate(p)}
function state(p){return {...W.defaults(),floor:p.floors[0].id}}
function saved(p,overrides={}){return{id:'saved-test',name:'Review',state:{...state(p),...overrides}}}
test('saved view survives project JSON, rename and deep-copy with all drafting settings',()=>{
 const p=house();p.savedViews=[saved(p,{mode:'section',layers:{walls:false,rooms:true},locks:{openings:true},sectionY:2.8,scale:50,frame:{x:3,y:2.5,width:14},camera:{position:[3,6,12],target:[3,1,2.5]},style:'clay',daylight:'golden',landscape:false,autoDimensions:true})];
 const q=E.validate(JSON.parse(JSON.stringify(p))),v=q.savedViews[0];assert.equal(v.state.layers.walls,false);assert.equal(v.state.locks.openings,true);assert.equal(v.state.sectionY,2.8);assert.equal(v.state.frame.width,14);assert.equal(v.state.style,'clay');assert.equal(v.state.daylight,'golden');assert.equal(v.state.landscape,false);assert.equal(v.state.autoDimensions,true);q.savedViews[0].name='Different';assert.equal(p.savedViews[0].name,'Review');
});
test('deleted saved-view floor falls back safely and unrelated unknown fields do not persist',()=>{
 const p=house();p.savedViews=[saved(p,{floor:'removed-floor',layers:{evil:true},execute:'bad'})];const view=E.validate(p).savedViews[0];assert.equal(view.state.floor,p.floors[0].id);assert.equal(view.state.execute,undefined);assert.equal(view.state.layers.evil,undefined);
});
test('reject malformed, oversized, duplicate and nonfinite view settings',()=>{
 const p=house();for(const raw of [{},[saved(p),saved(p)],Array.from({length:61},(_,i)=>({...saved(p),id:'v'+i})),[saved(p,{mode:'execute'})],[saved(p,{frame:{x:0,y:0,width:-1}})],[saved(p,{layers:{walls:'yes'}})],[saved(p,{camera:{position:[1,1,1],target:[1,1,1]}})],[saved(p,{camera:{position:[Infinity,0,0],target:[1,1,1]}})]])assert.throws(()=>W.normalizeViews(raw,p));
});
test('legacy invalid cameras are dropped safely, valid cameras preserved',()=>{
 const p=house();p.cameras=[{name:'invalid',position:[0,0,0],target:[0,0,0]},{name:'valid',position:[3,5,10],target:[0,0,0]}];assert.deepEqual(E.validate(p).cameras.map(c=>c.name),['valid']);
});
test('visibility and lock guard selection across rooms, walls, openings and electrical',()=>{
 const p=house(),s=state(p),wall=p.walls[0],room=E.detectRooms(p,s.floor)[0],light=E.object(p,'light',2,2,s.floor);
 assert.equal(W.canSelect(p,s,'room',room.id),true);s.layers.walls=false;assert.equal(W.canSelect(p,s,'wall',wall.id),false);assert.equal(W.canSelect(p,s,'opening',p.openings[0].id),true);s.locks.rooms=true;assert.equal(W.canSelect(p,s,'room',room.id),false);s.locks.electrical=true;assert.equal(W.canSelect(p,s,'object',light.id),false);
});
test('locked walls reject direct, shared-node and AI-style geometry changes',()=>{
 const p=house(),s=state(p);s.locks.walls=true;
 for(const mutate of [q=>q.walls.pop(),q=>q.walls[0].height=3,q=>E.moveNode(q,s.floor,q.walls[0].b,{x:7,y:0}),q=>E.wall(q,{x:1,y:1},{x:2,y:1},s.floor)]){const q=clone(p);mutate(q);assert.throws(()=>W.assertEditable(p,q,s),/墙体/)}
});
test('locked openings protect host-wall deletion and movement, locked host protects new openings',()=>{
 const p=house(),s=state(p);s.locks.openings=true;const q=clone(p);q.walls[0].b.x+=1;assert.throws(()=>W.assertEditable(p,q,s),/门窗/);
 const deleted=clone(p);deleted.walls.shift();deleted.openings=[];assert.throws(()=>W.assertEditable(p,deleted,s),/门窗/);
 s.locks={walls:true};const added=clone(p);E.opening(added,added.walls[1].id,.5,'window');assert.throws(()=>W.assertEditable(p,added,s),/墙体/);
});
test('locked derived rooms and floor relationships cannot be bypassed by wall or floor edits',()=>{
 const p=house(),s=state(p);s.locks.rooms=true;const q=clone(p);q.walls[2].a.y+=.5;assert.throws(()=>W.assertEditable(p,q,s),/房间/);
 s.locks={objects:true};const next=clone(p);next.floors[0].elevation=1;assert.throws(()=>W.assertEditable(p,next,s),/家具/);
});
test('hidden layers protect existing and new objects while metadata and saved views remain editable',()=>{
 const p=house(),s=state(p);E.object(p,'sofa',1,1,s.floor);s.layers.objects=false;const q=clone(p);q.objects[0].x=2;assert.throws(()=>W.assertEditable(p,q,s));
 const next=clone(p);next.name='Renamed';next.savedViews=[saved(p)];assert.doesNotThrow(()=>W.assertEditable(p,next,s));
});
test('electrical lock applies to electrical objects without blocking furniture',()=>{
 const p=house(),s=state(p);s.locks.electrical=true;let q=clone(p);E.object(q,'sofa',1,1,s.floor);assert.doesNotThrow(()=>W.assertEditable(p,q,s));q=clone(p);E.object(q,'socket',2,2,s.floor);assert.throws(()=>W.assertEditable(p,q,s),/电气/);
});
test('moving a stair cannot bypass the locked floor opening it drives',()=>{
 const p=E.validate(E.demoDuplex()),s=state(p),q=clone(p);s.locks.rooms=true;q.objects.find(o=>o.kind==='stairs').x+=.1;assert.throws(()=>W.assertEditable(p,q,s),/房间/);
});
test('camera round trip keeps walk orientation and refuses zero-distance orbit',()=>{
 const THREE=require('../dist/vendor/three.min.js');const context={THREE,BIM:E};context.window=context;vm.runInNewContext(fs.readFileSync('dist/view3d.js','utf8'),context);
 const view=Object.create(context.BuildingView.prototype);view.camera=new THREE.PerspectiveCamera();view.camera.position.set(2,1.65,3);view.target=new THREE.Vector3(2,0,3);view.walk=true;view.yaw=1.1;view.pitch=.2;view.render=()=>{};
 const c=view.captureCamera('Walk');assert.equal(c.walk,true);assert.ok(Math.hypot(...c.position.map((n,i)=>n-c.target[i]))>.9);assert.equal(view.restoreCamera(c),true);assert.equal(view.yaw,1.1);assert.equal(view.pitch,.2);assert.equal(view.walk,true);
 assert.equal(view.restoreCamera({position:[0,0,0],target:[0,0,0]}),false);assert.ok(Number.isFinite(view.distance));view.walk=false;const orbit={position:[5,6,8],target:[2,0,3]};assert.equal(view.restoreCamera(orbit),true);assert.ok(view.camera.position.distanceTo(new THREE.Vector3(...orbit.position))<1e-8);
});
