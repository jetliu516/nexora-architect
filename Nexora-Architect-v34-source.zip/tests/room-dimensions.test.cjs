const {test}=require('node:test'),assert=require('node:assert/strict');
const E=require('../dist/geometry.js'),R=require('../dist/room-dimensions.js');
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-6,`${a} ≠ ${b}`);
function home(){const p=E.newProject();E.addRectangle(p,0,0,10,8,p.floors[0].id);return E.validate(p)}
test('net width and depth drive wall faces, area and material quantities',()=>{
 const p=home(),f=p.floors[0].id,r=E.detectRooms(p,f)[0];
 const next=R.resize(p,r.id,4.25,3.5),m=R.measure(p,next);
 near(m.width,4.25);near(m.depth,3.5);near(next.netArea,14.875);
 near(E.estimate(p).rows.find(r=>r.key==='floor').quantity,14.875*1.1);
 near(p.walls[0].a.x,0);near(p.walls[0].a.y,0);
});
test('continuous shared wall, T junctions and neighbor labels survive resize',()=>{
 const p=home(),f=p.floors[0].id;E.wall(p,{x:6,y:0},{x:6,y:8},f,'interior');E.wall(p,{x:0,y:4},{x:6,y:4},f,'interior');
 const rooms=E.detectRooms(p,f);rooms.forEach((r,i)=>E.roomMeta(p,r,{name:'room-'+i}));
 const old=E.detectRooms(p,f).find(r=>r.center.x<6&&r.center.y<4);
 const next=R.resize(p,old.id,4.25,3.82),after=E.detectRooms(p,f);
 assert.equal(after.length,3);assert.deepEqual(after.map(r=>r.name).sort(),['room-0','room-1','room-2']);
 near(R.measure(p,next).width,4.25);near(p.walls.find(w=>w.kind==='interior'&&w.a.y===4).b.x,4.43);
 near(after.reduce((s,r)=>s+r.area,0),80);
});
test('hosted doors move with translated wall while offsets remain unchanged',()=>{
 const p=home(),f=p.floors[0].id,w=p.walls.find(w=>w.a.x===10&&w.b.x===10),o=E.opening(p,w.id,.5,'door'),offset=o.offset;
 R.resize(p,E.detectRooms(p,f)[0].id,12,7.76);const wall=p.walls.find(v=>v.id===w.id);
 near(wall.a.x,12.24);assert.equal(p.openings[0].offset,offset);E.validate(p);
});
test('invalid dimensions and hosted opening conflicts roll back atomically',()=>{
 const p=home(),f=p.floors[0].id;E.opening(p,p.walls[0].id,.8,'window');const room=E.detectRooms(p,f)[0],before=JSON.stringify(p);
 for(const dims of [[1,7.76],[NaN,7.76],[101,7.76],[-1,7.76]]) {assert.throws(()=>R.resize(p,room.id,...dims));assert.equal(JSON.stringify(p),before)}
});
test('room collapse and irregular contours are refused without data loss',()=>{
 const p=home(),f=p.floors[0].id;E.wall(p,{x:6,y:0},{x:6,y:8},f,'interior');const r=E.detectRooms(p,f).find(r=>r.center.x<6),before=JSON.stringify(p);
 assert.throws(()=>R.resize(p,r.id,12,7.76));assert.equal(JSON.stringify(p),before);
 const q=E.newProject(),id=q.floors[0].id,pts=[[0,0],[6,0],[6,3],[3,3],[3,6],[0,6]];pts.forEach((a,i)=>E.wall(q,{x:a[0],y:a[1]},{x:pts[(i+1)%6][0],y:pts[(i+1)%6][1]},id));assert.equal(R.measure(q,E.detectRooms(q,id)[0]),null);
});
test('room resize refuses to move an upper boundary across its linked stairwell',()=>{
 const p=E.demoDuplex(),f=p.floors[1].id,r=E.detectRooms(p,f).find(r=>r.center.x>6),before=JSON.stringify(p);
 assert.throws(()=>R.resize(p,r.id,.8,7.76));assert.equal(JSON.stringify(p),before);
});
