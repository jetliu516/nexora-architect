const test = require('node:test');
const assert = require('node:assert/strict');
const E = require('../dist/geometry.js');
const R = require('../dist/project-region.js');
const U = require('../dist/us-pricing.js');
const US = require('../dist/us-residential.js');
const N = require('../dist/north-america.js');
const PL = require('../dist/project-library.js');

const SF = 1 / .3048 ** 2, FT = 1 / .3048, CY = 1 / .9144 ** 3;
const factors = {floor: SF, wall: SF, concrete: CY, door: 1, window: SF, cabinet: FT, countertop: SF, backsplash: SF};
const metric = {floor: 'm²', wall: 'm²', concrete: 'm³', door: 'each', window: 'm²', cabinet: 'm', countertop: 'm²', backsplash: 'm²'};
const imperial = {floor: 'sq ft', wall: 'sq ft', concrete: 'cu yd', door: 'each', window: 'sq ft', cabinet: 'ft', countertop: 'sq ft', backsplash: 'sq ft'};
const close = (actual, expected, message) => assert.ok(
  Number.isFinite(actual) && Math.abs(actual - expected) <= Math.max(1, Math.abs(expected)) * 1e-10,
  message || `${actual} should equal ${expected}`);
let legacyFixture;
function legacy() {
  if (!legacyFixture) legacyFixture = US.build('ranch');
  const p = E.clone(legacyFixture);
  p.pricing = {currency: 'USD', rates: {floor: 9.25, door: 0, countertop: 81.375}, note: 'Existing project prices'};
  return p;
}
function reopen(p) {
  const db = PL.upsert({projects: [], trash: [], recovery: []}, p), writes = new Map();
  PL.persist({setItem: (k, v) => writes.set(k, v)}, 'pricing-library', db);
  return PL.load(writes.get('pricing-library'), {validate: E.validate, createEmpty: E.newProject}).projects[0];
}
function baseFields(result) {
  const {rows, total, currency, ...rest} = result;
  return rest;
}

test('pricing compatibility: all 100 new homes keep six canonical rows, original quantities and USD samples', () => {
  const samples = structuredClone(R.samples);
  assert.equal(N.entries.length, 100);
  for (const entry of N.entries) {
    const p = N.build(entry.id), before = JSON.stringify(p), base = E.estimate(p), result = R.estimate(p);
    assert.equal(Object.hasOwn(p, 'pricing'), false);
    assert.equal(result.currency, 'USD'); assert.equal(result.rows.length, 6);
    assert.deepEqual(baseFields(result), baseFields(base));
    close(result.total, base.total);
    for (const row of result.rows) {
      const source = base.rows.find(r => r.key === row.key);
      close(row.quantity, source.quantity * factors[row.key]);
      close(row.rate, source.rate / factors[row.key]);
      close(row.amount, source.quantity * source.rate);
    }
    close(result.rows.find(r => r.key === 'floor').rate, 12);
    assert.equal(JSON.stringify(p), before);
  }
  assert.deepEqual(R.samples, samples);
});

test('pricing compatibility: legacy USD fallback preserves custom prices, extras, allowances and full base fields', () => {
  const p = legacy(), before = JSON.stringify(p), source = U.estimate(p), result = R.estimate(p);
  assert.equal(Object.hasOwn(p, 'currency'), false); assert.equal(R.currency(p), 'USD');
  assert.equal(result.currency, 'USD'); assert.equal(result.rows.length, 8);
  assert.deepEqual(baseFields(result), baseFields(source)); close(result.total, source.total);
  for (const row of result.rows) {
    const original = source.rows.find(r => r.key === row.key);
    close(row.quantity, original.quantity); close(row.rate, original.rate); close(row.amount, original.amount);
  }
  close(result.rows.find(r => r.key === 'door').amount, 0);
  close(result.rows.find(r => r.key === 'floor').rate, 9.25);
  close(result.rows.find(r => r.key === 'countertop').rate, 81.375);
  close(result.rows.find(r => r.key === 'backsplash').rate, 18);
  assert.ok(result.rows.find(r => r.key === 'floor').quantity < E.estimate(p).netArea * 1.1 * SF,
    'legacy finish allowance excludes the concrete garage and unfinished basement');
  assert.match(R.money(p, 1234.56), /^\$1,234\.56$/);
  result.rows[0].rate = 999; result.rows[0].quantity = 0;
  assert.equal(JSON.stringify(p), before);
  const restored = reopen(p);
  assert.equal(Object.hasOwn(restored, 'currency'), false); assert.deepEqual(restored.pricing, p.pricing);
  assert.deepEqual(restored.rates, p.rates); close(R.estimate(restored).total, source.total);
});

test('pricing compatibility: legacy metric/imperial views and floor filters preserve subtotal and units', () => {
  const p = legacy();
  for (const unit of ['m', 'ft']) for (const floor of [undefined, ...p.floors.map(f => f.id)]) {
    p.unit = unit;
    const source = U.estimate(p, floor), result = R.estimate(p, floor);
    assert.deepEqual(baseFields(result), baseFields(source)); close(result.total, source.total);
    assert.deepEqual(R.rows(p, floor), result.rows);
    for (const row of result.rows) {
      const original = source.rows.find(r => r.key === row.key), f = unit === 'ft' ? 1 : factors[row.key];
      close(row.quantity, original.quantity / f); close(row.rate, original.rate * f);
      close(row.amount, original.amount); assert.equal(row.unit, (unit === 'ft' ? imperial : metric)[row.key]);
      close(R.factor(p, row.key), unit === 'ft' ? factors[row.key] : 1);
    }
    close(result.total, result.rows.reduce((sum, r) => sum + r.quantity * r.rate, 0));
  }
  const basement = p.floors.find(f => f.name === 'Basement');
  const result = R.estimate(p, basement.id);
  for (const key of ['floor', 'countertop', 'backsplash']) close(result.rows.find(r => r.key === key).quantity, 0);
});

test('pricing compatibility: editing each legacy displayed rate survives save/load and changes only that allowance', () => {
  for (const unit of ['m', 'ft']) for (const key of Object.keys(factors)) {
    const p = legacy(); p.unit = unit;
    const before = E.clone(p), estimate = R.estimate(p), row = estimate.rows.find(r => r.key === key), shown = 17.321098765;
    assert.equal(R.setRate(p, key, shown), p);
    const restored = reopen(E.validate(p)), after = R.estimate(restored), edited = after.rows.find(r => r.key === key);
    close(edited.rate, shown); close(edited.quantity, row.quantity);
    close(after.total, estimate.total + row.quantity * (shown - row.rate));
    close(restored.pricing.rates[key], shown * (unit === 'ft' ? 1 : 1 / factors[key]));
    assert.deepEqual(restored.rates, before.rates); assert.deepEqual(restored.walls, before.walls);
    assert.deepEqual(restored.objects, before.objects); assert.equal(restored.pricing.note, before.pricing.note);
    for (const other of Object.keys(before.pricing.rates).filter(k => k !== key)) {
      assert.equal(restored.pricing.rates[other], before.pricing.rates[other]);
    }
    assert.equal(Object.hasOwn(restored, 'currency'), false);
  }
});

test('pricing compatibility: canonical editing uses SI storage and never activates legacy default prices', () => {
  const fixture = N.defaultProject();
  for (const unit of ['m', 'ft']) for (const key of Object.keys(factors).slice(0, 6)) {
    const p = E.clone(fixture); p.unit = unit;
    const before = R.estimate(p), row = before.rows.find(r => r.key === key), rates = {...p.rates};
    R.setRate(p, key, 23.456789);
    const restored = reopen(p), result = R.estimate(restored);
    close(result.rows.find(r => r.key === key).rate, 23.456789);
    close(restored.rates[key], 23.456789 * (unit === 'ft' ? factors[key] : 1));
    close(result.total, before.total + row.quantity * (23.456789 - row.rate));
    assert.equal(result.rows.length, 6); assert.equal(Object.hasOwn(restored, 'pricing'), false);
    for (const other of Object.keys(rates).filter(k => k !== key)) assert.equal(restored.rates[other], rates[other]);
  }
});

test('pricing compatibility: waste remains canonical for both price sources, and zero prices remain valid', () => {
  for (const p of [legacy(), N.defaultProject()]) {
    const pricing = structuredClone(p.pricing), rates = {...p.rates}, before = R.estimate(p);
    R.setRate(p, 'waste', 20);
    assert.equal(p.rates.waste, 20); assert.deepEqual(p.pricing, pricing);
    const after = R.estimate(p), floorBefore = before.rows.find(r => r.key === 'floor'), floorAfter = after.rows.find(r => r.key === 'floor');
    close(floorAfter.quantity, floorBefore.quantity / (1 + rates.waste / 100) * 1.2);
    for (const row of after.rows.filter(r => r.key !== 'floor')) close(row.quantity, before.rows.find(r => r.key === row.key).quantity);
    R.setRate(p, 'floor', 0); close(R.estimate(E.validate(p)).rows.find(r => r.key === 'floor').amount, 0);
  }
});

test('pricing compatibility: explicit preset changes delete legacy overrides, including same-USD reset', () => {
  for (const code of ['USD', 'CAD', 'CNY']) {
    const p = legacy(), before = E.clone(p);
    assert.equal(R.setCurrency(p, code), p); assert.equal(p.currency, code);
    assert.equal(Object.hasOwn(p, 'pricing'), false); assert.deepEqual(p.rates, R.samples[code]);
    assert.notEqual(p.rates, R.samples[code]); assert.equal(p.unit, before.unit);
    const {pricing, rates, ...originalRest} = before, {currency, rates: updatedRates, ...updatedRest} = p;
    assert.deepEqual(updatedRest, originalRest); assert.equal(R.estimate(p).rows.length, 6);
    R.setCurrency(p, 'USD'); close(R.rows(p).find(r => r.key === 'floor').rate, 12);
    assert.equal(R.rows(p).some(r => r.key === 'countertop'), false);
  }
  const p = legacy(), before = structuredClone(p);
  for (const code of ['EUR', 'usd', '', null, Infinity, ['USD']]) {
    assert.throws(() => R.setCurrency(p, code), /currency/); assert.deepEqual(p, before);
  }
});

test('pricing compatibility: explicit non-USD currency wins without mutating the saved legacy price bag', () => {
  for (const code of ['CAD', 'CNY']) {
    const p = legacy(); p.currency = code; p.rates = {...R.samples[code]}; const before = JSON.stringify(p);
    const result = R.estimate(p); assert.equal(result.currency, code); assert.equal(result.rows.length, 6);
    close(result.total, E.estimate(p).total); assert.equal(JSON.stringify(p), before);
    const bag = structuredClone(p.pricing); R.setRate(p, 'floor', 16.75);
    assert.deepEqual(p.pricing, bag); close(R.rows(p).find(r => r.key === 'floor').rate, 16.75);
    assert.throws(() => R.setRate(p, 'countertop', 20), /category/);
  }
});

test('pricing compatibility: invalid rates and categories fail atomically in both storage paths', () => {
  for (const p of [legacy(), N.defaultProject()]) {
    for (const [key, value] of [['floor', -1], ['floor', Infinity], ['floor', NaN], ['floor', '8'], ['floor', null], ['floor', 1000001], ['waste', 101], ['waste', -1], ['unknown', 20], ['__proto__', 20]]) {
      const before = structuredClone(p);
      assert.throws(() => R.setRate(p, key, value)); assert.deepEqual(p, before);
    }
  }
  const canonical = N.defaultProject(), before = structuredClone(canonical);
  assert.throws(() => R.setRate(canonical, 'floor', 100000), /stored/);
  assert.throws(() => R.setRate(canonical, 'countertop', 75), /category/);
  assert.throws(() => R.setRate(canonical, 'backsplash', 18), /category/);
  assert.deepEqual(canonical, before);
});

test('pricing compatibility: raw nonfinite prices and malformed legacy metadata are rejected before cloning', () => {
  const badPricing = [[], 'USD', 12, {}, {currency: 'CAD', rates: {}}, {currency: 'USD'},
    ...[[], null, '8', new Date(0)].map(rates => ({currency: 'USD', rates})),
    ...[-1, Infinity, NaN, '8', null, 1000001].map(floor => ({currency: 'USD', rates: {floor}})),
    {currency: 'USD', rates: {waste: 10}}, {currency: 'USD', rates: {unrecognized: 5}}];
  for (const pricing of badPricing) {
    const p = E.demo(); p.pricing = pricing; const before = structuredClone(p);
    assert.throws(() => E.validate(p), /USD/); assert.throws(() => R.estimate(p), /USD/);
    assert.deepEqual(p, before);
  }
  for (const value of [Infinity, NaN, -1, '12', null, 1000001]) {
    const p = E.demo(); p.rates.floor = value; const before = structuredClone(p);
    assert.throws(() => E.validate(p), /price/); assert.deepEqual(p, before);
  }
  for (const rates of [[], 'rates', new Date(0)]) {
    const p = E.demo(); p.rates = rates; assert.throws(() => E.validate(p), /rates/);
  }
  const valid = legacy(); valid.pricing.rates = {};
  assert.doesNotThrow(() => E.validate(valid)); close(R.rows(valid).find(r => r.key === 'floor').rate, 7.5);
});

test('pricing compatibility: invalid legacy records are isolated while valid projects retain recoverable prices', () => {
  const good = legacy(), bad = legacy(); bad.id = E.uid(); bad.pricing.rates.floor = 'not a price';
  const db = PL.load(JSON.stringify({active: bad.id, projects: [good, bad]}), {validate: E.validate, createEmpty: E.newProject});
  assert.equal(db.projects.length, 1); assert.equal(db.active, good.id); assert.equal(db.recovery.length, 1);
  assert.deepEqual(db.projects[0].pricing, good.pricing);
  assert.equal(JSON.parse(db.recovery[0].raw).pricing.rates.floor, 'not a price');
  close(R.estimate(db.projects[0]).total, U.estimate(good).total);
});
