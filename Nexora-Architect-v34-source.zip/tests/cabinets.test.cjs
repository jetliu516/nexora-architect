const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs'), vm = require('node:vm');
const E = require('../dist/geometry.js'), C = require('../dist/cabinets.js');
global.BIM = E; global.Cabinets = C;
const D = require('../dist/drawings.js'); global.Drawings = D;
const CD = require('../dist/cabinet-drawings.js'), Templates = require('../dist/templates.js');
function cabinet(kind = 'baseCabinet') { const p = E.newProject(); return { p, o: E.object(p, kind, 0, 0, p.floors[0].id) }; }
const near = (a, b) => assert.ok(Math.abs(a - b) < 1e-6, `${a} != ${b}`);

test('old projects gain defaults without altering IDs, coordinates or dimensions', () => {
  const p = E.demo(); for (const o of p.objects) delete o.cabinet;
  const q = E.validate(p);
  for (let i = 0; i < p.objects.length; i++) for (const key of ['id','x','y','w','h','d','z','angle']) assert.equal(q.objects[i][key], p.objects[i][key]);
  assert.equal(C.config(q.objects.find(o=>o.kind==='wallCabinet') || {kind:'wallCabinet'}).countertop, false);
});
test('all layouts fit finished cabinet size, and drawer count follows the specification', () => {
  for (const layout of Object.keys(C.layouts)) for (const style of Object.keys(C.styles)) {
    const { p, o } = cabinet(); o.cabinet = {...o.cabinet, layout, style, drawerCount:4}; E.validate(p);
    const g = C.geometry(o);
    for (const part of g.parts) { assert.ok([part.w,part.h,part.d].every(v=>v>0)); assert.ok(part.y-part.h/2>=-1e-8); assert.ok(part.y+part.h/2<=o.h+1e-8); }
    if(layout==='drawers') assert.equal(g.fronts.length,4);
    if(layout==='mixed') assert.equal(g.fronts.filter(f=>f.kind==='door').length,2);
    if(layout==='open') assert.equal(g.fronts.length,0);
  }
});
test('previously valid miniature legacy cabinets remain loadable during migration', () => {
  for(const kind of C.kinds){const {p,o}=cabinet(kind);delete o.cabinet;o.w=o.d=o.h=.02;const q=E.validate(p);assert.equal(q.objects[0].h,.02);for(const part of C.geometry(q.objects[0]).parts)assert.ok([part.w,part.h,part.d].every(v=>Number.isFinite(v)&&v>0));}
});
test('countertop top equals total height and disabling it removes its geometry and quantity', () => {
  const {p,o}=cabinet();o.h=1.1;o.cabinet.topThickness=.07;o.cabinet.overhang=.08;
  const top=C.geometry(o).parts.find(p=>p.role==='countertop');near(top.y+top.h/2,1.1);near(top.w,1.06);near(top.d,.68);
  near(C.schedule(p)[0].countertopArea,1.06*.68);
  o.cabinet.countertop=false;assert.ok(!C.geometry(o).parts.some(p=>p.role==='countertop'));assert.equal(C.schedule(p)[0].countertopArea,0);
});
test('invalid nested values and insufficient height are rejected', () => {
  const {p,o}=cabinet();
  for (const patch of [{drawerCount:3.5},{toeHeight:-1},{topThickness:0},{overhang:Infinity},{layout:'__proto__'},{countertop:'true'},{topMaterial:'missing'}]) {
    const q=E.clone(p);q.objects[0].cabinet={...q.objects[0].cabinet,...patch};assert.throws(()=>E.validate(q));
  }
  o.h=.3;o.cabinet.toeHeight=.3;assert.throws(()=>E.validate(p));
  const sink=cabinet('sink');sink.o.cabinet.countertop=false;assert.throws(()=>E.validate(sink.p));
});
test('configuration survives JSON round trip and floor copy without shared nested state', () => {
  const {p,o}=cabinet();o.cabinet={...o.cabinet,layout:'mixed',style:'shaker',handle:'none',topMaterial:'walnut'};
  const q=E.validate(JSON.parse(JSON.stringify(p)));assert.deepEqual(q.objects[0].cabinet,o.cabinet);
  E.duplicateFloor(q,q.floors[0].id);q.objects[1].cabinet.topMaterial='white';assert.equal(q.objects[0].cabinet.topMaterial,'walnut');
});
test('wall runs reject door/window intersections and over-length without mutating the project', () => {
  const p=E.newProject(),w=E.wall(p,{x:0,y:0},{x:5,y:0},p.floors[0].id);E.opening(p,w.id,.3,'door');
  const before=JSON.stringify(p);assert.throws(()=>C.planRun(p,w,{count:3,width:.6}));assert.equal(JSON.stringify(p),before);
  assert.throws(()=>C.planRun(p,w,{count:3,width:2}));
  const placements=C.planRun(p,w,{count:3,width:.6,offset:2.5});assert.equal(placements.length,3);near(placements[0].x,2.5);
  p.openings=[];const win=E.opening(p,w.id,.4,'window');win.sill=1.1;
  assert.equal(C.planRun(p,w,{count:3,width:.6}).length,3);
  assert.throws(()=>C.planRun(p,w,{count:3,width:.6,kind:'wallCabinet'}));
});
test('rotated runs align cabinet backs with both wall faces and fronts point away', () => {
  const p=E.newProject(),w=E.wall(p,{x:2,y:1},{x:5,y:5},p.floors[0].id),dir={x:.6,y:.8},normal={x:-.8,y:.6};
  for(const side of [-1,1]) for(const o of C.planRun(p,w,{count:3,width:.6,offset:.4,side})) {
    const center={x:o.x+o.w/2,y:o.y+o.d/2};near((center.x-w.a.x)*normal.x+(center.y-w.a.y)*normal.y,side*(w.thickness/2+o.d/2));
    const angle=o.angle*Math.PI/180;near(-Math.sin(angle)*normal.x+Math.cos(angle)*normal.y,side);
  }
});
test('front drawing and quantities reflect resized doors, drawers and finishes', () => {
  const {p,o}=cabinet('drawerCabinet');o.w=1.2;o.h=1.05;o.cabinet.drawerCount=4;o.cabinet.style='shaker';
  const g=C.geometry(o),drawing=CD.front(o);assert.equal(g.fronts.length,4);assert.ok(drawing.markup.includes('1200 mm'));assert.ok(drawing.markup.includes('1050 mm'));assert.ok(!/NaN|Infinity/.test(drawing.markup));
  const row=C.schedule(p)[0];assert.equal(row.drawers,4);assert.equal(row.doors,0);
});
test('real Three.js cabinet mesh uses shared geometry and correct world transform', () => {
  const THREE=require('../dist/vendor/three.min.js'),context={THREE,BIM:E,Cabinets:C,window:{}};
  vm.runInNewContext(fs.readFileSync(require.resolve('../dist/view3d.js'),'utf8'),context);
  const view=Object.create(context.window.BuildingView.prototype);view.model=new THREE.Group();
  const {o}=cabinet();o.x=2;o.y=3;o.z=1.5;o.angle=90;o.cabinet.countertop=false;
  const g=view.objectMesh(o,3);assert.equal(g.children.length,C.geometry(o).parts.length);near(g.position.y,4.5);
  g.updateMatrixWorld(true);const bounds=new THREE.Box3().setFromObject(g);near(bounds.min.y,4.5);near(bounds.max.y,4.5+o.h);
  g.traverse(n=>{if(n.geometry)n.geometry.dispose();if(n.material)n.material.dispose()});
});
test('kitchen/bath template is valid, independently identified and draws all cabinet types', () => {
  const p=Templates.kitchen(),q=Templates.kitchen();assert.notEqual(p.id,q.id);E.validate(p);
  assert.equal(E.detectRooms(p,p.floors[0].id).length,2);assert.equal(C.schedule(p).length,10);
  for(const r of C.schedule(p))assert.ok(!/NaN|Infinity/.test(CD.front(r.object).markup));
  assert.ok(!/NaN|Infinity/.test(CD.sheet(p,p.objects.filter(C.isCabinet)).markup));
});
