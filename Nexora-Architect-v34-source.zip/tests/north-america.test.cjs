const test = require('node:test');
const assert = require('node:assert/strict');
const E = require('../dist/geometry.js');
const C = require('../dist/cabinets.js');
const N = require('../dist/north-america.js');
const FT = .3048, SQFT = 1 / FT ** 2;
const projects = new Map();
const plan = id => { if (!projects.has(id)) projects.set(id, N.build(id)); return projects.get(id); };
const allRooms = p => p.floors.flatMap(f => E.detectRooms(p, f.id));
const rect = points => {
  const xs = points.map(p => p.x), ys = points.map(p => p.y), x = Math.min(...xs), y = Math.min(...ys);
  return { x, y, w: Math.max(...xs) - x, d: Math.max(...ys) - y };
};
const overlaps = (a, b, e = 1e-6) => a.x < b.x + b.w - e && a.x + a.w > b.x + e && a.y < b.y + b.d - e && a.y + a.d > b.y + e;
const ids = p => [p.id, ...['floors', 'walls', 'openings', 'objects', 'roofs', 'annotations', 'slabOpenings'].flatMap(k => (p[k] || []).map(x => x.id))];

test('100 distinct homes provide 20 per style, four real room configurations per style and valid living areas', () => {
  assert.deepEqual(Object.keys(N).sort(), ['build', 'defaultProject', 'entries', 'gallery', 'preview']);
  const styles = ['Ranch', 'Colonial', 'Craftsman', 'Modern Farmhouse', 'Contemporary'];
  assert.deepEqual([...new Set(N.entries.map(t => t.style))], styles);
  assert.equal(N.entries.length, 100); assert.equal(new Set(N.entries.map(t => t.id)).size, 100);
  for (const style of styles) {
    const entries = N.entries.filter(t => t.style === style);
    assert.equal(entries.length, 20); assert.equal(new Set(entries.map(t => t.configurationId)).size, 4);
    assert.deepEqual([...new Set(entries.map(t => t.bedrooms))].sort(), [2, 3, 4]);
    const configurations = entries.filter((t, i) => i % 5 === 0);
    const physicalPlans = configurations.map(t => {
      const p = plan(t.id);
      return JSON.stringify(p.walls.map(w => [p.floors.find(f => f.id === w.floor).name, w.a, w.b]));
    });
    assert.equal(new Set(physicalPlans).size, 4, `${style}: configurations change actual partitions, not only room labels`);
  }
  const signatures = new Set(), normalizedSignatures = new Set();
  for (const t of N.entries) {
    const p = plan(t.id), rooms = allRooms(p), living = rooms.filter(r => r.includeLiving);
    const area = living.reduce((sum, r) => sum + r.netArea, 0), sqft = area * SQFT;
    assert.ok(sqft >= 1500 && sqft <= 2500, `${t.id}: ${sqft} sq ft net living`);
    assert.ok(Math.abs(area - E.estimate(p).livingNetArea) < 1e-6);
    assert.ok(Math.abs(sqft - p.template.livingNetAreaSqFt) < 1e-6);
    assert.ok(Math.abs(sqft - t.areaSqFt) < .1, `${t.id} published area agrees with actual geometry`);
    assert.ok(Math.abs(area - t.areaM2) < .01);
    assert.equal(p.floors.filter(f => f.elevation >= 0).length, t.floors);
    assert.equal(p.floors.some(f => f.name === 'Basement'), t.basement);
    assert.equal(rooms.filter(r => r.roomType === 'bedroom').length, t.bedrooms);
    assert.ok(rooms.some(r => r.name === 'Primary Bedroom'));
    assert.ok(rooms.filter(r => r.roomType === 'bath').length >= 2);
    assert.ok(rooms.every(r => /^[\x20-\x7e]+$/.test(r.name)), 'room names are English');
    const excluded = rooms.filter(r => r.roomType === 'garage' || p.floors.find(f => f.id === r.floor).elevation < 0);
    assert.ok(excluded.length > 0 && excluded.every(r => r.includeLiving === false));
    assert.ok(rooms.every(r => r.netArea > 0 && r.netArea < r.area), 'net areas deduct real wall footprints');
    assert.deepEqual(p.template.outdoorSpaces.map(s => s.name), ['Front Porch', 'Deck']);
    assert.ok(p.template.outdoorSpaces.every(s => s.includeLiving === false && p.objects.some(o => o.id === s.object && o.kind === 'deck')));
    for (const f of p.floors) {
      const rs = rooms.filter(r => r.floor === f.id), sum = rs.reduce((s, r) => s + r.netArea, 0);
      const union = E.polygonUnion(rs.map(r => r.netGeometry));
      assert.ok(Math.abs(sum - E.polygonArea(union)) < .001, 'room net areas do not overlap');
    }
    signatures.add(JSON.stringify(p.walls.map(w => [p.floors.find(f => f.id === w.floor).name, w.a, w.b])));
    const bounds = E.bounds(p), normalize = q => [(q.x - bounds.x) / bounds.w, (q.y - bounds.y) / bounds.d].map(n => +n.toFixed(5));
    normalizedSignatures.add(JSON.stringify(p.walls.map(w => [p.floors.find(f => f.id === w.floor).name, normalize(w.a), normalize(w.b)])));
    assert.equal(E.validate(JSON.parse(JSON.stringify(p))).template.id, t.id);
  }
  assert.equal(signatures.size, 100); assert.equal(normalizedSignatures.size, 100, 'plans are not uniform overall rescalings');
  assert.equal(N.entries.filter(t => t.basement).length, 40);
});

test('hosted openings, shared wall topology and room access survive serialization', () => {
  for (const t of N.entries) {
    const p = E.validate(JSON.parse(JSON.stringify(plan(t.id)))), rooms = allRooms(p);
    const graph = new Map(rooms.map(r => [r.id, new Set()]));
    const link = (a, b) => { graph.get(a.id).add(b.id); graph.get(b.id).add(a.id); };
    let start;
    for (const o of p.openings) {
      assert.equal(E.validateOpening(p, o), true);
      const w = p.walls.find(w => w.id === o.wall), owners = rooms.filter(r => r.wallIds.includes(w.id));
      assert.ok(owners.length === 1 || owners.length === 2, 'every opening belongs to a room boundary');
      if (o.kind === 'window') continue;
      if (owners.length === 2) link(...owners);
      if (o.id === p.template.entryDoorId) { assert.equal(owners.length, 1); start = owners[0]; }
    }
    for (const s of p.objects.filter(o => o.kind === 'stairs')) {
      const above = E.stairStatus(p, s).above;
      const mid = { x: s.x + s.w / 2, y: s.y + s.d / 2 };
      const lowerRoom = rooms.find(r => r.floor === s.floor && E.pointIn(mid, r.points));
      const upperRoom = rooms.find(r => r.floor === above.id && E.pointIn(mid, r.points));
      assert.ok(lowerRoom && upperRoom, 'stairs are within closed rooms on both floors');
      link(lowerRoom, upperRoom);
    }
    assert.ok(start, 'a real front entry is present');
    const seen = new Set([start.id]), queue = [start.id];
    for (let i = 0; i < queue.length; i++) for (const id of graph.get(queue[i])) if (!seen.has(id)) { seen.add(id); queue.push(id); }
    assert.deepEqual(rooms.filter(r => !seen.has(r.id)).map(r => r.name), [], `${t.id}: every room has an entry route through doors/stairs`);
    for (let i = 0; i < p.walls.length; i++) for (let j = i + 1; j < p.walls.length; j++) {
      const a = p.walls[i], b = p.walls[j];
      if (a.floor !== b.floor) continue;
      const horizontal = Math.abs(a.a.y - a.b.y) < 1e-6;
      const sameLine = horizontal ? Math.abs(b.a.y - b.b.y) < 1e-6 && Math.abs(a.a.y - b.a.y) < 1e-6 : Math.abs(b.a.x - b.b.x) < 1e-6 && Math.abs(a.a.x - b.a.x) < 1e-6;
      if (!sameLine) continue;
      const axis = horizontal ? 'x' : 'y';
      assert.ok(Math.min(a.b[axis], b.b[axis]) - Math.max(a.a[axis], b.a[axis]) < 1e-6, 'shared wall is a single atomic segment');
    }
  }
});

test('stairs reach the next floor, have linked openings and leave every doorway approach clear', () => {
  for (const t of N.entries) {
    const p = plan(t.id), stairs = p.objects.filter(o => o.kind === 'stairs');
    assert.equal(stairs.length, p.floors.length - 1);
    for (const s of stairs) {
      const status = E.stairStatus(p, s), h = (p.slabOpenings || []).find(h => h.sourceStair === s.id);
      assert.ok(status.reaches && status.riser <= .175 + 1e-6);
      assert.ok(h && h.floor === status.above.id && h.guard);
      assert.ok(E.polygonArea(E.openingGeometry(p, h)) > 3);
      const bounds = rect(E.objectFootprint(s));
      for (const o of p.openings.filter(o => o.kind !== 'window')) {
        const w = p.walls.find(w => w.id === o.wall);
        if (![s.floor, h.floor].includes(w.floor)) continue;
        const horizontal = Math.abs(w.a.y - w.b.y) < .001;
        const area = horizontal ? { x: w.a.x + o.offset - .08, y: w.a.y - .85, w: o.width + .16, d: 1.7 } : { x: w.a.x - .85, y: w.a.y + o.offset - .08, w: 1.7, d: o.width + .16 };
        assert.ok(!overlaps(bounds, area), `${t.id}: stairs/void do not obstruct a doorway`);
      }
    }
  }
});

test('editable furniture fits inside wall faces, leaves doorway approaches and does not overlap', () => {
  const structural = new Set(['stairs', 'deck', 'column']);
  for (const t of N.entries) {
    const p = plan(t.id), rooms = allRooms(p), furniture = p.objects.filter(o => !structural.has(o.kind));
    for (const o of furniture) {
      const points = E.objectFootprint(o), r = rooms.find(r => r.floor === o.floor && points.every(pt => E.containsGeometry(r.netGeometry, pt)));
      assert.ok(r, `${t.id}: ${o.name} fits inside one net room`);
      for (const other of furniture) if (other !== o && other.floor === o.floor) assert.ok(!overlaps(rect(points), rect(E.objectFootprint(other))), `${t.id}: ${o.name} / ${other.name} do not overlap`);
      for (const opening of p.openings.filter(v => v.kind !== 'window')) {
        const w = p.walls.find(w => w.id === opening.wall);
        if (w.floor !== o.floor) continue;
        const horizontal = Math.abs(w.a.y - w.b.y) < .001;
        const approach = horizontal ? { x: w.a.x + opening.offset - .08, y: w.a.y - .85, w: opening.width + .16, d: 1.7 } : { x: w.a.x - .85, y: w.a.y + opening.offset - .08, w: 1.7, d: opening.width + .16 };
        assert.ok(!overlaps(rect(points), approach), `${t.id}: ${o.name} leaves door approach clear`);
      }
      if (C.isCabinet(o)) { assert.equal(o.material, 'white'); assert.equal(o.cabinet.style, 'shaker'); assert.equal(o.cabinet.topMaterial, 'quartz'); }
    }
    for (const r of rooms.filter(r => r.roomType === 'bedroom')) assert.ok(furniture.some(o => o.floor === r.floor && o.kind === 'bed' && E.pointIn({ x: o.x, y: o.y }, r.points)));
    for (const r of rooms.filter(r => r.roomType === 'kitchen')) for (const kind of ['sink', 'stove', 'fridge', 'baseCabinet']) assert.ok(furniture.some(o => o.floor === r.floor && o.kind === kind && E.pointIn({ x: o.x, y: o.y }, r.points)), `${t.id}: ${kind}`);
  }
});

test('furnished rooms retain connected walking routes between doors and stair landings', () => {
  // Independent sampled occupancy check. This verifies circulation, not accessibility/code compliance.
  const step = .12, radius = .3, failures = [];
  for (const t of N.entries) {
    const p = plan(t.id);
    for (const f of p.floors) for (const r of E.detectRooms(p, f.id)) {
      const b = rect(r.points), rows = Math.ceil(b.d / step), cols = Math.ceil(b.w / step);
      const blocks = p.objects.filter(o => o.floor === f.id && !['deck', 'column'].includes(o.kind)).map(o => rect(E.objectFootprint(o)));
      const free = q => Array.from({ length: 8 }, (_, i) => ({ x: q.x + Math.cos(i * Math.PI / 4) * radius, y: q.y + Math.sin(i * Math.PI / 4) * radius })).every(v => E.containsGeometry(r.netGeometry, v)) && !blocks.some(v => q.x > v.x - radius && q.x < v.x + v.w + radius && q.y > v.y - radius && q.y < v.y + v.d + radius);
      const points = [], valid = new Set();
      for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) {
        const q = { x: b.x + (i + .5) * step, y: b.y + (j + .5) * step }, key = j * cols + i;
        points[key] = q; if (free(q)) valid.add(key);
      }
      const targets = [];
      for (const o of p.openings.filter(o => o.kind !== 'window' && r.wallIds.includes(o.wall))) {
        const w = p.walls.find(w => w.id === o.wall), len = E.dist(w.a, w.b), mid = E.lerp(w.a, w.b, (o.offset + o.width / 2) / len);
        const nx = -(w.b.y - w.a.y) / len, ny = (w.b.x - w.a.x) / len;
        for (const sign of [-1, 1]) {
          const q = { x: mid.x + nx * .52 * sign, y: mid.y + ny * .52 * sign };
          if (E.pointIn(q, r.points)) targets.push(q);
        }
      }
      for (const s of p.objects.filter(o => o.kind === 'stairs')) {
        const above = E.stairStatus(p, s).above, source = f.id === s.floor, destination = f.id === above.id;
        if (!source && !destination) continue;
        const q = { x: s.x + s.w * (source ? .25 : .75), y: s.y - .52 };
        if (E.pointIn(q, r.points)) targets.push(q);
      }
      const groups = new Map(); let group = 0;
      for (const start of valid) {
        if (groups.has(start)) continue;
        const queue = [start]; groups.set(start, group);
        for (let n = 0; n < queue.length; n++) {
          const k = queue[n];
          for (const v of [k - 1, k + 1, k - cols, k + cols]) if (valid.has(v) && !groups.has(v) && Math.abs(v % cols - k % cols) <= 1) { groups.set(v, group); queue.push(v); }
        }
        group++;
      }
      const targetGroups = targets.map(q => {
        const near = [...valid].filter(i => E.dist(q, points[i]) < .23).sort((a, b) => E.dist(q, points[a]) - E.dist(q, points[b]));
        return near.length ? groups.get(near[0]) : null;
      });
      if (targetGroups.includes(null)) failures.push(`${t.id}: ${r.name} blocked approach`);
      if (new Set(targetGroups).size > 1) failures.push(`${t.id}: ${r.name} disconnected route`);
    }
  }
  assert.deepEqual(failures, [], 'every door and stair landing retains a connected walking route');
});

test('imperial USD defaults use independent illustrative rates and preserve original project data', () => {
  for (const t of N.entries) {
    const p = plan(t.id);
    assert.equal(p.unit, 'ft'); assert.equal(p.currency, 'USD');
    assert.ok(Math.abs(p.rates.floor / SQFT - 12) < 1e-9);
    assert.ok(Math.abs(p.rates.wall / SQFT - 3.5) < 1e-9);
    assert.ok(Math.abs(p.rates.window / SQFT - 48) < 1e-9);
    assert.ok(Math.abs(p.rates.concrete * .764554857984 - 175) < 1e-9);
    assert.ok(Math.abs(p.rates.cabinet * FT - 220) < 1e-9);
    assert.equal(p.rates.door, 350);
    assert.equal(p.site.landscape, true);
    assert.ok(p.site.driveway.w > 0 && p.site.driveway.d > 0);
    assert.match(p.site.note, /presentation only/);
    const garage = allRooms(p).find(r => r.roomType === 'garage'), bounds = rect(garage.points);
    assert.ok(Math.abs(p.site.driveway.y - (bounds.y + bounds.d)) < .001, 'driveway starts at front of garage (+Y)');
    assert.match(p.template.note, /not established/);
    assert.equal(new Set(ids(p)).size, ids(p).length);
  }
  const a = N.defaultProject(), b = N.defaultProject(), aIds = new Set(ids(a));
  assert.ok(ids(b).every(id => !aIds.has(id)));
  assert.equal(a.template.id, 'NA-RANCH-01');
  a.walls[0].a.x = 900;
  assert.notEqual(b.walls[0].a.x, 900);
  assert.throws(() => N.build('missing'));
  for (const id of ['NA-RANCH', 'NA-COLONIAL', 'NA-CRAFTSMAN', 'NA-FARMHOUSE', 'NA-CONTEMPORARY']) assert.equal(N.build(id).template.id, id + '-01');
});

test('gallery filters 100 homes and paginates exactly 20 editable plans per page', () => {
  const gallery = N.gallery();
  const cardIds = html => [...html.matchAll(/data-load-north-america="([^"]+)"/g)].map(m => m[1]);
  const interleave = entries => entries.slice().sort((a, b) => Number(a.id.slice(-2)) - Number(b.id.slice(-2)) || N.entries.indexOf(a) - N.entries.indexOf(b));
  const order = interleave(N.entries);
  assert.equal(cardIds(gallery).length, 20);
  assert.match(gallery, /inside wall faces/);
  assert.match(gallery, /basements/);
  assert.match(gallery, /USD/);
  assert.ok(!gallery.includes('NaN') && !gallery.includes('undefined'));
  for (const id of ['naStyle', 'naBedrooms', 'naFloors', 'naArea', 'naSearch', 'naPage']) assert.ok(gallery.includes('id="' + id + '"'));
  assert.match(gallery, /data-na-page="2"/);
  const pages = [1, 2, 3, 4, 5].flatMap(page => cardIds(N.gallery({ page })));
  assert.equal(pages.length, 100); assert.equal(new Set(pages).size, 100);
  assert.deepEqual(pages, order.map(t => t.id));
  assert.equal(new Set(order.slice(0, 5).map(t => t.style)).size, 5, 'the first five cards show all five architectural styles');
  const cases = [
    [{ style: 'colonial' }, t => t.styleId === 'colonial'],
    [{ bedrooms: '4', floors: '1' }, t => t.bedrooms === 4 && t.floors === 1],
    [{ area: '1500-1800' }, t => t.areaSqFt >= 1500 && t.areaSqFt < 1800],
    [{ area: '1800-2100', style: 'ranch' }, t => t.areaSqFt >= 1800 && t.areaSqFt < 2100 && t.styleId === 'ranch'],
    [{ area: '2100-2500', bedrooms: 2 }, t => t.areaSqFt >= 2100 && t.areaSqFt <= 2500 && t.bedrooms === 2],
    [{ search: 'Walk-in Closet' }, t => [t.id, t.name, t.summary].join(' ').toLowerCase().includes('walk-in closet')]
  ];
  for (const [options, predicate] of cases) {
    const expected = N.entries.filter(predicate);
    assert.deepEqual(cardIds(N.gallery(options)), (options.style ? expected : interleave(expected)).slice(0, 20).map(t => t.id));
  }
  assert.equal(cardIds(N.gallery({ search: '<script>alert(1)</script>' })).length, 0);
  assert.ok(!N.gallery({ search: '<script>alert(1)</script>' }).includes('<script>'));
  assert.deepEqual(cardIds(N.gallery({ page: 999 })), order.slice(80).map(t => t.id));
  assert.deepEqual(cardIds(N.gallery({ page: -1 })), order.slice(0, 20).map(t => t.id));
  for (const t of N.entries) {
    const svg = N.preview(t);
    assert.match(svg, /<svg/); assert.match(svg, /Front Porch/); assert.match(svg, /Garage/); assert.match(svg, /Deck/);
    assert.equal(svg, N.preview(t.id));
  }
  const previousLocale = globalThis.NexoraI18n;
  try {
    globalThis.NexoraI18n = { language: 'zh' };
    const zh = N.gallery({ style: 'colonial' });
    assert.match(zh, /建筑风格/); assert.match(zh, /墙体内表面/); assert.match(zh, /保留已有项目/); assert.match(zh, /尚未取得专业人员/); assert.match(zh, /Colonial/); assert.match(N.preview('NA-RANCH'), /Primary/);
    globalThis.NexoraI18n = { language: 'es' };
    const es = N.gallery({ style: 'colonial' });
    assert.match(es, /Superficie habitable neta/); assert.match(es, /caras interiores de los muros/); assert.match(es, /se conservan los proyectos existentes/); assert.match(es, /No se ha obtenido revisión/); assert.match(es, /Colonial/);
    globalThis.NexoraI18n = { language: 'unsupported' };
    assert.match(N.gallery(), /inside wall faces/);
  } finally {
    if (previousLocale === undefined) delete globalThis.NexoraI18n; else globalThis.NexoraI18n = previousLocale;
  }
});
