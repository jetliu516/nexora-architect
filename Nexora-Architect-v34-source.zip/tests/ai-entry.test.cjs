const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const dist=path.join(__dirname,'../dist');
const read=name=>fs.readFileSync(path.join(dist,name),'utf8');
const ui=read('residential-ui.js'),index=read('index.html'),workbench=read('workbench.js');

// Execute the actual UI initializer and delegated editor click handler. This
// small DOM fixture models the header and sibling toolbars, not layout pixels.
class Element{
 constructor(tag){this.tagName=tag.toLowerCase();this.attributes={};this.children=[];this.parentElement=null;this._text='';this.value='';this.style={};}
 setAttribute(k,v){this.attributes[k]=String(v);}
 getAttribute(k){return this.attributes[k]??null;}
 hasAttribute(k){return Object.hasOwn(this.attributes,k);}
 get id(){return this.getAttribute('id')||'';}set id(v){this.setAttribute('id',v);}
 get className(){return this.getAttribute('class')||'';}set className(v){this.setAttribute('class',v);}
 get type(){return this.getAttribute('type')||'';}set type(v){this.setAttribute('type',v);}
 get hidden(){return this.hasAttribute('hidden');}set hidden(v){if(v)this.setAttribute('hidden','');else delete this.attributes.hidden;}
 get dataset(){return Object.fromEntries(Object.entries(this.attributes).filter(([k])=>k.startsWith('data-')).map(([k,v])=>[k.slice(5).replace(/-([a-z])/g,(_,c)=>c.toUpperCase()),v]));}
 get classList(){const self=this;return{contains:k=>self.className.split(/\s+/).includes(k),toggle(k,on){const s=new Set(self.className.split(/\s+/).filter(Boolean));if(on===undefined)on=!s.has(k);on?s.add(k):s.delete(k);self.className=[...s].join(' ');return on;}};}
 append(...nodes){for(const n of nodes){n.parentElement=this;this.children.push(n);}}
 prepend(...nodes){for(const n of nodes)n.parentElement=this;this.children.unshift(...nodes);}
 after(n){const siblings=this.parentElement.children;n.parentElement=this.parentElement;siblings.splice(siblings.indexOf(this)+1,0,n);}
 get textContent(){return this._text+this.children.map(c=>c.textContent).join('');}
 set innerHTML(html){this.children=[];const stack=[this];let cursor=0;for(const m of html.matchAll(/<\/?[a-z][^>]*>/gi)){
  stack.at(-1)._text+=html.slice(cursor,m.index);cursor=m.index+m[0].length;
  if(m[0].startsWith('</')){stack.pop();continue;}
  const tag=m[0].match(/^<([\w-]+)/)[1],el=new Element(tag);
  for(const a of m[0].slice(tag.length+1,-1).matchAll(/([\w-]+)(?:="([^"]*)"|='([^']*)'|=([^\s>]+))?/g))el.setAttribute(a[1],a[2]??a[3]??a[4]??'');
  stack.at(-1).append(el);if(!['input','img','br','hr','meta','link'].includes(tag))stack.push(el);
 }stack.at(-1)._text+=html.slice(cursor);}
 closest(selector){for(let el=this;el;el=el.parentElement)if(selector.split(',').some(s=>matches(el,s)))return el;return null;}
}
function descendants(el){return[el,...el.children.flatMap(descendants)];}
function simple(el,selector){
 if(!el||selector.includes(':'))return false;
 const tag=selector.match(/^[a-z][\w-]*/i)?.[0];if(tag&&el.tagName!==tag)return false;
 for(const id of selector.matchAll(/#([\w-]+)/g))if(el.id!==id[1])return false;
 for(const cls of selector.matchAll(/\.([\w-]+)/g))if(!el.classList.contains(cls[1]))return false;
 for(const a of selector.matchAll(/\[([\w-]+)(?:=['"]?([^\]'"]+)['"]?)?\]/g))if(!el.hasAttribute(a[1])||(a[2]!==undefined&&el.getAttribute(a[1])!==a[2]))return false;
 return true;
}
function matches(el,selector){
 const parts=selector.trim().replace(/>/g,' > ').split(/\s+/);
 function visit(node,i){if(!simple(node,parts[i]))return false;if(i===0)return true;
  if(parts[i-1]==='>')return visit(node.parentElement,i-2);
  for(let p=node.parentElement;p;p=p.parentElement)if(visit(p,i-1))return true;
  return false;
 }
 return visit(el,parts.length-1);
}
function fixture(mode='starter',panelOpen=false){
 const body=new Element('body');body.className='cad-workspace';
 body.innerHTML=index.match(/<header>[\s\S]*?<\/header>/)[0]+index.match(/<nav class="project-actions"[\s\S]*?<\/nav>/)[0]+index.match(/<nav class="menu"[\s\S]*?<\/nav>/)[0]+'<div id="viewport"></div><aside id="aiPanel"></aside><dialog id="dialog"></dialog>';
 const listeners={},get=id=>descendants(body).find(el=>el.id===id),query=selector=>descendants(body).find(el=>matches(el,selector));
 get('aiPanel').hidden=!panelOpen;
 const document={body,activeElement:null,getElementById:get,querySelector:query,createElement:tag=>new Element(tag),addEventListener(type,fn){(listeners[type]??=[]).push(fn);}};
 const writes=[],project={id:'retained-project',walls:[],openings:[],objects:[]},state={mode:'plan'};
 let resize=0,opened=0;
 const c={document,MutationObserver:class{observe(){}},localStorage:{getItem:()=>mode,setItem:(k,v)=>writes.push([k,v])},Drawings:{esc:String},addEventListener(){},
  fetch(){throw Error('Entry discovery must not call an AI service');},ArchitectAI:{open(){opened++;get('aiPanel').hidden=false;}}};
 c.window=c;vm.createContext(c);vm.runInContext(ui,c);
 c.ResidentialUI.init({state:()=>({p:project,s:state}),resize(){resize++;},toast(){},dialog(){},tool(){},view(){}});
 // Match the language adapter's actual prepend order after ResidentialUI.init.
 const language=new Element('select');language.id='languageSelect';query('.header-end').prepend(language);
 const begin=workbench.indexOf('function action('),end=workbench.indexOf('\ndocument.addEventListener(',begin+1);
 c.endDrag=()=>true;c.selection=()=>null;
 vm.runInContext(workbench.slice(begin,end),c);
 const click=workbench.split('\n').find(l=>l.startsWith("document.addEventListener('click',e=>{const b=e.target.closest('button')"));
 assert.ok(click);vm.runInContext(click,c);
 return{body,get,query,writes,project,state,c,resize:()=>resize,opened:()=>opened,click(target){for(const fn of listeners.click||[])fn({target});}};
}

// Parse the shipped CSS files and apply relevant selector specificity/media
// rules. This checks actual cascade visibility and grid constraints; visual
// rendering remains a separate browser smoke check.
function rules(css,min=0,max=Infinity,out=[]){
 css=css.replace(/\/\*[\s\S]*?\*\//g,'');let cursor=0;
 while(cursor<css.length){const start=css.indexOf('{',cursor);if(start<0)break;const head=css.slice(cursor,start).trim();let end=start+1,depth=1,quote='';
  for(;end<css.length&&depth;end++){const char=css[end];if(quote){if(char===quote&&css[end-1]!=='\\')quote='';continue;}if(char==='"'||char==="'")quote=char;else if(char==='{')depth++;else if(char==='}')depth--;}
  const content=css.slice(start+1,end-1);cursor=end;
  if(head.startsWith('@media')){if(/\bprint\b/.test(head))continue;const lo=Number(head.match(/min-width\s*:\s*([\d.]+)px/)?.[1]||0),hi=Number(head.match(/max-width\s*:\s*([\d.]+)px/)?.[1]||Infinity);rules(content,Math.max(min,lo),Math.min(max,hi),out);}
  else if(!head.startsWith('@'))for(const selector of head.split(','))out.push({selector:selector.trim(),min,max,content});
 }
 return out;
}
const shippedRules=rules(['workbench.css','workspace.css','residential.css'].map(read).join('\n'));
function computed(el,width){
 const result={},priorities={};
 shippedRules.forEach((rule,index)=>{if(width<rule.min||width>rule.max||!matches(el,rule.selector))return;
  const specificity=(rule.selector.match(/#[\w-]+/g)||[]).length*100+(rule.selector.match(/\.[\w-]+|\[[^\]]+\]/g)||[]).length*10+(rule.selector.match(/(?:^|\s|>)[a-z][\w-]*/gi)||[]).length;
  for(const pair of rule.content.split(';')){const colon=pair.indexOf(':');if(colon<0)continue;const key=pair.slice(0,colon).trim(),raw=pair.slice(colon+1).trim(),important=raw.includes('!important'),priority=(important?1e9:0)+specificity*1e5+index;
   if(!(key in priorities)||priority>=priorities[key]){priorities[key]=priority;result[key]=raw.replace(/\s*!important\s*$/,'');}}
 });return result;
}

test('AI entry: actual starter and professional initialization keeps the same visible, labelled header button',()=>{
 for(const mode of ['starter','pro']){
  const h=fixture(mode),entry=h.get('aiAssistantEntry'),before=JSON.stringify(h.project);
  assert.ok(entry);assert.equal(entry.tagName,'button');assert.equal(entry.type,'button');assert.equal(entry.parentElement,h.query('.header-end'));
  assert.match(entry.textContent,/AI 助手/);assert.equal(entry.children[0].getAttribute('aria-hidden'),'true');
  assert.equal(entry.dataset.action,'aiAssistant');assert.equal(entry.getAttribute('aria-controls'),'aiPanel');assert.equal(entry.getAttribute('aria-expanded'),'false');
  assert.equal(entry.hasAttribute('disabled'),false);assert.equal(entry.closest('.menu'),null);
  assert.equal(h.query('.local-privacy').textContent.includes('需要登录'),false);
  assert.ok(descendants(h.query('.local-privacy')).some(e=>e.dataset.action==='json'));
  for(const value of ['pro','starter','pro']){h.get('workspaceMode').value=value;h.get('workspaceMode').onchange();assert.equal(h.get('aiAssistantEntry'),entry);}
  assert.equal(JSON.stringify(h.project),before);assert.equal(h.resize(),4);
 }
});

test('AI entry: icon and text clicks use the actual existing editor action without service or authentication changes',()=>{
 const h=fixture(),entry=h.get('aiAssistantEntry');
 h.click(entry.children[0]);assert.equal(h.opened(),1);assert.equal(h.get('aiPanel').hidden,false);
 h.click(entry.children[1]);assert.equal(h.opened(),2);
 const alreadyOpen=fixture('pro',true);assert.equal(alreadyOpen.get('aiAssistantEntry').getAttribute('aria-expanded'),'true');
});

test('AI entry: shipped CSS does not hide the header launcher at desktop, tablet or 390px in either mode',()=>{
 for(const mode of ['starter','pro'])for(const width of [390,650,768,1440]){
  const h=fixture(mode),entry=h.get('aiAssistantEntry');
  for(let el=entry;el;el=el.parentElement){const style=computed(el,width);assert.notEqual(style.display,'none');assert.notEqual(style.visibility,'hidden');assert.equal(el.hidden,false);}
  assert.equal(computed(entry,width).display,'inline-flex');assert.ok(parseFloat(computed(entry,width)['min-height'])>=36);
  assert.equal(computed(entry,width)['white-space'],'nowrap');
  assert.equal(computed(h.query('.menu'),width).display,mode==='starter'?'none':'flex');
 }
});

test('AI entry: actual narrow-screen CSS allocates separate AI, mode, language and help columns',()=>{
 for(const mode of ['starter','pro']){
  const h=fixture(mode),header=h.query('header'),end=h.query('.header-end'),ai=h.get('aiAssistantEntry'),preferences=h.query('.residential-preferences'),language=h.get('languageSelect');
  const headerStyle=computed(header,390),endStyle=computed(end,390);
  assert.equal(headerStyle.display,'grid');assert.equal(endStyle.display,'grid');assert.equal(endStyle['grid-row'],'2');
  assert.equal(computed(h.query('.project-menu'),390)['grid-row'],'3');
  const items=end.children.filter(el=>computed(el,390).display!=='none').sort((a,b)=>Number(computed(a,390).order||0)-Number(computed(b,390).order||0));
  assert.deepEqual(items.slice(0,3),[ai,preferences,language]);assert.equal(items.length,4);assert.equal(items[3].dataset.action,'help');
  const tracks=[...endStyle['grid-template-columns'].matchAll(/minmax\(0,([\d.]+)fr\)|([\d.]+)px/g)].map(m=>({fraction:Number(m[1]||0),fixed:Number(m[2]||0)}));
  assert.equal(tracks.length,items.length);assert.ok(tracks.slice(0,3).every(t=>t.fraction>0));
  const padding=Number(headerStyle.padding.split(/\s+/)[1].replace('px','')),gap=parseFloat(endStyle.gap),available=390-2*padding-gap*(tracks.length-1)-tracks.reduce((s,t)=>s+t.fixed,0),weight=tracks.reduce((s,t)=>s+t.fraction,0);
  let left=padding;const rectangles=tracks.map(t=>{const width=t.fixed||available*t.fraction/weight,box={left,right:left+width,width};left+=width+gap;return box;});
  assert.ok(rectangles[0].width>=125,'AI keeps a full text label at 390px');
  assert.ok(rectangles.every((r,i)=>i===0||r.left>=rectangles[i-1].right+gap-1e-9));assert.ok(rectangles.at(-1).right<=390-padding+1e-9);
  assert.equal(computed(ai,390)['min-width'],'0');assert.equal(computed(preferences,390)['min-width'],'0');
  for(const select of [h.get('workspaceMode'),language]){assert.equal(computed(select,390).width,'100%');assert.equal(computed(select,390)['max-width'],'none');assert.equal(computed(select,390)['min-width'],'0');}
  assert.equal(computed(end.children.find(e=>e.dataset.action==='export'),390).display,'none');
  assert.ok(descendants(h.query('.starter-toolbar')).some(e=>e.dataset.action==='export'),'starter export remains available in its own toolbar');
 }
});
