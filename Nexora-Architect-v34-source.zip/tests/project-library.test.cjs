const test=require('node:test'),assert=require('node:assert/strict');
const L=require('../dist/project-library.js');
const a={id:'a',name:'厨房 A',updatedAt:'2026-11-01',floors:[{id:'f'}],walls:[{id:'w'}],openings:[{id:'o',wall:'w'}],objects:[{id:'s'}]};
const b={...a,id:'b',name:'Bedroom',updatedAt:'2026-11-02'};
const state=()=>({active:'a',projects:structuredClone([a,b]),trash:[]});
test('new project and edits preserve existing project and activate the saved project',()=>{const db=state();const next=L.upsert(db,{...a,id:'c',name:'新项目'});assert.equal(next.projects.length,3);assert.equal(next.active,'c');assert.equal(db.projects.length,2);next.projects[0].walls[0].id='changed';assert.equal(db.projects[0].walls[0].id,'w')});
test('copy is independent and preserves model relationships',()=>{const db=state(),copy=L.duplicate(db,'a','copy');assert.equal(copy.openings[0].wall,copy.walls[0].id);copy.objects[0].id='changed';assert.equal(db.projects[0].objects[0].id,'s');assert.throws(()=>L.duplicate(db,'a','b'));assert.throws(()=>L.duplicate(db,'missing','c'))});
test('renames trim whitespace, reject blank names and do not rename other projects',()=>{const db=state();assert.equal(L.rename(db,'b','  房屋 B  ').projects[1].name,'房屋 B');assert.equal(db.projects[1].name,'Bedroom');assert.throws(()=>L.rename(db,'a',' '));assert.throws(()=>L.rename(db,'a','x'.repeat(101)))});
test('deleting active project switches active id, preserves full project in trash and can restore after reload',()=>{const db=state(),deleted=L.remove(db,'a',()=>{throw Error('unneeded')});assert.equal(deleted.active,'b');assert.deepEqual(deleted.trash[0].project,a);assert.equal(db.projects.length,2);const restored=L.restore(JSON.parse(JSON.stringify(deleted)),'a');assert.equal(restored.projects.length,2);assert.deepEqual(restored.projects[1].openings,a.openings);assert.equal(restored.trash.length,0);assert.equal(restored.active,'b')});
test('deleting inactive project preserves active project',()=>{const next=L.remove(state(),'b',()=>{});assert.equal(next.active,'a');assert.deepEqual(next.projects[0],a)});
test('deleting final project retains recoverable original and creates a separate empty workspace',()=>{const next=L.remove({active:'a',projects:[a]},'a',()=>({id:'new',name:'未命名项目',walls:[]}));assert.equal(next.active,'new');assert.equal(next.trash[0].project.id,'a');assert.equal(next.projects[0].walls.length,0);assert.equal(L.restore(next,'a').projects.length,2)});
test('failed storage write leaves original library untouched',()=>{const db=state(),next=L.remove(db,'a',()=>{});let active=db;assert.throws(()=>{active=L.persist({setItem(){throw Error('quota')}},'test',next)});assert.equal(active,db);assert.equal(active.projects.length,2);assert.equal(active.trash.length,0)});
test('search and sort do not mutate saved ordering',()=>{const db=state();assert.equal(L.list(db,'BED')[0].id,'b');assert.deepEqual(L.list(db,'','recent').map(p=>p.id),['b','a']);assert.deepEqual(db.projects.map(p=>p.id),['a','b']);assert.equal(L.list(db,'missing').length,0)});
test('restore refuses collision and never overwrites a surviving project',()=>{const db=state();db.trash=[{project:a,deletedAt:'today'}];assert.throws(()=>L.restore(db,'a'));assert.throws(()=>L.restore(db,'missing'));assert.equal(db.trash.length,1)});

const E=require('../dist/engine.js');
const options={validate:E.validate,createEmpty:()=>E.newProject('恢复工作区'),createDemo:E.demo};
const valid=()=>{const p=E.newProject('Surviving project');E.addRectangle(p,0,0,5,4,p.floors[0].id);return p;};
test('startup editing model never aliases the saved library before its first transaction',()=>{
 const vm=require('node:vm'),fs=require('node:fs'),source=fs.readFileSync('dist/workbench.js','utf8'),good=valid(),raw=JSON.stringify({active:good.id,projects:[good]});
 const context={BIM:E,Drawings:{esc:String},Cabinets:{},CabinetDrawings:{},ProjectLibrary:L,WorkspaceModel:{},document:{getElementById:()=>({})},localStorage:{getItem:k=>k==='nexora-bim-projects-v2'?raw:null,length:0}};
 const result=vm.runInNewContext(source.slice(0,source.indexOf('\nconst s='))+'p.walls[0].thickness=-1;return db.projects[0].walls[0].thickness;})()',context);
 assert.equal(result,good.walls[0].thickness);
});
test('load isolates a malformed project without losing valid model geometry or original data',()=>{
 const good=valid(),bad=valid();bad.name='Broken';bad.walls[0].thickness=-1;
 const raw=JSON.stringify({active:bad.id,projects:[good,bad],trash:[]}),db=L.load(raw,options);
 assert.equal(db.projects.length,1);assert.equal(db.active,good.id);assert.deepEqual(db.projects[0].walls,good.walls);
 assert.equal(db.recovery.length,1);assert.deepEqual(JSON.parse(db.recovery[0].raw),bad);
 const reload=L.load(JSON.stringify(db),options);assert.deepEqual(reload.recovery,db.recovery);assert.equal(reload.active,good.id);
});
test('malformed root JSON is preserved byte for byte across saving and reloading a recovery workspace',()=>{
 const raw=' {"projects": [ { "name":"recover me" ';let storage=raw;
 const db=L.load(raw,options);assert.equal(db.projects[0].walls.length,0);assert.equal(db.recovery[0].raw,raw);
 L.persist({setItem(_key,value){storage=value}},'test',db);
 assert.equal(L.load(storage,options).recovery[0].raw,raw);
});
test('all invalid projects and wrong root schemas preserve originals without replacing them by a demo',()=>{
 for(const value of [null,[],{projects:'bad'},{projects:[null,{id:'invalid'}]}]){
  const db=L.load(JSON.stringify(value),options);assert.equal(db.projects[0].name,'恢复工作区');assert.equal(db.projects[0].walls.length,0);assert.ok(db.recovery.length);
 }
 assert.ok(L.load(null,options).projects[0].walls.length>0);
});
test('duplicate ids are isolated and cannot overwrite an existing model during subsequent editing',()=>{
 const first=valid(),second=E.clone(first);second.name='Duplicate';const db=L.load(JSON.stringify({active:first.id,projects:[first,second]}),options);
 assert.equal(db.projects.length,1);assert.deepEqual(JSON.parse(db.recovery[0].raw),second);
 assert.throws(()=>L.retryRecovery(db,db.recovery[0].id,E.validate),/重复/);assert.equal(db.projects[0].name,first.name);
});
test('invalid trash and malformed recovery records are preserved while normal trash remains restorable',()=>{
 const good=valid(),deleted=valid();deleted.name='Deleted';const bad={project:{id:'bad'},deletedAt:'yesterday'};
 const db=L.load(JSON.stringify({active:good.id,projects:[good],trash:[{project:deleted,deletedAt:'today'},bad],recovery:{unexpected:'keep this'}}),options);
 assert.equal(db.trash.length,1);assert.equal(db.recovery.length,2);assert.ok(db.recovery.some(e=>e.raw===JSON.stringify(bad)));
 assert.equal(L.restore(db,deleted.id).projects.length,2);
});
test('successful retry returns an independent transaction; failed retry preserves raw recovery data',()=>{
 const good=valid(),candidate=valid();candidate.name='Old version';candidate.walls[0].height=30;
 const db=L.load(JSON.stringify({active:good.id,projects:[good,candidate]}),options),entry=db.recovery[0];
 assert.throws(()=>L.retryRecovery(db,entry.id,E.validate));assert.equal(db.recovery[0].raw,JSON.stringify(candidate));
 const repaired=L.retryRecovery(db,entry.id,raw=>{raw.walls[0].height=2.8;return E.validate(raw)});
 assert.equal(repaired.projects.length,2);assert.equal(repaired.recovery.length,0);assert.equal(db.projects.length,1);assert.equal(db.recovery.length,1);
});
test('storage quota failure while saving recovery leaves the original storage bytes untouched',()=>{
 const raw=JSON.stringify({projects:[valid(),null]}),db=L.load(raw,options);let saved=raw;
 assert.throws(()=>L.persist({setItem(){throw Error('quota')}},'test',db));assert.equal(saved,raw);assert.equal(db.recovery[0].raw,'null');
});
test('library backup merge keeps current edits, remaps only project ids, and preserves recovery payloads',()=>{
 const good=valid(),deleted=valid();const db=L.load(JSON.stringify({active:good.id,projects:[good],trash:[{project:deleted,deletedAt:'today'},null]}),options);
 const backup=L.load(JSON.stringify({...db,format:'nexora-library-v1'}),options);let n=0;
 const next=L.merge(db,backup,()=>`import-${++n}`);
 assert.equal(next.active,good.id);assert.equal(next.projects.length,2);assert.equal(next.trash.length,2);assert.equal(next.recovery.length,2);
 assert.equal(new Set([...next.projects.map(p=>p.id),...next.trash.map(e=>e.project.id)]).size,4);
 assert.deepEqual(next.projects[1].walls,db.projects[0].walls);assert.equal(next.recovery[1].raw,db.recovery[0].raw);
 assert.notEqual(next.recovery[0].id,next.recovery[1].id);assert.equal(db.projects.length,1);
 const reloaded=L.load(JSON.stringify(next),options);assert.equal(reloaded.recovery.length,2);assert.equal(reloaded.projects.length,2);
});
test('backup merge rejects a broken id generator without changing either library',()=>{
 const good=valid(),db=L.load(JSON.stringify({projects:[good]}),options),before=JSON.stringify(db);
 assert.throws(()=>L.merge(db,db,()=>good.id));assert.equal(JSON.stringify(db),before);
});
test('actual workbench startup and persistence refuse all writes after a storage read error',()=>{
 const vm=require('node:vm'),fs=require('node:fs'),source=fs.readFileSync('dist/workbench.js','utf8');let writes=0;
 const prefix=source.slice(0,source.indexOf('\nconst s='));
 const persistence=source.slice(source.indexOf('function commitLibrary('),source.indexOf('\nfunction save()'));
 const el={textContent:''},context={NorthAmerica:{defaultProject:E.demo},BIM:E,Drawings:{esc:String},Cabinets:{},CabinetDrawings:{},ProjectLibrary:L,WorkspaceModel:{},document:{getElementById:()=>el},localStorage:{getItem(){throw Error('denied')},setItem(){writes++}},toast(){}};
 const result=vm.runInNewContext(prefix+persistence+'return {blocked:storageBlocked,saved:commitLibrary(db)};})()',context);
 assert.equal(result.blocked,true);assert.equal(result.saved,false);assert.equal(writes,0);assert.match(el.textContent,/停止写入/);
});

// Hooks run at storage-operation boundaries, allowing an independent editor to
// complete a real session.write between another editor's check and final write.
function memoryStorage(initial={}){
 const data=new Map(Object.entries(initial)),calls=[];
 const storage={data,calls,beforeSet:null,fail:null,get length(){return data.size},key:i=>[...data.keys()][i]??null,
  getItem(key){calls.push(['get',key]);return data.get(key)??null;},
  setItem(key,value){calls.push(['set',key]);storage.beforeSet?.(key,value);if(storage.fail?.(key,value))throw Object.assign(Error('quota'),{name:'QuotaExceededError'});data.set(key,String(value));},
  removeItem(key){calls.push(['remove',key]);data.delete(key);}};
 return storage;
}
const storageKey='test-library';
const checkpointKeys=storage=>[...storage.data.keys()].filter(k=>k.startsWith(storageKey+':checkpoint:'));
const realLibrary=()=>{const first=valid(),second=valid();second.name='Second project';return{active:first.id,projects:[first,second],trash:[],recovery:[]};};
function libraryVersions(raw){
 const result=[],seen=new Set(),visit=value=>{if(typeof value==='string'){if(seen.has(value))return;seen.add(value);try{value=JSON.parse(value)}catch{return;}}
  if(!value||!Array.isArray(value.projects))return;result.push(value);for(const r of value.recovery||[])if(r.source==='library')visit(r.raw);};
 visit(raw);return result;
}
function interleavedLibraries(){
 const base=realLibrary(),storage=memoryStorage({[storageKey]:JSON.stringify(base)}),a=L.session(storage,storageKey),b=L.session(storage,storageKey);
 const snapshotA=L.load(a.read(),options),snapshotB=L.load(b.read(),options);
 const winner=L.rename(snapshotA,base.projects[0].id,'A winner');winner.projects[0].walls[0].height=3.75;
 const created=valid();created.name='B new house';let branch=L.upsert(snapshotB,created);branch=L.remove(branch,base.projects[1].id,()=>{throw Error('unexpected empty library')});
 let savedBranch;storage.beforeSet=k=>{if(k===storageKey){storage.beforeSet=null;savedBranch=b.write(branch);}};
 const savedWinner=a.write(winner);
 return {base,storage,a,b,savedWinner,savedBranch,created};
}

test('stale tabs cannot save, add or delete over another editor’s committed geometry',()=>{
 for(const operation of ['save','add','delete']){
  const base=realLibrary(),storage=memoryStorage({[storageKey]:JSON.stringify(base)}),first=L.session(storage,storageKey),stale=L.session(storage,storageKey);
  let live=L.load(first.read(),options),old=L.load(stale.read(),options);const originalOld=JSON.stringify(old);
  live=L.rename(live,live.active,'Current revision');live.projects[0].walls[0].height=4.25;first.write(live);
  let candidate;if(operation==='save'){candidate=L.rename(old,old.active,'Stale edit');candidate.projects[0].walls[0].height=2.25;}
  if(operation==='add')candidate=L.upsert(old,valid());
  if(operation==='delete')candidate=L.remove(old,old.active,()=>valid());
  const before=[...storage.data];assert.throws(()=>stale.write(candidate),e=>e.code==='LIBRARY_CONFLICT');
  assert.deepEqual([...storage.data],before);assert.equal(JSON.stringify(old),originalOld);
  const reopened=L.load(L.session(storage,storageKey).read(),options);assert.equal(reopened.projects[0].name,'Current revision');assert.equal(reopened.projects[0].walls[0].height,4.25);assert.equal(reopened.recovery.length,0);
 }
});

test('a competing write between preflight and checkpoint completion rejects the stale writer without losing either saved library',()=>{
 const base=realLibrary(),storage=memoryStorage({[storageKey]:JSON.stringify(base)}),a=L.session(storage,storageKey),b=L.session(storage,storageKey);
 a.read();b.read();const latest=L.rename(base,base.active,'Winner during checkpoint'),stale=L.rename(base,base.active,'Interrupted stale edit');
 storage.beforeSet=k=>{if(k!==storageKey){storage.beforeSet=null;b.write(latest);}};
 assert.throws(()=>a.write(stale),e=>e.code==='LIBRARY_CONFLICT');
 assert.equal(JSON.parse(storage.getItem(storageKey)).projects[0].name,'Winner during checkpoint');assert.equal(checkpointKeys(storage).length,1);
 const restored=L.load(L.session(storage,storageKey).read(),options);assert.equal(restored.recovery.length,0);assert.equal(restored.projects[0].name,latest.projects[0].name);
});

test('two successful writes in the final race window retain the complete losing branch for recovery',()=>{
 const h=interleavedLibraries(),read=L.session(h.storage,storageKey),raw=read.read(),loaded=L.load(raw,options);
 assert.deepEqual(loaded.projects,h.savedWinner.projects);assert.equal(loaded.recovery.length,1);assert.equal(checkpointKeys(h.storage).length,2);
 const branch=JSON.parse(loaded.recovery[0].raw);assert.equal(branch.format,'nexora-library-v1');assert.deepEqual(branch.projects,h.savedBranch.projects);assert.deepEqual(branch.trash,h.savedBranch.trash);
 assert.equal(branch.projects.find(p=>p.id===h.created.id).name,'B new house');assert.equal(branch.trash[0].project.id,h.base.projects[1].id);
 assert.equal(read.read(),raw,'repeated reads must not duplicate a recovered branch');
});

test('the exported original recovery library imports as independent projects and keeps current edits and deleted geometry',()=>{
 const h=interleavedLibraries(),reader=L.session(h.storage,storageKey),loaded=L.load(reader.read(),options);
 const exported=loaded.recovery[0].raw,incoming=L.load(exported,options);let serial=0;
 const imported=L.merge(loaded,incoming,()=>`restored-${++serial}`),current=imported.projects.find(p=>p.id===h.savedWinner.projects[0].id);
 assert.deepEqual(current,h.savedWinner.projects[0]);assert.equal(imported.projects.length,loaded.projects.length+incoming.projects.length);assert.equal(imported.trash.length,incoming.trash.length);
 const branchCopy=imported.projects.find(p=>p.id.startsWith('restored-'));assert.ok(branchCopy);assert.deepEqual(branchCopy.walls,incoming.projects[0].walls);assert.deepEqual(branchCopy.openings,incoming.projects[0].openings);
 assert.notEqual(branchCopy.id,current.id);assert.deepEqual(imported.trash[0].project.walls,incoming.trash[0].project.walls);assert.equal(imported.recovery[0].raw,exported);
 reader.write(imported);assert.equal(checkpointKeys(h.storage).length,1);
 const reloaded=L.load(L.session(h.storage,storageKey).read(),options);assert.deepEqual(reloaded.projects,imported.projects);assert.deepEqual(reloaded.trash,imported.trash);assert.equal(reloaded.recovery[0].raw,exported);assert.equal(reloaded.recovery.length,1);
});

test('quota failure while acknowledging one’s own orphaned save never destroys that already committed branch',()=>{
 const h=interleavedLibraries(),recovered=L.load(h.b.read(),options);assert.equal(recovered.recovery.length,1);
 const mainBefore=h.storage.getItem(storageKey);h.storage.fail=k=>k===storageKey;
 assert.throws(()=>h.b.write(recovered),/quota/);assert.equal(h.storage.getItem(storageKey),mainBefore);h.storage.fail=null;
 const versions=libraryVersions(L.session(h.storage,storageKey).read());
 assert.ok(versions.some(v=>JSON.stringify(v.projects)===JSON.stringify(h.savedBranch.projects)&&JSON.stringify(v.trash)===JSON.stringify(h.savedBranch.trash)),'the successful B branch must remain recoverable after a later main-write failure');
 h.b.write(recovered);const reopened=L.load(L.session(h.storage,storageKey).read(),options);assert.equal(reopened.recovery.length,1);assert.deepEqual(JSON.parse(reopened.recovery[0].raw).projects,h.savedBranch.projects);assert.equal(checkpointKeys(h.storage).length,1);
});

test('checkpoint and main-key quota failures preserve original bytes and allow an explicit retry',()=>{
 for(const phase of ['checkpoint','main']){
  const initial=realLibrary(),raw=JSON.stringify(initial),storage=memoryStorage({[storageKey]:raw}),editor=L.session(storage,storageKey);editor.read();
  const next=L.remove(initial,initial.active,()=>{throw Error('unexpected fallback')});storage.fail=k=>phase==='main'?k===storageKey:k!==storageKey;
  assert.throws(()=>editor.write(next),/quota/);assert.equal(storage.getItem(storageKey),raw);assert.equal(checkpointKeys(storage).length,0);
  storage.fail=null;editor.write(next);const actual=L.load(L.session(storage,storageKey).read(),options);assert.deepEqual(actual.projects,next.projects);assert.deepEqual(actual.trash,next.trash);assert.equal(actual.recovery.length,0);
 }
});

test('legacy libraries, missing main storage and malformed main bytes retain all available recovery data',()=>{
 for(const main of [null,' {"projects": [ unfinished ',JSON.stringify({wrong:'schema'})]){
  const base=realLibrary(),storage=memoryStorage({[storageKey]:JSON.stringify(base)}),editor=L.session(storage,storageKey);editor.read();editor.write(base);
  if(main===null)storage.removeItem(storageKey);else storage.setItem(storageKey,main);
  const fresh=L.session(storage,storageKey),loaded=L.load(fresh.read(),options),versions=libraryVersions(JSON.stringify(loaded));
  assert.ok(versions.some(v=>JSON.stringify(v.projects)===JSON.stringify(base.projects)),'the complete checkpoint must be accessible immediately');
  if(main!==null)assert.ok(loaded.recovery.some(r=>r.raw===main),'malformed main bytes must also be preserved exactly');
  fresh.write(loaded);const reopened=L.load(L.session(storage,storageKey).read(),options);assert.ok(libraryVersions(JSON.stringify(reopened)).some(v=>JSON.stringify(v.projects)===JSON.stringify(base.projects)));assert.equal(checkpointKeys(storage).length,1);
 }
 const base=realLibrary(),raw=JSON.stringify(base),storage=memoryStorage({[storageKey]:raw}),legacy=L.session(storage,storageKey);assert.equal(legacy.read(),raw);
 const saved=legacy.write(L.load(raw,options));assert.deepEqual(saved.projects,base.projects);assert.equal(saved.recovery.length,0);
});

test('continuous saves and fresh editor sessions keep a bounded checkpoint count without accumulating recovery chains',()=>{
 const base=realLibrary(),storage=memoryStorage({[storageKey]:JSON.stringify(base)});let editor=L.session(storage,storageKey),db=L.load(editor.read(),options);
 for(let i=0;i<150;i++){
  if(i%3===0){editor=L.session(storage,storageKey);db=L.load(editor.read(),options);}
  db=L.rename(db,db.active,`Saved revision ${i}`);db=editor.write(db);
  assert.equal(checkpointKeys(storage).length,1,`checkpoint count after save ${i}`);assert.equal(db.recovery.length,0);assert.ok(db._persistence.ancestors.length<=1);
 }
 const reopened=L.load(L.session(storage,storageKey).read(),options);assert.equal(reopened.projects[0].name,'Saved revision 149');assert.equal(reopened.recovery.length,0);assert.equal(storage.data.size,2);
});

test('unacknowledged race branches survive repeated winner saves and are compacted only after recovery is persisted',()=>{
 const h=interleavedLibraries();let db=h.savedWinner;
 for(let i=0;i<60;i++){db=L.rename(db,db.active,`Winner revision ${i}`);db=h.a.write(db);assert.equal(checkpointKeys(h.storage).length,2);}
 const reader=L.session(h.storage,storageKey),recovered=L.load(reader.read(),options);assert.equal(recovered.recovery.length,1);assert.deepEqual(JSON.parse(recovered.recovery[0].raw).projects,h.savedBranch.projects);
 reader.write(recovered);assert.equal(checkpointKeys(h.storage).length,1);
 const reopened=L.load(L.session(h.storage,storageKey).read(),options);assert.equal(reopened.projects[0].name,'Winner revision 59');assert.equal(reopened.recovery.length,1);assert.deepEqual(JSON.parse(reopened.recovery[0].raw).trash,h.savedBranch.trash);
});

test('repeated real races retain every branch without recursively embedding the already saved recovery history',()=>{
 const base=realLibrary(),storage=memoryStorage({[storageKey]:JSON.stringify(base)}),branches=[];
 for(let i=0;i<8;i++){
  const a=L.session(storage,storageKey),b=L.session(storage,storageKey),pa=L.load(a.read(),options),pb=L.load(b.read(),options);
  pa.projects[0].name=`Main ${i}`;pb.projects[0].name=`Branch ${i}`;pb.projects[0].walls[0].height=3+i/10;branches.push(structuredClone(pb.projects));
  storage.beforeSet=k=>{if(k===storageKey){storage.beforeSet=null;b.write(pb);}};a.write(pa);
  const reader=L.session(storage,storageKey),recovered=L.load(reader.read(),options);reader.write(recovered);
  assert.equal(checkpointKeys(storage).length,1);assert.equal(recovered.recovery.length,i+1);
 }
 const raw=storage.getItem(storageKey),versions=libraryVersions(raw),reopened=L.load(raw,options);
 for(const projects of branches)assert.ok(versions.some(v=>JSON.stringify(v.projects)===JSON.stringify(projects)),`${projects[0].name} must remain recoverable`);
 for(const entry of reopened.recovery){const imported=L.load(entry.raw,options);assert.match(imported.projects[0].name,/^Branch /);assert.equal(imported.projects[0].walls.length,base.projects[0].walls.length);}
 const uniquePayloadBytes=JSON.stringify(base).length+branches.reduce((n,projects)=>n+JSON.stringify({projects,trash:[],recovery:[]}).length,0);
 assert.ok(raw.length<uniquePayloadBytes*4,`8 small branch saves used ${raw.length} bytes for ${uniquePayloadBytes} bytes of distinct library payloads; old recovery history must not be recursively copied`);
});

test('race-history compaction preserves recovery bytes unique to the losing branch',()=>{
 const base=realLibrary(),common={id:'common-recovery',source:'project',reason:'Existing malformed input',createdAt:'2026-11-01',raw:'{"common": "unfinished"'},unique={id:'branch-recovery',source:'project',reason:'Branch-only malformed import',createdAt:'2026-11-02',raw:' {"privateBranch": [ "original bytes" '};base.recovery.push(common);
 const nestedProject=valid(),nestedOriginal={id:'nested-original',source:'project',reason:'Nested original',raw:'[ "deep branch bytes" '},nested={id:'branch-library',source:'library',reason:'Branch-only nested backup',raw:JSON.stringify({format:'nexora-library-v1',active:nestedProject.id,projects:[nestedProject],trash:[],recovery:[nestedOriginal]})};
 const storage=memoryStorage({[storageKey]:JSON.stringify(base)}),a=L.session(storage,storageKey),b=L.session(storage,storageKey),pa=L.load(a.read(),options),pb=L.load(b.read(),options);
 pb.projects[0].name='Branch with its own recovery';pb.recovery.push(unique,nested);
 storage.beforeSet=k=>{if(k===storageKey){storage.beforeSet=null;b.write(pb);}};a.write(pa);
 const reader=L.session(storage,storageKey),recovered=L.load(reader.read(),options),entry=recovered.recovery.find(r=>r.source==='library');assert.ok(entry);
 const exported=L.load(entry.raw,options);assert.ok(exported.recovery.some(r=>r.raw===unique.raw),'exporting this branch must retain its unique malformed input');
 assert.ok(exported.recovery.some(r=>r.raw===nested.raw),'the nested library original must remain byte-for-byte exportable');
 reader.write(recovered);const records=libraryVersions(L.session(storage,storageKey).read()).flatMap(v=>v.recovery||[]);
 assert.ok(records.some(r=>r.raw===common.raw));assert.ok(records.some(r=>r.raw===unique.raw));assert.ok(records.some(r=>r.raw===nestedOriginal.raw));
});
