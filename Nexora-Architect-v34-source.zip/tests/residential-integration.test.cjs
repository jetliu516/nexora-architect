const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const E = require('../dist/geometry.js');
const W = require('../dist/workspace-model.js');
const R = require('../dist/project-region.js');
const U = require('../dist/units.js');
const C = require('../dist/cabinets.js');
const PL = require('../dist/project-library.js');
const NA = require('../dist/north-america.js');
const M = globalThis.MEP;
const root = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'dist/workbench.js'), 'utf8'), lines = source.split('\n');
const close = (a, b, tolerance = 1e-9) => assert.ok(Math.abs(a-b) <= tolerance, `${a} should equal ${b}`);

function memoryStorage(initial = {}, onWrite = () => {}) {
  const data = new Map(Object.entries(initial));
  return {get length() {return data.size;}, key: index => [...data.keys()][index] ?? null,
    getItem: key => data.get(key) ?? null,
    setItem(key, value) {data.set(key, String(value)); onWrite(key, String(value));},
    removeItem: key => {data.delete(key);}};
}

function startup(raw) {
  let stored;
  const key = 'nexora-bim-projects-v2', localStorage = memoryStorage(raw == null ? {} : {[key]: raw},
    (changedKey, value) => {if (changedKey === key) stored = value;});
  const prefix = source.slice(0, source.indexOf('\nconst s='));
  const persistence = source.slice(source.indexOf('function commitLibrary('), source.indexOf('\nfunction save('));
  const c = {BIM: E, Drawings: {esc: String}, Cabinets: C, CabinetDrawings: {}, NorthAmerica: NA,
    ProjectLibrary: PL, WorkspaceModel: W, ProjectRegion: R, document: {getElementById: () => ({})}, toast() {}, localStorage};
  const result = vm.runInNewContext(prefix+persistence+lines.find(l => l.startsWith('function save('))+
    ';save();return {p,db};})()', c);
  return {...result, stored: JSON.parse(stored)};
}

// Actual editor functions and listeners, with rendering and browser-native
// focus machinery stubbed. The independent editor-audit suite covers drag/blur.
function workbench(project = E.demo()) {
  const handlers = {}, elements = new Map, messages = [], exports = [];
  let stored = null;
  const storageKey = 'audit', localStorage = memoryStorage({}, (key, value) => {if (key === storageKey) stored = JSON.parse(value);});
  const storageSession = PL.session(localStorage, storageKey); storageSession.read();
  const element = id => {if (!elements.has(id)) elements.set(id, {id, dataset: {}, style: {}, hidden: false,
    classList: {toggle() {}}, close() {}, append() {}, prepend() {}, after() {}, setAttribute() {}}); return elements.get(id);};
  const p = E.validate(project), s = {...W.defaults(), mode: 'plan', floor: p.floors[0].id, selected: null, schedule: 'materials'};
  const c = {E, BIM: E, WM: W, WorkspaceModel: W, MEP: M, C, Cabinets: C, PL, ProjectLibrary: PL,
    ProjectRegion: R, Units: U, NorthAmerica: NA, Openings: globalThis.Openings, p, s, history: [], future: [], drag: null,
    db: {active: p.id, projects: [E.clone(p)], trash: [], recovery: []}, STORAGE: storageKey, storageBlocked: false, storageSession,
    $: element, document: {activeElement: null, addEventListener: (type, fn) => handlers[type] = fn,
      querySelectorAll: () => []}, localStorage,
    toast: text => messages.push(text), endDrag: () => true,
    esc: value => String(value).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;'),
    display: n => c.p.unit === 'ft' ? n*3.280839895 : n, metric: n => c.p.unit === 'ft' ? n/3.280839895 : n,
    unit: () => c.p.unit === 'ft' ? 'ft' : 'm', floor: () => c.p.floors.find(f => f.id === c.s.floor),
    refresh: () => {c.lastRendered = E.clone(c.p);}, renderInspector() {}, renderPlan() {}, render3d() {}, renderDocument() {},
    model: null, exportFile: (name, text, type) => exports.push({name, text, type})};
  c.window = c; vm.createContext(c);
  const run = code => {assert.ok(code); vm.runInContext(code, c);};
  run(source.slice(source.indexOf('function commitLibrary('), source.indexOf('\nfunction save(')));
  for (const name of ['save', 'transact', 'travelHistory', 'selection', 'field', 'moveNode', 'openingRows', 'csv', 'renderSchedule'])
    run(lines.find(l => l.startsWith('function '+name+'(')));
  run('globalThis.lengthField=lf');
  run(lines.find(l => l.startsWith("document.addEventListener('change',e=>{const el=e.target")));
  run(lines.find(l => l.startsWith("document.addEventListener('click',e=>{const b=e.target.closest('button')")));
  const change = props => handlers.change({target: {dataset: {}, value: '', type: 'text',
    hasAttribute: () => false, checkValidity: () => true, reportValidity() {}, ...props}});
  const click = dataset => handlers.click({target: {closest: () => ({dataset, closest: () => null})}});
  const lengthInput = (key, value, min = .02, max = 100) => {
    const html = c.lengthField('Dimension', key, value, min, max), attrs = Object.fromEntries(
      [...html.matchAll(/([\w-]+)="([^"]*)"/g)].map(m => [m[1], m[2].replace(/&quot;/g, '"').replace(/&amp;/g, '&')]));
    const dataset = Object.fromEntries(Object.entries(attrs).filter(([k]) => k.startsWith('data-')).map(([k, v]) => [k.slice(5), v]));
    return {html, dataset, value: attrs.value, type: attrs.type};
  };
  return {c, handlers, element, messages, exports, change, click, lengthInput, stored: () => stored};
}

test('residential: actual fresh startup selects an English USD/imperial project, while existing projects retain CNY semantics', () => {
  const fresh = startup(null);
  assert.equal(fresh.p.unit, 'ft'); assert.equal(fresh.p.currency, 'USD');
  assert.ok(!/[\u3400-\u9fff]/.test(fresh.p.name)); assert.equal(fresh.stored.active, fresh.p.id);
  for (const unit of ['m', 'ft']) {
    const p = E.demo(); p.unit = unit; p.name = '用户项目'; p.rates.floor = 137.1234567;
    const old = E.clone(p), result = startup(JSON.stringify({active: p.id, projects: [p], trash: [], recovery: []}));
    assert.equal(result.p.id, old.id); assert.equal(result.p.name, old.name); assert.equal(result.p.unit, unit);
    assert.equal(Object.hasOwn(result.p, 'currency'), false); assert.equal(R.currency(result.p), 'CNY');
    assert.deepEqual(result.p.rates, old.rates); assert.deepEqual(result.p.floors, old.floors); assert.deepEqual(result.p.walls, old.walls);
    assert.equal(result.stored.projects[0].unit, unit); assert.equal(Object.hasOwn(result.stored.projects[0], 'currency'), false);
  }
});

test('residential: browser locale survives preference read failure, while saved preferences take priority', () => {
  const setup = fs.readFileSync(path.join(root, 'dist/i18n.js'), 'utf8').split('\n').slice(1, 3).join('\n');
  for (const [saved, language, denied, expected] of [[null, 'en-US', false, 'en'], [null, 'en-US', true, 'en'], ['zh', 'en-US', false, 'zh'], [null, 'es-MX', false, 'es'], [null, 'es-MX', true, 'es'], [null, 'zh-CN', false, 'zh'], [null, 'xx-ZZ', false, 'en']]) {
    const c = {navigator: {language}, localStorage: {getItem() {if (denied) throw Error('denied'); return saved;}}};
    vm.runInNewContext(setup+';result=lang', c); assert.equal(c.result, expected);
  }
});

test('residential: actual imperial length fields accept inches, feet/fractions and explicit metric values with atomic save', () => {
  const p = E.newProject('Precise dimensions'); p.unit = 'ft'; const o = E.object(p, 'coffee', 1, 1, p.floors[0].id);
  const h = workbench(p), c = h.c; c.s.selected = {type: 'object', id: o.id};
  for (const [input, expected] of [['32 in', .8128], ['2′ 8 1/2″', .8255], ['2.40 m', 2.4], ['3.5', 1.0668]]) {
    const field = h.lengthInput('w', c.p.objects[0].w);
    assert.equal(field.dataset.length, 'true'); h.change({...field, value: input});
    close(c.p.objects[0].w, expected); close(h.stored().projects[0].objects[0].w, expected);
  }
  const before = E.clone(c.p.objects[0]); h.click({mode: '3d'}); h.click({mode: 'plan'}); c.save();
  assert.deepEqual(c.p.objects[0], before); assert.deepEqual(h.stored().projects[0].objects[0], before);
});

test('residential: unchanged formatted feet/inches preserve sub-sixteenth canonical precision; invalid dimensions do not edit', () => {
  const p = E.newProject('Precision'); p.unit = 'ft'; const o = E.object(p, 'coffee', 1, 1, p.floors[0].id); o.w = 1.23456789123;
  const h = workbench(p), c = h.c; c.s.selected = {type: 'object', id: o.id};
  h.change(h.lengthInput('w', o.w)); assert.equal(c.history.length, 0); assert.equal(c.p.objects[0].w, o.w);
  for (const value of ['0 in', '-1 in', '10000 ft', '1/0 in', 'nonsense', '']) {
    const before = JSON.stringify(c.p); h.change({...h.lengthInput('w', c.p.objects[0].w), value});
    assert.equal(JSON.stringify(c.p), before); assert.equal(c.history.length, 0); assert.equal(h.stored(), null);
  }
});

test('residential: actual rate change listener converts displayed imperial prices and a unit toggle preserves the total', () => {
  const p = E.demo(); p.unit = 'ft'; p.currency = 'USD'; const h = workbench(p), c = h.c;
  for (const key of ['floor', 'wall', 'concrete', 'door', 'window', 'cabinet']) {
    h.change({dataset: {rate: key}, type: 'number', value: '17.25'});
    close(R.rows(c.p).find(r => r.key === key).rate, 17.25);
    close(c.p.rates[key], 17.25*R.factor(c.p, key));
  }
  const total = E.estimate(c.p).total, before = E.clone(c.p);
  h.change({id: 'units', value: 'm'}); close(E.estimate(c.p).total, total);
  assert.deepEqual(c.p.rates, before.rates); assert.deepEqual(c.p.objects, before.objects);
  h.change({id: 'units', value: 'ft'}); close(E.estimate(c.p).total, total);
  c.renderSchedule(); assert.match(h.element('documentPane').innerHTML, /USD \/ 单位/);
  assert.match(h.element('documentPane').innerHTML, /cu yd/);
  c.csv(); const csv = h.exports.at(-1).text;
  assert.match(csv, /单价 USD/); assert.match(csv, /金额 USD/); assert.match(csv, /cu yd/);
  assert.equal(h.stored().projects[0].currency, 'USD');
});

test('residential: currency preset changes remain undoable and restoring legacy CNY does not change geometry or units', () => {
  const h = workbench(), c = h.c, before = E.clone(c.p);
  h.change({id: 'budgetCurrency', value: 'USD'});
  assert.equal(c.p.currency, 'USD'); assert.equal(c.p.unit, before.unit); assert.deepEqual(c.p.walls, before.walls);
  assert.equal(c.travelHistory(), true); assert.equal(R.currency(c.p), 'CNY'); assert.equal(Object.hasOwn(c.p, 'currency'), false);
  assert.deepEqual(c.p.rates, before.rates); assert.deepEqual(h.stored().projects[0].rates, before.rates);
});

test('residential: exported budget quantity and unit price reproduce the exported line amount to currency precision', () => {
  const p = E.demo(); p.unit = 'ft'; const h = workbench(p); h.c.csv();
  const rows = h.exports.at(-1).text.trim().replace(/^\uFEFF/, '').split('\r\n').slice(1).map(line =>
    [...line.matchAll(/"((?:[^"]|"")*)"/g)].map(m => m[1].replace(/""/g, '"')));
  for (const row of rows) close(Number(row[1])*Number(row[3]), Number(row[4]), .02);
});

function residential(h) {
  const {c} = h, modeWrites = [], listeners = {}, bodyClasses = new Set;
  c.document = {getElementById: h.element, querySelector: h.element,
    createElement: () => ({setAttribute() {}, append() {}, after() {}, prepend() {}}),
    body: {classList: {toggle(name, enabled) {if (enabled) bodyClasses.add(name); else bodyClasses.delete(name);}}},
    addEventListener: (type, fn) => listeners[type] = fn};
  c.localStorage = {getItem: () => null, setItem: (key, value) => modeWrites.push([key, value])};
  c.addEventListener = () => {};
  c.Drawings = {esc: String}; c.MutationObserver=class{observe(){}};
  vm.runInContext(fs.readFileSync(path.join(root, 'dist/residential-ui.js'), 'utf8'), c);
  c.ResidentialUI.init({state: () => ({p: c.p, s: c.s, db: c.db}), resize() {}, toast: c.toast,
    refresh: c.refresh, transact: c.transact, view: mode => c.s.mode = mode, tool: tool => c.s.tool = tool,
    dialog() {}, open() {return false;}});
  const click = dataset => listeners.click({target: {closest: () => ({dataset})}});
  return {modeWrites, bodyClasses, click};
}

test('residential: starter/pro mode and guide navigation do not alter a legacy project or its layer/lock configuration', () => {
  const h = workbench(), c = h.c; c.s.locks.walls = true; c.s.layers.objects = false;
  const before = JSON.stringify(c.p), locks = JSON.stringify(c.s.locks), layers = JSON.stringify(c.s.layers), r = residential(h);
  h.element('workspaceMode').value = 'pro'; h.element('workspaceMode').onchange();
  h.element('workspaceMode').value = 'starter'; h.element('workspaceMode').onchange();
  assert.ok(r.bodyClasses.has('starter-workspace')); assert.equal(JSON.stringify(c.p), before);
  assert.equal(JSON.stringify(c.s.locks), locks); assert.equal(JSON.stringify(c.s.layers), layers);
  r.click({residential: 'tourStart'}); r.click({residential: 'tourNext'});
  assert.ok(h.messages.some(m => m.includes('完成一面墙'))); assert.equal(JSON.stringify(c.p), before);
  c.p = E.newProject('Another project'); c.ResidentialUI.update(); assert.equal(h.element('starterGuide').hidden, true);
});

test('residential: wall assembly and height presets obey actual transaction locks and are undoable', () => {
  const h = workbench(), c = h.c, r = residential(h), wall = c.p.walls[0], thickness = wall.thickness;
  c.s.selected = {type: 'wall', id: wall.id}; c.s.locks.walls = true;
  const before = JSON.stringify(c.p); r.click({wallAssembly: '2x4'}); assert.equal(JSON.stringify(c.p), before);
  c.s.locks.walls = false; r.click({wallAssembly: '2x4'}); assert.equal(c.p.walls[0].thickness, .1143, h.messages.join(' | '));
  assert.equal(c.travelHistory(), true); close(c.p.walls[0].thickness, thickness);
  c.s.locks.walls = true; const restored = JSON.stringify(c.p); r.click({floorHeight: '3.048'});
  assert.equal(JSON.stringify(c.p), restored);
});

test('residential: sofa rendering follows editable overall width, height and depth in the actual Three.js mesh', () => {
  const T = require('../dist/vendor/three.min.js'), c = {BIM: E, THREE: T, Cabinets: C}; c.window = c;
  vm.runInNewContext(fs.readFileSync(path.join(root, 'dist/view3d.js'), 'utf8'), c);
  const view = Object.create(c.BuildingView.prototype); view.model = new T.Group;
  for (const height of [.8, 1.6]) {
    const p = E.newProject(), o = E.object(p, 'sofa', 0, 0, p.floors[0].id); o.h = height;
    const before = JSON.stringify(p), mesh = view.objectMesh(o, 0), box = new T.Box3().setFromObject(mesh), size = box.getSize(new T.Vector3);
    assert.equal(JSON.stringify(p), before); close(size.x, o.w, 1e-5); close(size.y, o.h, 1e-5); close(size.z, o.d, 1e-5);
  }
});

test('residential: changing the sofa material updates its rendered upholstery with the residential material module enabled', () => {
  const T = require('../dist/vendor/three.min.js');
  const paint = {fillRect() {}, beginPath() {}, moveTo() {}, lineTo() {}, bezierCurveTo() {}, stroke() {}};
  const c = {BIM: E, THREE: T, Cabinets: C, document: {createElement: () => ({width: 0, height: 0, getContext: () => paint})}};
  c.window = c;
  vm.runInNewContext(fs.readFileSync(path.join(root, 'dist/render-materials.js'), 'utf8'), c);
  vm.runInNewContext(fs.readFileSync(path.join(root, 'dist/view3d.js'), 'utf8'), c);
  const view = Object.create(c.BuildingView.prototype); view.model = new T.Group;
  const palette = material => {
    const p = E.newProject(), o = E.object(p, 'sofa', 0, 0, p.floors[0].id); o.material = material;
    const mesh = view.objectMesh(o, 0), colors = [];
    mesh.traverse(n => {if (n.material?.color) colors.push(n.material.color.getHexString());});
    return colors;
  };
  assert.notDeepEqual(palette('sage'), palette('walnut'), 'a material edit must have a visible effect on the selected furniture');
});

function mergedRendering() {
  const T = require('../dist/vendor/three.min.js'), noop = () => {};
  let serializations = 0;
  const paint = new Proxy({createLinearGradient: () => ({addColorStop() {}})}, {
    get: (o, k) => o[k] || noop, set: (o, k, v) => (o[k] = v, true)});
  const c = {RoofModel:require('../dist/roof-model'),RoofDisplay:require('../dist/roof-display'),BIM: E, THREE: T, Cabinets: C, Openings: globalThis.Openings,
    document: {createElement: () => ({width: 0, height: 0, getContext: () => paint,
      toDataURL: () => {serializations++; return 'data:image/png;base64,test';}})}};
  c.window = c;
  for (const name of ['render-materials', 'residential-rendering', 'view3d'])
    vm.runInNewContext(fs.readFileSync(path.join(root, 'dist/'+name+'.js'), 'utf8'), c);
  const view = Object.create(c.BuildingView.prototype);
  view.scene = new T.Scene(); view.model = new T.Group(); view.landscape = new T.Group();
  view.ground = new T.Mesh(new T.PlaneGeometry(200, 200), c.ResidentialMaterials.material('grass'));
  view.sun = new T.DirectionalLight(); view.renderer = {}; view.render = noop;
  view.scene.add(view.model, view.landscape, view.ground, view.sun);
  c.ResidentialRendering.setup(view);
  return {c, T, view, serializations: () => serializations};
}
function renderState(p, options = {}) {
  return {...W.defaults(), floor: p.floors[0].id, style: 'material', daylight: 'day', landscape: true, ...options};
}

test('merged rendering: old and new textures share one cached library and preserve numeric/material UV adapters', () => {
  const {c, T, serializations} = mergedRendering(), R = c.ResidentialRendering;
  for (const key of ['oak', 'walnut', 'tile', 'shingle', 'quartz', 'subway', 'siding', 'fabric']) {
    const material = R.material(key), geo = new T.BoxGeometry(2, 1, 1);
    assert.equal(material.map, c.ResidentialMaterials.texture(key)); assert.equal(material.bumpMap, material.map);
    R.uv(geo, material); assert.ok([...geo.attributes.uv.array].every(Number.isFinite));
    material.dispose(); assert.equal(R.material(key).map, material.map);
  }
  const geo = new T.BoxGeometry(2, 1, 1); R.uv(geo, .5);
  close(Math.max(...geo.attributes.uv.array), .5);
  R.uv(geo, R.material('subway')); close(Math.max(...geo.attributes.uv.array), 1/.8128, 1e-6);
  R.preview('subway'); R.preview('subway'); assert.equal(serializations(), 1);
});

test('merged rendering: floor/daylight changes keep one saved landscape without reallocating geometry or moving the site', () => {
  const {c, T, view} = mergedRendering(), p = E.newProject('Site');
  const main = p.floors[0]; main.elevation = 2;
  E.wall(p, {x: 0, y: 0}, {x: 8, y: 0}, main.id);
  p.floors.unshift({...main, id: 'upstairs', elevation: 5});
  E.wall(p, {x: 40, y: 40}, {x: 44, y: 40}, 'upstairs');
  p.site = {landscape: true, driveway: {x: 11, y: 12, w: 3, d: 7}};
  const original = JSON.stringify(p), s = renderState(p, {floor: main.id, foundation: false});
  view.rebuild(p, s);
  close(view.ground.position.y, 1.72);
  const mesh = view.landscape.children[0], geometry = mesh.geometry, day = view.scene.background;
  close(mesh.position.x, 12.5); close(mesh.position.z, 15.5);
  close(mesh.geometry.parameters.width, 3); close(mesh.geometry.parameters.depth, 7);
  const sun = view.sun.position.clone(), count = view.scene.children.length;
  s.floor = 'upstairs'; view.rebuild(p, s);
  assert.equal(view.landscape.children[0].geometry, geometry); assert.deepEqual(view.sun.position, sun);
  s.daylight = 'golden'; view.rebuild(p, s); assert.ok(view.sun.position.y < sun.y);
  s.daylight = 'overcast'; view.rebuild(p, s); close(view.sun.intensity, 1.3);
  s.daylight = 'day'; view.rebuild(p, s); assert.equal(view.scene.background, day);
  assert.equal(view.landscape.children[0].geometry, geometry); assert.equal(view.scene.children.length, count);
  c.ResidentialRendering.setup(view); assert.equal(view.scene.children.length, count);
  s.landscape = false; view.rebuild(p, s); assert.equal(view.landscape.visible, false);
  s.landscape = true; p.site.landscape = false; view.rebuild(p, s); assert.equal(view.landscape.visible, false);
  p.site.landscape = true; view.rebuild(p, s); assert.equal(view.landscape.visible, true);
  assert.equal(JSON.stringify(p), original, 'rendering must not rewrite site or model data');
  s.style = 'clay'; view.rebuild(p, s); assert.equal(view.scene.environment, null); close(view.sun.intensity, 2);
  view.model.traverse(o => {if (o.isMesh) {assert.equal(o.material.map, null); assert.equal(o.material.bumpMap, null);}});
});

test('merged rendering: decorative rugs follow bed rotation/layer/deletion without changing the entity selection box', () => {
  const {T, view} = mergedRendering(), p = E.newProject('Bedroom'), o = E.object(p, 'bed', 2, 3, p.floors[0].id);
  o.angle = 37;
  const details = view.objectDetails; view.objectDetails = () => {};
  const plain = view.objectMesh(o, 0), before = new T.Box3().setFromObject(plain);
  view.objectDetails = details; view.model.clear();
  const bed = view.objectMesh(o, 0), after = new T.Box3().setFromObject(bed);
  assert.deepEqual(after, before);
  const rug = view.model.children.find(g => g.userData.detail === 'rug');
  assert.ok(rug && !rug.userData.entity); assert.equal(rug.userData.presentationFor, o.id);
  close(rug.rotation.y, -37*Math.PI/180);
  const intersections = []; rug.children[0].raycast(new T.Raycaster(), intersections); assert.deepEqual(intersections, []);
  view.rebuild(p, renderState(p, {layers: {...W.defaults().layers, objects: false}}));
  assert.ok(!view.model.children.some(g => g.userData.presentationFor === o.id));
  view.rebuild(p, renderState(p)); assert.ok(view.model.children.some(g => g.userData.detail === 'rug'));
  p.objects = []; view.rebuild(p, renderState(p)); assert.ok(!view.model.children.some(g => g.userData.detail));
});

test('merged rendering: Shaker geometry remains shared and backsplash clips real openings including rotated walls', () => {
  for (const degrees of [0, 45, 180]) {
    const {T, view} = mergedRendering(), p = E.newProject('Kitchen'), floor = p.floors[0].id;
    const angle = degrees*Math.PI/180, u = {x: Math.cos(angle), y: Math.sin(angle)}, n = {x: -u.y, y: u.x};
    const wall = E.wall(p, {x: 0, y: 0}, {x: u.x*6, y: u.y*6}, floor); wall.thickness = .2;
    const o = E.object(p, 'baseCabinet', 0, 0, floor); o.w = 2; o.d = .6; o.angle = degrees;
    const center = {x: u.x*2 + n.x*.41, y: u.y*2 + n.y*.41}; o.x = center.x-o.w/2; o.y = center.y-o.d/2;
    o.material = 'white'; o.cabinet = {...C.defaults(o), style: 'shaker', topMaterial: 'quartz'};
    const opening = E.opening(p, wall.id, .35, 'window'); opening.offset = 1.7; opening.width = .6; opening.sill = 1.05; opening.height = 1;
    E.validateOpening(p, opening);
    const original = JSON.stringify(p); view.rebuild(p, renderState(p));
    const object = view.model.children.find(g => g.userData.entity?.id === o.id), parts = C.geometry(o).parts;
    assert.equal(object.children.length, parts.length); assert.ok(parts.filter(p => p.role === 'rail').length >= 8);
    assert.ok(object.children.some(m => m.material.map === view.material('quartz').map));
    const splash = view.model.children.find(g => g.userData.detail === 'backsplash'); assert.ok(splash);
    close(splash.rotation.y, -Math.atan2(u.y, u.x));
    for (const mesh of splash.children) {
      const b = new T.Box3().setFromObject(mesh);
      // Mesh local positions are the host wall's X and height coordinates.
      const left = mesh.position.x-mesh.geometry.parameters.width/2, right = mesh.position.x+mesh.geometry.parameters.width/2;
      const bottom = mesh.position.y-mesh.geometry.parameters.height/2, top = mesh.position.y+mesh.geometry.parameters.height/2;
      assert.ok(right <= opening.offset+1e-6 || left >= opening.offset+opening.width-1e-6 || top <= opening.sill+1e-6 || bottom >= opening.sill+opening.height-1e-6);
      assert.ok([...b.min.toArray(), ...b.max.toArray()].every(Number.isFinite));
    }
    assert.equal(JSON.stringify(p), original);
    o.x += n.x*2; o.y += n.y*2; view.rebuild(p, renderState(p));
    assert.ok(!view.model.children.some(g => g.userData.detail === 'backsplash'), 'free-standing cabinets must not gain floating tile');
  }
});

test('merged rendering: gable and shed closures still meet the wall tops and both roof eaves', () => {
  for (const type of ['gable', 'shed']) {
    const {view} = mergedRendering(), p = E.newProject('Closed roof'), f = p.floors[0];
    E.wall(p, {x: 0, y: 0}, {x: 8, y: 0}, f.id);
    E.wall(p, {x: 8, y: 0}, {x: 8, y: 6}, f.id);
    E.wall(p, {x: 8, y: 6}, {x: 0, y: 6}, f.id);
    E.wall(p, {x: 0, y: 6}, {x: 0, y: 0}, f.id);
    const r = E.autoRoof(p, f.id); Object.assign(r, {type, pitch: 27, overhang: .6});
    view.rebuild(p, renderState(p, {roof: true, cutaway: false}));
    const group = view.model.children.find(g => g.userData.entity?.id === r.id), faces = E.roofFaces(p, r);
    assert.equal(group.children.filter(m=>m.userData.roofSurface).length,require('../dist/roof-model').build(p).triangles.length);
    assert.ok(group.children[0].material.map, 'textured roofing must survive the renderer merge');
    const vertices = group.children.filter(m=>m.userData.roofClosure).flatMap(m => {
      const a = m.geometry.attributes.position, points = [];
      for (let i = 0; i < a.count; i++) points.push([a.getX(i), a.getY(i), a.getZ(i)]);
      return points;
    });
    const contains = expected => vertices.some(point => point.every((value, i) => Math.abs(value-expected[i]) < 1e-5));
    // Closures follow actual exterior walls (0..8 × 0..6), rather than the roof bounding rectangle.
    const base = f.elevation+f.height, slope = Math.tan(r.pitch*Math.PI/180), eave = base+.08+slope*(r.overhang-r.y);
    for (const x of [0, 8]) {
      assert.ok(contains([x, base, 0])); assert.ok(contains([x, base, 6]));
      assert.ok(contains([x, eave, 0]));
      assert.ok(contains([x, type==='shed'?base+.08+slope*(6-r.y+r.overhang):eave, 6]));
      if (type==='gable') assert.ok(contains([x, base+.08+slope*(r.d/2+r.overhang), r.y+r.d/2]));
    }
  }
});
