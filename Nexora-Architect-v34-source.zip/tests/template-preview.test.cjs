const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const E=require('../dist/geometry'),N=require('../dist/north-america'),P=require('../dist/template-preview'),U=require('../dist/units');
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-7,`${a} != ${b}`);
test('all 100 real previews reconcile every floor and area category with the model without changing it',()=>{
 for(const t of N.entries){const p=N.build(t.id),before=JSON.stringify(p),i=P.inspect(p);near(i.living,E.estimate(p).livingNetArea);near(i.living/.09290304,t.areaSqFt);assert.equal(i.floors.length,p.floors.length);
  for(const f of p.floors){const info=i.floors.find(v=>v.id===f.id),rooms=E.detectRooms(p,f.id);near(info.living,E.estimate(p,f.id).livingNetArea);assert.equal(info.rooms.length,rooms.length);
   const svg=P.plan(p,f.id,'ft');assert.match(svg,/<svg/);for(const r of rooms)assert.ok(svg.includes(r.id));for(const w of p.walls.filter(w=>w.floor===f.id))assert.ok(svg.includes(w.id));
   for(const h of p.slabOpenings.filter(h=>h.floor===f.id))assert.ok(svg.includes(h.id));if(f.elevation<0)assert.equal(info.living,0);
   const m=P.plan(p,f.id,'m');assert.match(m,/m²/);assert.match(svg,/sq ft/);assert.equal((m.match(/data-entity="wall"/g)||[]).length,(svg.match(/data-entity="wall"/g)||[]).length);
  }assert.ok(i.garage>30);assert.ok(i.outdoor>0);assert.equal(i.basement>0,t.basement);assert.equal(JSON.stringify(p),before);
 }
});
test('plan bounds contain the actual driveway, and exterior/interior scopes use the chosen model floors',()=>{
 const p=N.build('NA-COLONIAL-01'),main=p.floors.find(f=>f.elevation===0),base=p.floors.find(f=>f.elevation<0),d=E.siteDriveway(p),svg=P.plan(p,main.id,'ft');
 const [x,y,w,h]=svg.match(/viewBox="([^"]+)"/)[1].split(' ').map(Number);assert.ok(d.x>=x&&d.y>=y&&d.x+d.w<=x+w&&d.y+d.d<=y+h);
 const a=P.state(p,main.id,'exterior'),b=P.state(p,base.id,'inside');assert.ok(a.allFloors&&a.roof&&!a.cutaway);assert.ok(!b.allFloors&&!b.roof&&b.cutaway);assert.equal(b.floor,base.id);assert.throws(()=>P.plan(p,'bad','ft'));
});
function fixture(){
 const elements={},views=[],opened=[],state={},errors=[];let html='',back=0,closed=0,succeed=true,openHook=null;
 const make=id=>elements[id]={id,style:{},textContent:'',scrollTop:50,scrollLeft:30,setAttribute(){},querySelector:()=>({style:{}}),close(){closed++;}};
 make('dialog');global.document={getElementById:id=>elements[id]};
 class View{constructor(host){this.host=host;this.ground={visible:true};this.landscape={visible:true};this.disposed=0;views.push(this);}rebuild(p,s){this.p=p;this.s=s;}fit(p,f,options){this.fitFloor=f;this.fitOptions=options;this.camera={position:[8,7,6],target:[0,0,0],walk:false};}captureCamera(){return structuredClone(this.camera);}restoreCamera(c){this.camera=structuredClone(c);return true;}dispose(){this.disposed++;}}
 const previous=global.BuildingView;global.BuildingView=View;
 const bridge={dialog(title,value){html=value;for(const id of ['templatePreview','previewViewport','previewZoom','previewFloor','previewUnit'])make(id);},open(p){if(openHook)return openHook(p);if(!succeed)return false;opened.push(p);return true;},state:()=>({s:state}),refresh(){},toast:m=>errors.push(m)};
 const ui=P.create(bridge);
 return{ui,views,opened,state,errors,elements,get html(){return html},get closed(){return closed},get back(){return back},set succeed(v){succeed=v},set openHook(v){openHook=v},open(id='NA-COLONIAL-01'){ui.open(id,()=>back++);},cleanup(){ui.close();delete global.document;if(previous===undefined)delete global.BuildingView;else global.BuildingView=previous;}};
}
test('preview/back/units/floor/3D are non-writing; only create opens the inspected independent project',()=>{
 const h=fixture();try{h.open();const firstHTML=h.html;assert.equal(h.opened.length,0);assert.match(firstHTML,/2,076.94 sq ft/);assert.match(firstHTML,/Create my project/);
  h.ui.click({previewMode:'exterior'});const p=h.views[0].p,before=JSON.stringify(p),base=p.floors.find(f=>f.elevation<0);h.ui.change('previewFloor',base.id);h.ui.click({previewMode:'inside'});const inside=h.views.at(-1);assert.equal(inside.s.floor,base.id);assert.equal(inside.ground.visible,false);assert.equal(inside.landscape.visible,false);
  h.ui.change('previewUnit','m');assert.match(h.html,/m²/);assert.equal(JSON.stringify(p),before);assert.equal(h.opened.length,0);h.ui.click({previewAction:'load'});assert.equal(h.opened.length,1);assert.equal(h.opened[0].unit,'m');assert.equal(h.opened[0].template.id,p.template.id);assert.notEqual(h.opened[0],p);assert.deepEqual(h.opened[0].walls,p.walls);assert.equal(h.closed,1);assert.equal(h.state.allFloors,true);assert.equal(h.ui.active(),false);assert.ok(h.views.every(v=>v.disposed===1));
  h.open();h.ui.click({previewAction:'back'});assert.equal(h.back,1);assert.equal(h.opened.length,1);h.open();h.ui.click({previewAction:'load'});assert.notEqual(h.opened[0].id,h.opened[1].id);assert.ok(h.opened[0].walls.every(w=>!h.opened[1].walls.some(v=>v.id===w.id)));
 }finally{h.cleanup();}
});
test('storage failure leaves preview available; invalid selectors are rejected; WebGL failure retains plans',()=>{
 const h=fixture();try{h.open();h.succeed=false;h.ui.click({previewAction:'load'});assert.equal(h.opened.length,0);assert.equal(h.closed,0);assert.equal(h.ui.active(),true);assert.equal(h.errors.length,1);
  assert.equal(h.ui.change('previewFloor','unknown'),false);assert.equal(h.ui.change('previewUnit','invalid'),false);assert.equal(h.ui.click({previewMode:'invalid'}),false);
  const V=global.BuildingView;global.BuildingView=class{constructor(){throw Error('WebGL unavailable')}};h.ui.click({previewMode:'exterior'});assert.match(h.elements.previewViewport.textContent,/3D could not start/);global.BuildingView=V;h.ui.click({previewMode:'plan'});assert.match(h.html,/<svg/);h.ui.click({previewAction:'zoom'});assert.equal(h.elements.previewZoom.textContent,'150%');h.ui.click({previewAction:'fit'});assert.equal(h.elements.previewZoom.textContent,'100%');
 }finally{h.cleanup();}
});
test('preview supports Chinese, English and Spanish UI while authored English room names remain intact',()=>{
 const old=global.NexoraI18n,h=fixture();try{for(const [lang,label]of [['zh','创建我的项目'],['es','Crear mi proyecto'],['en','Create my project']]){global.NexoraI18n={language:lang};h.open();assert.ok(h.html.includes(label));assert.match(h.html,/Living Room/);assert.match(h.html,/data-no-translate/);}}finally{h.cleanup();if(old===undefined)delete global.NexoraI18n;else global.NexoraI18n=old;}
});
test('every template entry point uses the 100-home gallery and every card offers detailed preview with exact area',()=>{
 const wb=fs.readFileSync(require.resolve('../dist/workbench'),'utf8'),ui=fs.readFileSync(require.resolve('../dist/residential-ui'),'utf8');assert.ok(!wb.includes('data-us-home'));assert.ok(!wb.includes('USResidential.build'));assert.ok(!ui.includes('featuredHomes'));
 for(let page=1;page<=5;page++){const html=N.gallery({page});const ids=[...html.matchAll(/data-preview-north-america="([^"]+)"/g)].map(m=>m[1]);assert.equal(ids.length,20);for(const id of ids){const t=N.entries.find(t=>t.id===id);assert.ok(html.includes(t.areaSqFt.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})));assert.ok(html.includes(`data-load-north-america="${id}"`));}}
});
test('disposing a preview releases owned GPU resources once while keeping shared material textures alive',()=>{
 const THREE=require('../dist/vendor/three.min'),ctx={THREE,BIM:E,RoofModel:require('../dist/roof-model'),RoofDisplay:require('../dist/roof-display')};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync(require.resolve('../dist/view3d'),'utf8'),ctx);
 const v=Object.create(ctx.BuildingView.prototype),counts={geometry:0,material:0,shared:0,owned:0,observer:0,renderer:0,removed:0};const g=new THREE.BoxGeometry(),shared=new THREE.Texture(),owned=new THREE.Texture(),m=new THREE.MeshBasicMaterial({map:shared}),label=new THREE.SpriteMaterial({map:owned});label.userData.ownsMap=true;
 for(const [obj,key]of [[g,'geometry'],[m,'material'],[shared,'shared'],[owned,'owned']])obj.addEventListener('dispose',()=>counts[key]++);
 v.scene=new THREE.Scene();v.scene.add(new THREE.Mesh(g,m),new THREE.Mesh(g,m),new THREE.Sprite(label));v.resizeObs={disconnect(){counts.observer++}};v.renderer={dispose(){counts.renderer++},domElement:{remove(){counts.removed++}}};v.dispose();v.dispose();v.resize();v.render();assert.deepEqual(counts,{geometry:1,material:1,shared:0,owned:1,observer:1,renderer:1,removed:1});assert.equal(v.scene.children.length,0);
});

test('failed load attempts cannot mutate the preview; retry uses a fresh deep copy and invalid open preserves the prior preview',()=>{
 const h=fixture();try{
  h.open();h.ui.click({previewMode:'exterior'});const preview=h.views.at(-1).p,before=JSON.stringify(preview),attempts=[];
  h.openHook=p=>{attempts.push(p);p.walls[0].a.x=999;p.floors[0].name='damaged candidate';throw Error('Storage unavailable');};
  assert.doesNotThrow(()=>h.ui.click({previewAction:'load'}));assert.equal(h.errors.at(-1),'Storage unavailable');assert.equal(h.closed,0);assert.equal(h.ui.active(),true);assert.equal(JSON.stringify(preview),before);
  assert.throws(()=>h.open('UNKNOWN-TEMPLATE'));assert.equal(h.ui.active(),true);assert.equal(h.views.at(-1).disposed,0);
  h.openHook=p=>{attempts.push(p);return false;};h.ui.click({previewAction:'load'});
  assert.notEqual(attempts[0],attempts[1]);assert.notEqual(attempts[0].walls[0].a,attempts[1].walls[0].a);assert.equal(JSON.stringify(attempts[1]),before);
  h.openHook=null;h.ui.click({previewAction:'load'});assert.equal(h.opened.length,1);h.opened[0].walls[0].a.x=888;assert.equal(JSON.stringify(preview),before);
 }finally{h.cleanup();}
});

test('language and unit refresh retain the observed floor, model and 3D camera without writing a project',()=>{
 const h=fixture(),old=global.NexoraI18n;try{
  h.open();h.ui.click({previewMode:'inside'});const p=h.views.at(-1).p,base=p.floors.find(f=>f.elevation<0);h.ui.change('previewFloor',base.id);
  const camera={position:[12,-1,18],target:[4,-2,6],walk:false};h.views.at(-1).camera=structuredClone(camera);const before=JSON.stringify(p);
  for(const [language,label]of [['zh','查看本层室内'],['es','Interior de esta planta'],['en','Inside this floor']]){
   global.NexoraI18n={language};h.ui.refresh();const view=h.views.at(-1);assert.match(h.html,new RegExp(label));assert.equal(view.s.floor,base.id);assert.deepEqual(view.camera,camera);assert.deepEqual(view.fitOptions,{singleFloor:true});assert.equal(view.p,p);
  }
  h.ui.change('previewUnit','m');assert.deepEqual(h.views.at(-1).camera,camera);assert.equal(JSON.stringify(p),before);assert.equal(h.opened.length,0);assert.ok(h.views.slice(0,-1).every(v=>v.disposed===1));
 }finally{h.cleanup();if(old===undefined)delete global.NexoraI18n;else global.NexoraI18n=old;}
});

function viewContext(extra={}){
 const THREE=require('../dist/vendor/three.min'),paint=new Proxy({},{get:()=>()=>{},set:()=>true}),ctx={THREE,BIM:E,Cabinets:require('../dist/cabinets'),Openings:global.Openings,RoofModel:require('../dist/roof-model'),RoofDisplay:require('../dist/roof-display'),document:{createElement:()=>({getContext:()=>paint})},...extra};ctx.window=ctx;vm.createContext(ctx);
 vm.runInContext(fs.readFileSync(require.resolve('../dist/render-materials'),'utf8'),ctx);vm.runInContext(fs.readFileSync(require.resolve('../dist/view3d'),'utf8'),ctx);return ctx;
}

test('real inside-floor geometry and camera use basement world elevations and exclude other floors in every template',()=>{
 const c=viewContext(),T=c.THREE,v=Object.create(c.BuildingView.prototype);v.scene=new T.Scene();v.model=new T.Group();v.landscape=new T.Group();v.scene.add(v.model,v.landscape);v.sun=new T.DirectionalLight();v.ground=new T.Mesh(new T.PlaneGeometry(1,1),new T.MeshBasicMaterial());v.scene.add(v.sun,v.ground);v.camera=new T.PerspectiveCamera(42,1.7,.05,2000);v.target=new T.Vector3();v.renderer={render(){},dispose(){},domElement:{remove(){}}};
 let floors=0,basements=0;
 try{for(const entry of N.entries){const p=N.build(entry.id),before=JSON.stringify(p);for(const f of p.floors){
  floors++;if(f.elevation<0)basements++;const s=P.state(p,f.id,'inside');v.rebuild(p,s);v.fit(p,f.id,{singleFloor:true});v.camera.updateMatrixWorld(true);
  const walls=new Set(),objects=new Set(),rooms=new Set();v.model.traverse(o=>{const e=o.userData.entity;if(e?.type==='wall')walls.add(e.id);if(e?.type==='object')objects.add(e.id);if(e?.type==='room')rooms.add(e.id);assert.ok(!o.userData.roofSurface,'inside preview must not contain hidden roof geometry');});
  assert.deepEqual([...walls].sort(),p.walls.filter(w=>w.floor===f.id).map(w=>w.id).sort());assert.deepEqual([...objects].sort(),p.objects.filter(o=>o.floor===f.id).map(o=>o.id).sort());assert.deepEqual([...rooms].sort(),E.detectRooms(p,f.id).map(r=>r.id).sort());
  assert.ok(v.target.y>=f.elevation-f.slab-.01&&v.target.y<=f.elevation+1.35,entry.id+' camera target belongs to selected floor');
  const b=new T.Box3().setFromObject(v.model);b.max.y=Math.min(b.max.y,f.elevation+1.35);
  for(const x of [b.min.x,b.max.x])for(const y of [b.min.y,b.max.y])for(const z of [b.min.z,b.max.z]){const q=new T.Vector3(x,y,z).project(v.camera);assert.ok(Math.abs(q.x)<=1.000001&&Math.abs(q.y)<=1.000001&&Math.abs(q.z)<=1,entry.id+' visible floor fits camera');}
  v.model.traverse(o=>{if(o.material)for(const m of Array.isArray(o.material)?o.material:[o.material]){assert.equal(m.clippingPlanes.length,1);near(m.clippingPlanes[0].constant,f.elevation+1.35);}});
 }assert.equal(JSON.stringify(p),before);}assert.ok(floors>100&&basements>0);
 }finally{v.dispose();}
});

test('a real BuildingView constructor failure releases its partial context, observer and geometry',()=>{
 const T=require('../dist/vendor/three.min'),counts={renderer:0,context:0,removed:0,observer:0,geometry:0},canvas={style:{},addEventListener(){},remove(){counts.removed++}};
 class Renderer{constructor(){this.domElement=canvas;this.shadowMap={};}setPixelRatio(){}setSize(){}render(){throw Error('Initial render failed');}dispose(){counts.renderer++;}forceContextLoss(){counts.context++;}}
 class PlaneGeometry extends T.PlaneGeometry{constructor(...args){super(...args);this.addEventListener('dispose',()=>counts.geometry++);}}
 const c=viewContext({THREE:{...T,WebGLRenderer:Renderer,PlaneGeometry},devicePixelRatio:1,ResizeObserver:class{observe(){}disconnect(){counts.observer++;}}});
 assert.throws(()=>new c.BuildingView({append(){},clientWidth:800,clientHeight:600},()=>false),/Initial render failed/);
 assert.deepEqual(counts,{renderer:1,context:1,removed:1,observer:1,geometry:1});
});
