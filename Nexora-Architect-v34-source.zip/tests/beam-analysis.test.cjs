const test=require('node:test'),assert=require('node:assert/strict');
const E=require('../dist/geometry'),S=require('../dist/structure'),B=require('../dist/beam-analysis');
const near=(a,b,eps=1e-8)=>assert.ok(Math.abs(a-b)<=eps*Math.max(1,Math.abs(b)),`${a} != ${b}`);
const member=()=>({id:'beam-1',floor:'floor-1',kind:'beam',x1:0,y1:0,x2:4,y2:0,z:2.7,width:.1,depth:.3,material:'Explicit fixture',note:''});
const input=()=>({method:B.method,dead:2000,variable:1000,points:[],E:10e9,G:.6e9,Fb:12e6,Fv:1e6,Fc:3e6,leftBearing:.1,rightBearing:.1,totalLimit:240,variableLimit:360,loadBasis:'Fixture service loads including self-weight',materialBasis:'Synthetic test properties, not species values',criteriaBasis:'User-entered test criteria, not adopted code',supportsConfirmed:true,solidSectionConfirmed:true,selfWeightIncluded:true});
const project=()=>{const p=E.validate(E.newProject('Beam tests'));p.structure=S.data(p);p.structure.members=[{...member(),floor:p.floors[0].id}];return p;};
test('uniform load matches closed-form reactions, stress, shear-corrected deflection and exact endpoints',()=>{
 const m=member(),v=input(),r=B.calculate(m,v),L=4,w=3000,I=.1*.3**3/12,A=.1*.3,K=5*A/6*v.G;
 near(r.cases.total.reactionLeft,w*L/2);near(r.cases.total.reactionRight,w*L/2);near(r.cases.total.moment.value,w*L*L/8);near(r.cases.total.moment.x,2);
 near(r.cases.total.deflection.value,5*w*L**4/(384*v.E*I)+w*L*L/(8*K));near(r.cases.total.deflection.x,2);
 near(r.checks.find(c=>c.id==='bending').demand,w*L*L/8/(.1*.3*.3/6));near(r.checks.find(c=>c.id==='shear').demand,1.5*w*L/2/A);
 near(r.checks.find(c=>c.id==='bearingLeft').demand,w*L/2/(.1*.1));near(r.cases.variable.deflection.value,r.cases.total.deflection.value/3);
 for(const a of [r.cases.total.diagram[0],r.cases.total.diagram.at(-1)]){near(a.deflection,0);near(a.moment,0);}
 assert.equal(r.status,'draft_not_certified');assert.ok(r.limitations.length>=6);assert.ok(!Object.hasOwn(r,'pass'));
});
test('midspan point load matches independent closed-form point case and shear jumps',()=>{
 const m=member(),v={...input(),dead:0,variable:0,points:[{x:2,dead:6000,variable:0}]},r=B.calculate(m,v).cases.total;
 const I=.1*.3**3/12,K=5/6*.1*.3*v.G;near(r.reactionLeft,3000);near(r.moment.value,6000);near(r.deflection.value,6000*4**3/(48*v.E*I)+6000*4/(4*K));
 const jumps=r.diagram.filter(p=>p.x===2);assert.equal(jumps.length,2);near(jumps[0].shear-jumps[1].shear,6000);near(jumps[0].moment,jumps[1].moment);near(jumps[0].deflection,jumps[1].deflection);
});
test('asymmetric mixed loads satisfy equilibrium and maxima exceed every dense probe',()=>{
 const m=member(),v={...input(),points:[{x:.65,dead:4000,variable:1000},{x:2.9,dead:0,variable:1700}]},r=B.calculate(m,v).cases.total;
 near(r.reactionLeft+r.reactionRight,3000*4+6700);near(r.reactionRight*4,3000*4*2+5000*.65+1700*2.9);
 for(const q of r.diagram){assert.ok(q.moment<=r.moment.value+1e-7);assert.ok(q.deflection<=r.deflection.value+1e-10);}
 assert.ok(Math.abs(r.deflection.x-2)>.01);assert.ok(Math.abs(r.deflection.x-r.moment.x)>.01);
});
test('actual imperial values converted to SI give dimensionally identical results',()=>{
 const ft=.3048,lb=4.4482216152605,psi=lb/(.0254**2),m={...member(),x2:12*ft,width:3.5*.0254,depth:11.25*.0254};
 const v={...input(),dead:100*lb/ft,variable:200*lb/ft,E:1.6e6*psi,G:.1e6*psi};const r=B.calculate(m,v).cases.total;
 near(r.reactionLeft/lb,1800);near(r.moment.value/(lb*ft),5400);const L=144,I=3.5*11.25**3/12,A=3.5*11.25,w=300/12;
 near(r.deflection.value/.0254,5*w*L**4/(384*1.6e6*I)+w*L*L/(8*(5*A/6)*.1e6));
});
test('missing limits remain missing and insufficient section explicitly exceeds the entered limits',()=>{
 const v={...input(),Fb:null,Fv:null,Fc:null,totalLimit:null,variableLimit:null},r=B.calculate(member(),v);assert.ok(r.checks.every(c=>c.status==='missing_limit'&&c.ratio===null));
 const failed=B.calculate({...member(),depth:.05},input());assert.ok(failed.checks.some(c=>c.status==='exceeds_entered_limit'));
 const missing=B.calculate(member(),{...input(),loadBasis:'',materialBasis:'',criteriaBasis:''});assert.equal(missing.missingBasis.length,3);
});
test('invalid inputs and unsupported geometry are rejected without coercion',()=>{
 for(const edit of [v=>v.E=NaN,v=>v.G=0,v=>v.Fb=Infinity,v=>v.dead=-1,v=>v.variable='200',v=>v.totalLimit=0,v=>v.points=[{x:4,dead:2,variable:0}],v=>v.points=[{x:0,dead:2,variable:0}],v=>v.points=Array(13).fill({x:1,dead:1,variable:0}),v=>v.supportsConfirmed=false,v=>v.solidSectionConfirmed=false,v=>v.selfWeightIncluded=false,v=>v.method='cantilever']){const v=input();edit(v);assert.throws(()=>B.calculate(member(),v));}
 for(const edit of [m=>m.kind='post',m=>m.kind='rafter',m=>m.width=0,m=>m.x2=0,m=>m.depth=NaN]){const m=member();edit(m);assert.throws(()=>B.calculate(m,input()));}
 assert.throws(()=>B.calculate(member(),{...input(),dead:0,variable:0}));
});
test('records persist, recompute results, detect geometry/basis changes, and do not export stale calculations',()=>{
 const p=project();B.save(p,'beam-1',input());const saved=JSON.stringify(p);assert.equal(B.saved(p,'beam-1').state,'current');assert.equal(B.report(p,'beam-1').format,'nexora-beam-analysis-v1');
 const roundtrip=E.validate(JSON.parse(saved));assert.equal(B.saved(roundtrip,'beam-1').state,'current');
 for(const edit of [q=>q.structure.members[0].depth=.25,q=>q.structure.members[0].x2=3,q=>q.structure.members[0].material='Different material',q=>q.structure.loads='Revised loads',q=>q.codeReview={profile:{address:'Changed address'}},q=>q.codeReview={research:{queriedAt:'2026-11-09'}}]){const copy=JSON.parse(saved);edit(copy);assert.equal(B.saved(copy,'beam-1').state,'stale');assert.throws(()=>B.report(copy,'beam-1'));}
 roundtrip.name='Renamed';roundtrip.unit='ft';assert.equal(B.saved(roundtrip,'beam-1').state,'current');
 const bad=JSON.parse(saved);bad.structure.members[0].analysis.input.Fb=Infinity;assert.throws(()=>E.validate(bad));
 const copyFloor=JSON.parse(saved),upper=E.duplicateFloor(copyFloor,p.floors[0].id),copied=copyFloor.structure.members.find(m=>m.floor===upper.id);assert.equal(B.saved(copyFloor,copied.id).state,'stale');
 assert.equal(JSON.stringify(p),saved);
});
