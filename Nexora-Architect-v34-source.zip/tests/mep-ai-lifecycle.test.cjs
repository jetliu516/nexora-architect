// Read-only VM regression probe. Run from the project root with node --test.
// The fetch stub deliberately ignores AbortSignal so late responses are exercised.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const E = require(path.join(root, 'dist/geometry.js'));
const M = require(path.join(root, 'dist/mep-profile.js'));
const A = require(path.join(root, 'dist/mep-ai.js'));
const W = require(path.join(root, 'dist/workspace-model.js'));
const U = require(path.join(root, 'dist/units.js'));
const flush = () => new Promise(resolve => setImmediate(resolve));

function harness() {
  let p = E.newProject('AI lifecycle regression');
  const f = p.floors[0].id;
  const a = M.node(p, 'cold', 'waterMeter', f, 0, 0, 1);
  const b = M.node(p, 'cold', 'inlet', f, 4, 0, 1);
  const run = M.connect(p, a.id, b.id, {routing: 'direct'});
  p = E.validate(p);
  const s = {...W.defaults(), floor: f, selected: {type: 'mepRun', id: run.id}};
  const handlers = {}, elements = {}, dialogs = [], messages = [], pending = [];
  let form, commits = 0, deny = false;
  const context = {
    BIM: E, MEP: M, MEPAI: A, WorkspaceModel: W, Units: U,
    Drawings: {esc: String}, AbortController,
    FormData: class {
      has(key) { return key === 'share'; }
      get() { return 'Change selected diameter to 32 mm'; }
    },
    document: {
      querySelector: id => elements[id],
      addEventListener: (name, callback) => { handlers[name] = callback; }
    },
    fetch: async (url, options) => {
      if (url === '/api/ai/session') return {
        json: async () => ({authenticated: true, configured: true, model: 'mock'})
      };
      assert.equal(url, '/api/ai/mep');
      return new Promise(resolve => pending.push({resolve, options}));
    }
  };
  context.window = context;
  elements['#dialog'] = {addEventListener: (name, callback) => {
    handlers['dialog:' + name] = callback;
  }};
  vm.runInNewContext(fs.readFileSync(path.join(root, 'dist/mep-ai-ui.js'), 'utf8'), context);
  context.MEPAIUI.init({
    state: () => ({p, s}),
    dialog(title) {
      dialogs.push(title);
      if (form) form.isConnected = false;
      if (title !== 'AI 机电修改') return;
      elements['#mepAIScope'] = {value: 'selected'};
      elements['#mepAIRebuild'] = {checked: false};
      for (const id of ['mepAIContext', 'mepAIStatus', 'mepAILogin', 'mepAISubmit']) {
        elements['#' + id] = {};
      }
      form = {
        id: 'mepAIForm', isConnected: true,
        querySelector: id => elements[id],
        querySelectorAll: () => ['#mepAIScope', '#mepAIRebuild', '#mepAISubmit'].map(id => elements[id])
      };
      elements['#mepAIForm'] = form;
    },
    toast: value => messages.push(value),
    close: () => handlers['dialog:close'](),
    refresh() {},
    transact(fn) { if(deny)return false;const before=E.clone(p);try{fn();W.assertEditable(before,p,s);commits++;return true}catch{p=before;return false} }
  });
  return {
    get p() { return p; }, set p(value) { p = value; }, s, run, dialogs, messages, pending,
    get commits() { return commits; }, set deny(value) { deny = value; },
    get disabled() { return elements['#mepAISubmit'].disabled; },
    get status() { return elements['#mepAIStatus'].textContent; },
    click(dataset) { handlers.click({target: {closest: () => ({dataset})}}); },
    submit() { handlers.submit({target: form, preventDefault() {}}); },
    close() { handlers['dialog:close'](); },
    respond(index = 0) {
      pending[index].resolve({ok: true, json: async () => ({plan: {
        summary: 'Proposed diameter change', assumptions: [], operations: [
          {type: 'set_run', runId: run.id, diameterM: .032, slope: null}
        ]
      }})});
    }
  };
}

test('removed selected run invalidates old form without unhandled rejection or resubmission', async () => {
  const h = harness(), unhandled = [];
  const listen = error => unhandled.push(error);
  process.on('unhandledRejection', listen);
  try {
    h.click({mepAiOpen: ''}); await flush();
    h.submit(); assert.equal(h.pending.length, 1);
    h.p.mep.runs = [];
    h.respond(); await flush(); await flush();
    assert.equal(h.disabled, true);
    assert.match(h.status, /重新打开/);
    assert.equal(h.commits, 0);
    assert.deepEqual(h.dialogs, ['AI 机电修改']);
    h.submit(); await flush();
    assert.equal(h.pending.length, 1);
    assert.deepEqual(unhandled, []);
  } finally { process.removeListener('unhandledRejection', listen); }
});

test('stop and modal close both reject late successful responses even if fetch ignores abort', async () => {
  for (const action of ['stop', 'close']) {
    const h = harness(), before = JSON.stringify(h.p);
    h.click({mepAiOpen: ''}); await flush(); h.submit();
    if (action === 'stop') h.click({mepAiCancel: ''}); else h.close();
    assert.equal(h.pending[0].options.signal.aborted, true);
    h.respond(); await flush(); await flush();
    assert.deepEqual(h.dialogs, ['AI 机电修改']);
    h.click({mepAiApply: ''});
    assert.equal(h.commits, 0);
    assert.equal(JSON.stringify(h.p), before);
  }
});

test('project replacement rejects late response and disables the stale form', async () => {
  const h = harness();
  h.click({mepAiOpen: ''}); await flush(); h.submit();
  h.p = E.validate(E.newProject('Replacement project'));
  const before = JSON.stringify(h.p);
  h.respond(); await flush(); await flush();
  assert.equal(h.disabled, true);
  assert.match(h.status, /重新打开/);
  assert.equal(h.commits, 0);
  assert.equal(JSON.stringify(h.p), before);
  h.submit(); await flush();
  assert.equal(h.pending.length, 1);
});

test('review apply respects failed transactions and a newly locked layer, then commits only once',async()=>{
 const h=harness();h.click({mepAiOpen:''});await flush();h.submit();h.respond();await flush();await flush();assert.equal(h.dialogs.at(-1),'AI 机电修改预览');
 h.deny=true;h.click({mepAiApply:''});assert.equal(h.commits,0);assert.equal(h.p.mep.runs[0].diameter,.025);h.deny=false;h.s.locks.mep_cold=true;h.click({mepAiApply:''});assert.equal(h.commits,0);assert.equal(h.p.mep.runs[0].diameter,.025);
 h.s.locks.mep_cold=false;h.click({mepAiApply:''});assert.equal(h.commits,1);assert.equal(h.p.mep.runs[0].diameter,.032);h.click({mepAiApply:''});assert.equal(h.commits,1);
});
