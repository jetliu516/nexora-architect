const test = require('node:test');
const assert = require('node:assert/strict');
const E = require('../dist/geometry.js');

test('audit: automatic roof uses this floor exterior walls, unaffected by isolated furniture or interior walls', () => {
  const p = E.newProject('Roof bounds audit'), f = p.floors[0].id;
  E.addRectangle(p, 0, 0, 6, 4, f);
  E.wall(p, {x: 20, y: 20}, {x: 25, y: 20}, f, 'interior');
  E.object(p, 'coffee', -80, 70, f);
  const upper = {...p.floors[0], id: E.uid(), name: 'Upper', elevation: 3}; p.floors.push(upper);
  E.addRectangle(p, 50, 50, 10, 10, upper.id);
  const roofAbove = E.autoRoof(p, upper.id), beforeAbove = E.clone(roofAbove);
  assert.deepEqual(E.roofBounds(p, f), {x: -.12, y: -.12, w: 6.24, d: 4.24});
  const roof = E.autoRoof(p, f);
  assert.deepEqual({x: roof.x, y: roof.y, w: roof.w, d: roof.d}, {x: -.12, y: -.12, w: 6.24, d: 4.24});
  const replacement = E.autoRoof(p, f, 'hip');
  assert.equal(p.roofs.filter(r => r.floor === f).length, 1); assert.notEqual(roof.id, replacement.id);
  assert.deepEqual(p.roofs.find(r => r.id === roofAbove.id), beforeAbove);
  assert.doesNotThrow(() => E.validate(p));
});

test('audit: roof bounds fall back to same-floor interior walls and reject a floor containing only furniture', () => {
  const p = E.newProject('Interior fallback'), f = p.floors[0].id;
  E.object(p, 'coffee', 80, 80, f);
  assert.throws(() => E.roofBounds(p, f), /墙体/); assert.throws(() => E.autoRoof(p, f), /墙体/);
  E.wall(p, {x: -2, y: 1}, {x: 3, y: 1}, f, 'interior');
  E.wall(p, {x: 3, y: 1}, {x: 3, y: 4}, f, 'interior');
  for(const [key,value] of Object.entries({x:-2.06,y:.94,w:5.12,d:3.12}))assert.ok(Math.abs(E.roofBounds(p,f)[key]-value)<1e-9);
  const r = E.autoRoof(p, f); assert.equal(r.w, 5.12); assert.ok(Math.abs(r.d-3.12)<1e-9);
});

test('audit: roof coverage includes eaves, ignores other floors and interior walls, and detects an uncovered endpoint', () => {
  const p = E.newProject('Roof coverage'), f = p.floors[0].id;
  E.addRectangle(p, 0, 0, 6, 4, f); const r = E.autoRoof(p, f); r.overhang = .5;
  const inside = E.wall(p, {x: -.5, y: 0}, {x: -.5, y: 4}, f);
  const outside = E.wall(p, {x: 6.4, y: 2}, {x: 6.7, y: 2}, f);
  E.wall(p, {x: 20, y: 20}, {x: 21, y: 20}, f, 'interior');
  const upper = {...p.floors[0], id: E.uid(), name: 'Upper', elevation: 3}; p.floors.push(upper);
  E.wall(p, {x: 30, y: 30}, {x: 31, y: 30}, upper.id);
  assert.deepEqual(E.uncoveredRoofWalls(p, f).map(w => w.id), [outside.id]);
  assert.ok(!E.uncoveredRoofWalls(p, f).includes(inside));
  r.w = 7; assert.deepEqual(E.uncoveredRoofWalls(p, f), []);
  p.roofs = []; assert.deepEqual(E.uncoveredRoofWalls(p, f), [], 'no existing roof is not a partial-coverage warning');
});

test('audit: continuous coverage detects a midpoint gap between separate roofs even when both wall endpoints are covered', () => {
  const p = E.newProject('Midpoint roof gap'), f = p.floors[0].id;
  const w = E.wall(p, {x: 0, y: 0}, {x: 10, y: 4}, f), r = E.autoRoof(p, f);
  Object.assign(r, {x: -1, y: -1, w: 2, d: 2, overhang: 0});
  p.roofs.push({...r, id: E.uid(), x: 9, y: 3});
  assert.deepEqual(E.uncoveredRoofWalls(p, f).map(x => x.id), [w.id]);
  p.roofs.push({...r, id: E.uid(), x: 4, y: 1});
  assert.deepEqual(E.uncoveredRoofWalls(p,f).map(x=>x.id),[w.id],'coverage gaps between samples remain detected');
  p.roofs.push({...r,id:E.uid(),x:0,y:0,w:10,d:4});assert.deepEqual(E.uncoveredRoofWalls(p,f),[]);
});

test('upper roofs cover lower-story walls, while a ground-level roof cannot cover upper walls',()=>{const p=E.newProject(),f=p.floors[0].id;E.addRectangle(p,0,0,8,6,f);const upper=E.duplicateFloor(p,f);const r=E.autoRoof(p,upper.id);assert.deepEqual(E.uncoveredRoofWalls(p,f),[]);assert.deepEqual(E.uncoveredRoofWalls(p,upper.id),[]);p.roofs.push({...r,id:E.uid(),floor:upper.id,x:30});p.roofs[0].floor=f;assert.ok(E.uncoveredRoofWalls(p,upper.id).length>0)});
