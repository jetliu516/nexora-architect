const test=require('node:test'),assert=require('node:assert/strict');
const E=require('../dist/geometry.js'),M=require('../dist/mep-clashes.js'),W=require('../dist/workspace-model.js');
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-6,`${a} != ${b}`);
function house(){const p=E.newProject('Routing QA'),f=p.floors[0].id;E.addRectangle(p,0,0,10,8,f);for(let x=1;x<9;x+=2)E.object(p,'sink',x,1,f);return E.validate(p)}
function line(p,a,b,{system='cold',floor=p.floors[0].id,diameter=.02,aNode,bNode}={}){const elevation=p.floors.find(f=>f.id===floor).elevation;const x=aNode||M.node(p,system,'junction',floor,a.x,a.y,a.z-elevation),y=bNode||M.node(p,system,'junction',floor,b.x,b.y,b.z-elevation);return M.connect(p,x.id,y.id,{routing:'direct',diameter})}
test('shared routing reduces all populated system lengths on a fixed residential fixture',()=>{
 const p=house(),old=M.generateHomeRuns(p),next=M.generate(p),before=new Map(M.schedule(old).map(r=>[r.system,r.length]));
 for(const row of M.schedule(next)){assert.ok(row.length<before.get(row.system)*.65, row.system);const ids=new Set(next.mep.nodes.filter(n=>n.system===row.system).map(n=>n.id));assert.equal(next.mep.runs.filter(r=>r.system===row.system).length,ids.size-1)}
 assert.equal(M.checks(next).filter(i=>['uphill','disconnected','source'].includes(i.code)).length,0);assert.equal(M.clashes(next).issues.filter(i=>i.code==='overlap').length,0);
});
test('optimization preserves source and terminal identities, user values and unselected systems',()=>{
 const p=M.generateHomeRuns(house()),before=JSON.stringify(p),keep=p.mep.nodes.filter(n=>n.system==='cold'&&n.kind!=='junction');keep[0].flowLpm=7;const snapshot=E.clone(p);
 const q=M.optimize(p,{selected:['cold']});assert.equal(JSON.stringify(p),JSON.stringify(snapshot));assert.notEqual(before,JSON.stringify(snapshot));
 for(const node of keep)assert.deepEqual(q.mep.nodes.find(n=>n.id===node.id),node);
 assert.deepEqual(q.mep.nodes.filter(n=>n.system!=='cold'),p.mep.nodes.filter(n=>n.system!=='cold'));assert.deepEqual(q.mep.runs.filter(n=>n.system!=='cold'),p.mep.runs.filter(n=>n.system!=='cold'));
});
test('repeat optimization is geometrically idempotent and near-identical coordinates do not self-connect',()=>{
 const p=M.generate(house()),q=M.optimize(p),r=M.optimize(q);const geometry=v=>M.schedule(v).map(row=>({system:row.system,length:+row.length.toFixed(6),nodes:row.nodes,runs:row.runs}));assert.deepEqual(geometry(q),geometry(r));
 assert.ok(q.mep.runs.every(r=>r.a!==r.b));const cold=p.mep.nodes.filter(n=>n.system==='cold'&&n.kind==='inlet');cold[1].x=cold[0].x+1e-10;assert.doesNotThrow(()=>M.optimize(p,{selected:['cold']}));
});
test('shared multi-floor shaft has no duplicate risers and drain graph reaches its fixed outlet',()=>{
 const p=house();E.duplicateFloor(p,p.floors[0].id);E.duplicateFloor(p,p.floors[1].id);const q=M.generate(p);
 assert.equal(M.clashes(q).issues.filter(i=>i.code==='overlap').length,0);assert.equal(M.checks(q).filter(i=>['uphill','disconnected'].includes(i.code)).length,0);
 const outlet=q.mep.nodes.find(n=>n.kind==='drainOutlet');outlet.z=2;const r=M.optimize(q,{selected:['drain']});assert.equal(r.mep.nodes.find(n=>n.id===outlet.id).z,2);assert.ok(M.checks(r).some(i=>i.code==='uphill'));assert.ok(!M.checks(r).some(i=>i.code==='disconnected'&&M.item(r,i.type,i.id)?.system==='drain'));
});
test('routing refuses ambiguous or absent sources atomically and respects indirect system locks',()=>{
 const p=M.generate(house()),n=p.mep.nodes.find(n=>n.kind==='waterMeter');M.node(p,'cold','waterMeter',n.floor,n.x+1,n.y,n.z);const before=JSON.stringify(p);assert.throws(()=>M.optimize(p,{selected:['cold']}),/一个源点/);assert.equal(JSON.stringify(p),before);
 const q=M.generateHomeRuns(house()),next=M.optimize(q,{selected:['cold']}),s={...W.defaults(),locks:{mep_cold:true}};assert.throws(()=>W.assertEditable(q,next,s),/冷水/);
});
test('closest segment computation handles skew, parallel, degenerate and endpoint distances',()=>{
 close(M.closestSegments({x:0,y:0,z:0},{x:4,y:0,z:0},{x:2,y:-2,z:.3},{x:2,y:2,z:.3}).distance,.3);
 close(M.closestSegments({x:0,y:0,z:0},{x:4,y:0,z:0},{x:2,y:1,z:0},{x:6,y:1,z:0}).distance,1);
 close(M.closestSegments({x:0,y:0,z:0},{x:0,y:0,z:0},{x:2,y:0,z:0},{x:6,y:0,z:0}).distance,2);
});
test('pipe collisions distinguish different elevations, shared fittings and real overlap',()=>{
 const p=E.newProject('Crossing');line(p,{x:0,y:0,z:2},{x:4,y:0,z:2});line(p,{x:2,y:-2,z:2},{x:2,y:2,z:2},{system:'hot'});assert.equal(M.clashes(p).issues.filter(i=>i.code==='pipe').length,1);
 p.mep.nodes.filter(n=>n.system==='hot').forEach(n=>n.z+=.1);assert.equal(M.clashes(p).issues.length,0);
 const q=E.newProject('Tee'),r=line(q,{x:0,y:0,z:2},{x:4,y:0,z:2}),tee=M.item(q,'mepNode',r.b);line(q,null,{x:4,y:3,z:2},{aNode:tee});assert.equal(M.clashes(q).issues.length,0);
 line(q,{x:1,y:0,z:2},{x:3,y:0,z:2});assert.ok(M.clashes(q).issues.some(i=>i.code==='overlap'));
});
test('connected records do not conceal overlapping pipe lengths away from their shared endpoint',()=>{
 const p=E.newProject('Overlap'),r=line(p,{x:0,y:0,z:1},{x:4,y:0,z:1}),tee=M.item(p,'mepNode',r.a);line(p,null,{x:3,y:0,z:1},{aNode:tee});assert.ok(M.clashes(p).issues.some(i=>i.code==='overlap'));
});
test('wall collision checks use actual opening void and pipe diameter at the reveal',()=>{
 const p=E.newProject('Opening'),f=p.floors[0].id,w=E.wall(p,{x:3,y:0},{x:3,y:6},f),o=E.opening(p,w.id,.5,'door');o.width=1;o.offset=2.5;o.height=2.1;E.validate(p);
 const r=line(p,{x:1,y:3,z:1},{x:5,y:3,z:1});assert.equal(M.clashes(p).issues.filter(i=>i.code==='wall').length,0);
 M.item(p,'mepNode',r.a).y=1;M.item(p,'mepNode',r.b).y=1;assert.equal(M.clashes(p).issues.filter(i=>i.code==='wall').length,1);
 M.item(p,'mepNode',r.a).y=2.505;M.item(p,'mepNode',r.b).y=2.505;assert.equal(M.clashes(p).issues.filter(i=>i.code==='wall').length,1);
});
test('floor penetration distinguishes solid slab, clear hole and pipe touching hole rim',()=>{
 const p=house(),f=p.floors[0].id;p.objects=[];p.slabOpenings=[{id:E.uid(),floor:f,points:[{x:4,y:3},{x:6,y:3},{x:6,y:5},{x:4,y:5}],guard:false,guardHeight:1.05}];
 const r=line(p,{x:5,y:4,z:-1},{x:5,y:4,z:1});assert.equal(M.clashes(p).issues.filter(i=>i.code==='slab').length,0);
 M.item(p,'mepNode',r.a).x=2;M.item(p,'mepNode',r.b).x=2;assert.equal(M.clashes(p).issues.filter(i=>i.code==='slab').length,1);
 M.item(p,'mepNode',r.a).x=4.005;M.item(p,'mepNode',r.b).x=4.005;assert.equal(M.clashes(p).issues.filter(i=>i.code==='slab').length,1);
});
test('rotated object envelope detects collisions and excludes intentional host connection',()=>{
 const p=E.newProject('Cabinet'),f=p.floors[0].id,o=E.object(p,'baseCabinet',2,2,f);o.angle=45;
 const r=line(p,{x:0,y:2.3,z:.5},{x:5,y:2.3,z:.5});assert.equal(M.clashes(p).issues.filter(i=>i.code==='object').length,1);
 const b=M.item(p,'mepNode',r.b);b.fixtureId=o.id;b.x=0;b.y=0;assert.equal(M.clashes(p).issues.filter(i=>i.code==='object').length,0);
});
test('clash report is bounded, declares truncation and contains navigation evidence',()=>{
 const p=E.newProject('Many');for(let i=0;i<5;i++)line(p,{x:0,y:0,z:1},{x:5,y:0,z:1});const r=M.clashes(p,{limit:2});assert.equal(r.issues.length,2);assert.equal(r.truncated,true);for(const issue of r.issues){assert.ok(issue.id&&issue.otherId);assert.ok(Object.values(issue.point).every(Number.isFinite))}
});
test('optimized geometry remains identical through save/reload and DXF contains shared direct segments',()=>{
 const p=M.generate(house()),q=E.validate(JSON.parse(JSON.stringify(p)));assert.deepEqual(M.schedule(q),M.schedule(p));assert.deepEqual(M.clashes(q),M.clashes(p));
 const dxf=E.dxfExport(q,q.floors[0].id),segments=q.mep.runs.reduce((v,r)=>v+M.path(q,r).length-1,0);assert.equal((dxf.match(/\nMEP_/g)||[]).length,segments);
});
test('nested branches and terminals on the source stem share physical segments once',()=>{
 for(const points of [[[2,2],[2,4],[5,0],[8,0],[10,0]],[[0,1],[0,3],[2,5],[4,5],[6,5]]]){
  const p=E.newProject('Shared branches'),f=p.floors[0].id;M.node(p,'cold','waterMeter',f,0,0,1);for(const [x,y]of points)M.node(p,'cold','inlet',f,x,y,.5);
  const q=M.optimize(p,{selected:['cold']});assert.equal(M.checks(q).filter(i=>i.code==='disconnected').length,0);assert.equal(M.clashes(q).issues.filter(i=>i.code==='overlap').length,0);
  assert.equal(q.mep.runs.length,q.mep.nodes.length-1);
 }
});
test('negative zero and coordinate quantization boundaries cannot disconnect terminals',()=>{
 for(const [sourceX,portX]of [[0,-1e-8],[4.9e-7,5.1e-7],[0,1e-8],[-4.9e-7,-5.1e-7]]){
  const p=E.newProject('Near coordinates'),f=p.floors[0].id;M.node(p,'cold','waterMeter',f,sourceX,0,1);for(const [x,y]of [[portX,1],[5,0],[10,0]])M.node(p,'cold','inlet',f,x,y,.5);
  const q=M.optimize(p,{selected:['cold']});assert.equal(M.checks(q).filter(i=>i.code==='disconnected').length,0);assert.equal(q.mep.runs.length,q.mep.nodes.length-1);
 }
});
test('short perpendicular pipes collide and closest distance is scale invariant',()=>{
 for(const scale of [.001,.01,1,1000]){
  const a={x:0,y:0,z:0},b={x:scale,y:0,z:0},c={x:scale/2,y:-scale/2,z:0},d={x:scale/2,y:scale/2,z:0};close(M.closestSegments(a,b,c,d).distance,0);
  close(M.closestSegments(a,b,{...c,z:scale/5},{...d,z:scale/5}).distance/scale,.2);
 }
 const p=E.newProject('Small pipes');line(p,{x:0,y:0,z:1},{x:.01,y:0,z:1},{diameter:.002});line(p,{x:.005,y:-.005,z:1},{x:.005,y:.005,z:1},{system:'hot',diameter:.002});E.validate(p);assert.equal(M.clashes(p).issues.filter(i=>i.code==='pipe').length,1);
});
test('intermediate floor riser clash navigates to collision floor and marker stays there',()=>{
 const p=E.newProject('Riser'),f=p.floors[0];E.duplicateFloor(p,f.id);E.duplicateFloor(p,p.floors[1].id);p.floors.forEach((f,i)=>f.elevation=i*3);
 const middle=p.floors[1],top=p.floors[2],a=M.node(p,'cold','waterMeter',f.id,30,1,1),b=M.node(p,'cold','inlet',top.id,30,1,1),r=M.connect(p,a.id,b.id,{routing:'direct'});E.wall(p,{x:30,y:0},{x:30,y:2},middle.id);E.validate(p);
 const report=M.clashes(p),index=report.issues.findIndex(i=>i.code==='wall'),issue=report.issues[index];assert.ok(issue);assert.equal(issue.floor,middle.id);
 const s={...W.defaults(),floor:f.id},callbacks={},context={BIM:E,MEP:M,WorkspaceModel:W,Units:{length:String},Drawings:{esc:String},document:{addEventListener:(event,fn)=>callbacks[event]=fn}};context.window=context;
 require('node:vm').runInNewContext(require('node:fs').readFileSync('dist/mep-ui.js','utf8'),context);
 context.MEPUI.init({state:()=>({p,s}),dialog(){},close(){},refresh(){},toast:message=>assert.fail(message),select(type,id){s.selected={type,id};s.floor=M.item(p,type,id).floor}});
 context.MEPUI.action('clashes');callbacks.click({target:{closest:()=>({dataset:{mepClash:String(index)}})}});
 assert.equal(s.floor,middle.id);assert.equal(s.selected.id,r.id);assert.equal(s.mepClash.floor,middle.id);
 assert.ok(M.plan(p,s).includes('#ff5d3322'));assert.ok(M.plan(p,s).includes(r.id));assert.ok(M.floorPaths(p,r,middle.id).length);assert.ok(M.bounds(p,middle.id).x+M.bounds(p,middle.id).w>=30);
 assert.ok(E.dxfExport(p,middle.id).includes('MEP_CW'));s.floor=f.id;assert.ok(!M.plan(p,s).includes('#ff5d3322'));
});
test('terminal drops and source risers at the same XY share vertical intervals',()=>{
 for(const system of ['cold','drain'])for(const points of [[[0,0,.5],[2,0,.5]],[[2,0,.5],[2,0,1.5]],[[2,0,.5],[2,0,.5]]]){
  const p=E.newProject('Vertical union'),f=p.floors[0].id,source=M.node(p,system,M.systems[system].source,f,0,0,system==='drain'?-2:1);
  for(const [x,y,z]of points)M.node(p,system,system==='drain'?'waste':'inlet',f,x,y,z);
  const q=M.optimize(p,{selected:[system]});assert.equal(M.checks(q).filter(i=>['disconnected','uphill'].includes(i.code)).length,0);assert.equal(M.clashes(q).issues.filter(i=>i.code==='overlap').length,0);assert.equal(q.mep.runs.length,q.mep.nodes.length-1);assert.deepEqual(q.mep.nodes.find(n=>n.id===source.id),source);
 }
});
test('intermediate-floor 3D renders the clipped riser and adjacent floors never double the mesh length',()=>{
 const p=E.newProject('3D riser');for(let i=0;i<3;i++)E.duplicateFloor(p,p.floors.at(-1).id);p.floors.forEach((f,i)=>f.elevation=i*3);
 const a=M.node(p,'cold','waterMeter',p.floors[0].id,1,1,1),b=M.node(p,'cold','inlet',p.floors[3].id,1,1,1),r=M.connect(p,a.id,b.id,{routing:'direct'});
 const THREE=require('../dist/vendor/three.min.js'),context={THREE,BIM:E,MEP:M};context.window=context;require('node:vm').runInNewContext(require('node:fs').readFileSync('dist/view3d.js','utf8'),context);
 const view=Object.create(context.BuildingView.prototype);view.model=new THREE.Group();view.mepMesh(p,{layers:{}},new Set([p.floors[1].id]));const g=view.model.children.find(g=>g.userData.entity.id===r.id);assert.ok(g&&g.children.length);close(g.children.reduce((v,m)=>v+m.geometry.parameters.height,0),p.floors[1].height+p.floors[1].slab);
 const visible=new Set([p.floors[1].id,p.floors[2].id]),parts=M.visiblePaths(p,r,visible),len=parts.reduce((v,ps)=>v+ps.at(-1).z-ps[0].z,0);close(len,p.floors[2].elevation+p.floors[2].height-(p.floors[1].elevation-p.floors[1].slab));
});
