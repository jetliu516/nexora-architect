const test=require('node:test'),assert=require('node:assert/strict');
const E=require('../dist/geometry'),Roof=require('../dist/roof-model'),Footprint=require('../dist/roof-footprint');
test('labeling only an inner courtyard does not turn the surrounding living room into a deck',()=>{
 const p=E.newProject(),f=p.floors[0].id;E.addRectangle(p,0,0,10,10,f);E.addRectangle(p,3,3,3,3,f);
 const inner=E.detectRooms(p,f).find(r=>r.area<10);E.roomMeta(p,inner,{name:'Courtyard',roomType:'deck',includeLiving:false});
 const rooms=E.detectRooms(p,f),outside=rooms.find(r=>r.area>10);
 assert.equal(outside.roomType,'living');assert.equal(outside.area,91);assert.notEqual(outside.name,'Courtyard');
 Footprint.generate(p,f,{type:'flat',overhang:0});assert.ok(Math.abs(Roof.build(p).area-91)<1e-8);
});
test('stable outer labels are not copied into newly enclosed inner rooms, while moved room labels are recovered',()=>{
 const p=E.newProject(),f=p.floors[0].id;E.addRectangle(p,0,0,10,10,f);let r=E.detectRooms(p,f)[0];E.roomMeta(p,r,{name:'Family Room',roomType:'living'});
 E.addRectangle(p,3,3,3,3,f);let rooms=E.detectRooms(p,f);assert.equal(rooms.find(r=>r.area>10).name,'Family Room');assert.notEqual(rooms.find(r=>r.area<10).name,'Family Room');
 const inner=rooms.find(r=>r.area<10);E.roomMeta(p,inner,{name:'Pantry',roomType:'kitchen'});
 E.moveNode(p,f,{x:6,y:3},{x:7,y:3});E.moveNode(p,f,{x:6,y:6},{x:7,y:6});rooms=E.detectRooms(p,f);
 assert.equal(rooms.find(r=>r.area<20).name,'Pantry');assert.equal(rooms.find(r=>r.area>20).name,'Family Room');
});
