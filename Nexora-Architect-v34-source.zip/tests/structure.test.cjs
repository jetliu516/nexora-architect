const test=require('node:test'),assert=require('node:assert/strict');
const E=require('../dist/geometry.js'),S=require('../dist/structure.js');
test('structure persists and rejects invalid floor and section',()=>{const p=E.demo();p.structure=S.data(p);p.structure.members.push({id:'s1',floor:p.floors[0].id,kind:'beam',x1:0,y1:0,x2:3,y2:0,z:2.7,width:.09,depth:.24,material:'TBD',note:'<script>'});assert.equal(S.validate(E.validate(p)).structure.members.length,1);assert.ok(S.sheet(p,p.floors[0].id).includes('NOT FOR CONSTRUCTION'));assert.ok(!S.panel(p,p.floors[0].id).includes('<script>'));p.structure.members[0].width=0;assert.throws(()=>S.validate(p));p.structure.members[0].width=.09;p.structure.members[0].floor='missing';assert.throws(()=>S.validate(p));});

test('duplicating a real floor preserves every structural member with independent identity and editable data',()=>{
 const p=E.newProject('Structural floor copy'),source=p.floors[0];
 E.addRectangle(p,0,0,6,5,source.id);
 const other={...source,id:E.uid(),name:'Unrelated floor',elevation:3};p.floors.push(other);
 E.addRectangle(p,10,0,4,4,other.id);
 p.structure={...S.data(p),jurisdiction:'Fixture AHJ',code:'Fixture code',loads:'Fixture loads'};
 for(const [i,kind]of Object.keys(S.kinds).entries())p.structure.members.push({
  id:'member-'+i,floor:source.id,kind,x1:.5,y1:.5+i*.5,x2:kind==='post'?.5:5,y2:.5+i*.5,
  z:kind==='footing'?-.3:2.7,width:.09,depth:.24,material:'Douglas Fir No. 2',note:'Connection S-'+i,
  detail:{connection:{reference:'S-'+i},attachments:['fixture-'+i]}
 });
 p.structure.members.push({...E.clone(p.structure.members[0]),id:'other-member',floor:other.id});
 const original=E.clone(p.structure),sourceMembers=p.structure.members.filter(m=>m.floor===source.id);
 const upper=E.duplicateFloor(p,source.id),copies=p.structure.members.filter(m=>m.floor===upper.id);
 assert.equal(p.walls.filter(w=>w.floor===upper.id).length,4);
 assert.equal(copies.length,Object.keys(S.kinds).length);
 assert.equal(p.structure.members.length,original.members.length+sourceMembers.length);
 assert.deepEqual(p.structure.members.filter(m=>m.floor!==upper.id),original.members);
 assert.equal(new Set(p.structure.members.map(m=>m.id)).size,p.structure.members.length);
 for(const member of sourceMembers){
  const copy=copies.find(m=>m.kind===member.kind);assert.ok(copy);assert.notEqual(copy.id,member.id);
  assert.deepEqual({...copy,id:member.id,floor:member.floor},member);
 }
 assert.deepEqual(E.validate(p).structure,p.structure);
 const originalBeam=sourceMembers.find(m=>m.kind==='beam'),copyBeam=copies.find(m=>m.kind==='beam');
 copyBeam.width=.14;copyBeam.detail.connection.reference='Upper connection';copyBeam.detail.attachments.push('upper');
 assert.equal(originalBeam.width,.09);assert.equal(originalBeam.detail.connection.reference,'S-1');assert.equal(originalBeam.detail.attachments.length,1);
 originalBeam.note='Lower beam only';originalBeam.x2=4.5;
 assert.equal(copyBeam.note,'Connection S-1');assert.equal(copyBeam.x2,5);
 const saved=E.validate(JSON.parse(JSON.stringify(p)));
 assert.equal(saved.structure.members.find(m=>m.id===copyBeam.id).width,.14);
 assert.equal(saved.structure.members.find(m=>m.id===originalBeam.id).x2,4.5);
 assert.deepEqual(saved.structure.members.find(m=>m.id==='other-member'),original.members.at(-1));
});

test('copying a floor without structural members keeps the project without structural data',()=>{
 const p=E.newProject('No structural draft');E.addRectangle(p,0,0,4,4,p.floors[0].id);
 E.duplicateFloor(p,p.floors[0].id);assert.equal(p.structure,undefined);assert.equal(E.validate(p).floors.length,2);
});
