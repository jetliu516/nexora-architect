const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const E = require('../dist/geometry.js');
const S = require('../dist/sheets.js');
const W = require('../dist/workspace-model.js');
const M = globalThis.MEP;
const D = globalThis.Drawings;
const U = require('../dist/units.js');

function fixture() {
  const p = E.newProject('Independent layout audit'), f = p.floors[0].id;
  E.addRectangle(p, 0, 0, 6, 4, f);
  const sh = S.create(p), v = S.add(p, sh, {kind: 'plan', floor: f, layers: W.defaults().layers});
  return {p: E.validate(p), f, sheetId: sh.id, viewId: v.id};
}
function drawingTransform(markup) {
  const m = markup.match(/<g transform="scale\(([^)]+)\) rotate\(([^)]+)\) translate\(([^ ]+) ([^)]+)\)">/);
  assert.ok(m, 'a geometric viewport must have an explicit model-to-paper transform');
  const [scale, degrees, tx, ty] = m.slice(1).map(Number), a = degrees*Math.PI/180;
  return q => ({x: scale*((q.x+tx)*Math.cos(a)-(q.y+ty)*Math.sin(a)), y: scale*((q.x+tx)*Math.sin(a)+(q.y+ty)*Math.cos(a))});
}
function ui(p) {
  const handlers = {}, messages = [], pane = {innerHTML: ''}, dialogs = [];
  let writable = true, stored = null;
  const context = {setTimeout, BIM: E, E, Sheets: S, WorkspaceModel: W, WM: W, MEP: M,
    Penetrations: globalThis.Penetrations, Drawings: D, Units: U,
    p, s: {...W.defaults(), mode: 'layout', floor: p.floors[0].id}, history: [], future: [], drag: null,
    endDrag() {return true;},
    document: {addEventListener: (type, fn) => handlers[type] = fn, getElementById: () => pane},
    FormData: class {constructor(form) {this.values = form.values || {};} get(k) {return this.values[k] ?? null;} has(k) {return Object.hasOwn(this.values, k);}},
    toast: message => messages.push(message),
    save() {if (!writable) return false; stored = E.clone(context.p); return true;},
    refresh() {context.SheetUI?.render();}};
  context.window = context;
  vm.createContext(context);
  const workbench = fs.readFileSync(path.join(root, 'dist/workbench.js'), 'utf8').split('\n');
  for (const name of ['transact', 'travelHistory']) vm.runInContext(workbench.find(line => line.startsWith('function '+name+'(')), context);
  vm.runInContext(fs.readFileSync(path.join(root, 'dist/sheet-ui.js'), 'utf8'), context);
  context.SheetUI.init({state: () => ({p: context.p, s: context.s}), transact: context.transact,
    refresh: context.refresh, toast: context.toast, dialog: (...args) => dialogs.push(args), close() {},
    select() {}, printHtml() {}, exportFile() {}});
  context.SheetUI.render(); // The live layout renders once before a user can select a sheet tab.
  return {context, handlers, messages, pane, dialogs, allowSave: v => writable = v, stored: () => stored};
}

test('audit: 6 model meters measure 60 paper mm at 1:100 through rotation and crop', () => {
  const {p} = fixture(), sh = p.sheets[0], v = sh.views[0];
  for (const rotation of [0, 90, 180, 270]) {
    Object.assign(v, {scale: 100, rotation, cx: 3, cy: 2, w: 120, h: 90});
    const markup = S.svg(p, sh), transform = drawingTransform(markup);
    assert.match(markup, /width="420mm" height="297mm" viewBox="0 0 420 297"/);
    const a = transform({x: 0, y: 0}), b = transform({x: 6, y: 0});
    assert.ok(Math.abs(Math.hypot(b.x-a.x, b.y-a.y)-60) < 1e-8);
    v.w = 50; v.h = 50;
    const cropped = S.svg(p, sh), after = drawingTransform(cropped);
    assert.deepEqual(after({x: 6, y: 0}), b, 'resizing changes only viewport clipping');
    assert.match(cropped, /width="50" height="42" viewBox="-25 -21 50 42" overflow="hidden"/);
    v.scale = 50;
    const doubled = drawingTransform(S.svg(p, sh));
    const c = doubled({x: 0, y: 0}), d = doubled({x: 6, y: 0});
    assert.ok(Math.abs(Math.hypot(d.x-c.x, d.y-c.y)-120) < 1e-8);
  }
});

test('audit: fit respects rotation and model changes update content without changing composition', () => {
  const {p, f} = fixture(), sh = p.sheets[0], v = sh.views[0];
  Object.assign(v, {w: 100, h: 140, rotation: 90}); S.fit(p, v);
  const bounds = S.source(p, v).box;
  assert.ok(bounds.h*1000/v.scale <= v.w-4+1e-8);
  assert.ok(bounds.w*1000/v.scale <= v.h-12+1e-8);
  const record = JSON.stringify(v), old = S.source(p, v).markup;
  E.wall(p, {x: 20, y: 0}, {x: 25, y: 0}, f);
  assert.notEqual(S.source(p, v).markup, old);
  assert.equal(JSON.stringify(v), record);
  const upper = E.duplicateFloor(p, f), lowerMarkup = S.source(p, v).markup;
  p.walls.find(w => w.floor === upper.id).height += .2;
  assert.equal(S.source(p, v).markup, lowerMarkup, 'a lower-floor source remains bound to that floor');
});

test('audit: source floor can disappear without deleting layout, with explicit error and blocked export', () => {
  const {p} = fixture(), sh = p.sheets[0], v = sh.views[0];
  v.source.floor = 'missing-floor';
  assert.doesNotThrow(() => E.validate(p));
  assert.equal(S.inspect(p, sh)[0].level, 'error');
  assert.match(S.svg(p, sh), /源楼层已删除/);
  assert.throws(() => S.printHTML(p), /失联视口/);
  v.source.floor = p.floors[0].id;
  assert.doesNotThrow(() => S.printHTML(p));
});

test('audit: legacy source identifiers remain usable for floor and drainage sources', () => {
  for (const id of ['floor:main.1', 'f'.repeat(150)]) {
    const p = E.newProject('Legacy source ID'); p.floors[0].id = id;
    E.addRectangle(p, 0, 0, 6, 4, id); assert.doesNotThrow(() => E.validate(p));
    const sh = S.create(p); S.add(p, sh, {kind: 'plan', floor: id, layers: W.defaults().layers});
    assert.doesNotThrow(() => E.validate(p));
    const a = M.node(p, 'drain', 'waste', id, 1, 1, 1), b = M.node(p, 'drain', 'drainOutlet', id, 3, 1, .5);
    const run = M.connect(p, a.id, b.id, {routing: 'direct'}); run.id = 'run:drain.1';
    S.add(p, sh, {kind: 'profile', runId: run.id});
    assert.doesNotThrow(() => E.validate(p));
  }
});

test('audit: sheet copy, reorder and JSON round trip preserve sources with independent identities', () => {
  const {p} = fixture(), sh = p.sheets[0], original = E.clone(sh);
  const duplicate = S.duplicate(p, sh); duplicate.title = 'Copied'; duplicate.views[0].cx += 2;
  assert.deepEqual(sh, original);
  assert.notEqual(duplicate.id, sh.id); assert.notEqual(duplicate.views[0].id, sh.views[0].id);
  p.sheets.reverse(); const q = E.validate(JSON.parse(JSON.stringify(p)));
  assert.deepEqual(q.sheets, p.sheets);
  assert.equal(q.sheets[0].id, duplicate.id);
  assert.deepEqual(q.sheets[1].views[0].source, original.views[0].source);
});

test('audit: sheet text is escaped and duplicate IDs, invalid values and oversized collections are rejected', () => {
  const {p} = fixture(), sh = p.sheets[0];
  const malicious = '<img src=x onerror="alert(1)">';
  sh.title = malicious; sh.notes = malicious; sh.number = '<script>x</script>'; sh.views[0].title = malicious;
  assert.doesNotThrow(() => E.validate(p));
  const svg = S.svg(p, sh), html = S.printHTML(p);
  for (const output of [svg, html]) {assert.ok(!output.includes('<img')); assert.ok(!output.includes('<script>')); assert.ok(output.includes('&lt;img'));}
  const mutations = [q => q.sheets[0].id = q.walls[0].id,
    q => q.sheets[0].views[0].id = q.sheets[0].id, q => q.sheets[0].views[0].scale = Infinity,
    q => q.sheets[0].views[0].source.layers = {__bad: true}, q => q.sheets[0].views[0].source.floor = '<script>',
    q => q.sheets[0].notes = 'x'.repeat(501), q => q.sheets = Array(101).fill(q.sheets[0]),
    q => q.sheets[0].views = Array(21).fill(q.sheets[0].views[0])];
  for (const mutate of mutations) {const q = E.clone(p); mutate(q); assert.throws(() => E.validate(q));}
});

test('audit: automatic MEP schedules cover every row exactly once across page boundaries', () => {
  const p = E.newProject('Schedule pagination'), f = p.floors[0].id;
  for (let i = 0; i < 51; i++) {
    const a = M.node(p, 'cold', 'waterMeter', f, i, 0, 1), b = M.node(p, 'cold', 'inlet', f, i, .5, 1);
    M.connect(p, a.id, b.id, {routing: 'direct', label: 'AUDIT-RUN-'+String(i).padStart(3, '0')});
  }
  const h = ui(p); h.context.SheetUI.generate(p, h.context.s);
  const views = p.sheets.flatMap(s => s.views).filter(v => v.source.kind === 'mepSchedule');
  assert.equal(views.length, 3);
  const markup = views.map(v => S.source(p, v).markup).join('');
  const rows = [...markup.matchAll(/>AUDIT-RUN-\d{3}<\/text>/g)].map(m => m[0]);
  assert.equal(rows.length, 51); assert.equal(new Set(rows).size, 51);
});

test('audit: index pagination includes all index sheets themselves at the 50-page boundary', () => {
  const p = E.newProject('Index boundary'); for (let i = 0; i < 46; i++) S.create(p);
  const h = ui(p); h.context.SheetUI.generate(p, h.context.s);
  const index = p.sheets.flatMap(s => s.views).filter(v => v.source.kind === 'index');
  const covered = new Set(index.flatMap(v => Array.from({length: v.source.rowCount}, (_, i) => v.source.rowStart+i)));
  assert.ok(p.sheets.every((_, i) => covered.has(i)), 'the generated index must cover its own final page');
  assert.equal(S.source(p, index.at(-1)).more, false);
});

test('audit: print HTML uses physical sheet dimensions and requested page ordering', () => {
  const {p} = fixture(); const first = p.sheets[0], second = S.duplicate(p, first), third = S.duplicate(p, first);
  first.title = 'AUDIT-FIRST'; second.title = 'AUDIT-SECOND'; third.title = 'AUDIT-THIRD';
  second.paper = 'ANSI B'; second.views[0].w = 200; second.views[0].h = 100;
  const html = S.printHTML(p, [second, first]);
  assert.equal((html.match(/<section class="print-sheet">/g)||[]).length, 2);
  assert.match(html, /@page sheet0\{size:431\.8mm 279\.4mm;margin:0\}/);
  assert.match(html, /@page sheet1\{size:420mm 297mm;margin:0\}/);
  assert.ok(html.indexOf('AUDIT-SECOND') < html.indexOf('AUDIT-FIRST'));
  assert.ok(!html.includes('AUDIT-THIRD'));
});

test('audit: real drag transaction rolls back storage failure and supports undo/redo without losing composition', () => {
  const {p} = fixture(); Object.assign(p.sheets[0].views[0], {w: 100, h: 100, scale: 100});
  const h = ui(p), c = h.context, id = p.sheets[0].views[0].id;
  const attrs = {}, el = {dataset: {sheetView: id}, ownerSVGElement: {getBoundingClientRect: () => ({width: 840})},
    setPointerCapture() {}, setAttribute: (key, value) => attrs[key] = value};
  const start = () => h.handlers.pointerdown({target: {closest: () => el}, button: 0, pointerId: 1, clientX: 100, clientY: 100});
  const move = (x, y) => h.handlers.pointermove({clientX: x, clientY: y});
  const before = JSON.stringify(c.p); h.allowSave(false); start(); move(120, 100); h.handlers.pointerup();
  assert.equal(JSON.stringify(c.p), before); assert.equal(c.history.length, 0); assert.equal(h.stored(), null);
  assert.equal(attrs.transform, 'translate(10 10)');
  h.allowSave(true); start(); move(120, 100); h.handlers.pointerup();
  assert.equal(c.p.sheets[0].views[0].x, 20); assert.equal(c.history.length, 1);
  assert.equal(c.p.sheets[0].views[0].scale, 100);
  assert.equal(c.travelHistory(), true); assert.equal(c.p.sheets[0].views[0].x, 10);
  assert.equal(c.travelHistory(true), true); assert.equal(c.p.sheets[0].views[0].x, 20);
  const after = JSON.stringify(c.p); start(); move(10000, 100); h.handlers.pointerup();
  assert.equal(JSON.stringify(c.p), after, 'out-of-frame drag must roll back');
  start(); move(130, 100); c.p.name += ' changed'; const stale = JSON.stringify(c.p); h.handlers.pointerup();
  assert.equal(JSON.stringify(c.p), stale); assert.ok(h.messages.some(m => m.includes('模型已变化')));
});

test('audit: stale sheet property form cannot overwrite a newer model', () => {
  const {p} = fixture(), h = ui(p); h.context.SheetUI.act('properties'); h.context.p.name = 'Newer model';
  const before = JSON.stringify(h.context.p);
  h.handlers.submit({target: {id: 'sheetProperties', dataset: {id: p.sheets[0].id}, values: {}}, preventDefault() {}});
  assert.equal(JSON.stringify(h.context.p), before); assert.equal(h.context.history.length, 0);
  assert.ok(h.messages.some(m => m.includes('模型已变化')));
});

test('audit: dimension command toggles every plan viewport on the selected sheet only and supports undo', () => {
  const {p, f} = fixture(), otherId = p.sheets[0].id;
  const chosen = S.create(p), chosenId = chosen.id;
  S.add(p, chosen, {kind: 'plan', floor: f, layers: {...W.defaults().layers, dimensions: false}});
  S.add(p, chosen, {kind: 'plan', floor: f, layers: {...W.defaults().layers, dimensions: true}});
  S.add(p, chosen, {kind: 'elevation', direction: 'front'});
  const h = ui(p), c = h.context;
  c.SheetUI.act('select', chosenId);
  const before = E.clone(c.p), workspaceLayers = JSON.stringify(c.s.layers);
  c.SheetUI.act('dimensions');
  let page = S.item(c.p, chosenId);
  assert.ok(page.views.filter(v => v.source.kind === 'plan').every(v => v.source.layers.dimensions === true));
  assert.deepEqual(S.item(c.p, otherId), S.item(before, otherId));
  assert.deepEqual(page.views.find(v => v.source.kind === 'elevation'), chosen.views.find(v => v.source.kind === 'elevation'));
  assert.equal(JSON.stringify(c.s.layers), workspaceLayers, 'the live plan workspace keeps its independent layers');
  assert.ok(h.messages.includes('当前图纸自动尺寸已显示'));
  c.SheetUI.act('dimensions'); page = S.item(c.p, chosenId);
  assert.ok(page.views.filter(v => v.source.kind === 'plan').every(v => v.source.layers.dimensions === false));
  assert.ok(S.item(h.stored(), chosenId).views.filter(v => v.source.kind === 'plan').every(v => v.source.layers.dimensions === false));
  assert.ok(h.messages.includes('当前图纸自动尺寸已隐藏'));
  assert.equal(c.travelHistory(), true);
  assert.ok(S.item(c.p, chosenId).views.filter(v => v.source.kind === 'plan').every(v => v.source.layers.dimensions === true));
});

test('audit: dimension command on a sheet without plan viewports reports the limit without editing another sheet', () => {
  const {p} = fixture(), onlyElevation = S.create(p);
  S.add(p, onlyElevation, {kind: 'elevation', direction: 'front'});
  const h = ui(p), c = h.context; c.SheetUI.act('select', onlyElevation.id);
  const before = JSON.stringify(c.p);
  c.SheetUI.act('dimensions');
  assert.equal(JSON.stringify(c.p), before); assert.equal(c.history.length, 0); assert.equal(h.stored(), null);
  assert.ok(h.messages.some(m => m.includes('当前图纸没有平面视口')));
  c.p.sheets = []; const empty = JSON.stringify(c.p); c.SheetUI.act('dimensions');
  assert.equal(JSON.stringify(c.p), empty); assert.equal(c.history.length, 0);
});

test('audit: failed saving of sheet dimensions rolls back all viewport changes', () => {
  const {p, f} = fixture();
  S.add(p, p.sheets[0], {kind: 'plan', floor: f, layers: {...W.defaults().layers, dimensions: false}});
  const h = ui(p), c = h.context, before = JSON.stringify(c.p);
  h.allowSave(false); c.SheetUI.act('dimensions');
  assert.equal(JSON.stringify(c.p), before); assert.equal(c.history.length, 0); assert.equal(h.stored(), null);
  assert.ok(!h.messages.includes('当前图纸自动尺寸已显示'));
});
