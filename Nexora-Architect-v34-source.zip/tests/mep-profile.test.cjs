const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const E=require('../dist/geometry.js'),M=require('../dist/mep-profile.js'),U=require('../dist/units.js'),W=require('../dist/workspace-model.js');
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-8,`${a} != ${b}`);
function fixture(){const p=E.newProject('Drain profile'),f=p.floors[0].id,a=M.node(p,'drain','waste',f,0,0,3),b=M.node(p,'drain','junction',f,3,4,2.9),c=M.node(p,'drain','drainOutlet',f,3,4,-.2),r=M.connect(p,a.id,b.id,{routing:'direct'}),vertical=M.connect(p,b.id,c.id,{routing:'direct'});return{p,f,a,b,c,r,vertical}}
test('connected drain profile accumulates horizontal station and true 3D length including vertical drop',()=>{
 const {p,a,c,r}=fixture(),before=JSON.stringify(p),v=M.drainProfile(p,{start:a.id,end:c.id});near(v.horizontal,5);near(v.drop,3.2);near(v.length,Math.hypot(5,.1)+3.1);near(v.requiredDrop,.1);assert.equal(v.issues,0);assert.equal(v.segments[1].slope,null);near(v.segments[1].stationStart,5);near(v.segments[1].stationEnd,5);near(v.segments[0].bottomStart,3-r.diameter/2);assert.equal(JSON.stringify(p),before);
});
test('world elevations honor floor elevation and routed points, not just endpoint slope',()=>{
 const {p,a,b,r}=fixture();p.floors[0].elevation=4;r.routing='waypoints';r.waypoints=[{x:2,y:0,z:3.1},{x:2,y:3,z:3.08}];const v=M.drainProfile(p,{runId:r.id});near(v.segments[0].a.z,7);near(v.segments[0].b.z,7.1);assert.equal(v.segments[0].status,'uphill');assert.equal(v.segments[1].status,'slope');assert.equal(v.issues,2);near(v.segments.at(-1).b.z,6.9);assert.equal(v.runIds.length,1);
});
test('directed route selection finds shortest existing path and rejects reverse or disconnected endpoints',()=>{
 const {p,f,a,b,c,r}=fixture(),d=M.node(p,'drain','junction',f,1,0,2.98);M.connect(p,a.id,d.id,{routing:'direct'});M.connect(p,d.id,c.id,{routing:'direct'});M.connect(p,b.id,d.id,{routing:'direct'});const v=M.drainProfile(p,{start:a.id,end:c.id});assert.equal(v.runIds[0],p.mep.runs[2].id);assert.ok(v.branchNodes.includes(a.id));assert.ok(!v.runIds.includes(r.id));assert.throws(()=>M.drainProfile(p,{start:c.id,end:a.id}),/流向/);assert.throws(()=>M.drainProfile(p,{start:a.id,end:a.id}),/不同/);assert.throws(()=>M.drainProfile(p,{runId:'missing'}));
});
test('zero-weight directed cycles terminate and zero-length runs remain explicit issues',()=>{
 const p=E.newProject(),f=p.floors[0].id,n=Array.from({length:4},(_,i)=>M.node(p,'drain',i===3?'drainOutlet':'junction',f,0,0,1));M.connect(p,n[0].id,n[1].id,{routing:'direct'});M.connect(p,n[1].id,n[2].id,{routing:'direct'});M.connect(p,n[2].id,n[0].id,{routing:'direct'});M.connect(p,n[2].id,n[3].id,{routing:'direct'});const v=M.drainProfile(p,{start:n[0].id,end:n[3].id});assert.equal(v.runIds.length,3);assert.equal(v.issues,3);assert.ok(v.segments.every(s=>s.status==='zero'));assert.ok(!/NaN|Infinity/.test(M.profileSVG(p,v)));
});
test('profile selection follows model identities even when two nodes share the same coordinates',()=>{
 const {p,f,a,c}=fixture(),other=M.node(p,'drain','waste',f,0,0,3);assert.throws(()=>M.drainProfile(p,{start:other.id,end:c.id}),/流向/);assert.equal(M.drainProfile(p,{start:a.id,end:c.id}).runIds.length,2);
});
test('profile location chooses a visible floor for below-floor runs and gap-spanning risers',()=>{
 const p=E.newProject(),first=p.floors[0];first.height=2.8;const upper={...first,id:E.uid(),name:'Upper',elevation:4};p.floors.push(upper);
 const a=M.node(p,'drain','waste',upper.id,0,0,-.7),b=M.node(p,'drain','drainOutlet',upper.id,4,0,-.8),r=M.connect(p,a.id,b.id,{routing:'direct'}),report=M.drainProfile(p,{runId:r.id});
 assert.equal(M.floorPaths(p,r,first.id).length,0);const located=M.profileLocation(p,report.segments[0]);assert.equal(located.floor,upper.id);near(located.point.x,2);near(located.point.z,3.25);
 b.floor=first.id;b.z=1;a.z=1;const rise=M.profileLocation(p,M.drainProfile(p,{runId:r.id}).segments[0]);assert.ok(M.floorPaths(p,r,rise.floor).length);const floor=p.floors.find(f=>f.id===rise.floor);assert.ok(rise.point.z>=floor.elevation-floor.slab-1e-8&&rise.point.z<=floor.elevation+floor.height+1e-8);
});
test('CSV retains numerical negative elevations, escapes formulas, and converts all lengths to feet',()=>{
 const {p,a,c,r}=fixture();r.label=' \t=SUM(A1)';p.unit='ft';const report=M.drainProfile(p,{start:a.id,end:c.id}),csv=M.profileCSV(p,report);assert.ok(csv.includes('"\' \t=SUM(A1)"'));assert.ok(csv.includes('"-0.656168"'));assert.ok(!csv.includes("'-0.656168"));assert.ok(csv.includes('"16.404199"'));assert.ok(csv.includes('"0.328084"'));assert.ok(csv.includes('中心标高 ft'));assert.ok(!/NaN|Infinity/.test(csv));
});
test('cross-floor zero-length or wholly invisible connections locate the real start node',()=>{
 const p=E.newProject(),first=p.floors[0];first.height=2.8;const upper={...first,id:E.uid(),elevation:4};p.floors.push(upper);const a=M.node(p,'drain','waste',upper.id,0,0,-1),b=M.node(p,'drain','drainOutlet',first.id,0,0,3),r=M.connect(p,a.id,b.id,{routing:'direct'});
 for(const x of [0,2]){b.x=x;E.validate(p);const v=M.profileLocation(p,M.drainProfile(p,{runId:r.id}).segments[0]);assert.equal(v.type,'mepNode');assert.equal(v.id,a.id);assert.equal(v.floor,upper.id);near(v.point.z,3)}
});
test('SVG escapes project and pipe names, preserves issues, and embeds self-contained vector geometry',()=>{
 const {p,r}=fixture();p.name='<script>alert(1)</script>';r.label='<img onerror="x">';M.item(p,'mepNode',r.b).z=3.1;const report=M.drainProfile(p,{runId:r.id}),svg=M.profileSVG(p,report);assert.ok(svg.startsWith('<svg'));assert.ok(!svg.includes('<script>'));assert.ok(svg.includes('&lt;script&gt;'));assert.ok(svg.includes('&lt;img'));assert.ok(svg.includes('#b63239'));assert.ok(svg.includes('管外底不是管内底'));assert.ok(!svg.includes('href='));
});
test('profile UI exports current reports only and positions the selected run on its actual elevation floor',()=>{
 const {p,a,c,r}=fixture(),s={...W.defaults(),floor:p.floors[0].id},handlers={},exports=[],messages=[],selected=[],context={MEP:M,Units:U,Drawings:{esc:String},WorkspaceModel:W,document:{addEventListener:(type,fn)=>handlers[type]=fn},FormData:class{get(k){return k==='start'?a.id:c.id}}};context.window=context;
 vm.runInNewContext(fs.readFileSync('dist/mep-profile-ui.js','utf8'),context);context.MEPProfileUI.init({state:()=>({p,s}),dialog(){},close(){},refresh(){},toast:v=>messages.push(v),exportFile:(...args)=>exports.push(args),select:(...args)=>selected.push(args)});
 const click=dataset=>handlers.click({target:{closest:()=>({dataset})}});click({mepProfile:r.id});click({profileAction:'svg'});click({profileAction:'csv'});assert.equal(exports.length,2);assert.ok(exports[0][1].startsWith('<svg'));assert.ok(exports[1][1].includes('起点中心标高'));
 click({profileLocate:'0'});assert.equal(selected[0][1],r.id);assert.equal(s.floor,p.floors[0].id);near(s.center.x,1.5);near(s.center.y,2);
 p.name+=' changed';click({profileAction:'csv'});click({profileLocate:'0'});assert.equal(exports.length,2);assert.equal(selected.length,1);assert.ok(messages.every(m=>m.includes('模型已变化')));
});
