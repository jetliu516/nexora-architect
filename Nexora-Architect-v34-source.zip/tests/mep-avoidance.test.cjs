const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const E=require('../dist/geometry.js'),M=require('../dist/mep-avoidance.js'),W=require('../dist/workspace-model.js'),U=require('../dist/units.js');
function fixture(system='cold'){const p=E.newProject('绕障流程验收'),f=p.floors[0].id;const a=M.node(p,system,system==='drain'?'waste':'waterMeter',f,0,0,1),b=M.node(p,system,system==='drain'?'drainOutlet':'inlet',f,4,0,system==='drain'?.5:1),r=M.connect(p,a.id,b.id,{routing:'direct'});E.wall(p,{x:2,y:-1},{x:2,y:1},f);return{p,r,a,b,f}}
const issues=(p,id)=>M.clashes(p,{onlyRunIds:[id]}).issues;
test('avoidance detours around wall, preserves identities and source, leaves input unchanged',()=>{
 const {p,r,a,b}=fixture(),before=JSON.stringify(p),result=M.avoid(p,r.id);assert.equal(result.ok,true);assert.equal(JSON.stringify(p),before);const next=result.next,newRun=M.item(next,'mepRun',r.id),path=M.path(next,newRun);
 assert.deepEqual(path[0],M.position(p,a));assert.deepEqual(path.at(-1),M.position(p,b));assert.deepEqual(next.mep.nodes,p.mep.nodes);assert.equal(newRun.a,r.a);assert.equal(newRun.b,r.b);assert.equal(newRun.diameter,r.diameter);assert.ok(result.length>4);assert.equal(issues(next,r.id).length,0);
 assert.ok(path.every((q,i)=>!i||!M.routeScene(p,r,.05).blocked(path[i-1],q)));assert.deepEqual(E.validate(JSON.parse(JSON.stringify(next))).mep,next.mep);
});
test('existing wall opening is usable when it admits requested diameter and clearance',()=>{
 const {p,r}=fixture(),w=p.walls[0],o=E.opening(p,w.id,.5,'door');o.offset=.5;o.width=1;o.height=2;E.validate(p);const result=M.avoid(p,r.id);assert.ok(result.ok);assert.ok(Math.abs(result.length-4)<1e-8);o.width=.12;o.offset=.94;const narrow=M.avoid(p,r.id,{clearance:.1});assert.ok(narrow.ok);assert.ok(narrow.length>4);
});
test('pressure line finds route through existing slab hole without cutting model',()=>{
 const p=E.newProject('Slab'),f=p.floors[0].id;E.addRectangle(p,0,0,8,8,f);p.slabOpenings=[{id:E.uid(),floor:f,points:[{x:4,y:2},{x:5,y:2},{x:5,y:4},{x:4,y:4}],guard:false,guardHeight:1.05}];const a=M.node(p,'cold','waterMeter',f,3,3,-1),b=M.node(p,'cold','inlet',f,3,3,1),r=M.connect(p,a.id,b.id,{routing:'direct'});E.validate(p);const result=M.avoid(p,r.id,{clearance:.03,detour:2});assert.ok(result.ok);assert.equal(issues(result.next,r.id).length,0);assert.deepEqual(result.next.slabOpenings,E.validate(p).slabOpenings);assert.ok(result.length>2);
});
test('drainage proposals preserve flow and minimum grade or reject insufficient head',()=>{
 const {p,r}=fixture('drain'),result=M.avoid(p,r.id);assert.ok(result.ok);assert.equal(M.checks(result.next).filter(i=>i.id===r.id).length,0);const ps=M.path(result.next,M.item(result.next,'mepRun',r.id));assert.ok(ps.every((q,i)=>!i||ps[i-1].z-q.z+1e-7>=Math.hypot(q.x-ps[i-1].x,q.y-ps[i-1].y)*r.slope));
 M.item(p,'mepNode',r.b).z=.99;assert.equal(M.avoid(p,r.id).ok,false);
});
test('unavoidable endpoint blockage refuses without modifying geometry',()=>{
 const {p,r}=fixture();p.walls[0].a.x=0;p.walls[0].b.x=0;const before=JSON.stringify(p),result=M.avoid(p,r.id,{detour:.5});assert.equal(result.ok,false);assert.equal(JSON.stringify(p),before);
 for(const settings of [{clearance:-1},{clearance:Infinity},{detour:0},{detour:21}])assert.throws(()=>M.avoid(p,r.id,settings));
});
test('manual route validation, floor-relative elevations and host/floor layer locks',()=>{
 const {p,r}=fixture();p.floors[0].elevation=3;const points=[{x:1,y:2,z:1},{x:3,y:2,z:1}],next=M.setRoute(p,r.id,points);assert.equal(M.path(next,M.item(next,'mepRun',r.id))[1].z,4);assert.equal(p.mep.runs[0].routing,'direct');assert.throws(()=>W.assertEditable(p,next,{...W.defaults(),locks:{mep_cold:true}}));
 for(const bad of [[{x:Infinity,y:0,z:1}],[{x:0,y:0}],[...Array(65)].map(()=>({x:1,y:1,z:1}))])assert.throws(()=>M.setRoute(p,r.id,bad));assert.ok(E.dxfExport(next,next.floors[0].id).includes('MEP_CW'));
});
test('manual self-intersection reports in full and selected run check',()=>{
 const {p,r}=fixture();p.walls=[];const next=M.setRoute(p,r.id,[{x:2,y:2,z:1},{x:0,y:2,z:1},{x:2,y:0,z:1}]);assert.ok(M.clashes(next).issues.length);assert.ok(issues(next,r.id).length);
});
test('adjacent segments only exempt the shared fitting, not a long backward overlap',()=>{
 const {p,r}=fixture();p.walls=[];M.item(p,'mepNode',r.b).x=1;const next=M.setRoute(p,r.id,[{x:2,y:0,z:1}]);assert.ok(issues(next,r.id).some(i=>i.code==='overlap'));
});
test('preexisting route outside requested bounds is not accepted as bounded search result',()=>{
 const {p,r}=fixture(),next=M.setRoute(p,r.id,[{x:0,y:5,z:1},{x:4,y:5,z:1}]);assert.equal(M.avoid(next,r.id,{detour:.1}).ok,false);
});
test('manual drain shallow grade is reported without confusing it with uphill',()=>{
 const {p,r}=fixture('drain');M.item(p,'mepNode',r.b).z=.99;const next=M.setRoute(p,r.id,[{x:2,y:2,z:.995}]);assert.ok(M.checks(next).some(i=>i.id===r.id&&i.code==='slope'));assert.ok(!M.checks(next).some(i=>i.id===r.id&&i.code==='uphill'));
});
test('route preview rejects stale model and obeys transaction failures without consuming candidate',()=>{
 const {p,r}=fixture(),s={...W.defaults(),floor:p.floors[0].id},handlers={},messages=[],context={BIM:E,MEP:M,Units:U,Drawings:{esc:String},document:{addEventListener:(type,fn)=>handlers[type]=fn},FormData:class{get(key){return key==='clearance'?'0.05 m':'2 m'}}};context.window=context;
 vm.runInNewContext(fs.readFileSync('dist/mep-route-ui.js','utf8'),context);let deny=true,applies=0;
 context.MEPRouteUI.init({state:()=>({p,s}),dialog(){},close(){},refresh(){},toast:v=>messages.push(v),transact(fn){if(deny)return false;fn();applies++;return true}});
 const click=dataset=>handlers.click({target:{closest:()=>({dataset})}}),submit=()=>handlers.submit({target:{id:'mepRouteAvoidForm'},preventDefault(){}});
 click({mepAvoid:r.id});submit();click({routeApply:''});assert.equal(applies,0);deny=false;click({routeApply:''});assert.equal(applies,1);click({routeApply:''});assert.equal(applies,1);
 click({mepAvoid:r.id});submit();p.name+=' changed';click({routeApply:''});assert.equal(applies,1);assert.ok(messages.some(m=>m.includes('模型已变化')));
});
