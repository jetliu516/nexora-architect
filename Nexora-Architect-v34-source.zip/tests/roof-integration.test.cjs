const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const E = require('../dist/geometry.js');
const C = require('../dist/cabinets.js');
const N = require('../dist/north-america.js');
const root = path.resolve(__dirname, '..');
const Roof = () => require('../dist/roof-model.js');
const EPS = 1e-7;
const near = (actual, expected, tolerance = EPS, message = '') =>
  assert.ok(Number.isFinite(actual) && Math.abs(actual-expected) <= tolerance,
    `${message}: ${actual} != ${expected} (tolerance ${tolerance})`);
const clone = value => JSON.parse(JSON.stringify(value));
const rect = r => ({x0: r.x-r.overhang, x1: r.x+r.w+r.overhang,
  y0: r.y-r.overhang, y1: r.y+r.d+r.overhang});
function roof(p, options = {}) {
  const r = {id: 'roof-'+(p.roofs.length+1), floor: p.floors[0].id, x: 0, y: 0,
    w: 8, d: 6, type: 'gable', pitch: 30, overhang: 0, material: 'charcoal', ...options};
  p.roofs.push(r); return r;
}
function project() { return E.newProject('Independent roof fixture'); }
// Independent analytic oracle: no E.roofFaces or RoofModel helpers are used.
function height(p, r, x, y) {
  const b = rect(r); if (x < b.x0-EPS || x > b.x1+EPS || y < b.y0-EPS || y > b.y1+EPS) return -Infinity;
  const f = p.floors.find(f => f.id === r.floor), base = f.elevation+f.height+.08+(r.elevationOffset||0);
  const slope = Math.tan(r.pitch*Math.PI/180), dx = Math.min(x-b.x0,b.x1-x), dy = Math.min(y-b.y0,b.y1-y);
  if (r.type === 'flat') return base;
  if (r.type === 'hip') return base+slope*Math.min(dx,dy);
  if (r.type === 'gable') return base+slope*(r.axis === 'y' ? dx : dy);
  const position = r.axis === 'y' ? x-b.x0 : y-b.y0, length = r.axis === 'y' ? b.x1-b.x0 : b.y1-b.y0;
  return base+slope*(r.reverse ? length-position : position);
}
const upper = (p,x,y) => Math.max(...p.roofs.map(r => height(p,r,x,y)));
function unionArea(roofs) {
  const boxes = roofs.map(rect), xs = [...new Set(boxes.flatMap(b => [b.x0,b.x1]))].sort((a,b) => a-b);
  let area = 0;
  for (let i = 1; i < xs.length; i++) {
    const x = (xs[i]+xs[i-1])/2, spans = boxes.filter(b => b.x0<x && b.x1>x).map(b => [b.y0,b.y1]).sort((a,b) => a[0]-b[0]);
    let start, end, total = 0;
    for (const [a,b] of spans) { if (start == null) {start=a;end=b;} else if (a<=end) end=Math.max(end,b); else {total+=end-start;start=a;end=b;} }
    if (start != null) total+=end-start;
    area+=(xs[i]-xs[i-1])*total;
  }
  return area;
}
const cross = (a,b,c) => (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
const signedArea = poly => poly.reduce((sum,a,i) => {const b=poly[(i+1)%poly.length];return sum+a[0]*b[1]-a[1]*b[0];},0)/2;
const plan = point => [point[0],point[2]];
const projected = tri => Math.abs(cross(...tri.points.map(plan)))/2;
function spatialArea(points) {
  const [a,b,c] = points, u=b.map((n,i)=>n-a[i]), v=c.map((n,i)=>n-a[i]);
  return Math.hypot(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])/2;
}
// Independent Sutherland-Hodgman clipping for convex projected triangles.
function intersection(a,b) {
  let result = a.map(q=>q.slice()), clip = signedArea(b)<0 ? b.slice().reverse() : b;
  for (let i=0;i<clip.length && result.length;i++) {
    const from=clip[i], to=clip[(i+1)%clip.length], input=result; result=[];
    for (let j=0;j<input.length;j++) {
      const p=input[j], q=input[(j+1)%input.length], dp=cross(from,to,p), dq=cross(from,to,q);
      if (dp >= -1e-12) result.push(p);
      if ((dp>0&&dq<0)||(dp<0&&dq>0)) {const t=dp/(dp-dq);result.push([p[0]+(q[0]-p[0])*t,p[1]+(q[1]-p[1])*t]);}
    }
  }
  return result.length>2 ? Math.abs(signedArea(result)) : 0;
}
function interpolate(points, x, y) {
  const [a,b,c]=points.map(plan), denominator=cross(a,b,c);
  const weights=[cross([x,y],b,c)/denominator,cross(a,[x,y],c)/denominator,cross(a,b,[x,y])/denominator];
  return weights.every(w=>w>=-1e-8&&w<=1+1e-8) ? weights.reduce((h,w,i)=>h+w*points[i][1],0) : null;
}
function verify(p, label) {
  const before=JSON.stringify(p);let result;try{result=Roof().build(p)}catch(error){error.message=label+': '+error.message;throw error}const triangles=result.triangles;
  assert.ok(Array.isArray(result.surfaces)&&Array.isArray(triangles), label+' result contract');
  assert.ok(Array.isArray(result.edges)&&result.diagnostics&&typeof result.diagnostics==='object', label+' edge/diagnostic contract');
  assert.equal(JSON.stringify(p),before,label+' read-only derivation');
  const owners=new Map(p.roofs.map(r=>[r.id,r])), expectedArea=unionArea(p.roofs);
  let area=0, area3d=0;
  for(const [i,t] of triangles.entries()) {
    assert.ok(owners.has(t.roofId),label+' triangle source id');
    assert.equal(t.points.length,3); assert.ok(t.points.every(p=>p.length===3&&p.every(Number.isFinite)),label+' finite XYZ');
    const projectedArea=projected(t); assert.ok(projectedArea>1e-11,label+' nondegenerate triangle '+i);
    area+=projectedArea;area3d+=spatialArea(t.points);
    for(const weights of [[1/3,1/3,1/3],[.17,.31,.52]]) {
      const q=[0,1,2].map(j=>weights.reduce((sum,w,k)=>sum+w*t.points[k][j],0));
      near(q[1],height(p,owners.get(t.roofId),q[0],q[2]),2e-6,label+' triangle on original owner');
      near(q[1],upper(p,q[0],q[2]),2e-6,label+' visible upper envelope');
    }
  }
  near(area,expectedArea,Math.max(1e-7,expectedArea*1e-8),label+' projected union');
  near(result.area,area3d,Math.max(1e-7,area3d*1e-8),label+' spatial area');
  for(let i=0;i<triangles.length;i++)for(let j=i+1;j<triangles.length;j++)
    assert.ok(intersection(triangles[i].points.map(plan),triangles[j].points.map(plan))<1e-7,label+' overlapping interiors '+i+'/'+j);
  let surfaceArea=0;
  for(const surface of result.surfaces) {
    const owner=owners.get(surface.roofId);assert.ok(owner,label+' surface source id');assert.equal(surface.floor,owner.floor);
    const {a,b,c}=surface.plane;assert.ok([a,b,c].every(Number.isFinite));
    assert.ok(surface.rings.length>0);
    for(const ring of surface.rings)for(const q of ring)near(q[1],a*q[0]+b*q[2]+c,2e-6,label+' surface equation');
    const area2=surface.rings.reduce((sum,ring,i)=>sum+(i?-1:1)*Math.abs(signedArea(ring.map(plan))),0);
    assert.ok(area2>1e-11);surfaceArea+=area2*Math.hypot(a,b,1);
  }
  near(surfaceArea,area3d,Math.max(1e-7,area3d*1e-8),label+' polygon holes triangulated correctly');
  for(const e of result.edges)assert.ok([e.a,e.b].every(p=>p.length===3&&p.every(Number.isFinite)),label+' finite edge');
  return result;
}

test('roof analytic: every basic type, axis and shed reversal matches closed-form height and area',()=>{
  for(const type of ['flat','gable','hip','shed'])for(const axis of ['x','y'])for(const reverse of [false,true]) {
    const p=project(),r=roof(p,{type,axis,reverse,w:7,d:4,pitch:27,overhang:.35,elevationOffset:.7}), result=verify(p,[type,axis,reverse].join('/'));
    const footprint=(r.w+2*r.overhang)*(r.d+2*r.overhang);
    near(result.area,footprint/(type==='flat'?1:Math.cos(r.pitch*Math.PI/180)),1e-6,'single equal-pitch slope area');
  }
});

test('roof analytic: crossing gables, coplanar ties, contained holes, mixed floors and narrow contacts',()=>{
  const fixtures=[
    [{w:8,d:8,pitch:45,axis:'x'},{w:8,d:8,pitch:45,axis:'y',material:'terracotta'}],
    [{type:'flat',w:6,d:6,id:'a'},{type:'flat',w:6,d:6,id:'b'}],
    [{type:'flat',w:8,d:6},{type:'flat',x:4,y:2,w:7,d:5}],
    [{type:'flat',w:8,d:8},{type:'flat',x:2,y:2,w:4,d:4,elevationOffset:1}],
    [{type:'hip',w:8,d:6},{type:'gable',x:2,y:2,w:4,d:7,elevationOffset:.7,axis:'y'}],
    [{type:'gable',w:8,d:6},{type:'shed',x:8,y:0,w:4,d:6,pitch:15}],
    [{type:'gable',w:8,d:6},{type:'shed',x:7.9999,y:0,w:4,d:6,pitch:15}],
    [{type:'shed',x:99,y:-90,w:8,d:6,pitch:30},{type:'shed',x:101,y:-88,w:8,d:6,pitch:30.00001,reverse:true}]
  ];
  fixtures.forEach((options,i)=>{const p=project();options.forEach(o=>roof(p,o));verify(p,'fixture '+i);});
  const p=project(),low=roof(p,{type:'flat',w:8,d:8});
  p.floors.push({...p.floors[0],id:'upper',elevation:4});roof(p,{type:'flat',floor:'upper',x:2,y:2,w:4,d:4});
  const result=verify(p,'two floors');
  near(result.triangles.filter(t=>t.roofId===low.id).reduce((sum,t)=>sum+projected(t),0),48,1e-6,'lower floor stays cut by higher roof');
  assert.ok(result.edges.some(e=>e.kind==='step'),'height discontinuity is identified, not a valley');
});

test('roof analytic: coincident tie ownership and geometry are stable under roof-array reversal',()=>{
  const p=project();roof(p,{id:'a'});roof(p,{id:'z'});
  const a=verify(p,'coincident forward');p.roofs.reverse();const b=verify(p,'coincident reversed');
  assert.deepEqual([...new Set(a.triangles.map(t=>t.roofId))],[...new Set(b.triangles.map(t=>t.roofId))]);
  assert.equal(new Set(a.triangles.map(t=>t.roofId)).size,1,'one copy survives');near(a.area,b.area);
});

test('roof properties: all 100 original templates have exact union coverage, no triangle overlap and only maximum-height surfaces',()=>{
  assert.equal(N.entries.length,100);
  for(const entry of N.entries)verify(N.build(entry.id),entry.id);
});

test('roof derivation: same-object geometry and floor changes invalidate results without relying on updatedAt',()=>{
  const cases=[
    r=>r.pitch+=7,r=>r.axis='y',r=>r.reverse=true,r=>r.elevationOffset=.65,
    r=>r.x+=.6,r=>r.y-=.7,r=>r.w+=1.1,r=>r.d+=.8,r=>r.overhang=.4,
    (r,p)=>p.floors[0].height+=.5,(r,p)=>p.floors[0].elevation+=1.2
  ];
  for(const [i,mutate] of cases.entries()) {
    const p=project(),r=roof(p,{type:'shed'}),before=JSON.stringify(Roof().build(p).triangles),timestamp=p.updatedAt;
    mutate(r,p);const result=verify(p,'cache mutation '+i);
    assert.notEqual(JSON.stringify(result.triangles),before,'stale result after mutation '+i);assert.equal(p.updatedAt,timestamp);
  }
});

function renderer(p, options={}) {
  const T=require('../dist/vendor/three.min.js'), W=require('../dist/workspace-model.js');
  const paint=new Proxy({},{get:()=>()=>{},set:()=>true});
  const c={THREE:T,BIM:E,Cabinets:C,Openings:globalThis.Openings,RoofModel:Roof(),document:{createElement:()=>({width:0,height:0,getContext:()=>paint})}};c.window=c;
  vm.createContext(c);vm.runInContext(fs.readFileSync(path.join(root,'dist/render-materials.js'),'utf8'),c);
  vm.runInContext(fs.readFileSync(path.join(root,'dist/roof-display.js'),'utf8'),c);
  vm.runInContext(fs.readFileSync(path.join(root,'dist/view3d.js'),'utf8'),c);
  const view=Object.create(c.BuildingView.prototype);
  view.model=new T.Group();view.landscape=new T.Group();view.scene=new T.Scene();view.scene.add(view.model,view.landscape);
  view.sun=new T.DirectionalLight();view.ground=new T.Mesh(new T.PlaneGeometry(200,200),new T.MeshStandardMaterial());view.render=()=>{};
  const state={...W.defaults(),floor:p.floors[0].id,roof:true,cutaway:false,foundation:false,landscape:false,allFloors:true,...options};
  view.rebuild(p,state);view.model.updateMatrixWorld(true);
  return {view,state,T,c};
}
function meshTriangles(view,T,tag='roofSurface') {
  const result=[];
  view.model.traverse(mesh=>{
    if(!mesh.isMesh||!mesh.userData[tag])return;
    let parent=mesh;while(parent&&!parent.userData.entity)parent=parent.parent;
    assert.equal(parent?.userData.entity?.type,'roof','roof mesh keeps selectable entity identity');
    const owner=parent.userData.entity.id,pos=mesh.geometry.attributes.position,index=mesh.geometry.index,count=index?index.count:pos.count;
    for(let i=0;i<count;i+=3){const points=[0,1,2].map(k=>new T.Vector3().fromBufferAttribute(pos,index?index.getX(i+k):i+k).applyMatrix4(mesh.matrixWorld).toArray());result.push({roofId:owner,points,mesh});}
  });
  return result;
}
function compareMesh(p,actual,expected,label) {
  assert.ok(actual.length>0,label+' real roof mesh exists');
  for(const r of p.roofs){
    const a=actual.filter(t=>t.roofId===r.id),e=expected.filter(t=>t.roofId===r.id);
    near(a.reduce((sum,t)=>sum+projected(t),0),e.reduce((sum,t)=>sum+projected(t),0),2e-5,label+' projected source '+r.id);
    near(a.reduce((sum,t)=>sum+spatialArea(t.points),0),e.reduce((sum,t)=>sum+spatialArea(t.points),0),2e-5,label+' area source '+r.id);
  }
  for(const t of actual){const q=[0,1,2].map(j=>t.points.reduce((sum,p)=>sum+p[j],0)/3);near(q[1],upper(p,q[0],q[2]),2e-5,label+' visible joined mesh');}
}
function objTriangles(text) {
  const vertices=[],triangles=[];let id='';
  for(const line of text.split('\n')){
    if(line.startsWith('o '))id=line.slice(2);
    else if(line.startsWith('v '))vertices.push(line.slice(2).trim().split(/\s+/).map(Number));
    else if(line.startsWith('f ')){const indices=line.slice(2).trim().split(/\s+/).map(v=>Number(v.split('/')[0])-1);for(let i=1;i<indices.length-1;i++){const t={roofId:id,points:[indices[0],indices[i],indices[i+1]].map(j=>vertices[j])};if(projected(t)>1e-8)triangles.push(t);}}
  }
  return triangles;
}

test('roof integration: actual Three.js surfaces and OBJ preserve joined geometry, source roof IDs and materials',()=>{
  const p=project();roof(p,{id:'main',w:8,d:8,pitch:30,material:'charcoal'});roof(p,{id:'cross',w:8,d:8,pitch:35,axis:'y',material:'terracotta'});
  const expected=verify(p,'render/export'),{view,T,c}=renderer(p),actual=meshTriangles(view,T);
  compareMesh(p,actual,expected.triangles,'3D');
  for(const t of actual){const r=p.roofs.find(r=>r.id===t.roofId),expectedMaterial=c.ResidentialMaterials.material(r.material==='charcoal'?'shingle':r.material);assert.equal(t.mesh.material.color.getHexString(),expectedMaterial.color.getHexString());assert.equal(t.mesh.material.map,expectedMaterial.map);expectedMaterial.dispose();}
  const exported=objTriangles(view.obj());compareMesh(p,exported,expected.triangles,'OBJ');
  // Check the exact export precision independently of area tolerances. The OBJ
  // must serialize the rendered world vertices, with every roof ID preserved.
  const canonical=triangles=>triangles.map(t=>JSON.stringify([t.roofId,t.points.map(q=>q.map(n=>Number(n.toFixed(7)))).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)))])).sort();
  assert.deepEqual(canonical(exported),canonical(actual),'OBJ is the complete rendered triangle set at seven decimal places');
});

test('roof integration: floor visibility never regenerates the hidden lower roof beneath an upper roof',()=>{
  const p=project(),low=roof(p,{id:'low',type:'flat',w:8,d:8});
  p.floors.push({...p.floors[0],id:'upper',elevation:4});roof(p,{id:'high',floor:'upper',type:'flat',x:2,y:2,w:4,d:4});
  const expected=Roof().build(p).triangles.filter(t=>t.roofId===low.id),{view,T}=renderer(p,{allFloors:false,floor:low.floor});
  const actual=meshTriangles(view,T);assert.ok(actual.every(t=>t.roofId===low.id));compareMesh({...p,roofs:[low]},actual,expected,'filtered lower roof');
  near(actual.reduce((sum,t)=>sum+projected(t),0),48,2e-5);
});

function svgRoofSegments(markup, role='section') {
  const segments=[];
  for(const tag of markup.match(/<(?:path|line)\b[^>]*>/g)||[]){
    const attributes=Object.fromEntries([...tag.matchAll(/([\w-]+)="([^"]*)"/g)].map(m=>[m[1],m[2]]));
    if(attributes['data-roof-role']!==role)continue;
    const id=attributes['data-roof-id'];assert.ok(id,'roof drawing keeps its source ID');
    if(tag.startsWith('<line'))segments.push({id,a:[+attributes.x1,-attributes.y1],b:[+attributes.x2,-attributes.y2]});
    else{
      const chunks=attributes.d.match(/[ML][^MLZ]+/gi)||[];let last;
      for(const chunk of chunks){const q=chunk.slice(1).trim().split(/[ ,]+/).map(Number);assert.equal(q.length,2,'section path uses 2D M/L coordinates');if(chunk[0].toUpperCase()==='L'&&last)segments.push({id,a:last,b:[q[0],-q[1]]});last=[q[0],-q[1]];}
    }
  }
  return segments;
}
function drawingContext() {
  const c={BIM:E,Cabinets:C,Openings:globalThis.Openings,RoofModel:Roof(),Units:require('../dist/units.js')};c.window=c;c.globalThis=c;
  vm.createContext(c);vm.runInContext(fs.readFileSync(path.join(root,'dist/roof-display.js'),'utf8'),c);vm.runInContext(fs.readFileSync(path.join(root,'dist/drawings.js'),'utf8'),c);return c;
}

test('roof integration: section cut follows the joined upper envelope and leaves a real hole in lower-level surfaces',()=>{
  const p=project();roof(p,{id:'outer',type:'flat',w:8,d:8});roof(p,{id:'inner',type:'flat',x:2,y:2,w:4,d:4,elevationOffset:1});
  const c=drawingContext(),s={...require('../dist/workspace-model.js').defaults(),floor:p.floors[0].id,roof:true};
  for(const cutY of [1.5,3.7,6.5]){
    const drawing=c.Drawings.section(p,s,cutY),segments=svgRoofSegments(drawing.markup);assert.ok(segments.length,'section includes actual roof cut');
    for(const segment of segments){const x=(segment.a[0]+segment.b[0])/2,h=(segment.a[1]+segment.b[1])/2;near(h,upper(p,x,cutY),2e-6,'section hides lower overlapping roof');}
    for(let x=.17;x<8;x+=.37){const found=segments.filter(e=>x>Math.min(e.a[0],e.b[0])+EPS&&x<Math.max(e.a[0],e.b[0])-EPS);assert.equal(found.length,1,'one visible section roof per interior X');const e=found[0],t=(x-e.a[0])/(e.b[0]-e.a[0]);near(e.a[1]+(e.b[1]-e.a[1])*t,upper(p,x,cutY),2e-6);}
  }
});

test('roof input: invalid geometry and unknown sources fail explicitly without mutating the saved project',()=>{
  for(const mutate of [r=>r.pitch=NaN,r=>r.pitch=Infinity,r=>r.w=0,r=>r.overhang=-1,r=>r.axis='diagonal',r=>r.type='curved',r=>r.floor='missing',r=>r.reverse='true']){
    const p=project(),r=roof(p);mutate(r);const before=JSON.stringify(p);assert.throws(()=>Roof().build(p));assert.equal(JSON.stringify(p),before);
  }
  const p=project();roof(p,{id:'duplicate'});roof(p,{id:'duplicate'});assert.throws(()=>Roof().build(p));
});

test('roof display: zero-overhang exterior boundaries retain every wall-top closure including both gable ends',()=>{
  const p=project(),f=p.floors[0];E.addRectangle(p,0,0,8,6,f.id);roof(p,{w:8,d:6,overhang:0});
  const D=require('../dist/roof-display.js'),closures=D.closures(p);
  for(const wall of p.walls){
    const forward=D.slice(p,wall.a,wall.b,f.id),reverse=D.slice(p,wall.b,wall.a,f.id);
    const span=parts=>parts.reduce((sum,c)=>sum+Math.hypot(c.b[0]-c.a[0],c.b[2]-c.a[2]),0);
    near(span(forward),E.dist(wall.a,wall.b),1e-6,'boundary slice covers wall');near(span(reverse),span(forward),1e-6,'wall direction does not change closure');
    const parts=closures.filter(c=>c.wallId===wall.id);
    assert.ok(parts.length,'missing closure for boundary '+JSON.stringify([wall.a,wall.b]));
    near(parts.reduce((sum,c)=>sum+Math.hypot(c.points[1][0]-c.points[0][0],c.points[1][2]-c.points[0][2]),0),E.dist(wall.a,wall.b),1e-6,'full wall boundary coverage');
    for(const c of parts){near(c.points[0][1],f.elevation+wall.height);near(c.points[1][1],f.elevation+wall.height);for(const q of c.points.slice(2))near(q[1],upper(p,q[0],q[2]),1e-6,'wall top meets joined roof');}
  }
});

test('roof display: upper-story roof never stretches a lower-story wall through the intermediate floor',()=>{
  const p=project(),f=p.floors[0];E.addRectangle(p,0,0,8,6,f.id);
  p.floors.push({...f,id:'upper',elevation:4});roof(p,{floor:'upper',w:8,d:6,overhang:.4});
  const D=require('../dist/roof-display.js');assert.equal(D.closures(p).length,0);
});

test('roof integration: all 100 template 3D roof surfaces preserve the joined source areas and finite mesh coordinates',()=>{
  const W=require('../dist/workspace-model.js'),layers=Object.fromEntries(Object.keys(W.defaults().layers).map(k=>[k,k==='roofs']));
  for(const entry of N.entries){
    const p=N.build(entry.id),expected=Roof().build(p),{view,T}=renderer(p,{layers}),actual=meshTriangles(view,T);
    assert.ok(actual.length,entry.id+' roof meshes');
    for(const r of p.roofs){
      const a=actual.filter(t=>t.roofId===r.id),e=expected.triangles.filter(t=>t.roofId===r.id);
      const expectedProjection=e.reduce((sum,t)=>sum+projected(t),0),expectedArea=e.reduce((sum,t)=>sum+spatialArea(t.points),0);
      near(a.reduce((sum,t)=>sum+projected(t),0),expectedProjection,Math.max(2e-5,expectedProjection*5e-7),entry.id+' projected mesh '+r.id);
      near(a.reduce((sum,t)=>sum+spatialArea(t.points),0),expectedArea,Math.max(2e-5,expectedArea*5e-7),entry.id+' spatial mesh '+r.id);
    }
    for(const t of actual){assert.ok(t.points.flat().every(Number.isFinite));const q=[0,1,2].map(j=>t.points.reduce((sum,p)=>sum+p[j],0)/3);near(q[1],upper(p,q[0],q[2]),2e-5,entry.id+' rendered upper envelope');}
  }
});

function perimeter(p,points,floor=p.floors[0].id) {
  points.forEach((q,i)=>{const b=points[(i+1)%points.length];E.wall(p,{x:q[0],y:q[1]},{x:b[0],y:b[1]},floor);});
}
function assertFootprint(p, polygons, label) {
  const expected=polygons.reduce((sum,poly)=>sum+Math.abs(signedArea(poly[0]))-poly.slice(1).reduce((n,ring)=>n+Math.abs(signedArea(ring)),0),0);
  near(unionArea(p.roofs),expected,1e-7,label+' source footprint area');
  const result=verify(p,label);near(result.diagnostics.coverageArea,expected,1e-7,label+' joined coverage');
  const points=polygons.flat(2),xs=[...new Set(points.map(q=>q[0]))].sort((a,b)=>a-b),ys=[...new Set(points.map(q=>q[1]))].sort((a,b)=>a-b);
  for(let i=1;i<xs.length;i++)for(let j=1;j<ys.length;j++){
    const q={x:(xs[i]+xs[i-1])/2,y:(ys[j]+ys[j-1])/2};
    const inside=polygons.some(poly=>E.pointIn(q,poly[0].map(([x,y])=>({x,y})))&&!poly.slice(1).some(r=>E.pointIn(q,r.map(([x,y])=>({x,y})))));
    assert.equal(Number.isFinite(upper(p,q.x,q.y)),inside,label+' source cell coverage '+JSON.stringify(q));
  }
}

test('roof footprint: automatic L, T and disconnected buildings preserve the occupied footprint exactly',()=>{
  const F=require('../dist/roof-footprint.js');
  const fixtures=[
    {name:'L',polygons:[[[[0,0],[12,0],[12,6],[6,6],[6,10],[0,10]]]]},
    {name:'T',polygons:[[[[0,0],[12,0],[12,4],[8,4],[8,10],[4,10],[4,4],[0,4]]]]},
    {name:'disconnected',polygons:[[[[0,0],[6,0],[6,4],[0,4]]],[[[9,2],[13,2],[13,7],[9,7]]]]}
  ];
  for(const {name,polygons} of fixtures){
    const p=project();polygons.forEach(poly=>perimeter(p,poly[0]));F.generate(p,p.floors[0].id,{overhang:0});
    assertFootprint(p,polygons,name);
  }
});

test('roof footprint: an excluded inner courtyard remains a hole in the surrounding room roof',()=>{
  const F=require('../dist/roof-footprint.js'),p=project(),f=p.floors[0].id;
  E.addRectangle(p,0,0,10,10,f);E.addRectangle(p,3,3,3,3,f);
  const rooms=E.detectRooms(p,f);
  E.roomMeta(p,rooms.find(r=>r.area===91),{roomType:'living',name:'Surrounding house'});
  E.roomMeta(p,rooms.find(r=>r.area===9),{roomType:'deck',name:'Open courtyard'});
  assert.deepEqual(E.detectRooms(p,f).map(r=>[r.area,r.roomType]),[[91,'living'],[9,'deck']],'fixture retains explicit room metadata');
  F.generate(p,f,{type:'flat',overhang:0});
  assertFootprint(p,[[[[0,0],[10,0],[10,10],[0,10]],[[3,3],[3,6],[6,6],[6,3]]]],'courtyard');
});

test('roof footprint: replacement is limited to the requested floor and failed generation preserves saved roofs',()=>{
  const F=require('../dist/roof-footprint.js'),p=project(),f=p.floors[0];
  E.addRectangle(p,0,0,8,6,f.id);const old=roof(p,{id:'replace-me'});
  p.floors.push({...f,id:'upper',elevation:4});const upstairs=roof(p,{id:'preserve-me',floor:'upper',x:1,y:1,w:2,d:2});
  const upperBefore=JSON.stringify(upstairs);F.generate(p,f.id,{overhang:0});
  assert.ok(!p.roofs.some(r=>r.id===old.id));assert.equal(JSON.stringify(p.roofs.find(r=>r.id===upstairs.id)),upperBefore);
  const before=JSON.stringify(p);
  assert.throws(()=>F.generate(p,f.id,{pitch:Infinity}));assert.equal(JSON.stringify(p),before,'invalid candidate is atomic');
  assert.throws(()=>F.generate(p,'missing-floor'));assert.equal(JSON.stringify(p),before,'unknown floor is atomic');
  const diagonal=project();perimeter(diagonal,[[0,0],[8,0],[7,6],[0,6]]);roof(diagonal);const saved=JSON.stringify(diagonal);
  assert.throws(()=>F.generate(diagonal,diagonal.floors[0].id),/直角/);assert.equal(JSON.stringify(diagonal),saved,'unsupported outline preserves old roof');
});

test('roof drawings: elevation and section view boxes include the actual roof beyond the wall bounds',()=>{
  const p=project(),f=p.floors[0].id;E.addRectangle(p,0,0,8,6,f);roof(p,{w:8,d:6,overhang:3});
  const c=drawingContext(),contains=(box,x,y,label)=>assert.ok(x>=box.x-EPS&&x<=box.x+box.w+EPS&&y>=box.y-EPS&&y<=box.y+box.h+EPS,label+' '+JSON.stringify({box,x,y}));
  for(const offset of [0,-8]){
    p.roofs[0].elevationOffset=offset;
    const points=Roof().build(p).surfaces.flatMap(s=>s.rings.flat());
    for(const direction of ['front','back','left','right']){
      const drawing=c.Drawings.elevation(p,{},direction),front=['front','back'].includes(direction),sign=['back','right'].includes(direction)?-1:1;
      for(const q of points)contains(drawing.box,q[front?0:2]*sign,-q[1],direction+' roof vertex is not cropped at offset '+offset);
    }
    const section=c.Drawings.section(p,{},3);
    for(const line of c.RoofDisplay.section(p,3))for(const q of [line.a,line.b])contains(section.box,q[0],-q[1],'section roof endpoint is not cropped at offset '+offset);
  }
});
