const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const E = require('../dist/geometry.js');
const WM = require('../dist/workspace-model.js');
const MEP = globalThis.MEP;
const PL = require('../dist/project-library.js');
const C = require('../dist/cabinets.js');
const source = fs.readFileSync(path.join(__dirname, '../dist/workbench.js'), 'utf8');
const lines = source.split('\n');

// Execute production model-editing functions and event handlers. DOM painting
// is stubbed; this proves state/transaction ordering, not a browser trigger.
function harness() {
  const base = E.newProject('Coffee table audit');
  const coffee = E.object(base, 'coffee', 1, 1, base.floors[0].id);
  const p = E.validate(base), handlers = {}, listenerOptions = {}, messages = [], elements = new Map;
  let persisted = null, failWrites = false;
  const storageKey = 'isolated-test-library', storageData = new Map;
  const localStorage = {get length() {return storageData.size;}, key: index => [...storageData.keys()][index] ?? null,
    getItem: key => storageData.get(key) ?? null,
    setItem(key, value) {if (failWrites) throw Error('quota'); storageData.set(key, String(value)); if (key === storageKey) persisted = String(value);},
    removeItem: key => {storageData.delete(key);}};
  const storageSession = PL.session(localStorage, storageKey); storageSession.read();
  const element = id => {
    if (!elements.has(id)) elements.set(id, {id, dataset: {}, clientWidth: 1000, clientHeight: 800,
      style: {setProperty() {}}, classList: {toggle() {}},
      addEventListener(type, fn) {(this.handlers ||= {})[type] = fn;}, setPointerCapture() {},
      releasePointerCapture() {}, hasPointerCapture() {return true;}, close() {}, setAttribute() {}});
    return elements.get(id);
  };
  const context = {E, BIM: E, WM, WorkspaceModel: WM, MEP, PL, ProjectLibrary: PL, C,
    Openings: globalThis.Openings, p, s: {...WM.defaults(), floor: p.floors[0].id, selected: null,
      tool: 'select', snap: false, grid: .1, zoom: 1, mode: 'plan', start: null, preview: null},
    history: [], future: [], drag: null, frame: null, model: null, selectionRevision: 0,
    db: {active: p.id, projects: [E.clone(p)], trash: [], recovery: []}, projectHistory: new Map,
    STORAGE: storageKey, storageBlocked: false, storageSession, localStorage,
    $: element, toast: text => messages.push(text),
    document: {activeElement: null, addEventListener(type, fn, options) {handlers[type] = fn; listenerOptions[type] = options;},
      querySelectorAll() {return [];}},
    MEPUI: {pointer() {return false;}}, WorkspaceUI: {setDock() {}, open() {}, render() {}},
    ArchitectAI: {followKitchen() {}, endVoice() {}},
    captureWorkspace() {return {};}, restoreWorkspace() {},
    cursor: e => ({x: e.clientX, y: e.clientY}), snap: q => q,
    viewBox: () => ({x: -5, y: -5, w: 20, h: 16}),
    esc: value => String(value).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;'),
    metric: n => context.p.unit === 'ft' ? n/3.280839895 : n,
    display: n => context.p.unit === 'ft' ? n*3.280839895 : n,
    unit: () => context.p.unit === 'ft' ? 'ft' : 'm', floor: () => context.p.floors.find(f => f.id === context.s.floor),
    refresh() {context.lastRendered = E.clone(context.p);},
    renderPlan() {context.lastPlan = E.clone(context.p);}, renderInspector() {}, render3d() {},
    renderRibbon() {}, renderCatalog() {}, status() {},
    requestAnimationFrame() {return 1;}, cancelAnimationFrame() {},
    ResizeObserver: class {observe() {}}, innerWidth: 1200};
  context.window = context;
  vm.createContext(context);
  function run(code) {assert.ok(code, 'production function/handler exists'); vm.runInContext(code, context);}
  run(source.slice(source.indexOf('function commitLibrary('), source.indexOf('\nfunction save(')));
  for (const name of ['save', 'transact', 'travelHistory', 'selection', 'select', 'endDrag', 'deleteSelection', 'setTool', 'moveNode', 'field']) {
    run(lines.find(line => line.startsWith('function '+name+'(')));
  }
  run(source.slice(source.indexOf('function resetProject('), source.indexOf('\nfunction refresh(')));
  run(source.slice(source.indexOf('function pointerDown('), source.indexOf("\n$('plan').addEventListener('pointerdown'")));
  run(lines.find(line => line.startsWith("$('plan').addEventListener('pointerdown'")));
  run(lines.find(line => line.startsWith("$('plan').addEventListener('pointerup'")));
  run(source.slice(source.indexOf('function action('), source.indexOf("\ndocument.addEventListener('click',e=>{const b=e.target.closest('button')")));
  run(lines.find(line => line.startsWith("document.addEventListener('click',e=>{const b=e.target.closest('button')")));
  run(lines.find(line => line.startsWith("document.addEventListener('change',e=>{const el=e.target")));
  const pointer = (type, x = 2, y = 2, options = {}) => {
    const {hit = {entity: 'object', id: coffee.id}, handle = null, ...event} = options;
    return element('plan').handlers[type]?.({button: 0, pointerId: 1, clientX: x, clientY: y, ...event,
      target: {closest: selector => selector === '[data-handle]' && handle ? {dataset: handle} :
        selector === '[data-entity]' && hit ? {dataset: hit} : null}});
  };
  const change = (props = {}) => handlers.change({target: {dataset: {}, type: 'text',
    hasAttribute() {return false;}, checkValidity() {return true;}, reportValidity() {}, ...props}});
  const changeField = (key, value, dataset = {}) => change({dataset: {field: key, number: 'true', ...dataset}, value: String(value)});
  const changeWidth = value => changeField('w', value);
  const fieldInput = (key, value, options = {}) => {
    const html = context.field(key, key, value, options), attrs = Object.fromEntries(
      [...html.matchAll(/([\w-]+)="([^"]*)"/g)].map(m => [m[1], m[2]]));
    const dataset = Object.fromEntries(Object.entries(attrs).filter(([k]) => k.startsWith('data-'))
      .map(([k, v]) => [k.slice(5).replace(/-([a-z])/g, (_, ch) => ch.toUpperCase()), v]));
    return {html, dataset, type: attrs.type, value: attrs.value};
  };
  const click = dataset => handlers.click({target: {closest: () => ({dataset, closest() {return null;}})}});
  // Model the browser's default pointer-down focus change: without preventDefault,
  // blur/change rebuilds the inspector and disconnects the button before click.
  // With focus retained, click begins first and can survive the blur-triggered rebuild.
  const focusedInspectorClick = (dataset, key, value) => {
    const originalRefresh = context.refresh, events = [];
    const input = {...fieldInput(key, context.display(context.selection()[key])), value: String(value), isConnected: true,
      closest: selector => selector === '#inspector input,#inspector select' ? input : null};
    const button = {dataset, isConnected: true,
      closest: selector => ['button', '#inspector button', '#inspector'].includes(selector) ? button : null};
    let prevented = false, clicks = 0, blurs = 0;
    context.document.activeElement = input;
    input.blur = () => {if (context.document.activeElement !== input) return; blurs++; events.push('blur');
      context.document.activeElement = null; change(input);};
    context.refresh = () => {events.push('refresh'); input.isConnected = false; button.isConnected = false; originalRefresh();};
    try {
      assert.equal(listenerOptions.pointerdown, true, 'focus prevention must execute in capture phase');
      handlers.pointerdown({target: button, preventDefault() {prevented = true; events.push('preventDefault');}});
      if (!prevented) input.blur();
      if (button.isConnected) {clicks++; events.push('click'); handlers.click({target: button});}
      return {prevented, clicks, blurs, events, button};
    } finally {context.refresh = originalRefresh;}
  };
  return {c: context, coffee, pointer, change, changeField, changeWidth, fieldInput, click, focusedInspectorClick, messages,
    stored: () => persisted && JSON.parse(persisted), failWrites: value => failWrites = value};
}

test('audit: completed drag then width edit, delete and view change preserve the saved deletion', () => {
  const h = harness(), c = h.c;
  h.pointer('pointerdown'); h.pointer('pointermove', 3, 2); h.pointer('pointerup', 3, 2);
  assert.equal(c.p.objects[0].x, 2); assert.equal(c.drag, null);
  h.changeWidth(2.5); assert.equal(c.p.objects[0].w, 2.5);
  h.click({action: 'delete'}); assert.equal(c.p.objects.length, 0);
  h.click({mode: '3d'}); h.click({mode: 'plan'});
  assert.equal(c.p.objects.length, 0); assert.equal(h.stored().projects[0].objects.length, 0);
  assert.ok(h.messages.includes('已删除，可撤销'));
});

test('audit: late pointer cancellation must not resurrect an object after committed width edit and delete', () => {
  const h = harness(), c = h.c;
  h.pointer('pointerdown'); h.pointer('pointermove', 3, 2);
  h.changeWidth(2.5);
  assert.equal(c.p.objects[0].x, 2, 'settling a pending drag must preserve the current position');
  assert.equal(c.p.objects[0].w, 2.5, 'settling a pending drag must not invalidate the selected entity closure');
  h.click({action: 'delete'});
  assert.equal(c.p.objects.length, 0); assert.equal(h.stored().projects[0].objects.length, 0);
  assert.ok(h.messages.includes('已删除，可撤销'));
  h.pointer('pointercancel', 3, 2); h.click({mode: '3d'}); h.click({mode: 'plan'});
  assert.equal(c.p.objects.length, 0, 'a stale drag snapshot must never undo a committed delete');
  assert.equal(c.lastRendered.objects.length, 0);
  assert.equal(h.stored().projects[0].objects.length, 0);
});

test('audit: late pointer move after deletion must not dereference a missing object', () => {
  const h = harness();
  h.pointer('pointerdown'); h.pointer('pointermove', 3, 2); h.click({action: 'delete'});
  assert.doesNotThrow(() => h.pointer('pointermove', 4, 2));
  assert.equal(h.c.p.objects.length, 0);
});

test('audit: capture loss must end an in-progress model drag', () => {
  const h = harness(); h.pointer('pointerdown'); h.pointer('pointermove', 3, 2);
  h.pointer('lostpointercapture', 3, 2);
  assert.equal(h.c.drag, null);
});

test('audit: stale drag cancellation cannot replace a newly opened project', () => {
  const h = harness(); h.pointer('pointerdown'); h.pointer('pointermove', 3, 2);
  const next = E.newProject('Different project'); assert.equal(h.c.resetProject(next), true);
  h.pointer('pointercancel', 3, 2);
  assert.equal(h.c.p.id, next.id); assert.equal(h.c.db.active, next.id);
  assert.equal(h.c.p.objects.length, 0);
});

test('audit: storage failure when finishing an ordinary drag restores original model without claiming success', () => {
  const h = harness(), before = JSON.stringify(h.c.p);
  h.failWrites(true); h.pointer('pointerdown'); h.pointer('pointermove', 3, 2); h.pointer('pointerup', 3, 2);
  assert.equal(JSON.stringify(h.c.p), before); assert.equal(h.c.history.length, 0); assert.equal(h.stored(), null);
  assert.ok(h.messages.some(x => x.includes('保存失败')));
});

test('audit: pending drag plus numeric edit is one atomic undo/redo transaction', () => {
  const h = harness(), c = h.c, original = E.clone(c.p.objects[0]);
  h.pointer('pointerdown'); h.pointer('pointermove', 3, 2); h.changeWidth(2.5);
  assert.equal(c.drag, null); assert.equal(c.history.length, 1);
  assert.equal(c.p.objects[0].x, 2); assert.equal(c.p.objects[0].w, 2.5);
  c.travelHistory(); assert.deepEqual(c.p.objects[0], original);
  c.travelHistory(true); assert.equal(c.p.objects[0].x, 2); assert.equal(c.p.objects[0].w, 2.5);
  assert.equal(h.stored().projects[0].objects[0].w, 2.5);
});

test('audit: save failure rolls back both pending drag and numeric edit, with no success history', () => {
  const h = harness(), before = JSON.stringify(h.c.p);
  h.pointer('pointerdown'); h.pointer('pointermove', 3, 2); h.failWrites(true); h.changeWidth(2.5);
  assert.equal(JSON.stringify(h.c.p), before); assert.equal(h.c.drag, null);
  assert.equal(h.c.history.length, 0); assert.equal(h.stored(), null);
  h.pointer('pointercancel'); assert.equal(JSON.stringify(h.c.p), before);
});

test('audit: a wall endpoint handle overrides the still-active wall creation tool', () => {
  const h = harness(), c = h.c, wall = E.wall(c.p, {x: 0, y: 0}, {x: 4, y: 0}, c.s.floor);
  c.s.selected = {type: 'wall', id: wall.id}; c.s.tool = 'wall'; c.s.start = {x: 0, y: 0};
  h.pointer('pointerdown', 4, 0, {handle: {id: wall.id, handle: 'b'}, hit: {entity: 'wall', id: wall.id}});
  assert.equal(c.p.walls.length, 1, 'handle press must not complete an accidental extra wall');
  assert.equal(c.drag?.type, 'node'); assert.equal(c.s.start, null); assert.equal(c.s.tool, 'select');
  h.pointer('pointermove', 5, 0); h.pointer('pointerup', 5, 0);
  assert.equal(c.p.walls.length, 1); assert.equal(c.p.walls[0].b.x, 5);
  c.travelHistory(); assert.equal(c.p.walls[0].b.x, 4);
});

test('audit: placing furniture returns to selection, so the next drag edits instead of duplicating it', () => {
  const h = harness(), c = h.c; c.s.placeKind = 'coffee'; c.setTool('object');
  h.pointer('pointerdown', 4, 3, {hit: null});
  assert.equal(c.p.objects.length, 2); assert.equal(c.s.tool, 'select');
  const id = c.s.selected.id, placed = E.clone(c.p.objects.find(o => o.id === id));
  h.pointer('pointerdown', 4, 3, {hit: {entity: 'object', id}});
  h.pointer('pointermove', 5, 3); h.pointer('pointerup', 5, 3);
  assert.equal(c.p.objects.length, 2); assert.equal(c.p.objects.find(o => o.id === id).x, E.round(placed.x+1, 2));
  c.setTool('object'); h.pointer('pointerdown', 7, 3, {hit: null, shiftKey: true});
  assert.equal(c.s.tool, 'object', 'Shift keeps the explicit repeat-placement workflow');
  assert.equal(c.p.objects.length, 3);
});

test('audit: formatted metric and imperial fields preserve canonical precision on unchanged display and unrelated edits', () => {
  for (const unit of ['m', 'ft']) {
    const h = harness(), c = h.c, width = 1.234567891234;
    c.p.unit = unit; c.p.objects[0].w = width; c.select('object', h.coffee.id);
    const input = h.fieldInput('w', c.display(width), {min: c.display(.02), max: c.display(100)});
    assert.match(input.value, /^\d+\.\d{2}$/); assert.equal(input.value, c.display(width).toFixed(2));
    h.change(input); assert.equal(c.history.length, 0); assert.equal(c.p.objects[0].w, width);
    h.changeField('h', c.display(.876543219876));
    assert.equal(c.p.objects[0].w, width); assert.ok(Math.abs(c.p.objects[0].h-.876543219876)<1e-12);
    const saved = E.validate(h.stored().projects[0]);
    assert.equal(saved.objects[0].w, width, 'display rounding must never rewrite untouched canonical dimensions');
  }
});

test('audit: edited text numeric fields reject empty, non-finite and out-of-range values atomically', () => {
  for (const value of ['', ' ', 'NaN', 'Infinity', '-1', '101']) {
    const h = harness(), c = h.c; c.select('object', h.coffee.id);
    const before = JSON.stringify(c.p), input = h.fieldInput('w', c.p.objects[0].w, {min: .02, max: 100});
    h.change({...input, value});
    assert.equal(JSON.stringify(c.p), before); assert.equal(c.history.length, 0); assert.equal(h.stored(), null);
  }
});

test('audit: events from a different pointer cannot move or finish the current drag', () => {
  const h = harness(), c = h.c;
  h.pointer('pointerdown'); h.pointer('pointermove', 3, 2, {pointerId: 2});
  h.pointer('pointerup', 3, 2, {pointerId: 2}); h.pointer('pointercancel', 3, 2, {pointerId: 2});
  assert.ok(c.drag); assert.equal(c.p.objects[0].x, 1);
  h.pointer('pointermove', 3, 2); h.pointer('pointerup', 3, 2);
  assert.equal(c.p.objects[0].x, 2); assert.equal(c.drag, null);
  h.pointer('pointerdown', 3, 2, {pointerId: 2}); h.pointer('pointercancel', 3, 2, {pointerId: 1});
  assert.ok(c.drag); h.pointer('pointermove', 4, 2, {pointerId: 2}); h.pointer('pointerup', 4, 2, {pointerId: 2});
  assert.equal(c.p.objects[0].x, 3);
});

test('audit: switching tools cancels an unfinished rectangle without generating geometry or dereferencing a null event', () => {
  const h = harness(), c = h.c; c.setTool('rectangle');
  h.pointer('pointerdown', 0, 0, {hit: null}); h.pointer('pointermove', 4, 3);
  assert.doesNotThrow(() => c.setTool('select'));
  assert.equal(c.drag, null); assert.equal(c.s.start, null); assert.equal(c.p.walls.length, 0);
  h.pointer('pointerup', 4, 3); assert.equal(c.p.walls.length, 0);
});

test('audit: failed drag persistence prevents project switching and later actions', () => {
  const h = harness(), c = h.c, originalId = c.p.id;
  h.pointer('pointerdown'); h.pointer('pointermove', 3, 2); h.failWrites(true);
  assert.equal(c.resetProject(E.newProject('Must not open')), false);
  assert.equal(c.p.id, originalId); assert.equal(c.p.objects[0].x, 1);
  assert.equal(c.history.length, 0); assert.equal(c.db.active, originalId);
  h.failWrites(false); h.pointer('pointerdown'); h.pointer('pointermove', 3, 2); h.failWrites(true);
  h.click({action: 'delete'}); assert.equal(c.p.objects.length, 1); assert.equal(c.p.objects[0].x, 1);
  assert.ok(!h.messages.includes('已删除，可撤销'));
});

test('audit: reopening the current project finishes its drag without replacing it with the stale library snapshot', () => {
  const h = harness(), c = h.c, staleProject = c.db.projects[0];
  h.pointer('pointerdown'); h.pointer('pointermove', 3, 2);
  assert.equal(c.resetProject(staleProject), true);
  assert.equal(c.p.objects[0].x, 2); assert.equal(h.stored().projects[0].objects[0].x, 2);
  c.travelHistory(); assert.equal(c.p.objects[0].x, 1);
});

test('audit: action-level drag settlement does not invalidate the selected object for the action', () => {
  const h = harness(), c = h.c;
  h.pointer('pointerdown'); h.pointer('pointermove', 3, 2); h.click({action: 'rotateObject'});
  assert.equal(c.p.objects[0].x, 2); assert.equal(c.p.objects[0].angle, 90);
  assert.equal(h.stored().projects[0].objects[0].angle, 90);
  c.travelHistory(); assert.equal(c.p.objects[0].angle, 0); assert.equal(c.p.objects[0].x, 2);
});

test('audit: a unit change during dragging cannot leave saved state different from the model after a late cancellation', () => {
  const h = harness(), c = h.c;
  h.pointer('pointerdown'); h.pointer('pointermove', 3, 2);
  h.change({id: 'units', value: 'ft'});
  assert.equal(c.p.unit, 'ft'); assert.equal(h.stored().projects[0].unit, 'ft');
  h.pointer('pointercancel', 3, 2);
  assert.equal(c.p.unit, 'ft', 'late drag cancellation must not revert a committed unit setting');
  assert.deepEqual(c.p, h.stored().projects[0], 'in-memory and saved model must agree after settlement');
});

test('audit: one inspector delete click commits a focused width field before the inspector rebuild and deletes once', () => {
  const h = harness(), c = h.c;
  h.pointer('pointerdown'); h.pointer('pointermove', 3, 2); h.pointer('pointerup', 3, 2);
  const flow = h.focusedInspectorClick({action: 'delete'}, 'w', '2.75');
  assert.equal(flow.prevented, true); assert.equal(flow.clicks, 1); assert.equal(flow.blurs, 1);
  assert.deepEqual(flow.events.slice(0, 4), ['preventDefault', 'click', 'blur', 'refresh']);
  assert.equal(flow.button.isConnected, false, 'the clicked node really was replaced during its handler');
  assert.equal(c.p.objects.length, 0); assert.equal(h.stored().projects[0].objects.length, 0);
  assert.equal(h.messages.filter(x => x === '已删除，可撤销').length, 1);
  c.travelHistory(); assert.equal(c.p.objects.length, 1);
  assert.equal(c.p.objects[0].w, 2.75, 'undo deletion restores the just-committed field value');
  assert.equal(c.p.objects[0].x, 2);
  c.travelHistory(true); assert.equal(c.p.objects.length, 0);
});

test('audit: inspector action after focused-field blur uses the current entity rather than the replaced model object', () => {
  const h = harness(), c = h.c; c.select('object', h.coffee.id);
  const original = c.p.objects[0], flow = h.focusedInspectorClick({action: 'rotateObject'}, 'w', '2.75');
  assert.equal(flow.clicks, 1); assert.equal(flow.blurs, 1); assert.notEqual(c.p.objects[0], original);
  assert.equal(c.p.objects[0].w, 2.75); assert.equal(c.p.objects[0].angle, 90);
  assert.equal(h.stored().projects[0].objects[0].angle, 90);
  c.travelHistory(); assert.equal(c.p.objects[0].w, 2.75); assert.equal(c.p.objects[0].angle, 0);
});
