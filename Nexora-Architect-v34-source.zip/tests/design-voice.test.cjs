const test = require('node:test');
const assert = require('node:assert/strict');
const BIM = require('../dist/geometry.js');
const Cabinets = require('../dist/cabinets.js');
const {createBridge} = require('../dist/voice-edits.js');

function fixture() {
  let project=BIM.newProject(), floorId=project.floors[0].id;
  BIM.addRectangle(project,0,0,5,4,floorId);
  const selectedWall=project.walls[0].id;
  const selectedCabinet=BIM.object(project,'baseCabinet',1,2,floorId).id;
  let selectionType='wall', id=selectedWall, snapshot;
  const state=()=>({project,floorId,selectionType,entity:[...project.walls,...project.objects].find(e=>e.id===id)});
  const bridge=createBridge({state,BIM,Cabinets,transact(fn,msg,onError) {
    snapshot=JSON.stringify(project);
    try { fn();project=BIM.validate(project);return true; }
    catch(err) {project=JSON.parse(snapshot);onError(err);return false;}
  },undo(){project=JSON.parse(snapshot);return true;}});
  return {bridge,state,selectedWall,selectedCabinet,select(type,target){selectionType=type;id=target;}};
}
const near=(x,y)=>assert.ok(Math.abs(x-y)<1e-8);
test('wall thickness: change vs set, bounds, JSON reopening and undo',()=>{
  const {bridge,state}=fixture();
  const apply=(amount,mode)=>bridge.edit_selection({action:'wall_thickness',target:bridge.inspect_selection().target,amount,mode,unit:'in'});
  const start=state().entity.thickness;
  assert.ok(apply(2,'change').ok);near(state().entity.thickness,start+.0508);
  assert.ok(apply(6,'set').ok);near(BIM.validate(JSON.parse(JSON.stringify(state().project))).walls[0].thickness,.1524);
  assert.ok(bridge.undo_voice_edit().ok);near(state().entity.thickness,start+.0508);
  assert.equal(apply(.5,'set').ok,false);near(state().entity.thickness,start+.0508);
});
test('plan-direction move, cancellation and stale selection protection',()=>{
  const {bridge,state,select,selectedWall,selectedCabinet}=fixture();
  bridge.inspect_selection();select('object',selectedCabinet);
  assert.equal(bridge.edit_selection({target:selectedWall,action:'wall_thickness',amount:1,unit:'in',mode:'change'}).ok,false);
  const move=(direction,amount)=>bridge.edit_selection({target:bridge.inspect_selection().target,action:'move_cabinet',direction,amount,unit:'cm'});
  assert.ok(move('right',30).ok);near(state().entity.x,1.3);near(state().entity.y,2);
  assert.ok(bridge.undo_voice_edit().ok);near(state().entity.x,1);
  assert.ok(move('up',10).ok);near(state().entity.y,1.9);
  assert.equal(move('up',undefined).ok,false);
  select('wall','missing');assert.equal(bridge.inspect_selection().ok,false);
});
test('wall length moves shared endpoints, protected openings still validate',()=>{
  const {bridge,state}=fixture();
  const w=state().entity,neighbor=state().project.walls[1];
  BIM.opening(state().project,w.id,.65,'door');
  const resize=amount=>bridge.edit_selection({action:'wall_length',target:bridge.inspect_selection().target,amount,mode:'set',unit:'m'});
  assert.ok(resize(6).ok);near(BIM.dist(state().entity.a,state().entity.b),6);
  near(state().project.walls.find(v=>v.id===neighbor.id).a.x,6);
  assert.equal(resize(.5).ok,false);near(BIM.dist(state().entity.a,state().entity.b),6);
});
const request=(uid,origin='https://app.test',body='v=0\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111\r\nm=application 9 UDP/DTLS/SCTP webrtc-datachannel\r\n')=>new Request('https://app.test/api/ai/voice',{method:'POST',headers:{Origin:origin,'X-Nexora-Client':'studio','oai-authenticated-user-id':uid,'Content-Type':'application/sdp'},body});
test('realtime handshake requires login, origin, SDP and server-only secret',async()=>{
  const {api}=await import('../worker/api.mjs');
  const env={OPENAI_API_KEY:'mock-secret'};let count=0;
  const upstream=async(url,init)=>{
    count++;assert.equal(url,'https://api.openai.com/v1/realtime/calls');assert.equal(init.headers.Authorization,'Bearer mock-secret');
    const session=JSON.parse(init.body.get('session'));assert.equal(session.audio.input.turn_detection.interrupt_response,true);
    assert.deepEqual(session.tools.map(t=>t.name),['design_kitchen','read_kitchen_brief','inspect_selection','edit_selection','edit_opening','undo_voice_edit']);
    return new Response('negotiated-answer');
  };
  assert.equal((await api(request(''),env,upstream)).status,401);
  assert.equal((await api(request('u','https://other.test'),env,upstream)).status,403);
  assert.equal((await api(request('u','https://app.test','x'.repeat(70000)),env,upstream)).status,413);
  assert.equal((await api(request('u','https://app.test','not SDP'),env,upstream)).status,400);
  const r=await api(request('u'),env,upstream);assert.equal(r.status,200);assert.equal(r.headers.get('content-type'),'application/sdp');
  assert.equal(await r.text(),'negotiated-answer');assert.equal(count,1);
});

test('voice UI supports several turns, interrupts, deduplicates edits and releases microphone',async()=>{
  const fs=require('node:fs'),vm=require('node:vm');
  const {bridge,state,select,selectedCabinet}=fixture();select('object',selectedCabinet);
  let pc,channel,trackStopped=false,closed=false,status='',active=false;
  const outputs=[],log=[];
  const micTrack={stop(){trackStopped=true;}};
  class Peer {
    constructor(){pc=this;}
    addTrack(){}
    createDataChannel(){channel={readyState:'open',send(raw){outputs.push(JSON.parse(raw));},close(){}};return channel;}
    async createOffer(){return {sdp:'test-offer',type:'offer'};}
    async setLocalDescription(){} async setRemoteDescription(){}
    close(){closed=true;}
  }
  const window={RTCPeerConnection:Peer,addEventListener(){}};
  vm.runInNewContext(fs.readFileSync(require.resolve('../dist/design-voice.js'),'utf8'),{
    window,navigator:{mediaDevices:{getUserMedia:async()=>({getAudioTracks:()=>[micTrack],getTracks:()=>[micTrack]})}},
    document:{createElement:()=>({setAttribute(){},pause(){},remove(){}}),body:{append(){}}},
    RTCPeerConnection:Peer,AbortController,fetch:async()=>new Response('answer'),setTimeout,clearTimeout});
  const voice=window.DesignVoice.create({tools:bridge,getProject:()=>state().project.id,shared:()=>true,
    getContext:()=> '{}',getHistory:()=>[],onTranscript:(role,line)=>log.push({role,line}),
    onActive:value=>active=value,onStatus:text=>status=text});
  await voice.start();channel.onopen();assert.ok(active&&pc);
  const emit=obj=>channel.onmessage({data:JSON.stringify(obj)});
  function result(id,item) {
    emit({type:'response.created',response:{id}});
    emit({type:'response.done',response:{id,status:'completed',output:[item]}});
  }
  const tool=(name,call_id,args)=>({type:'function_call',name,call_id,arguments:JSON.stringify(args)});
  emit({type:'input_audio_buffer.speech_started'});
  result('inspect',tool('inspect_selection','one',{}));
  const args={target:selectedCabinet,action:'move_cabinet',direction:'right',amount:6,unit:'in'};
  emit({type:'response.created',response:{id:'interrupted'}});
  emit({type:'input_audio_buffer.speech_started'});
  emit({type:'response.done',response:{id:'interrupted',status:'completed',output:[tool('edit_selection','cancelled',args)]}});
  near(state().entity.x,1);
  result('edit',tool('edit_selection','two',args));result('duplicate',tool('edit_selection','two',args));
  near(state().entity.x,1+.1524);
  result('speech',{type:'message',content:[{transcript:'已移动。'}]});
  assert.equal(log.at(-1).line,'已移动。');
  assert.equal(outputs.filter(x=>x.item?.call_id==='two').length,1);
  voice.stop();assert.ok(trackStopped&&closed&&!active);assert.match(status,/结束/);
});
