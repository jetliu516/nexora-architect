const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const E=require('../dist/geometry'),U=require('../dist/units'),PI=require('../dist/project-import'),PL=require('../dist/project-library'),W=require('../dist/workspace-model'),US=require('../dist/us-residential'),THREE=require('../dist/vendor/three.min');
const source=fs.readFileSync(require.resolve('../dist/workbench'),'utf8');
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-8,`${a} != ${b}`);
function drawing(){const c={RoofModel:require('../dist/roof-model'),RoofDisplay:require('../dist/roof-display'),BIM:E,Units:U,Openings:require('../dist/openings'),Cabinets:require('../dist/cabinets')};c.window=c;vm.createContext(c);vm.runInContext(fs.readFileSync(require.resolve('../dist/drawings'),'utf8'),c);return c.Drawings}
test('startup preserves language preference and new blank creation explicitly offers English',()=>{
 const data={'nexora-language':'zh'},elements={},element=()=>({nodeType:1,closest:()=>false,hasAttribute:()=>false,append(){},prepend(){},setAttribute(){}});
 const body=element(),header=element(),c={localStorage:{getItem:k=>data[k]||null,setItem:(k,v)=>data[k]=v},NodeFilter:{SHOW_ELEMENT:1,SHOW_TEXT:4},CustomEvent:class{},MutationObserver:class{observe(){}},navigator:{language:'zh-CN'},document:{body,documentElement:{},createElement:()=>{const el=element();Object.defineProperty(el,'id',{set:id=>elements[id]=el});return el},getElementById:id=>elements[id],querySelector:()=>header,createTreeWalker:()=>({nextNode:()=>null})},dispatchEvent(){}};c.window=c;
 vm.createContext(c);vm.runInContext(fs.readFileSync(require.resolve('../dist/i18n'),'utf8'),c);assert.equal(c.NexoraI18n.language,'zh');assert.equal(c.document.documentElement.lang,'zh-CN');c.NexoraI18n.set('en');assert.equal(data['nexora-language-preference-v2'],'en');c.NexoraI18n.set('zh');assert.equal(c.NexoraI18n.language,'zh');
 let dialogHTML='';c.dialog=(title,html)=>dialogHTML=html;c.p={unit:'m'};const action=source.slice(source.indexOf("case'new':")+10,source.indexOf("break;case'demo':"));vm.runInContext(action,c);assert.equal(c.NexoraI18n.language,'zh');assert.match(dialogHTML,/name="language"/);assert.match(dialogHTML,/value="zh" selected/);
});
test('actual new-project form creates Main Floor, English Room names, imperial units and respects an explicit language choice',()=>{
 const line=source.split('\n').find(l=>l.startsWith("document.addEventListener('submit',"));let submit,created,lang;
 const values={name:'Empty English',unit:'ft',language:'en'},ctx={E,PL,ProjectRegion:require('../dist/project-region'),window:{NexoraI18n:{set:v=>lang=v}},document:{addEventListener:(type,fn)=>submit=fn},FormData:class{get(k){return values[k]}},resetProject:p=>(created=p,true),$:()=>({close(){}}),toast(){}};
 vm.runInNewContext(line,ctx);submit({preventDefault(){},target:{id:'newProjectForm'}});assert.equal(created.unit,'ft');assert.equal(created.language,'en');assert.equal(created.floors[0].name,'Main Floor');assert.equal(lang,'en');E.addRectangle(created,0,0,5,4,created.floors[0].id);assert.equal(E.detectRooms(created,created.floors[0].id)[0].name,'Room 1');
 values.language='zh';submit({preventDefault(){},target:{id:'newProjectForm'}});E.addRectangle(created,0,0,5,4,created.floors[0].id);assert.equal(E.detectRooms(created,created.floors[0].id)[0].name,'空间 1');
});
test('real file import handler restores JSON as an independent deep copy and leaves original intact; bad/oversize inputs do not write',async()=>{
 const original=E.demo(),snapshot=JSON.stringify(original),db={active:original.id,projects:[E.clone(original)],trash:[],recovery:[]},messages=[];let writes=0;
 const ctx={E,PL,ProjectImport:PI,db,p:original,s:{floor:original.floors[0].id},importSequence:0,resetProject:next=>{ctx.db=PL.upsert(ctx.db,next);ctx.p=next;writes++;return true},toast:t=>messages.push(t),$:()=>({close(){}})};vm.createContext(ctx);
 for(const name of ['importOrigin','sameImportOrigin'])vm.runInContext(source.split('\n').find(l=>l.startsWith('function '+name+'(')),ctx);
 const a=source.indexOf('async function importProjectFile('),b=source.indexOf("document.addEventListener('change',importProjectFile)",a);vm.runInContext(source.slice(a,b),ctx);
 const upload=(text,size=text.length)=>({target:{id:'projectImportPicker',value:'fixture.json',files:[{name:'fixture.json',size,text:async()=>text}]}});
 await ctx.importProjectFile(upload(snapshot));assert.equal(writes,1);assert.equal(ctx.db.projects.length,2);assert.notEqual(ctx.p.id,original.id);assert.match(ctx.p.name,/Imported copy/);assert.equal(JSON.stringify(ctx.db.projects.find(p=>p.id===original.id)),snapshot);
 assert.deepEqual(JSON.parse(JSON.stringify(ctx.p.walls)),original.walls);ctx.p.walls[0].a.x=99;assert.equal(original.walls[0].a.x,0);assert.equal(ctx.db.projects.find(p=>p.id===original.id).walls[0].a.x,0);
 const before=JSON.stringify(ctx.db);await ctx.importProjectFile(upload('{bad'));await ctx.importProjectFile(upload(snapshot,15000001));assert.equal(writes,1);assert.equal(JSON.stringify(ctx.db),before);assert.ok(messages.some(m=>m.includes('15 MB')));
});
test('transverse section shows actual 28-degree roof slopes; longitudinal section remains physically horizontal',()=>{
 const D=drawing(),p=E.demo();p.roofs[0].pitch=28;
 const cross=D.section(p,{sectionAxis:'x'},6);const paths=[...cross.markup.matchAll(/data-roof-section="[^"]+" data-roof-pitch="28" d="M([\d.e+-]+) ([\d.e+-]+)L([\d.e+-]+) ([\d.e+-]+)"/g)];assert.equal(paths.length,2);
 for(const [,x1,y1,x2,y2]of paths)near(Math.atan(Math.abs((+y2-y1)/(+x2-x1)))*180/Math.PI,28);
 const along=D.section(p,{sectionAxis:'y'},4.5);const line=along.markup.match(/data-roof-section[^>]+ d="M([\d.e+-]+) ([\d.e+-]+)L([\d.e+-]+) ([\d.e+-]+)"/);near(+line[2],+line[4]);
 p.walls[0].height=3.4;const edited=D.section(p,{sectionAxis:'x'},6);assert.match(edited.markup,new RegExp('data-wall-height="'+p.walls[0].id+'" data-height-m="3.4"'));assert.match(edited.markup,/Wall height 3.40 m/);assert.match(edited.markup,/Floor setting 2.80 m/);
 assert.equal(W.normalizeState({sectionAxis:'x'},p).sectionAxis,'x');assert.equal(W.normalizeState({},p).sectionAxis,'y');assert.equal(W.defaults().sectionAxis,'x');
});
test('Craftsman summary states exact living area to two decimals without changing its footprint',()=>{
 const p=US.build('craftsman'),area=E.estimate(p,p.floors[0].id).livingNetArea/.09290304;near(Number(area.toFixed(2)),1620.62);assert.equal(US.summary('craftsman').livingSqFt,1620.62);assert.equal(US.entries.find(t=>t.id==='craftsman').width,52);
});
test('cut-height slider uses integer millimetres and exposes a canonical decimal readout',()=>{
 let handler;const output={},s={cutHeight:1.35},ctx={s,model:null,$:()=>({addEventListener:(type,fn)=>handler=fn,...output,textContent:''})};const controls={};ctx.$=id=>controls[id]||(controls[id]={addEventListener:(type,fn)=>handler=fn});
 vm.runInNewContext(source.split('\n').find(l=>l.startsWith("$('cutHeight').addEventListener('input'")),ctx);
 let text='';handler({target:{value:'1350',setAttribute:(k,v)=>text=v}});assert.equal(s.cutHeight,1.35);assert.equal(JSON.stringify(s.cutHeight),'1.35');assert.equal(W.normalizeState({cutHeight:1.350000023841858},E.demo()).cutHeight,1.35);assert.equal(text,'1.35 m');assert.equal(controls.cutHeightValue.textContent,'1.35 m');handler({target:{value:'1400',setAttribute(){}}});assert.equal(s.cutHeight,1.4);
 const html=fs.readFileSync(require.resolve('../dist/index.html'),'utf8');assert.match(html,/<input id="cutHeight" type="range" min="300" max="4000" step="50" value="1350"/);
});
test('subway tile is physical 3x6-inch staggered geometry; driveway has a readable 3D label and visible edges',()=>{
 const noop=()=>{},g=new Proxy({createLinearGradient:()=>({addColorStop:noop})},{get:(o,k)=>o[k]||noop,set:(o,k,v)=>(o[k]=v,true)}),c={THREE,BIM:E,Cabinets:require('../dist/cabinets'),Openings:require('../dist/openings'),document:{createElement:()=>({width:0,height:0,getContext:()=>g})}};c.window=c;vm.createContext(c);vm.runInContext(fs.readFileSync(require.resolve('../dist/render-materials'),'utf8'),c);vm.runInContext(fs.readFileSync(require.resolve('../dist/residential-rendering'),'utf8'),c);vm.runInContext(fs.readFileSync(require.resolve('../dist/view3d'),'utf8'),c);
 const v=Object.create(c.BuildingView.prototype);v.model=new THREE.Group();v.scene=new THREE.Scene();v.sun=new THREE.DirectionalLight();v.renderer={};v.ground=new THREE.Mesh(new THREE.PlaneGeometry(200,200),new THREE.MeshStandardMaterial());v.render=()=>{};c.ResidentialRendering.setup(v);
 const p=E.newProject('Backsplash'),f=p.floors[0].id,w=E.wall(p,{x:0,y:0},{x:6,y:0},f);w.thickness=.2;const o=E.object(p,'sink',1,.11,f);o.w=.762;o.d=.6096;v.p=p;v.s={floor:f,layers:{walls:true}};v.objectDetails(o,0);
 const surface=v.model.children.find(g=>g.userData.detail==='backsplash'),tiles=surface.children.filter(m=>m.userData.surface==='subway-tile');assert.ok(tiles.length>=30);assert.equal(new Set(tiles.map(m=>m.position.y.toFixed(6))).size,6);assert.ok(tiles.every(m=>m.geometry.parameters.width<=.1524&&m.geometry.parameters.height<.0762));assert.ok(v.model.children.some(g=>g.children.some(m=>m.userData.label?.includes('SUBWAY TILE'))));
 v.landscape=new THREE.Group();v.buildLandscape(p);assert.ok(v.landscape.children.some(m=>m.userData.label==='DRIVEWAY'));assert.ok(v.landscape.children.some(m=>m.userData.surface==='driveway'));
});
