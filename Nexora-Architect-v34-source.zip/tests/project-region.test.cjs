const test = require('node:test');
const assert = require('node:assert/strict');
const E = require('../dist/geometry.js');
const R = require('../dist/project-region.js');
const PL = require('../dist/project-library.js');

const close = (actual, expected, message) => assert.ok(
  Math.abs(actual-expected) <= Math.max(1, Math.abs(expected))*1e-11,
  message || `${actual} should equal ${expected}`);
const imperial = {floor: 1/.3048**2, wall: 1/.3048**2, window: 1/.3048**2,
  concrete: 1/.9144**3, cabinet: 1/.3048, door: 1};
const labels = {floor: 'sq ft', wall: 'sq ft', window: 'sq ft', concrete: 'cu yd', cabinet: 'ft', door: 'each'};
function house() {
  const p = E.demo();
  p.rates = {floor: 123.456789123, wall: 32.10987654, concrete: 512.3456789,
    door: 1234.56789123, window: 678.98765432, cabinet: 987.654321, waste: 13.25};
  return E.validate(p);
}
function reopen(p) {
  const db = PL.upsert({projects: [], trash: [], recovery: []}, p), writes = new Map;
  PL.persist({setItem: (k, v) => writes.set(k, v)}, 'test-library', db);
  return PL.load(writes.get('test-library'), {validate: E.validate, createEmpty: E.newProject});
}

test('region: legacy projects retain their original units and custom CNY prices through validation and reopening', () => {
  for (const unit of ['m', 'ft']) {
    const p = house(); p.unit = unit; const before = JSON.stringify(p), total = E.estimate(p).total;
    assert.equal(Object.hasOwn(p, 'currency'), false); assert.equal(R.currency(p), 'CNY');
    const checked = E.validate(p), restored = reopen(checked).projects[0];
    assert.equal(Object.hasOwn(checked, 'currency'), false, 'validation must not silently relabel legacy rates');
    assert.equal(restored.unit, unit); assert.equal(R.currency(restored), 'CNY');
    assert.deepEqual(restored.rates, p.rates); close(E.estimate(restored).total, total);
    assert.equal(JSON.stringify(p), before);
  }
});

test('region: USD, CAD and CNY persist independently without applying currency presets or exchange conversions', () => {
  const original = house();
  for (const currency of ['USD', 'CAD', 'CNY']) {
    const p = E.clone(original); p.currency = currency;
    const restored = reopen(p).projects[0];
    assert.equal(restored.currency, currency); assert.deepEqual(restored.rates, original.rates);
    close(E.estimate(restored).total, E.estimate(original).total);
    const copy = PL.duplicate({projects: [restored], trash: []}, restored.id, E.uid());
    assert.equal(copy.currency, currency); assert.deepEqual(copy.rates, restored.rates);
    copy.rates.floor += 1; assert.notEqual(copy.rates.floor, restored.rates.floor);
  }
});

test('region: independent physical conversion factors preserve every line amount and overall total in both unit systems', () => {
  const p = house(), canonical = E.estimate(p), before = JSON.stringify(p);
  for (const unit of ['m', 'ft']) {
    const q = {...p, unit}, rows = R.rows(q);
    for (const row of rows) {
      const source = canonical.rows.find(r => r.key === row.key), factor = unit === 'ft' ? imperial[row.key] : 1;
      close(R.factor(q, row.key), factor); close(row.quantity, source.quantity*factor);
      close(row.rate, source.rate/factor); close(row.quantity*row.rate, source.quantity*source.rate);
      assert.equal(row.unit, unit === 'ft' ? labels[row.key] : source.unit);
    }
    close(rows.reduce((sum, r) => sum+r.quantity*r.rate, 0), canonical.total);
  }
  assert.equal(JSON.stringify(p), before);
});

test('region: editing a displayed unit rate has an exact canonical round trip without modifying quantity or unrelated rates', () => {
  for (const unit of ['m', 'ft']) for (const key of Object.keys(imperial)) {
    const p = house(); p.unit = unit; const before = E.clone(p), shownRate = 17.321098765;
    const shownQuantity = R.rows(p).find(r => r.key === key).quantity;
    p.rates[key] = shownRate*R.factor(p, key);
    const restored = reopen(E.validate(p)).projects[0], row = R.rows(restored).find(r => r.key === key);
    close(row.rate, shownRate); close(row.quantity, shownQuantity); close(row.rate*row.quantity, shownRate*shownQuantity);
    for (const other of Object.keys(before.rates).filter(k => k !== key)) assert.equal(restored.rates[other], before.rates[other]);
    assert.deepEqual(restored.walls, before.walls); assert.deepEqual(restored.objects, before.objects);
  }
});

test('region: reading formatted rows, amounts and currency neither mutates projects nor exposes shared rate records', () => {
  const p = house(); p.unit = 'ft'; p.currency = 'CAD'; const before = JSON.stringify(p);
  const rows = R.rows(p); R.money(p, E.estimate(p).total); R.currency(p);
  rows[0].quantity = 999; rows[0].rate = 999; rows[0].name = 'changed label';
  assert.equal(JSON.stringify(p), before); assert.notEqual(R.rows(p)[0].rate, 999);
  assert.match(R.money({currency: 'USD'}, 1234.56), /^\$1,234\.56$/);
  assert.match(R.money({currency: 'CAD'}, 1234.56), /^CA\$1,234\.56$/);
  assert.match(R.money({}, 1234.56), /1,234\.56$/);
  assert.notEqual(R.money({currency: 'CNY'}, 1234.56), R.money({currency: 'USD'}, 1234.56));
});

test('region: new-project defaults are explicit and project-local, leaving old projects and shared samples untouched', () => {
  const old = house(), oldBefore = JSON.stringify(old), samplesBefore = JSON.stringify(R.samples);
  const a = E.newProject('New A'), b = E.newProject('New B'), identity = a.id;
  assert.equal(R.newDefaults(a), a); R.newDefaults(b);
  assert.equal(a.id, identity); assert.equal(a.name, 'New A'); assert.equal(a.unit, 'ft'); assert.equal(a.currency, 'USD');
  close(a.floors[0].height, 9*.3048); assert.equal(a.floors[0].name, 'Main Floor');
  assert.deepEqual(a.rates, R.samples.USD); assert.notEqual(a.rates, b.rates); assert.notEqual(a.rates, R.samples.USD);
  close(a.rates.floor*0.3048**2, 12); close(a.rates.concrete*0.9144**3, 175);
  assert.doesNotThrow(() => E.validate(a)); a.rates.floor += 3; a.floors[0].name = 'Custom';
  assert.equal(JSON.stringify(old), oldBefore); assert.equal(JSON.stringify(R.samples), samplesBefore);
  assert.equal(b.floors[0].name, 'Main Floor'); assert.equal(b.rates.floor, R.samples.USD.floor);
});

test('region: explicitly loading a currency preset changes only currency and rates; invalid codes are atomic', () => {
  const p = house(); p.unit = 'ft'; const before = E.clone(p);
  R.setCurrency(p, 'CAD');
  assert.equal(p.currency, 'CAD'); assert.deepEqual(p.rates, R.samples.CAD); assert.notEqual(p.rates, R.samples.CAD);
  const {currency, rates, ...rest} = p, {rates: oldRates, ...oldRest} = before;
  assert.deepEqual(rest, oldRest);
  for (const code of ['', 'EUR', 'usd', '<script>', 42, null, {}, ['USD']]) {
    const snapshot = JSON.stringify(p); assert.throws(() => R.setCurrency(p, code), /currency/);
    assert.equal(JSON.stringify(p), snapshot);
  }
});

test('region: malformed currency metadata is rejected before persistence, with the input left unchanged', () => {
  for (const currency of ['', 'EUR', 'usd', '<img onerror=1>', 42, true, {}, ['USD'], Infinity, NaN]) {
    const p = house(); p.currency = currency; const before = structuredClone(p);
    assert.throws(() => E.validate(p), /currency/, `reject currency ${String(currency)}`);
    assert.deepEqual(p, before);
  }
});

test('region: malformed prices remain rejected in regional projects, and invalid library entries are isolated', () => {
  for (const value of [-1, Infinity, NaN, '12', null, 1000001]) {
    const p = house(); p.currency = 'USD'; p.rates.floor = value;
    assert.throws(() => E.validate(p));
  }
  const valid = house(); valid.currency = 'USD';
  const bad = house(); bad.currency = 'bad-code';
  const db = PL.load(JSON.stringify({active: bad.id, projects: [valid, bad]}), {validate: E.validate, createEmpty: E.newProject});
  assert.equal(db.projects.length, 1); assert.equal(db.projects[0].id, valid.id); assert.equal(db.active, valid.id);
  assert.equal(db.recovery.length, 1); assert.equal(JSON.parse(db.recovery[0].raw).currency, 'bad-code');
});
