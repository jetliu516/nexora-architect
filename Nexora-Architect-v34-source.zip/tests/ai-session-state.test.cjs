const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../dist/ai-assistant.js'),'utf8');
const onlineURL='https://nexora-architect-studio-1103.jetliu518.chatgpt.site/#ai';
const loginURL='/signin-with-chatgpt?return_to=%2F%23ai';
const settle=()=>new Promise(resolve=>setImmediate(resolve));
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return{promise,resolve,reject};};
function response(body,{status=200,type='application/json',json}={}){
 const r={status,ok:status>=200&&status<300,headers:{get:key=>key.toLowerCase()==='content-type'?type:null},jsonCalls:0,
  json(){r.jsonCalls++;return json?json():Promise.resolve(body);}};return r;
}

// Run the real browser module with an isolated DOM and an entirely mocked fetch.
// No real network client, credentials, user project or OpenAI SDK is available.
function fixture(url='https://studio.example.test/'){
 const elements=new Map(),requests=[],launchers=[],events={},attachmentBusy=[];
 class Element{
  constructor(tag){this.tagName=tag;this.children=[];this.attributes={};this.dataset={};this.hidden=false;this.disabled=false;this.checked=false;this.value='';this.textContent='';this.href='';this.target='';this.rel='';const classes=new Set();
   this.classList={remove:k=>classes.delete(k),contains:k=>classes.has(k),toggle(k,on){if(on===undefined)on=!classes.has(k);on?classes.add(k):classes.delete(k);return on;}};
  }
  set id(value){this.attributes.id=value;elements.set(value,this);}get id(){return this.attributes.id;}
  setAttribute(key,value){this.attributes[key]=String(value);if(key==='id')this.id=value;else if(['hidden','disabled','checked'].includes(key))this[key]=true;else if(['href','target','rel'].includes(key))this[key]=String(value);else if(key.startsWith('data-'))this.dataset[key.slice(5).replace(/-([a-z])/g,(_,c)=>c.toUpperCase())]=String(value);}
  getAttribute(key){return this.attributes[key]??null;}
  set innerHTML(html){this.children=[];for(const match of html.matchAll(/<([a-z][\w-]*)\b([^>]*)>/gi)){
   const attrs=[...match[2].matchAll(/([\w-]+)(?:="([^"]*)"|='([^']*)'|=([^\s>]+))?/g)];
   if(!attrs.some(a=>a[1]==='id'||a[1]==='data-ai-prompt'))continue;
   const el=new Element(match[1]);for(const a of attrs)el.setAttribute(a[1],a[2]??a[3]??a[4]??'');this.append(el);
  }}
  append(...children){for(const child of children){child.parentNode=this;child.parentElement=this;this.children.push(child);}}
  replaceChildren(...children){this.children=[];this.append(...children);}
  querySelectorAll(selector){assert.equal(selector,'[data-ai-prompt]');return this.children.filter(e=>e.dataset.aiPrompt);}
  scrollIntoView(){}focus(){}
 }
 const document={body:new Element('body'),createElement:tag=>new Element(tag),getElementById:id=>elements.get(id),querySelectorAll(selector){assert.equal(selector,'[data-action="aiAssistant"]');return launchers;}};
 for(const id of ['headerAssistant','professionalAssistant']){const b=new Element('button');b.id=id;b.setAttribute('data-action','aiAssistant');b.setAttribute('aria-expanded','false');launchers.push(b);}
 const voice={active:false,startCalls:0,stopCalls:0,start(){this.startCalls++;this.active=true;voiceOptions.onActive(true);},stop(){this.stopCalls++;if(this.active){this.active=false;voiceOptions.onActive(false);}},followKitchen(){}};
 let voiceOptions;
 const context={document,location:new URL(url),URL,TextDecoder,AbortController,
  addEventListener:(name,fn)=>{events[name]=fn;},
  fetch(route,options){assert.ok(['/api/ai/session','/api/ai/chat'].includes(route),'Only isolated mock endpoints are allowed');const d=deferred();requests.push({route,options,...d});return d.promise;},
  AIAttachments:{create(){return{clear(){},busy:value=>attachmentBusy.push(value),snapshot:()=>({attachments:[]}),labels:()=>[]};}},
  DesignVoice:{create(options){voiceOptions=options;return voice;}},DesignConvert:{open(){throw Error('Image conversion is outside this test');}}
 };
 context.window=context;vm.runInNewContext(source,context);
 context.ArchitectAI.configure(()=>({name:'Isolated test plan',rooms:0}),()=>'mock-project',{});
 const get=id=>{const el=elements.get(id);assert.ok(el,`Element ${id} exists`);return el;};
 return{context,get,requests,launchers,voice,attachmentBusy,open:()=>context.ArchitectAI.open(),close:()=>get('aiClose').onclick(),reconnect:()=>get('aiReconnect').onclick(),
  sessions:()=>requests.filter(r=>r.route==='/api/ai/session'),chats:()=>requests.filter(r=>r.route==='/api/ai/chat'),
  submit(question='Please describe this test plan'){get('aiQuestion').value=question;return get('aiForm').onsubmit({preventDefault(){}});},
  snapshot(){return{status:get('aiStatus').textContent,send:get('aiSend').disabled,voice:get('aiVoice').disabled,reconnect:get('aiReconnect').disabled,loginHidden:get('aiLogin').hidden,href:get('aiLogin').href,target:get('aiLogin').target,rel:get('aiLogin').rel,label:get('aiLogin').textContent};}
 };
}
function assertFallback(h){
 assert.match(h.get('aiStatus').textContent,/本地预览/);assert.match(h.get('aiStatus').textContent,/JSON/);
 assert.equal(h.get('aiLogin').hidden,false);assert.equal(h.get('aiLogin').href,onlineURL);assert.equal(h.get('aiLogin').target,'_blank');
 assert.match(h.get('aiLogin').rel,/\bnoopener\b/);assert.match(h.get('aiLogin').rel,/\bnoreferrer\b/);
 assert.match(h.get('aiLogin').textContent,/在线 AI/);assert.equal(h.get('aiSend').disabled,true);assert.equal(h.get('aiVoice').disabled,true);assert.equal(h.get('aiReconnect').disabled,false);
}

test('AI session state: loopback 404 and HTML responses give a safe online link and never enable sending',async()=>{
 for(const host of ['localhost','127.0.0.1','[::1]'])for(const kind of ['404','html','missing-content-type']){
  const h=fixture(`http://${host}:8786/`);h.open();assert.equal(h.sessions().length,1);assert.equal(h.get('aiReconnect').disabled,true);
  const r=kind==='404'?response({authenticated:true,configured:true},{status:404}):response(null,{type:kind==='html'?'text/html; charset=utf-8':null,json:()=>{throw Error('Static HTML must not be parsed as session JSON');}});
  h.sessions()[0].resolve(r);await settle();assertFallback(h);assert.equal(r.jsonCalls,0);
  await h.submit();assert.equal(h.chats().length,0);assert.equal(h.get('aiQuestion').value,'Please describe this test plan');
 }
});

test('AI session state: file preview requires no network and exposes the same non-destructive online handoff',async()=>{
 const h=fixture('file:///test/Nexora/index.html');h.open();await settle();assertFallback(h);assert.equal(h.requests.length,0);
 h.reconnect();await settle();assertFallback(h);assert.equal(h.requests.length,0);await h.submit();assert.equal(h.chats().length,0);
});

test('AI session state: production JSON distinguishes sign-in, unconfigured and authenticated connections',async()=>{
 for(const [body,loginVisible,enabled,label] of [
  [{authenticated:false,configured:true},true,false,/登录后/],
  [{authenticated:true,configured:false},false,false,/待配置/],
  [{authenticated:true,configured:true,model:'test-model'},false,true,/已连接 OpenAI · test-model/]
 ]){
  const h=fixture();h.open();h.sessions()[0].resolve(response(body));await settle();
  assert.match(h.get('aiStatus').textContent,label);assert.equal(h.get('aiLogin').hidden,!loginVisible);assert.equal(h.get('aiLogin').href,loginURL);assert.equal(h.get('aiLogin').target,'_top');
  assert.equal(h.get('aiSend').disabled,!enabled);assert.equal(h.get('aiVoice').disabled,!enabled);assert.equal(h.get('aiReconnect').disabled,false);
  if(!enabled){await h.submit();assert.equal(h.chats().length,0);}
 }
});

test('AI session state: an allowed submit reaches only the mocked chat transport and completes normally',async()=>{
 const h=fixture();h.open();h.sessions()[0].resolve(response({authenticated:true,configured:true,model:'test-model'}));await settle();
 const submitted=h.submit('A deterministic mock question');assert.equal(h.chats().length,1);assert.equal(h.get('aiSend').disabled,true);assert.equal(h.get('aiStop').disabled,false);
 const request=h.chats()[0];assert.equal(request.options.method,'POST');assert.equal(JSON.parse(request.options.body).messages.at(-1).content,'A deterministic mock question');
 const bytes=new TextEncoder().encode('{"delta":"Mock answer"}\n{"done":true}\n');let sent=false;
 request.resolve({ok:true,body:{getReader:()=>({read:async()=>sent?{done:true}:(sent=true,{done:false,value:bytes})})}});
 await submitted;assert.equal(h.get('aiSend').disabled,false);assert.equal(h.get('aiVoice').disabled,false);assert.equal(h.get('aiStop').disabled,true);assert.match(h.get('aiStatus').textContent,/回复完成/);
 assert.deepEqual(h.attachmentBusy,[true,false]);assert.equal(h.requests.length,2);
});

test('AI session state: reconnect resets stale fallback, loading controls and login links before restoring service',async()=>{
 const h=fixture('http://localhost:8786/');h.open();h.sessions()[0].resolve(response(null,{status:404,type:'text/html'}));await settle();assertFallback(h);
 h.reconnect();assert.match(h.get('aiStatus').textContent,/正在检查/);assert.equal(h.get('aiLogin').hidden,true);assert.equal(h.get('aiReconnect').disabled,true);assert.equal(h.get('aiSend').disabled,true);assert.equal(h.get('aiVoice').disabled,true);
 h.sessions()[1].resolve(response({authenticated:false,configured:true}));await settle();
 assert.equal(h.get('aiLogin').href,loginURL);assert.equal(h.get('aiLogin').target,'_top');assert.match(h.get('aiLogin').textContent,/ChatGPT/);assert.equal(h.get('aiLogin').hidden,false);
 h.reconnect();h.sessions()[2].resolve(response({authenticated:true,configured:true,model:'recovered-model'}));await settle();
 assert.match(h.get('aiStatus').textContent,/recovered-model/);assert.equal(h.get('aiLogin').hidden,true);assert.equal(h.get('aiSend').disabled,false);assert.equal(h.get('aiVoice').disabled,false);
 h.reconnect();assert.equal(h.get('aiSend').disabled,true);h.sessions()[3].reject(new Error('Mock connection loss'));await settle();
 assert.match(h.get('aiStatus').textContent,/重新连接/);assert.equal(h.get('aiSend').disabled,true);assert.equal(h.get('aiVoice').disabled,true);assert.equal(h.get('aiReconnect').disabled,false);
 h.reconnect();h.sessions()[4].resolve(response({authenticated:true,configured:true,model:'again'}));await settle();assert.equal(h.get('aiSend').disabled,false);assert.match(h.get('aiStatus').textContent,/again/);
});

test('AI session state: stale fetch, JSON and rejected promises cannot overwrite the latest request',async()=>{
 for(const stalePhase of ['fetch-html','json','reject']){
  const h=fixture('http://localhost:8786/'),oldJSON=deferred();h.open();
  if(stalePhase==='json'){h.sessions()[0].resolve(response(null,{json:()=>oldJSON.promise}));await settle();}
  h.open();assert.equal(h.sessions().length,2);assert.equal(h.get('aiReconnect').disabled,true);
  h.sessions()[1].resolve(response({authenticated:true,configured:true,model:'latest-request'}));await settle();const latest=h.snapshot();
  if(stalePhase==='json')oldJSON.resolve({authenticated:false,configured:false});
  else if(stalePhase==='reject')h.sessions()[0].reject(new Error('Old mock request failed'));
  else h.sessions()[0].resolve(response(null,{status:404,type:'text/html'}));
  await settle();assert.deepEqual(h.snapshot(),latest);assert.equal(h.get('aiSend').disabled,false);
 }
 const h=fixture();h.open();h.open();h.sessions()[0].reject(new Error('Stale while newer request is pending'));await settle();
 assert.match(h.get('aiStatus').textContent,/正在检查/);assert.equal(h.get('aiReconnect').disabled,true);assert.equal(h.get('aiSend').disabled,true);
 h.sessions()[1].resolve(response({authenticated:false,configured:false}));await settle();assert.equal(h.get('aiReconnect').disabled,false);assert.match(h.get('aiStatus').textContent,/登录后/);
 const signedOut=fixture();signedOut.open();signedOut.open();signedOut.sessions()[1].resolve(response({authenticated:false,configured:true}));await settle();
 signedOut.sessions()[0].resolve(response({authenticated:true,configured:true,model:'stale-permission'}));await settle();
 assert.match(signedOut.get('aiStatus').textContent,/登录后/);assert.equal(signedOut.get('aiSend').disabled,true);assert.equal(signedOut.get('aiVoice').disabled,true);
 await signedOut.submit();assert.equal(signedOut.chats().length,0,'an old authenticated response cannot restore permission after a newer signed-out response');
});

test('AI session state: production connection failures remain local to the current page and recover through reconnect',async()=>{
 for(const kind of ['404','500','invalid-json','network']){
  const h=fixture();h.open();
  if(kind==='network')h.sessions()[0].reject(new Error('Mock network error'));
  else h.sessions()[0].resolve(response(null,kind==='invalid-json'?{json:()=>Promise.reject(new SyntaxError('Mock invalid JSON'))}:{status:Number(kind),type:'text/html'}));
  await settle();assert.match(h.get('aiStatus').textContent,/无法连接 AI 服务.*重新连接/);assert.doesNotMatch(h.get('aiStatus').textContent,/本地预览/);
  assert.equal(h.get('aiLogin').hidden,true);assert.equal(h.get('aiLogin').href,loginURL);assert.equal(h.get('aiSend').disabled,true);assert.equal(h.get('aiVoice').disabled,true);assert.equal(h.get('aiReconnect').disabled,false);
  await h.submit();assert.equal(h.chats().length,0);
 }
});

test('AI session state: open, close and hash activation synchronize every entry without reopening on a late response',async()=>{
 const h=fixture();assert.equal(h.get('aiPanel').hidden,true);h.open();
 for(const b of h.launchers){assert.equal(b.getAttribute('aria-controls'),'aiPanel');assert.equal(b.getAttribute('aria-expanded'),'true');}
 h.close();assert.equal(h.get('aiPanel').hidden,true);for(const b of h.launchers)assert.equal(b.getAttribute('aria-expanded'),'false');
 h.sessions()[0].resolve(response({authenticated:true,configured:true,model:'late'}));await settle();assert.equal(h.get('aiPanel').hidden,true);for(const b of h.launchers)assert.equal(b.getAttribute('aria-expanded'),'false');
 h.open();assert.equal(h.get('aiPanel').hidden,false);for(const b of h.launchers)assert.equal(b.getAttribute('aria-expanded'),'true');
 h.sessions()[1].resolve(response({authenticated:false,configured:true}));await settle();
 const hash=fixture('https://studio.example.test/#ai');assert.equal(hash.get('aiPanel').hidden,false);assert.equal(hash.sessions().length,1);
 for(const b of hash.launchers)assert.equal(b.getAttribute('aria-expanded'),'true');hash.sessions()[0].resolve(response({authenticated:false,configured:true}));await settle();
});
