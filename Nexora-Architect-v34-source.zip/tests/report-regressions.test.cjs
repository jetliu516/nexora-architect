const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const E=require('../dist/geometry.js'),W=require('../dist/workspace-model.js'),M=require('../dist/mep.js'),PL=require('../dist/project-library.js');
const source=fs.readFileSync(require.resolve('../dist/workbench.js'),'utf8');
function fixture(){const p=E.demo(),s={...W.defaults(),floor:p.floors[0].id};let saved;
 const canvas={hasPointerCapture:()=>false};
 const c={p,s,E,WM:W,MEP:M,drag:null,history:[],future:[],refresh(){},renderInspector(){},status(){},toast(){},$:()=>canvas,
 save(){saved=JSON.stringify(c.p);return true}};vm.createContext(c);
 for(const name of ['transact','endDrag'])vm.runInContext(source.split('\n').find(l=>l.startsWith('function '+name+'(')),c);
 c.roofBounds=f=>E.roofBounds(c.p,f);c.roofOutside=f=>!!E.uncoveredRoofWalls(c.p,f).length;
 return {c,saved:()=>JSON.parse(saved)};
}
test('drag commits changed shared wall endpoint once, cancel restores and undo data remains exact',()=>{
 const {c,saved}=fixture(),before=JSON.stringify(c.p),id=c.p.walls[0].id,old={...c.p.walls[0].b};
 E.moveNode(c.p,c.s.floor,old,{x:13,y:0});c.drag={type:'node',snapshot:before,changed:true};c.endDrag({});
 assert.equal(saved().walls.find(w=>w.id===id).b.x,13);assert.equal(c.history.length,1);
 const second=JSON.stringify(c.p);E.moveNode(c.p,c.s.floor,{x:13,y:0},{x:14,y:0});c.drag={type:'node',snapshot:second,changed:true};c.endDrag({},true);
 assert.equal(c.p.walls.find(w=>w.id===id).b.x,13);assert.equal(c.history.length,1);assert.equal(c.history[0],before);
});
test('simple selection is not a drag transaction; furniture change/delete persists once and round-trips',()=>{
 const {c,saved}=fixture();c.drag={type:'object',snapshot:JSON.stringify(c.p),changed:false};c.endDrag({});assert.equal(c.history.length,0);
 const id=c.p.objects[1].id;
 assert.ok(c.transact(()=>{const o=c.p.objects.find(o=>o.id===id);o.w=1.25;o.x+=.4}));
 const edited=saved();assert.equal(edited.objects.find(o=>o.id===id).w,1.25);
 const storage={setItem(k,v){this.raw=v}},db={projects:[],active:edited.id,trash:[],recovery:[]};PL.persist(storage,'test',PL.upsert(db,edited));
 const reloaded=PL.load(storage.raw,{validate:E.validate,createEmpty:E.newProject});assert.equal(reloaded.projects[0].objects.find(o=>o.id===id).w,1.25);
 const count=c.p.objects.length;assert.ok(c.transact(()=>{c.p.objects=c.p.objects.filter(o=>o.id!==id)}));
 assert.equal(saved().objects.length,count-1);assert.ok(!saved().objects.some(o=>o.id===id));assert.equal(E.validate(JSON.parse(c.history.at(-1))).objects.length,count);
});
test('roof warning detects attached and detached additions; fit covers complete wall thickness and preserves style',()=>{
 const {c}=fixture(),f=c.s.floor,r=c.p.roofs[0],pitch=r.pitch;assert.equal(c.roofOutside(f),false);
 E.addRectangle(c.p,13,0,3,3,f);assert.equal(c.roofOutside(f),true);Object.assign(r,c.roofBounds(f));assert.equal(c.roofOutside(f),false);assert.equal(r.pitch,pitch);assert.ok(r.x+r.w>=16.12);
});
test('wheel page deltas have bounded ten-percent changes',()=>{
 const segment=source.match(/s.zoom=Math.max\(\.2,Math.min\(8,s.zoom\*Math.exp\(-Math.max[^;]+/)[0];
 const s={zoom:1},ctx={s,delta:2000,e:{deltaY:2,deltaMode:2},Math,$:()=>({clientHeight:1000})};vm.runInNewContext(segment,ctx);assert.ok(s.zoom>.9&&s.zoom<1);
});
test('numeric inspector fields expose exact decimal strings and keep numeric validation metadata',()=>{
 const ctx={E,unit:()=> 'm',esc:String};vm.createContext(ctx);vm.runInContext(source.split('\n').find(l=>l.startsWith('function field(')).split('const lf=')[0],ctx);
 const html=ctx.field('Height','floorHeight',2.799999952316284,{min:1,max:10});assert.match(html,/value="2.80"/);assert.match(html,/data-number="true"/);assert.match(html,/type="text"/);assert.match(html,/data-max="10"/);
});
test('endpoint handles are the final SVG overlay; automatic dimensions propagate into printed drawing; section includes datums',()=>{
 const ctx={RoofModel:require('../dist/roof-model'),RoofDisplay:require('../dist/roof-display'),BIM:E,Units:require('../dist/units.js'),Cabinets:require('../dist/cabinets.js'),Openings:require('../dist/openings.js')};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync(require.resolve('../dist/drawings.js'),'utf8'),ctx);
 const p=E.demo(),s={...W.defaults(),floor:p.floors[0].id,selected:{type:'wall',id:p.walls[0].id},autoDimensions:true};
 const svg=ctx.Drawings.plan(p,s);assert.ok(svg.lastIndexOf('data-handle=')>svg.lastIndexOf('data-entity="opening"'));assert.match(ctx.Drawings.plan(p,s,{print:true}),/data-auto-dimensions/);
 const section=ctx.Drawings.section(p,s,4.5);assert.match(section.markup,/sectionHatch/);assert.match(section.markup,/data-section-datum/);assert.match(section.markup,/Floor setting/);assert.match(section.title,/Preview/);
});
