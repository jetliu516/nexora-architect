const test=require('node:test'),assert=require('node:assert/strict');
const E=require('../dist/geometry.js'),M=require('../dist/mep-profile.js'),A=require('../dist/mep-ai.js'),W=require('../dist/workspace-model.js');
function fixture(){const p=E.newProject('AI MEP verification'),f=p.floors[0].id,a=M.node(p,'cold','waterMeter',f,0,0,1),b=M.node(p,'cold','inlet',f,4,0,1),r=M.connect(p,a.id,b.id,{routing:'direct'});return{p,f,a,b,r}}
const plan=operations=>({summary:'Proposal only',assumptions:[],operations});
test('AI parameter proposal leaves original unchanged and reports downstream geometry changes',()=>{
 const {p,r,a}=fixture(),scope=A.scopeFor(p,['cold'],{type:'mepRun',id:r.id}),before=JSON.stringify(p),result=A.proposal(p,plan([{type:'set_run',runId:r.id,diameterM:.032,slope:null},{type:'set_node',nodeId:a.id,zM:2,loadW:null,flowLpm:null,gasKW:null}]),scope);assert.equal(JSON.stringify(p),before);assert.equal(result.next.mep.runs[0].diameter,.032);assert.equal(result.changes.length,2);assert.ok(result.changes.find(c=>c.type==='mepRun').after.lengthM>4);assert.throws(()=>W.assertEditable(p,result.next,{...W.defaults(),locks:{mep_cold:true}}));
});
test('AI scope rejects unlisted targets, structural fields, cross-system fields and nonfinite parameters atomically',()=>{
 const {p,r,a,f}=fixture(),x=M.node(p,'hot','heater',f,2,2,1),s=A.scopeFor(p,['cold'],{type:'mepNode',id:a.id}),before=JSON.stringify(p);
 for(const op of [{type:'set_run',runId:r.id,diameterM:.032,slope:null},{type:'set_node',nodeId:x.id,zM:2,loadW:null,flowLpm:null,gasKW:null},{type:'set_node',nodeId:a.id,zM:2,loadW:200,flowLpm:null,gasKW:null},{type:'set_node',nodeId:a.id,zM:Infinity,loadW:null,flowLpm:null,gasKW:null},{type:'set_node',nodeId:a.id,zM:2,loadW:null,flowLpm:null,gasKW:null,x:99}])assert.throws(()=>A.proposal(p,plan([op]),s));assert.equal(JSON.stringify(p),before);
});
test('AI rebuilding requires explicit permission and cannot expand system or selected-object scope',()=>{
 const {p,r}=fixture(),op={type:'optimize',systems:['cold'],drainSlope:.02};assert.throws(()=>A.proposal(p,plan([op]),A.scopeFor(p,['cold'])));assert.throws(()=>A.proposal(p,plan([op]),A.scopeFor(p,['cold'],{type:'mepRun',id:r.id},true)));assert.throws(()=>A.proposal(p,plan([{...op,systems:['gas']}]),A.scopeFor(p,['cold'],null,true)));
 const out=A.proposal(p,plan([op]),A.scopeFor(p,['cold'],null,true));assert.ok(out.changes.length);assert.equal(out.next.mep.nodes.find(n=>n.id===p.mep.nodes[0].id).id,p.mep.nodes[0].id);
});
test('AI avoidance uses real geometry and refuses impossible routes without committing earlier edits',()=>{
 const {p,r,f}=fixture();E.wall(p,{x:2,y:-1},{x:2,y:1},f);const scope=A.scopeFor(p,['cold'],{type:'mepRun',id:r.id}),ops=[{type:'set_run',runId:r.id,diameterM:.032,slope:null},{type:'avoid',runId:r.id,clearanceM:.05,detourM:2}],out=A.proposal(p,plan(ops),scope);assert.equal(out.afterClashes.count,0);assert.ok(out.next.mep.runs[0].waypoints.length);ops[1].detourM=.1;assert.throws(()=>A.proposal(p,plan(ops),scope));assert.equal(p.mep.runs[0].diameter,.025);
});
test('AI context bounds named targets and reports omissions instead of permitting hidden IDs',()=>{
 const {p,f}=fixture();for(let i=0;i<70;i++)M.node(p,'cold','inlet',f,i,2,1);const scope=A.scopeFor(p,['cold']),ctx=A.context(p,scope);assert.equal(ctx.nodes.length,60);assert.equal(ctx.omitted.nodes,12);assert.throws(()=>A.proposal(p,plan([{type:'set_node',nodeId:p.mep.nodes.at(-1).id,zM:2,loadW:null,flowLpm:null,gasKW:null}]),scope));assert.throws(()=>A.scopeFor(p,['__proto__']));
});
let api,validateMEPInput;const ready=Promise.all([import('../worker/api.mjs').then(m=>api=m.api),import('../worker/mep-ai.mjs').then(m=>validateMEPInput=m.validateMEPInput)]);
const req=(body,uid='mep-api',headers={})=>new Request('https://studio.test/api/ai/mep',{method:'POST',headers:{Origin:'https://studio.test','X-Nexora-Client':'studio','Content-Type':'application/json','oai-authenticated-user-id':uid,...headers},body:JSON.stringify(body)});
test('AI MEP API enforces authentication, request origin and bounded input before calling provider',async()=>{
 await ready;let calls=0;const f=()=>{calls++;throw Error()},body={prompt:'Change pipe',context:A.context(fixture().p,{systems:['cold']})};assert.equal((await api(req(body,''),{OPENAI_API_KEY:'test'},f)).status,401);assert.equal((await api(req(body,'mep-bad',{Origin:'https://evil.test'}),{OPENAI_API_KEY:'test'},f)).status,403);assert.throws(()=>validateMEPInput({...body,prompt:'x'.repeat(3001)}));assert.throws(()=>validateMEPInput({...body,context:{}}));assert.equal(calls,0);
});
test('AI MEP API passes actual model, no-store and constrained ID schema; response is only a proposed plan',async()=>{
 await ready;const {p,r}=fixture(),context=A.context(p,A.scopeFor(p,['cold'],{type:'mepRun',id:r.id}));let payload;const answer=plan([{type:'set_run',runId:r.id,diameterM:.032,slope:null}]);const response=await api(req({prompt:'32mm',context,language:'es'}),{OPENAI_API_KEY:'private'},async(url,opts)=>{payload=JSON.parse(opts.body);return Response.json({status:'completed',output:[{content:[{type:'output_text',text:JSON.stringify(answer)}]}]})});const data=await response.json();assert.equal(response.status,200);assert.deepEqual(data.plan,answer);assert.equal(payload.model,'gpt-6.1-sol');assert.equal(payload.store,false);assert.ok(payload.instructions.includes('Spanish'));assert.deepEqual(payload.text.format.schema.properties.operations.items.anyOf[0].properties.runId.enum,[r.id]);assert.equal(p.mep.runs[0].diameter,.025);
});
test('AI MEP incomplete, malformed or provider-error results never become applicable operations',async()=>{
 await ready;const {p}=fixture(),body={prompt:'32mm',context:A.context(p,{systems:['cold']})};for(const [i,response]of [Response.json({status:'incomplete'}),Response.json({status:'completed',output:[]}),new Response('private failure',{status:401})].entries()){const result=await api(req(body,'mep-error-'+i),{OPENAI_API_KEY:'private'},async()=>response);assert.equal(result.status,502);assert.ok(!(await result.text()).includes('private'))}
});
test('an already canceled MEP request never reaches the provider',async()=>{
 await ready;const controller=new AbortController();controller.abort();const {p}=fixture(),base=req({prompt:'Change diameter',context:A.context(p,{systems:['cold']})},'mep-pre-abort'),request=new Request(base,{signal:controller.signal});let called=0;const result=await api(request,{OPENAI_API_KEY:'test'},async()=>{called++;throw Error()});assert.equal(called,0);assert.equal(result.status,499);
});
