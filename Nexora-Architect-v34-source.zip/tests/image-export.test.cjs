const assert = require('node:assert/strict');
const { test } = require('node:test');
const { capture } = require('../dist/image-export.js');

function fixture({limit = 8192, encodeError = false, lost = false} = {}) {
  let width = 390, height = 300, ratio = 2;
  const captures = [], draws = [];
  const camera = {aspect: 1.3, updateProjectionMatrix() {}};
  const gl = {MAX_RENDERBUFFER_SIZE: 1, getParameter: () => limit, isContextLost: () => lost};
  const canvas = {width: 780, height: 600, toDataURL() {
    captures.push([this.width, this.height, camera.aspect]);
    if (encodeError) throw new Error('encoding failed');
    return 'data:image/png;base64,' + 'a'.repeat(100);
  }};
  const renderer = {
    domElement: canvas, capabilities: {maxTextureSize: limit},
    getContext: () => gl, getSize: target => target.set(width,height), getPixelRatio: () => ratio,
    setPixelRatio(v) { ratio=v; },
    setSize(w,h,updateStyle) { assert.equal(updateStyle,false); width=w; height=h; canvas.width=w*ratio; canvas.height=h*ratio; }
  };
  const view = {renderer,camera,render() {draws.push([canvas.width,canvas.height,camera.aspect]);}};
  return {view,captures,draws};
}
for (const [width,height] of [[1920,1080],[2560,1440],[3840,2160]]) {
  test(`${width}×${height} output renders at exact pixels and restores the mobile editor`, () => {
    const f=fixture(); capture(f.view,width,height);
    assert.deepEqual(f.captures,[[width,height,16/9]]);
    assert.deepEqual(f.draws,[[width,height,16/9],[780,600,1.3]]);
    assert.equal(f.view.renderer.getPixelRatio(),2);
  });
}
test('encoding failure restores size, pixel ratio and camera',()=>{
  const f=fixture({encodeError:true}); assert.throws(()=>capture(f.view,3840,2160),/encoding failed/);
  assert.deepEqual(f.draws.at(-1),[780,600,1.3]);
  assert.equal(f.view.renderer.getPixelRatio(),2);
});
test('unsupported GPU size and lost context fail before changing the editor',()=>{
  for(const options of [{limit:2048},{lost:true}]){
    const f=fixture(options); assert.throws(()=>capture(f.view,3840,2160));
    assert.equal(f.draws.length,0); assert.equal(f.view.camera.aspect,1.3);
  }
});
test('invalid dimensions are rejected without allocating a canvas',()=>{
  const f=fixture();
  for(const size of [0,NaN,Infinity,-1,4097,3840.5,'3840']) assert.throws(()=>capture(f.view,size,2160));
  assert.equal(f.draws.length,0);
});
