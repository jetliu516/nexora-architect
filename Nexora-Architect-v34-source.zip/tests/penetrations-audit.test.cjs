const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const root = require('node:path').resolve(__dirname, '..');
const E = require(root + '/dist/geometry.js');
const P = require(root + '/dist/penetrations.js');
const M = globalThis.MEP;
const W = require(root + '/dist/workspace-model.js');
const U = require(root + '/dist/units.js');

function fixture(diagonal = false) {
  const p = E.newProject('Independent penetration audit'), f = p.floors[0].id;
  const w = E.wall(p, {x: 0, y: 0}, {x: 6, y: 0}, f);
  const a = M.node(p, 'cold', 'waterMeter', f, diagonal ? 2 : 3, -1, 1);
  const b = M.node(p, 'cold', 'inlet', f, diagonal ? 4 : 3, 1, 1);
  const r = M.connect(p, a.id, b.id, {routing: 'direct'});
  return {p: E.validate(p), f, w, a, b, r};
}

function centerlineHits(p, h, r) {
  const path = M.path(p, r);
  return P.parts(p, h).flatMap(part => {
    const c = Math.cos(part.angle), s = Math.sin(part.angle);
    const local = q => ({x: (q.x-part.x)*c+(q.y-part.y)*s, y: -(q.x-part.x)*s+(q.y-part.y)*c, z: q.z-part.z});
    return path.slice(1).filter((b, i) => M.boxHit(local(path[i]), local(b),
      {x: -part.w/2, y: -part.d/2, z: -part.h/2},
      {x: part.w/2, y: part.d/2, z: part.h/2}, 0));
  }).length;
}

test('diagonal wall sleeve projection must not intersect its associated pipe centerline', () => {
  const {p, r} = fixture(true);
  const result = P.propose(p, {clearance: .01, sleeve: .003, projection: .2});
  assert.equal(result.added.length, 1);
  assert.equal(centerlineHits(result.next, result.added[0], r), 0);
  const before = P.propose(p, {clearance: .01, sleeve: .003, projection: 0}).next;
  before.penetrations[0].projection = .2;
  assert.ok(P.inspect(before, before.penetrations[0]).length, 'enlarging projection must trigger fit warning');
});

test('diagonal slab sleeve projection must not intersect its associated pipe centerline', () => {
  const p = E.newProject('Slab'), f = p.floors[0].id;
  E.addRectangle(p, 0, 0, 8, 8, f);
  const a = M.node(p, 'cold', 'waterMeter', f, 2, 3, -1);
  const b = M.node(p, 'cold', 'inlet', f, 4, 3, 1);
  const r = M.connect(p, a.id, b.id, {routing: 'direct'});
  const result = P.propose(p, {clearance: .01, sleeve: .003, projection: .2});
  assert.equal(result.added.length, 1);
  assert.equal(centerlineHits(result.next, result.added[0], r), 0);
});

test('pocket door cavity is protected from a new wall penetration', () => {
  const {p, f, w} = fixture(); p.mep = {schema: 1, nodes: [], runs: []};
  const o = E.opening(p, w.id, .3, 'door', 'pocket');
  Object.assign(o, {offset: 1, width: .8, height: 2.1, sill: 0, hingeRight: false});
  const a = M.node(p, 'cold', 'waterMeter', f, 2.2, -1, 1);
  const b = M.node(p, 'cold', 'inlet', f, 2.2, 1, 1);
  M.connect(p, a.id, b.id, {routing: 'direct'});
  const result = P.propose(p);
  assert.equal(result.added.length, 0);
  assert.ok(result.issues.length);
});

test('reuse check must use the existing sleeve inner aperture without translating it', () => {
  const {p, r} = fixture();
  const c = P.crossings(p, r, {clearance: 0, sleeve: .003})[0];
  p.penetrations = [{...c, id: 'existing', name: 'Existing', runIds: [r.id],
    u: 3.0315, v: 1.0315, width: .125, height: .125, clearance: 0, sleeve: .05, projection: 0, notes: ''}];
  const result = P.propose(E.validate(p), {clearance: 0, sleeve: .003, projection: 0});
  assert.equal(result.skipped.length, 0);
});

test('CSV guards formula prefixes after whitespace and tabs', () => {
  const {p} = fixture(), next = P.propose(p).next;
  next.penetrations[0].name = ' =1+1'; next.penetrations[0].notes = ' \t=1+1';
  const csv = P.csv(E.validate(next));
  assert.ok(!csv.includes('" =1+1"'));
  assert.ok(!csv.includes('" \t=1+1"'));
});

test('invalid geometry, overlapping records and malicious IDs are rejected without changing input', () => {
  const {p} = fixture(), good = P.propose(p).next;
  const changes = [h => h.width = NaN, h => h.sleeve = -1, h => h.projection = Infinity,
    h => h.id = '<img onerror=1>', h => h.host = 'unknown-host', h => h.runIds = ['bad"id'],
    h => h.name = 'a'.repeat(101), h => h.u = 200, h => h.sleeve = h.width];
  for (const change of changes) {
    const q = E.clone(good); change(q.penetrations[0]); const before = JSON.stringify(q);
    assert.throws(() => E.validate(q)); assert.equal(JSON.stringify(q), before);
  }
  const duplicate = E.clone(good); duplicate.penetrations.push({...duplicate.penetrations[0], id: 'duplicate'});
  assert.throws(() => E.validate(duplicate));
  assert.deepEqual(E.validate(JSON.parse(JSON.stringify(good))).penetrations, good.penetrations);
});

test('real workbench transaction rejects locks/storage failure, preserves preview for retry, blocks stale apply', () => {
  const {p} = fixture(), handlers = {}, messages = [], s = {...W.defaults(), floor: p.floors[0].id};
  let allowSave = true, saved = null;
  const context = {BIM: E, MEP: M, Penetrations: P, WorkspaceModel: W, Units: U, Drawings: {esc: M.escape},
    p, s, E, WM: W, history: [], future: [], drag: null,
    document: {addEventListener: (type, fn) => handlers[type] = fn},
    FormData: class {get(key) {return {scope: 'all', clearance: '.02 m', sleeve: '.003 m', projection: '.025 m'}[key];}},
    refresh() {}, toast: text => messages.push(text), save() {if (!allowSave) return false; saved = JSON.stringify(context.p); return true;}};
  context.window = context;
  const transaction = fs.readFileSync(root + '/dist/workbench.js', 'utf8').split('\n').find(line => line.startsWith('function transact('));
  vm.createContext(context); vm.runInContext(transaction, context);
  vm.runInContext(fs.readFileSync(root + '/dist/penetration-ui.js', 'utf8'), context);
  context.PenetrationUI.init({state: () => ({p: context.p, s}), dialog() {}, close() {}, refresh() {},
    toast: text => messages.push(text), transact: context.transact});
  const click = dataset => handlers.click({target: {closest: () => ({dataset})}});
  const submit = () => handlers.submit({target: {id: 'penetrationGenerate'}, preventDefault() {}});
  click({penGenerate: ''}); submit(); const before = JSON.stringify(context.p);
  for (const lock of ['penetrations', 'walls']) {
    s.locks = {[lock]: true}; click({penApply: ''});
    assert.equal(JSON.stringify(context.p), before); assert.equal(context.history.length, 0);
  }
  s.locks = {}; allowSave = false; click({penApply: ''});
  assert.equal(JSON.stringify(context.p), before); assert.equal(context.history.length, 0); assert.equal(saved, null);
  allowSave = true; click({penApply: ''}); assert.equal(context.p.penetrations.length, 1); assert.equal(context.history.length, 1);
  click({penApply: ''}); assert.equal(context.history.length, 1);
  context.p = E.clone(p); click({penGenerate: ''}); submit(); context.p.name += ' changed';
  const stale = JSON.stringify(context.p); click({penApply: ''}); assert.equal(JSON.stringify(context.p), stale);
  assert.ok(messages.some(m => m.includes('模型已变化')));
});

test('zero-clearance unsleeved openings do not report a tangency as wall penetration', () => {
  for (const diagonal of [false, true]) {
    const {p} = fixture(diagonal), result = P.propose(p, {clearance: 0, sleeve: 0, projection: .1});
    assert.equal(result.added.length, 1);
    assert.equal(result.clashes.issues.length, 0);
  }
});

test('an elbow inside sleeve projection is rejected without changing the source', () => {
  const {p, r} = fixture();
  const run = M.item(p, 'mepRun', r.id), end = M.item(p, 'mepNode', r.b);
  Object.assign(end, {x: 4, y: .2});
  Object.assign(run, {routing: 'waypoints', waypoints: [{x: 3, y: .2, z: 1}]});
  const before = JSON.stringify(p), result = P.propose(p, {clearance: .02, sleeve: .003, projection: .2});
  assert.equal(result.added.length, 0); assert.ok(result.issues.length);
  assert.equal(JSON.stringify(p), before);
});

test('single-run preview reports a new sleeve collision with an unselected run', () => {
  const {p, f, r} = fixture();
  const a = M.node(p, 'hot', 'heater', f, 2, .2, 1.03), b = M.node(p, 'hot', 'inlet', f, 4, .2, 1.03);
  const other = M.connect(p, a.id, b.id, {routing: 'direct'});
  const result = P.propose(p, {runIds: [r.id], clearance: .02, sleeve: .003, projection: .2});
  assert.equal(result.added.length, 1);
  assert.ok(M.clashes(result.next).issues.some(i => i.code === 'sleeve' && i.id === other.id));
  assert.ok(result.clashes.issues.some(i => i.code === 'sleeve' && i.id === other.id));
  const q = result.next, scene = M.routeScene(q, other, 0), path = M.path(q, other);
  assert.equal(scene.blocked(path[0], path[1]), true);
});

test('wall deletion cascades holes and locks protect the indirect deletion', () => {
  const {p, w} = fixture(), before = P.propose(p).next, after = E.clone(before);
  after.walls = after.walls.filter(v => v.id !== w.id); M.reconcile(after);
  assert.equal(after.penetrations.length, 0); assert.doesNotThrow(() => E.validate(after));
  assert.throws(() => W.assertEditable(before, after, {...W.defaults(), locks: {penetrations: true}}));
  const restored = E.validate(JSON.parse(JSON.stringify(before)));
  assert.deepEqual(restored.penetrations, before.penetrations);
});

test('copy floor remaps hosts, keeps local dimensions, clears stale run associations, and exports 12 edges per hole', () => {
  const p = E.newProject('Copy and DXF'), f = p.floors[0]; E.addRectangle(p, 0, 0, 6, 6, f.id);
  const a = M.node(p, 'cold', 'waterMeter', f.id, 3, -1, 1), b = M.node(p, 'cold', 'inlet', f.id, 3, 1, 1);
  const c = M.node(p, 'hot', 'heater', f.id, 3, 3, -1), d = M.node(p, 'hot', 'inlet', f.id, 3, 3, 1);
  M.connect(p, a.id, b.id, {routing: 'direct'}); M.connect(p, c.id, d.id, {routing: 'direct'});
  const q = P.propose(p).next, originals = E.clone(q.penetrations); assert.equal(originals.length, 2);
  const upper = E.duplicateFloor(q, f.id), valid = E.validate(q), copies = P.data(valid).filter(h => h.floor === upper.id);
  assert.equal(copies.length, 2);
  for (const original of originals) {
    const h = copies.find(v => v.kind === original.kind);
    assert.notEqual(h.id, original.id); assert.notEqual(h.host, original.host); assert.deepEqual(h.runIds, []);
    for (const key of ['u', 'v', 'width', 'height', 'sleeve', 'projection']) assert.equal(h[key], original[key]);
    assert.ok(Math.abs(P.frame(valid, h).center.z-P.frame(valid, original).center.z-(upper.elevation-f.elevation)) < 1e-8);
  }
  for (const floor of [f.id, upper.id]) {
    const dxf = E.dxfExport(valid, floor), entities = dxf.split('0\nLINE\n').slice(1).map(block => {
      const lines = block.split('\n'), values = {};
      for (let i = 0; i < lines.length-1 && lines[i] !== '0'; i += 2) values[lines[i]] = lines[i+1];
      return values;
    }).filter(e => e['8']?.startsWith('PENETRATION_'));
    assert.equal(entities.length, 24);
    for (const h of P.data(valid).filter(h => h.floor === floor)) {
      const edges = entities.filter(e => e['8'] === 'PENETRATION_'+h.kind.toUpperCase()); assert.equal(edges.length, 12);
      const points = edges.flatMap(e => [{x: +e['10'], y: -e['20'], z: +e['30']}, {x: +e['11'], y: -e['21'], z: +e['31']}]);
      const g = P.frame(valid, h);
      for (const axis of ['x', 'y', 'z']) assert.ok(Math.abs((Math.min(...points.map(v => v[axis]))+Math.max(...points.map(v => v[axis])))/2-g.center[axis]) < 1e-8);
    }
  }
});

test('elevation and section exports reflect penetrations and projected sleeves', () => {
  const D = require(root + '/dist/drawings.js');
  const {p, f} = fixture(), q = P.propose(p, {clearance: .02, sleeve: .003, projection: .2}).next, s = {...W.defaults(), floor: f};
  assert.notEqual(D.elevation(p, s).markup, D.elevation(q, s).markup);
  assert.notEqual(D.section(p, {...s,sectionAxis:'y'}, .2).markup, D.section(q, {...s,sectionAxis:'y'}, .2).markup);
});
