const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const E=require('../dist/geometry');
const RoofModel=require('../dist/roof-model');
const WM=require('../dist/workspace-model');
const MEP=require('../dist/mep');
const Structure=require('../dist/structure');
const ProjectRegion=require('../dist/project-region');
const PL=require('../dist/project-library');
const source=fs.readFileSync(require.resolve('../dist/workbench'),'utf8');
const lines=source.split('\n');
const line=prefix=>{const value=lines.find(l=>l.startsWith(prefix));assert.ok(value,'Actual workbench source: '+prefix);return value;};
function between(start,end){const a=source.indexOf(start),b=source.indexOf(end,a+start.length);assert.ok(a>=0&&b>a,'Actual workbench block: '+start);return source.slice(a,b);}
const json=value=>JSON.parse(JSON.stringify(value));
function project(name='Original',language='en'){
 const p=ProjectRegion.newDefaults(E.newProject(name));p.language=language;return E.validate(p);
}

// Rendering and persistence are boundaries; state changes, validation, history,
// resetProject, actions, submit handlers and import handlers execute shipped code.
function harness({language='en',projects=[project()],active=projects[0].id}={}){
 const handlers={},elements={},messages=[],writes=[],languageChanges=[],dialogs=[];
 const get=id=>elements[id]||(elements[id]={open:false,close(){this.open=false;this.closes=(this.closes||0)+1;}});
 const c={E,WM,MEP,RoofModel,Structure,ProjectRegion,PL,ProjectImport:require('../dist/project-import'),
  Units:require('../dist/units'),p:E.clone(projects.find(p=>p.id===active)),
  db:{active,projects:E.clone(projects),trash:[],recovery:[]},s:{...WM.defaults()},
  drag:null,history:[],future:[],model:null,projectHistory:new Map(),importSequence:0,nativeScanOrigin:null,
  pendingLibraryImport:null,failSave:false,innerWidth:1200,
  document:{addEventListener(type,fn){(handlers[type]??=[]).push(fn);}},
  FormData:class{constructor(form){this.values=form.values;}get(k){return this.values[k]??null;}},
  $:get,toast:value=>messages.push(value),endDrag:()=>true,selection:()=>null,
  refresh(){if(!c.p.floors.some(f=>f.id===c.s.floor))c.s.floor=c.p.floors[0].id;},
  dialog(title,html){dialogs.push({title,html});get('dialog').open=true;},
  projectDialog(){},captureWorkspace:()=>({}),restoreWorkspace(){},
  WorkspaceUI:{open(){}},ArchitectAI:{endVoice(){},followKitchen(){}},
  NexoraI18n:{language,set(value){this.language=value;languageChanges.push(value);}},
  commitLibrary(next){if(c.failSave)return false;c.db=E.clone(next);writes.push(E.clone(next));return true;}
 };
 c.s.floor=c.p.floors[0].id;c.window=c;vm.createContext(c);
 vm.runInContext([
  line('function save()'),line('function transact'),line('function travelHistory'),
  between('function resetProject(', '\nfunction refresh('),
  between('function action(', '\ndocument.addEventListener('),
  line("document.addEventListener('submit',"),
  between('function importScan(', "document.addEventListener('change',importProjectFile)")
 ].join('\n'),c);
 return {c,messages,writes,languageChanges,dialogs,get,
  submit(id,values){for(const fn of handlers.submit||[])fn({preventDefault(){},target:{id,values}});},
 };
}

test('self audit: opening and cancelling New project preserves the current language and saved model',()=>{
 for(const language of ['zh','es']){
  const h=harness({language}),before=JSON.stringify(h.c.p),library=JSON.stringify(h.c.db);
  h.c.action('new');assert.equal(h.get('dialog').open,true);
  assert.equal(h.c.NexoraI18n.language,language);assert.deepEqual(h.languageChanges,[]);
  h.c.action('close');assert.equal(h.get('dialog').open,false);
  assert.equal(h.c.NexoraI18n.language,language);assert.equal(JSON.stringify(h.c.p),before);
  assert.equal(JSON.stringify(h.c.db),library);assert.equal(h.writes.length,0);
 }
});

test('self audit: the actual New project form creates Spanish, imperial, USD data and retains the old project',()=>{
 const h=harness({language:'zh'}),original=E.clone(h.c.p);h.c.action('new');
 h.submit('newProjectForm',{name:'Casa española',unit:'ft',language:'es'});
 assert.notEqual(h.c.p.id,original.id);assert.equal(h.c.p.name,'Casa española');
 assert.equal(h.c.p.language,'es');assert.equal(h.c.p.floors[0].name,'Planta baja');
 assert.equal(h.c.p.unit,'ft');assert.equal(h.c.p.currency,'USD');
 assert.deepEqual(json(h.c.p.rates),ProjectRegion.samples.USD);
 assert.equal(h.c.NexoraI18n.language,'es');assert.deepEqual(h.languageChanges,['es']);
 assert.deepEqual(json(h.c.db.projects.find(p=>p.id===original.id)),original);
 assert.equal(h.c.db.projects.length,2);assert.equal(h.writes.length,1);
 assert.equal(h.get('dialog').open,false);assert.equal(E.validate(h.c.p).language,'es');
});

test('self audit: failed reset during New project does not change language, close the form or replace the model',()=>{
 const h=harness({language:'zh'});h.c.action('new');h.c.failSave=true;
 const original=JSON.stringify(h.c.p),library=JSON.stringify(h.c.db);
 h.submit('newProjectForm',{name:'Cannot save',unit:'ft',language:'es'});
 assert.equal(JSON.stringify(h.c.p),original);assert.equal(JSON.stringify(h.c.db),library);
 assert.equal(h.c.NexoraI18n.language,'zh');assert.deepEqual(h.languageChanges,[]);
 assert.equal(h.get('dialog').open,true);assert.equal(h.writes.length,0);
});

test('self audit: deleting the last project preserves current language and imperial/USD defaults in its replacement',()=>{
 for(const [language,floorName]of [['en','Main Floor'],['zh','一层'],['es','Planta baja']]){
  // Current UI language deliberately differs from the stored project language.
  const original=project('Last project','en'),h=harness({language,projects:[original]});
  h.submit('deleteProjectForm',{projectId:original.id});
  assert.notEqual(h.c.p.id,original.id);assert.equal(h.c.db.projects.length,1);
  assert.equal(h.c.p.language,language);assert.equal(h.c.p.floors[0].name,floorName);
  assert.equal(h.c.NexoraI18n.language,language);assert.equal(h.c.p.unit,'ft');assert.equal(h.c.p.currency,'USD');
  assert.deepEqual(json(h.c.p.rates),ProjectRegion.samples.USD);assert.equal(h.c.db.trash.length,1);
  assert.deepEqual(json(h.c.db.trash[0].project),original);assert.equal(h.writes.length,1);
  assert.equal(E.validate(h.c.p).currency,'USD');
 }
});

test('self audit: deleting a floor removes only its structural members and real Undo restores the full model',()=>{
 const p=project('Structure deletion'),lower=p.floors[0];E.addRectangle(p,0,0,5,4,lower.id);
 const upper=E.duplicateFloor(p,lower.id);p.structure=Structure.data(p);
 for(const [i,floor]of [lower,upper].entries())p.structure.members.push({
  id:'beam-'+i,floor:floor.id,kind:'beam',x1:0,y1:1,x2:4,y2:1,z:2.5,
  width:.09,depth:.24,material:'Fixture',note:'Floor '+i,detail:{reference:'S-'+i}
 });
 const h=harness({projects:[E.validate(p)]});h.c.s.floor=upper.id;
 const original=E.clone(h.c.p),other=E.clone(h.c.p.structure.members[0]);
 h.c.action('confirmDeleteFloor');
 assert.equal(h.c.p.floors.length,1);assert.equal(h.c.p.floors[0].id,lower.id);
 assert.deepEqual(json(h.c.p.structure.members),[other]);assert.equal(h.c.history.length,1);
 assert.equal(h.writes.length,1);E.validate(h.c.p);
 assert.equal(h.c.travelHistory(),true);assert.equal(h.c.history.length,0);assert.equal(h.c.future.length,1);
 const restored=E.clone(h.c.p);delete restored.updatedAt;delete original.updatedAt;
 assert.deepEqual(restored,original);assert.equal(h.writes.length,2);E.validate(h.c.p);
});

function payload(kind,length){return kind==='dxf'
 ?`0\nSECTION\n2\nENTITIES\n0\nLINE\n8\nWalls\n10\n0\n20\n0\n11\n${length}\n21\n0\n0\nENDSEC\n0\nEOF`
 :JSON.stringify({format:'nexora-roomplan-v1',walls:[{a:[0,0],b:[length,0],height:2.8}]});}
function pendingImport(h,kind,length=4,target={id:'projectImportPicker'}){
 let release;const text=payload(kind,length),promise=new Promise(resolve=>release=resolve);
 target.value='fixture.'+(kind==='dxf'?'dxf':'json');
 target.files=[{name:target.value,size:text.length,text:()=>promise}];
 const done=h.c.importProjectFile({target});return {target,done,release:()=>release(text)};
}

for(const kind of ['dxf','roomplan']){
 test(`self audit: pending ${kind} import rejects a changed project, floor or model`,async t=>{
  for(const mutation of ['project','floor','model'])await t.test(mutation,async()=>{
   const a=project('Import A'),b=project('Untouched B');
   a.floors.push({...a.floors[0],id:E.uid(),name:'Upper',elevation:3});
   const h=harness({projects:[E.validate(a),b]}),upload=pendingImport(h,kind);
   if(mutation==='project')assert.equal(h.c.resetProject(b),true);
   if(mutation==='floor')h.c.s.floor=h.c.p.floors[1].id;
   if(mutation==='model')assert.equal(h.c.transact(()=>E.wall(h.c.p,{x:8,y:0},{x:12,y:0},h.c.s.floor)),true);
   const before=JSON.stringify(h.c.p),saved=JSON.stringify(h.c.db),count=h.writes.length,history=h.c.history.length;
   upload.release();await upload.done;
   assert.equal(JSON.stringify(h.c.p),before);assert.equal(JSON.stringify(h.c.db),saved);
   assert.equal(h.writes.length,count);assert.equal(h.c.history.length,history);
   assert.ok(h.messages.some(m=>/导入已取消/.test(m)),h.messages.join('\n'));
   assert.equal(upload.target.value,'');
  });
 });

 test(`self audit: a second ${kind} file selection supersedes the first without clearing the newer input`,async t=>{
  for(const order of ['old-first','new-first'])await t.test(order,async()=>{
   const h=harness(),target={id:'projectImportPicker'},first=pendingImport(h,kind,4,target),second=pendingImport(h,kind,7,target);
   if(order==='old-first'){
    first.release();await first.done;assert.equal(h.writes.length,0);assert.notEqual(target.value,'');
    second.release();await second.done;
   }else{second.release();await second.done;first.release();await first.done;}
   assert.equal(h.writes.length,1);assert.equal(h.c.history.length,1);assert.equal(h.c.p.walls.length,1);
   assert.equal(E.dist(h.c.p.walls[0].a,h.c.p.walls[0].b),7);assert.equal(target.value,'');
   assert.ok(!h.messages.some(m=>/导入已取消/.test(m)));
  });
 });

 test(`self audit: successful ${kind} import persists only the original target project`,async()=>{
  const a=project('Import A'),b=project('Keep B');E.addRectangle(b,10,0,4,4,b.floors[0].id);
  const h=harness({projects:[a,E.validate(b)]}),untouched=E.clone(h.c.db.projects[1]),floor=h.c.s.floor;
  const upload=pendingImport(h,kind,6);h.c.s.zoom=2;upload.release();await upload.done;
  assert.equal(h.c.p.id,a.id);assert.equal(h.c.db.active,a.id);assert.equal(h.c.db.projects.length,2);
  assert.equal(h.writes.length,1);assert.equal(h.c.history.length,1);assert.equal(h.c.p.walls.length,1);
  assert.equal(h.c.p.walls[0].floor,floor);assert.equal(E.dist(h.c.p.walls[0].a,h.c.p.walls[0].b),6);
  assert.deepEqual(json(h.c.db.projects.find(p=>p.id===b.id)),untouched);
  assert.deepEqual(json(h.c.db.projects.find(p=>p.id===a.id).walls),json(h.c.p.walls));
  E.validate(h.c.p);
 });
}
