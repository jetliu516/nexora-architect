const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const E=require('../dist/geometry.js'),O=require('../dist/openings.js'),W=require('../dist/workspace-model.js'),C=require('../dist/cabinets.js');
const {createBridge}=require('../dist/voice-edits.js');
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-8,`${a} != ${b}`);
function house(style='hinged'){const p=E.newProject();const w=E.wall(p,{x:0,y:0},{x:10,y:0},p.floors[0].id);w.thickness=.2;const o=E.opening(p,w.id,.3,O.types[style].kind,style);return {p,w,o};}
test('all opening types round-trip independently and legacy single/double migrate',()=>{
 for(const style of Object.keys(O.types)){const {p,o}=house(style);const next=E.validate(JSON.parse(JSON.stringify(p)));assert.equal(next.openings[0].style,style);assert.equal(next.openings[0].kind,O.types[style].kind);assert.equal(next.openings[0].id,o.id);for(const part of O.parts(next.openings[0],.2)){assert.ok([...part.a,...part.b,part.bottom,part.height,part.depth].every(Number.isFinite));assert.ok(part.height>0&&part.depth>0);}}
 const {p,o}=house();o.style='single';assert.equal(E.validate(p).openings[0].style,'hinged');o.kind='window';o.style='double';assert.equal(E.validate(p).openings[0].style,'standard');
});
test('niche keeps a physical back wall and quantity uses only removed depth',()=>{
 const {p,w,o}=house('niche');o.width=1;o.height=.6;o.recessDepth=.1;const parts=E.wallPanels(p,w),back=parts.find(p=>p.recess);near(back.depth,.1);near(back.y,-.05);
 near(parts.reduce((s,p)=>s+p.w*p.h*(p.depth??w.thickness),0),10*2.8*.2-1*.6*.1);
 near(E.estimate(p).wallVolume,10*2.8*.2-.06);near(E.estimate(p).wallNet,10*2.8*2+2*(1+.6)*.1);o.flip=true;near(E.wallPanels(p,w).find(p=>p.recess).y,.05);
 o.recessDepth=.19;assert.throws(()=>E.validate(p),/背墙/);
});
test('pass-through cuts the full wall depth, fixed leaf retains solid panel',()=>{
 const {p,w,o}=house('passThrough');assert.equal(O.parts(o,.2).length,0);assert.equal(E.wallPanels(p,w).some(p=>p.recess),false);
 const fixed=house('fixed').o;assert.equal(O.parts(fixed).filter(p=>p.role==='leaf').length,1);assert.doesNotMatch(O.plan(fixed,.2),/<path d="M[^\"]+ A/);
});
test('hinge angle and handedness produce consistent endpoints; sliding has stationary leaf',()=>{
 const {o}=house();o.openAngle=0;let leaf=O.parts(o).find(p=>p.role==='leaf');near(leaf.b[1],0);o.openAngle=90;leaf=O.parts(o).find(p=>p.role==='leaf');near(leaf.b[0],0);near(leaf.b[1],o.width-.05);o.hingeRight=true;o.flip=true;leaf=O.parts(o).find(p=>p.role==='leaf');near(leaf.a[0],o.width);assert.ok(leaf.b[1]<0);
 const v=house('sliding').o;v.openRatio=0;const closed=O.parts(v);v.openRatio=1;const open=O.parts(v);assert.deepEqual(open.find(p=>p.role==='fixedLeaf'),closed.find(p=>p.role==='fixedLeaf'));near(open.find(p=>p.role==='leaf').a[0]-closed.find(p=>p.role==='leaf').a[0],v.width/2);
});
test('folding, pocket, barn and garage have distinct movement geometry',()=>{
 const o=house('bifold').o;o.openRatio=0;let leaves=O.parts(o).filter(p=>p.role==='leaf');near(leaves[0].b[1],0);o.openRatio=1;leaves=O.parts(o).filter(p=>p.role==='leaf');near(leaves[1].b[0],0);assert.ok(leaves[0].b[1]>.3);
 const p=house('pocket').o;p.openRatio=1;near(O.parts(p).find(p=>p.role==='leaf').a[0],p.width);
 const barn=house('barn').o;assert.ok(O.parts(barn,.2).find(p=>p.role==='leaf').a[1]>.1);assert.ok(O.parts(barn).some(p=>p.role==='track'));
 const g=house('garage').o;g.openRatio=1;assert.ok(O.parts(g).some(p=>p.role==='overheadSection'));assert.equal(O.parts(g).some(p=>p.role==='section'),false);
});
test('projected window profiles have real depth, distinct sides, and matching glazing segments',()=>{
 for(const style of ['bay','box','bow']){const o=house(style).o;o.projection=.6;const profile=O.profile(o);assert.equal(O.parts(o).filter(p=>p.role==='glazing').length,profile.length-1);near(Math.min(...profile.map(p=>p[1])),-.6);o.flip=true;near(Math.max(...O.profile(o).map(p=>p[1])),.6);}
 const box=O.profile(house('box').o);near(box[0][0],box[1][0]);assert.ok(O.profile(house('bay').o)[1][0]>0);assert.equal(O.profile(house('bow').o).length,7);
});
test('reject invalid style, motion, intrusion, overlap and out-of-bounds without repairing away data',()=>{
 const {p,o}=house();for(const [key,value]of [['style','unknown'],['openRatio',2],['openAngle',151],['flip','yes'],['width',50],['sill',3]]){const next=E.clone(p);next.openings[0][key]=value;assert.throws(()=>E.validate(next));}
 E.opening(p,p.walls[0].id,.7,'door');p.openings[1].offset=o.offset+.1;assert.throws(()=>E.validate(p),/重叠/);
});
function voiceFixture(){const seed=house('hinged');let project=E.validate(seed.p),id=seed.o.id,selectionRevision=0,busy=false,locked=false,saveFail=false,history=[];
 const state=()=>({project,floorId:project.floors[0].id,selectionType:'opening',entity:project.openings.find(o=>o.id===id),selectionRevision,busy});
 const bridge=createBridge({state,BIM:E,Cabinets:C,transact(fn,msg,onError){const before=E.clone(project);try{fn();const next=E.validate(project);W.assertEditable(before,next,{...W.defaults(),locks:{openings:locked}});if(saveFail)throw Error('保存失败');history.push(before);project=next;return true;}catch(e){project=before;onError(e);return false;}},undo(){if(locked||saveFail||!history.length)return false;project=history.pop();return true;}});
 return {state,bridge,lock:v=>locked=v,saveFail:v=>saveFail=v,busy:v=>busy=v,reselect:()=>selectionRevision++,edit:changes=>bridge.edit_opening({target:bridge.inspect_selection().target,unit:'in',changes})};
}
test('AI edits opening dimensions/style atomically in inches and restores on undo',()=>{
 const f=voiceFixture();assert.equal(f.bridge.inspect_selection().kind,'door');assert.ok(f.edit({width:36,height:80,sill:0,style:'sliding',openRatio:.25}).ok);near(f.state().entity.width,.9144);assert.equal(f.state().entity.style,'sliding');assert.ok(f.bridge.undo_voice_edit().ok);assert.equal(f.state().entity.style,'hinged');
 const before=JSON.stringify(f.state().project);assert.equal(f.edit({width:999,height:81}).ok,false);assert.equal(JSON.stringify(f.state().project),before);
});
test('AI stale inspection rejects selection round-trip, in-place edits and active gestures',()=>{
 const f=voiceFixture(),args=()=>({target:f.state().entity.id,unit:'m',changes:{width:1}});
 f.bridge.inspect_selection();f.reselect();assert.equal(f.bridge.edit_opening(args()).ok,false);
 f.bridge.inspect_selection();f.state().entity.offset+=.1;assert.equal(f.bridge.edit_opening(args()).ok,false);
 f.bridge.inspect_selection();f.busy(true);assert.equal(f.bridge.edit_opening(args()).ok,false);assert.equal(f.bridge.inspect_selection().ok,false);
});
test('AI lock/save failure rolls back and failed undo remains retryable',()=>{
 const f=voiceFixture();f.lock(true);assert.equal(f.edit({width:40}).ok,false);f.lock(false);assert.ok(f.edit({width:40}).ok);f.lock(true);assert.equal(f.bridge.undo_voice_edit().ok,false);near(f.state().entity.width,1.016);f.lock(false);assert.ok(f.bridge.undo_voice_edit().ok);near(f.state().entity.width,.9);
 f.saveFail(true);assert.equal(f.edit({width:41}).ok,false);near(f.state().entity.width,.9);
});

test('pocket reserves a real cavity and rejects insufficient storage or overlapping openings',()=>{
 const {p,w,o}=house('pocket');const skins=E.wallPanels(p,w).filter(p=>p.recess);assert.equal(skins.length,2);near(skins[0].depth,.07);near(E.estimate(p).wallVolume,10*2.8*.2-o.width*o.height*(.2+.06));
 o.offset=9;assert.throws(()=>E.validate(p),/收纳/);o.offset=3;E.validate(p);
 const v={...O.defaults('standard'),id:E.uid(),wall:w.id,offset:4,width:.7,height:.8,sill:1};p.openings.push(v);assert.throws(()=>E.validate(p),/重叠/);
});
test('rendered 3D niche is recessed from one side and solid from the reverse side',()=>{
 const T=require('../dist/vendor/three.min.js'),ctx={THREE:T,BIM:E,Cabinets:C,Openings:O,window:{}};
 vm.runInNewContext(fs.readFileSync(require.resolve('../dist/view3d.js'),'utf8'),ctx);
 const {p,w,o}=house('niche');o.recessDepth=.1;const v=Object.create(ctx.window.BuildingView.prototype);v.model=new T.Group();v.ground=new T.Object3D();v.sun={intensity:1};v.scene=new T.Scene();v.landscape=new T.Group();v.sun=new T.DirectionalLight();v.render=()=>{};
 v.rebuild(p,{floor:w.floor,layers:{walls:true,openings:true},style:'material'});v.model.updateMatrixWorld(true);
 const ray=new T.Raycaster(new T.Vector3(o.offset+o.width/2,o.sill+o.height/2,1),new T.Vector3(0,0,-1));near(ray.intersectObjects(v.model.children,true)[0].point.z,0);
 ray.set(new T.Vector3(o.offset+o.width/2,o.sill+o.height/2,-1),new T.Vector3(0,0,1));near(ray.intersectObjects(v.model.children,true)[0].point.z,-.1);
 // Through-opening has neither a hidden backing slab nor a selectable fake rectangle in 3D.
 o.style='passThrough';v.rebuild(p,{floor:w.floor,layers:{walls:true,openings:true},style:'material'});v.model.updateMatrixWorld(true);assert.equal(ray.intersectObjects(v.model.children,true).length,0);
});

test('sections use the same niche backing, pocket skins and oblique thickness as 3D',()=>{
 global.BIM=E;const D=require('../dist/drawings.js');const {p,w,o}=house('niche');w.a={x:2,y:0};w.b={x:2,y:10};o.recessDepth=.1;
 const cut=o.offset+o.width/2,section=D.section(p,{},cut).markup;assert.match(section,/data-section-role="backing"/);o.style='passThrough';assert.doesNotMatch(D.section(p,{},cut).markup,/data-section-role="backing"/);
 o.kind='door';o.style='pocket';const pocket=D.section(p,{},o.offset+o.width*1.5).markup;assert.equal((pocket.match(/data-section-role="backing"/g)||[]).length,2);
 // A wall at 45 degrees has a wider section than its perpendicular thickness.
 p.openings=[];w.b={x:12,y:10};const diagonal=D.section(p,{},5).markup;const width=Number(diagonal.match(/data-section-role="wall"[^>]*width="([^"]+)"/)[1]);near(width,.2*Math.sqrt(2));
});
