'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const B = require('../dist/beam-analysis');

// Independent mechanics benchmarks, not approved design properties or code limits.
// Reference: USDA FPL Wood Handbook 2021, Chapter 9, equations 9-2--9-4,
// 9-13--9-14 and Table 9-1: https://research.fs.usda.gov/download/treesearch/62251.pdf
// The stored deflections were evaluated using 60-digit Decimal virtual work:
// integral(M * m_unit / EI) + integral(V * v_unit / (kGA)), split at every
// actual and unit load. Piecewise cubic/linear integrands were integrated
// exactly; the observation position was independently optimized. They do not
// use BeamAnalysis's Green functions, candidate selection, or output as oracle.
// Fixture: L=4 m, b=.1 m, h=.3 m, E_true=10 GPa, G=.625 GPa, k=5/6.
const golden = [
  {
    name: 'full-span uniform load', q: 2000, points: [], left: 4000, right: 4000,
    moment: 4000, momentX: 2, bendingStress: 2666666.6666666666667,
    shearStress: 200000, deflectionX: 2,
    bending: .00296296296296296296296296296296296,
    shear: .000256,
    deflection: .00321896296296296296296296296296296
  },
  {
    name: 'centered point load', q: 0, points: [{ x: 2, dead: 10000, variable: 0 }],
    left: 5000, right: 5000, moment: 10000, momentX: 2,
    bendingStress: 6666666.6666666666667, shearStress: 250000, deflectionX: 2,
    bending: .00592592592592592592592592592592593,
    shear: .00064,
    deflection: .00656592592592592592592592592592593
  },
  {
    name: 'off-center point load', q: 0, points: [{ x: 1, dead: 10000, variable: 0 }],
    left: 7500, right: 2500, moment: 7500, momentX: 1,
    bendingStress: 5000000, shearStress: 375000,
    deflectionX: 1.70043482371123040177822467617181500,
    bending: .00413581055409565376628331147129988,
    shear: .00036793042820620313571548405181251,
    deflection: .00450374098230185690199879552311239
  },
  {
    name: 'uniform plus off-center point load', q: 2000,
    points: [{ x: 1, dead: 10000, variable: 0 }],
    left: 11500, right: 6500, moment: 10500, momentX: 1,
    bendingStress: 7000000, shearStress: 575000,
    deflectionX: 1.83035599283544599539464450018240298,
    bending: .00707285209364399192675292177906007,
    shear: .00060130117943965041670835281970018,
    deflection: .00767415327308364234346127459876025
  }
];

const member = () => ({
  id: 'golden-beam', floor: 'golden-floor', kind: 'beam', material: 'Synthetic benchmark',
  x1: 0, y1: 0, x2: 4, y2: 0, z: 0, width: .1, depth: .3
});
const input = (overrides = {}) => ({
  method: B.method, dead: 2000, variable: 0, points: [], E: 1e10, G: 625e6,
  Fb: 12e6, Fv: 1e6, Fc: 3e6, leftBearing: .1, rightBearing: .2,
  totalLimit: 240, variableLimit: 360,
  loadBasis: 'Synthetic downward service loads, self-weight already included',
  materialBasis: 'Synthetic true E, independent G and already-adjusted allowables',
  criteriaBasis: 'Synthetic user limits, not local adopted code',
  supportsConfirmed: true, solidSectionConfirmed: true, selfWeightIncluded: true,
  ...overrides
});
const fixtureInput = g => input({ dead: g.q, points: g.points.map(p => ({ ...p })) });
function close(actual, expected, label, rel = 2e-12, abs = 2e-15) {
  assert.ok(Number.isFinite(actual), `${label}: non-finite result ${actual}`);
  const tolerance = abs + rel * Math.abs(expected);
  assert.ok(Math.abs(actual - expected) <= tolerance,
    `${label}: got ${actual}, expected ${expected}, tolerance ${tolerance}`);
}
const check = (r, id) => {
  const value = r.checks.find(c => c.id === id);
  assert.ok(value, `missing ${id} check`);
  return value;
};
function checkResponse(r, g) {
  close(r.reactionLeft, g.left, 'left reaction');
  close(r.reactionRight, g.right, 'right reaction');
  close(r.totalLoad, g.left + g.right, 'total load');
  close(r.moment.value, g.moment, 'maximum moment');
  close(r.moment.x, g.momentX, 'moment maximum position');
  close(r.shear, Math.max(g.left, g.right), 'maximum absolute shear force');
  close(r.deflection.x, g.deflectionX, 'combined deflection maximum position');
  close(r.deflection.value, g.deflection, 'maximum combined deflection');
  close(r.deflection.bending, g.bending, 'bending component at combined maximum');
  close(r.deflection.shear, g.shear, 'shear component at combined maximum');
  close(r.deflection.bending + r.deflection.shear, r.deflection.value, 'component sum');
  for (const point of [r.diagram[0], r.diagram.at(-1)]) {
    close(point.moment, 0, 'support moment');
    close(point.bending, 0, 'support bending displacement');
    close(point.shearDeflection, 0, 'support shear displacement');
    close(point.deflection, 0, 'support total displacement');
  }
}

for (const g of golden) test(`independent 60-digit benchmark: ${g.name}`, () => {
  const m = member(), v = fixtureInput(g), before = JSON.stringify([m, v]);
  const r = B.calculate(m, v);
  checkResponse(r.cases.total, g);
  close(r.section.span, 4, 'span');
  close(r.section.area, .03, 'gross area');
  close(r.section.I, .000225, 'second moment');
  close(r.section.Z, .0015, 'section modulus');
  close(r.section.shearArea, .025, 'effective shear area');
  close(check(r, 'bending').demand, g.bendingStress, 'extreme-fiber bending stress');
  close(check(r, 'shear').demand, g.shearStress, 'maximum rectangular shear stress');
  close(check(r, 'bearingLeft').demand, g.left / .01, 'left bearing average stress');
  close(check(r, 'bearingRight').demand, g.right / .02, 'right bearing average stress');
  close(check(r, 'totalDeflection').demand, g.deflection, 'total deflection demand');
  close(check(r, 'totalDeflection').limit, 1 / 60, 'entered L/240 criterion');
  assert.equal(JSON.stringify([m, v]), before, 'calculation must not mutate its input');
  assert.equal(r.status, 'draft_not_certified');
  assert.equal(Object.hasOwn(r, 'pass'), false, 'entered checks are not code certification');
});

test('combined deflection maximizes the sum, not separately maximized components', () => {
  const r = B.calculate(member(), fixtureInput(golden[2])).cases.total;
  // Bending-only maximum is x = 4 - sqrt(5), distinct from total and shear maxima.
  close(4 - Math.sqrt(5), 1.7639320225002103036, 'independent bending-only maximum');
  assert.ok(Math.abs(r.deflection.x - (4 - Math.sqrt(5))) > .06);
  assert.ok(Math.abs(r.deflection.x - 1) > .7);
  assert.ok(r.deflection.bending < .0041408666249996105488);
  assert.ok(r.deflection.shear < .00048);
  assert.ok(r.deflection.value < .0041408666249996105488 + .00048,
    'adding unrelated maxima overstates displacement');
});

test('maximum moment lies between the point load and midspan when V crosses zero', () => {
  const r = B.calculate(member(), input({
    points: [{ x: 1, dead: 1000, variable: 0 }]
  })).cases.total;
  close(r.reactionLeft, 4750, 'left reaction');
  close(r.reactionRight, 4250, 'right reaction');
  close(r.moment.x, 1.875, 'independent zero-shear location');
  close(r.moment.value, 4515.625, 'independent interior moment maximum');
  const peak = r.diagram.find(p => Math.abs(p.x - 1.875) < 1e-13);
  assert.ok(peak, 'diagram must retain the analytic extremum between sampling stations');
  close(peak.shear, 0, 'shear at interior moment maximum');
  assert.ok(r.moment.x !== 1 && r.moment.x !== 2);
});

test('mirroring asymmetric loads swaps reactions and mirrors both analytic maxima', () => {
  for (const g of golden.slice(2)) {
    const original = B.calculate(member(), fixtureInput(g)).cases.total;
    const v = fixtureInput(g);
    v.points = v.points.map(p => ({ ...p, x: 4 - p.x }));
    const mirror = B.calculate(member(), v).cases.total;
    close(mirror.reactionLeft, original.reactionRight, 'mirrored left reaction');
    close(mirror.reactionRight, original.reactionLeft, 'mirrored right reaction');
    close(mirror.moment.value, original.moment.value, 'mirrored maximum moment');
    close(mirror.moment.x, 4 - original.moment.x, 'mirrored moment location');
    close(mirror.deflection.value, original.deflection.value, 'mirrored maximum displacement');
    close(mirror.deflection.x, 4 - original.deflection.x, 'mirrored displacement location');
    close(mirror.deflection.bending, original.deflection.bending, 'mirrored bending component');
    close(mirror.deflection.shear, original.deflection.shear, 'mirrored shear component');
    for (const x of [0, 1, 2, 3, 4]) {
      const a = original.diagram.filter(p => Math.abs(p.x - x) < 1e-13);
      const b = mirror.diagram.filter(p => Math.abs(p.x - (4 - x)) < 1e-13).reverse();
      assert.equal(a.length, b.length);
      a.forEach((p, i) => {
        close(b[i].moment, p.moment, 'mirrored station moment');
        close(b[i].deflection, p.deflection, 'mirrored station displacement');
        close(b[i].shear, -p.shear, 'mirrored one-sided shear');
      });
    }
  }
});

test('support-center point loads are expressly rejected without moving or dropping them', () => {
  for (const x of [0, 4]) {
    const v = input({ dead: 0, points: [{ x, dead: 10000, variable: 0 }] });
    const before = JSON.stringify(v);
    assert.throws(() => B.calculate(member(), v), /Point loads must lie between the support centers/);
    assert.equal(JSON.stringify(v), before);
  }
  for (const x of [.000001, 3.999999]) {
    const r = B.calculate(member(), input({ dead: 0, points: [{ x, dead: 10000, variable: 0 }] }));
    close(r.cases.total.reactionLeft + r.cases.total.reactionRight, 10000, 'interior load preserved');
    close(r.cases.total.moment.x, x, 'interior point remains at its actual position');
  }
});

test('zero variable loading produces a finite zero Q case while permanent loading remains', () => {
  for (const g of golden) {
    const r = B.calculate(member(), fixtureInput(g)), q = r.cases.variable;
    for (const key of ['reactionLeft', 'reactionRight', 'totalLoad', 'shear']) close(q[key], 0, key);
    close(q.moment.value, 0, 'Q moment');
    for (const key of ['value', 'bending', 'shear']) close(q.deflection[key], 0, `Q deflection ${key}`);
    assert.ok(Number.isFinite(q.deflection.x));
    for (const point of q.diagram) for (const key of ['moment', 'shear', 'bending', 'shearDeflection', 'deflection']) {
      close(point[key], 0, `Q diagram ${key}`);
    }
    assert.equal(check(r, 'variableDeflection').status, 'within_entered_limit');
    close(check(r, 'variableDeflection').ratio, 0, 'Q displacement utilization');
    checkResponse(r.cases.total, g);
  }
  assert.throws(() => B.calculate(member(), input({ dead: 0 })), /at least one downward load/);
});

test('D plus Q and Q optimize separate service cases, without adding separate case maxima', () => {
  const r = B.calculate(member(), input({ points: [{ x: 1, dead: 0, variable: 10000 }] }));
  checkResponse(r.cases.total, golden[3]);
  checkResponse(r.cases.variable, golden[2]);
  close(check(r, 'variableDeflection').demand, golden[2].deflection, 'Q-only check demand');
  assert.ok(Math.abs(r.cases.total.deflection.x - r.cases.variable.deflection.x) > .12);
  assert.ok(r.cases.total.deflection.value < golden[0].deflection + golden[2].deflection);
});

test('independently rounded US inputs and SI inputs yield the same physical result', () => {
  // International inch/foot and standard gravity conversions; no nominal lumber dimensions.
  const inch = .0254, ft = .3048, lbf = 4.4482216152605, psi = lbf / inch ** 2;
  const usMember = {
    ...member(), x2: 13.123359580052493 * ft,
    width: 3.937007874015748 * inch, depth: 11.811023622047244 * inch
  };
  const usInput = input({
    dead: 137.043531713583510 * lbf / ft,
    E: 1450377.37730209215 * psi, G: 90648.586081380759 * psi,
    points: [{ x: 3.280839895013123359 * ft, dead: 2248.089430997104829 * lbf, variable: 0 }]
  });
  const us = B.calculate(usMember, usInput), si = B.calculate(member(), fixtureInput(golden[3]));
  checkResponse(us.cases.total, golden[3]);
  for (const key of ['span', 'area', 'I', 'Z', 'shearArea']) close(us.section[key], si.section[key], key);
  us.checks.forEach(c => close(c.demand, check(si, c.id).demand, `${c.id} in canonical SI`));
  const r = us.cases.total;
  close(r.reactionLeft / lbf, 2585.302845646671, 'US left reaction lbf');
  close(r.reactionRight / lbf, 1461.258130148118, 'US right reaction lbf');
  close(r.moment.value / (lbf * ft), 7744.402567411286, 'US moment lbf ft');
  close(check(us, 'bending').demand / psi, 1015.264164111465, 'US bending psi');
  close(check(us, 'shear').demand / psi, 83.396699194870, 'US shear psi');
  close(r.deflection.x / ft, 6.005104963371, 'US maximum location ft');
  close(r.deflection.value / inch, .302132018625, 'US total displacement inches', 3e-12, 5e-13);
});

test('exact equality to a stress limit is not a false exceedance caused by floating-point roundoff', () => {
  const v = { ...fixtureInput(golden[3]), Fb: 7000000, Fv: 575000 };
  const r = B.calculate(member(), v);
  close(check(r, 'bending').demand, 7000000, 'exact mathematical bending demand');
  assert.equal(check(r, 'bending').status, 'within_entered_limit');
  assert.equal(check(r, 'bending').ratio, 1);
  assert.equal(check(r, 'shear').status, 'within_entered_limit');
  // Only machine-precision accommodation is justified, not an engineering margin.
  for (const excess of [1e-10, 1e-7]) {
    const exceeded = B.calculate(member(), { ...v, Fb: 7000000 * (1 - excess) });
    assert.equal(check(exceeded, 'bending').status, 'exceeds_entered_limit');
    assert.ok(check(exceeded, 'bending').ratio > 1);
  }
});
