const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const E=require('../dist/geometry.js'),C=require('../dist/cabinets.js'),THREE=require('../dist/vendor/three.min.js');
global.BIM=E;const D=require('../dist/drawings.js');
const context={THREE,BIM:E,Cabinets:C,window:{}};vm.runInNewContext(fs.readFileSync(require.resolve('../dist/view3d.js'),'utf8'),context);
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-5,`${a} ≠ ${b}`);
function view(){const v=Object.create(context.window.BuildingView.prototype);v.model=new THREE.Group();return v}
test('real extruded slab has a physical hole, exact top surface area and level',()=>{
 const p=E.demoDuplex(),f=p.floors[1],r=E.detectRooms(p,f.id).find(r=>r.center.x>6),v=view();v.floorMesh(r,f.elevation,f.slab);v.model.updateMatrixWorld(true);
 let area=0;const hole=E.openingGeometry(p,p.slabOpenings[0]);
 v.model.traverse(mesh=>{if(!mesh.geometry)return;const pos=mesh.geometry.getAttribute('position'),index=mesh.geometry.index;const count=index?index.count:pos.count;
   for(let i=0;i<count;i+=3){const points=[0,1,2].map(j=>new THREE.Vector3().fromBufferAttribute(pos,index?index.getX(i+j):i+j).applyMatrix4(mesh.matrixWorld));
     if(points.every(q=>Math.abs(q.y-f.elevation)<1e-6)){
       const [a,b,c]=points;area+=new THREE.Vector3().subVectors(b,a).cross(new THREE.Vector3().subVectors(c,a)).length()/2;
       assert.equal(E.containsGeometry(hole,{x:(a.x+b.x+c.x)/3,y:(a.z+b.z+c.z)/3}),false,'top triangle must not bridge the opening');
     }
   }
 });near(area,r.floorArea);const bounds=new THREE.Box3().setFromObject(v.model);near(bounds.max.y,f.elevation);near(bounds.min.y,f.elevation-f.slab);
});
test('stairs, plan, section, quantities and JSON share the linked opening',()=>{
 const p=E.demoDuplex(),o=p.objects.find(o=>o.kind==='stairs'),hole=p.slabOpenings[0],upper=p.floors[1];
 const q=E.validate(JSON.parse(JSON.stringify(p)));assert.equal(q.slabOpenings[0].sourceStair,o.id);
 const state={floor:upper.id,layers:{rooms:true,walls:true,objects:true,openings:true,dimensions:true,labels:true,annotations:true}};
 const plan=D.plan(q,state),section=D.section(q,state,2).markup;
 assert.ok(plan.includes('data-entity="slabOpening"'));assert.ok(plan.includes('fill-rule="evenodd"'));assert.ok(!/NaN|undefined|Infinity/.test(plan+section));
 const v=view(),g=v.objectMesh(o,0);g.updateMatrixWorld(true);let stepTop=0;
 for(const mesh of g.children)if(mesh.geometry?.type==='BoxGeometry'&&mesh.geometry.parameters.width>.1)stepTop=Math.max(stepTop,mesh.position.y+mesh.geometry.parameters.height/2);
 near(stepTop,upper.elevation);near(E.estimate(q).voidArea,E.polygonArea(E.openingGeometry(q,hole)));
});
test('editing floor elevation cannot silently detach a linked stairwell',()=>{const p=E.demoDuplex();p.floors[1].elevation+=.2;assert.throws(()=>E.validate(p),/上层标高/)});
test('room types and manual floor voids survive floor copy',()=>{const p=E.newProject(),id=p.floors[0].id;E.addRectangle(p,0,0,6,5,id);E.roomMeta(p,E.detectRooms(p,id)[0],{roomType:'garage',includeLiving:false});p.slabOpenings=[{id:E.uid(),floor:id,points:[{x:1,y:1},{x:2,y:1},{x:2,y:2},{x:1,y:2}],guard:false}];const f=E.duplicateFloor(p,id),q=E.validate(p);assert.equal(E.detectRooms(q,f.id)[0].roomType,'garage');assert.equal(q.slabOpenings.length,2);assert.notEqual(q.slabOpenings[0].id,q.slabOpenings[1].id);near(E.estimate(q).livingNetArea,0)});
