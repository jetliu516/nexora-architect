const {test}=require('node:test'),assert=require('node:assert/strict');
const K=require('../dist/kitchen-layout.js'),E=require('../dist/geometry.js');
const clone=x=>JSON.parse(JSON.stringify(x)),near=(x,y)=>assert.ok(Math.abs(x-y)<.00001);
test('standard SKU range and independent window-based L kitchen model',()=>{
  assert.deepEqual(K.widths,[9,12,15,18,21,24,27,30,33,36,39,42,45,48]);
  const {project,layout}=K.build(K.sample,E);
  const rows=layout.rows.filter(r=>r.level==='base');
  assert.deepEqual(rows.map(r=>r.sku),['P24','DW24','SB36','COR36','R30','REF36','B42']);
  const corner=project.objects.filter(o=>o.kind==='cornerUnit');assert.equal(corner.length,1);
  near(rows.find(r=>r.kind==='sink').start+18,66);
  near(project.openings[0].offset/.0254,48);near(project.openings[0].height/.0254,24);
  assert.deepEqual(E.validate(clone(project)).kitchenBrief,K.sample);
});
test('turn direction, three legs and second turn reserve are independent of the example',()=>{
  const draft={turn:'left',runs:[{lengthIn:108,items:[{kind:'fridge',widthIn:30}]},{lengthIn:132,items:[{kind:'sink',widthIn:30,centerIn:69}]},{lengthIn:100,endWall:true,items:[{kind:'oven',widthIn:27}]}]};
  const {project,layout}=K.build(draft,E);assert.equal(project.walls.length,3);
  assert.equal(layout.rows.filter(r=>r.kind==='corner').length,2);
  assert.ok(project.walls[1].b.y<project.walls[1].a.y);
  near(layout.rows.find(r=>r.kind==='sink').start,54);
});
test('locks water/gas/electric positions, reports measured conflicts without committing',()=>{
  const draft={runs:[{lengthIn:144,startWall:true,endWall:true,items:[
    {kind:'sink',widthIn:36,services:[{kind:'water',atIn:30,align:'center'}]},
    {kind:'range',widthIn:30,services:[{kind:'gas',atIn:80,align:'within'}]},
    {kind:'fridge',widthIn:36,services:[{kind:'electric',atIn:126,align:'center'}]}]}]};
  const {layout}=K.build(draft,E),get=k=>layout.rows.find(r=>r.kind===k);
  near(get('sink').start,12);near(get('fridge').start,108);assert.ok(get('range').start<=80&&get('range').start+30>=80);
  draft.runs[0].items[1].services=[{kind:'gas',atIn:45,align:'center'}];assert.throws(()=>K.build(draft,E),/重叠 18/);
});
test('small fillers go at a confirmed wall end; larger gaps never become pretend fillers',()=>{
  for(const lengthIn of [49.5,48.5,97.25]){
    const r=K.build({runs:[{lengthIn,startWall:true,items:[]}]},E).layout.rows.filter(a=>a.level==='base');
    assert.equal(r[0].kind,'filler');near(r[0].start,0);assert.ok(r[0].width<3);
    near(r.reduce((s,a)=>s+a.width,0),lengthIn);
    assert.ok(r.slice(1).every(a=>K.widths.includes(a.width)));
  }
  const {layout}=K.build({runs:[{lengthIn:50,items:[]}]},E);assert.ok(!layout.rows.some(a=>a.kind==='filler'));assert.match(layout.notes.join(' '),/靠墙端/);
  const {layout:l}=K.build({runs:[{lengthIn:41,endWall:true,items:[{kind:'fridge',widthIn:36}]}]},E);
  assert.ok(!l.rows.some(a=>a.level==='base'&&a.kind==='filler'));assert.match(l.notes.join(' '),/5″/);
});
test('window reference changes sink and pantry fit; never shifts sink behind the scenes',()=>{
  const spec=clone(K.sample);delete spec.runs[0].windows[0].reference;assert.throws(()=>K.plan(spec),/窗左边/);
  spec.runs[0].windows[0].reference='center';assert.throws(()=>K.plan(spec),/差 6″/);
  spec.runs[0].items[1].widthIn=18;const rows=K.plan(spec).rows;
  assert.equal(rows.find(r=>r.kind==='pantry').width,12);near(rows.find(r=>r.kind==='sink').start+18,48);
});
