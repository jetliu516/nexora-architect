const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const E=require('../dist/geometry.js'),M=require('../dist/mep.js'),W=require('../dist/workspace-model.js');
function house(){const p=E.newProject('MEP QA'),f=p.floors[0].id;E.addRectangle(p,0,0,8,6,f);E.object(p,'sink',2,1,f);E.object(p,'toilet',6,4,f);E.object(p,'stove',4,1,f);return E.validate(p)}
const state=p=>({...W.defaults(),floor:p.floors[0].id});
test('all six systems generate real connected graphs, preserve source, and survive JSON',()=>{
 const source=house(),before=JSON.stringify(source),p=M.generate(source);assert.equal(JSON.stringify(source),before);assert.equal(M.schedule(p).length,6);
 assert.ok(p.mep.nodes.length>20);assert.equal(M.checks(p).filter(i=>['disconnected','source','uphill'].includes(i.code)).length,0);
 for(const r of p.mep.runs){assert.ok(M.item(p,'mepNode',r.a));assert.ok(M.item(p,'mepNode',r.b));assert.ok(M.runLength(p,r)>0)}
 assert.deepEqual(E.validate(JSON.parse(JSON.stringify(p))).mep,p.mep);assert.ok(M.checks(p).some(i=>i.code==='load'));assert.ok(M.checks(p).some(i=>i.code==='flow'));
});
test('regeneration requires explicit replacement and keeps all other systems byte-for-byte',()=>{
 const p=M.generate(house());assert.throws(()=>M.generate(p),/已有数据/);
 const cold=p.mep.nodes.filter(n=>n.system==='cold'),coldRuns=p.mep.runs.filter(r=>r.system==='cold');
 const next=M.generate(p,{selected:['electric'],replace:true});assert.deepEqual(next.mep.nodes.filter(n=>n.system==='cold'),cold);assert.deepEqual(next.mep.runs.filter(r=>r.system==='cold'),coldRuns);
 assert.equal(next.mep.nodes.length,p.mep.nodes.length);assert.equal(next.mep.runs.length,p.mep.runs.length);
});
test('bound fixture translation, elevation, rotation and size drive routes and quantities',()=>{
 const p=M.generate(house()),sink=p.objects.find(o=>o.kind==='sink'),n=p.mep.nodes.find(n=>n.fixtureId===sink.id&&n.system==='cold'),r=p.mep.runs.find(r=>r.b===n.id),a=M.position(p,n),length=M.runLength(p,r);
 sink.x+=2;sink.z+=.4;sink.w+=.2;assert.ok(Math.abs(M.position(p,n).x-a.x-2.1)<1e-9);assert.ok(Math.abs(M.position(p,n).z-a.z-.4)<1e-9);assert.notEqual(M.runLength(p,r),length);
 n.x=.1;sink.angle=90;assert.ok(Math.abs(M.position(p,n).y-(sink.y+sink.d/2+.1))<1e-9);
});
test('host deletion cascades only in explicit transactions; invalid imports reject dangling ports',()=>{
 const p=M.generate(house()),sink=p.objects.find(o=>o.kind==='sink'),ids=p.mep.nodes.filter(n=>n.fixtureId===sink.id).map(n=>n.id);p.objects=p.objects.filter(o=>o.id!==sink.id);
 assert.throws(()=>E.validate(p),/宿主/);M.reconcile(p);assert.doesNotThrow(()=>E.validate(p));assert.ok(!p.mep.nodes.some(n=>ids.includes(n.id)));assert.ok(!p.mep.runs.some(r=>ids.includes(r.a)||ids.includes(r.b)));
});
test('manual editing enforces endpoints, systems, duplicate IDs and numerical ranges',()=>{
 const p=M.generate(house()),a=p.mep.nodes.find(n=>n.system==='cold'),b=p.mep.nodes.find(n=>n.system==='hot');assert.throws(()=>M.connect(p,a.id,b.id),/同一系统/);assert.throws(()=>M.connect(p,a.id,a.id));
 const r=p.mep.runs[0];assert.throws(()=>M.connect(p,r.a,r.b),/重复/);
 for(const mutate of [q=>q.mep.runs[0].a='missing',q=>q.mep.runs[0].diameter=0,q=>q.mep.runs[0].level=Infinity,q=>q.mep.runs[0].slope=-.02,q=>q.mep.runs[0].id=q.walls[0].id,q=>q.mep.nodes[0].fixtureId='missing']){const q=E.clone(p);mutate(q);assert.throws(()=>E.validate(q))}
});
test('multistorey risers preserve elevations and drainage falls towards outlet',()=>{
 const p=house(),first=p.floors[0].id;E.duplicateFloor(p,first);const q=M.generate(p);assert.ok(q.mep.nodes.some(n=>n.floor!==first));assert.equal(M.checks(q).filter(i=>['uphill','disconnected'].includes(i.code)).length,0);
 const riser=q.mep.runs.find(r=>M.item(q,'mepNode',r.a).floor!==M.item(q,'mepNode',r.b).floor);assert.ok(M.path(q,riser).some((v,i,a)=>i&&Math.abs(v.z-a[i-1].z)>2));
 const drain=q.mep.runs.find(r=>r.system==='drain'&&M.item(q,'mepNode',r.a).kind==='waste');M.item(q,'mepNode',drain.b).z=10;assert.ok(M.checks(q).some(i=>i.id===drain.id&&i.code==='uphill'));
});
test('sprinkler points stay within actual net geometry including holes and concave rooms',()=>{
 const p=E.newProject('Concave'),f=p.floors[0].id,points=[[0,0],[7,0],[7,3],[3,3],[3,7],[0,7]].map(([x,y])=>({x,y}));points.forEach((v,i)=>E.wall(p,v,points[(i+1)%points.length],f));
 p.slabOpenings=[{id:E.uid(),floor:f,points:[{x:1,y:1},{x:2,y:1},{x:2,y:2},{x:1,y:2}],guard:false,guardHeight:1.05}];
 const q=M.generate(E.validate(p),{selected:['fire'],sprinklerSpacing:1.5}),rooms=E.detectRooms(q,f);assert.ok(q.mep.nodes.filter(n=>n.kind==='sprinkler').length>5);
 for(const n of q.mep.nodes.filter(n=>n.kind==='sprinkler'))assert.ok(rooms.some(r=>E.containsGeometry(r.netGeometry,M.position(q,n))));
});
test('system locks protect port edits, host movements, deletions, floor changes and dependent routes',()=>{
 const p=M.generate(house()),s=state(p);s.locks.mep_cold=true;const sink=p.objects.find(o=>o.kind==='sink');
 for(const mutate of [q=>q.objects.find(o=>o.id===sink.id).x++,q=>q.floors[0].elevation++,q=>{q.objects=q.objects.filter(o=>o.id!==sink.id);M.reconcile(q)},q=>q.mep.nodes.find(n=>n.system==='cold').z++]){const q=E.clone(p);mutate(q);assert.throws(()=>W.assertEditable(p,q,s),/冷水/)}
 const q=E.clone(p);q.name='Safe rename';assert.doesNotThrow(()=>W.assertEditable(p,q,s));
 s.layers.mep_cold=false;assert.equal(W.canSelect(p,s,'mepNode',p.mep.nodes.find(n=>n.system==='cold').id),false);
});
test('manual node deletion removes dependent lines, recovery and undo snapshots restore identities',()=>{
 const p=M.generate(house()),snapshot=JSON.stringify(p),n=p.mep.nodes.find(n=>n.kind==='junction');M.remove(p,'mepNode',n.id);assert.ok(!p.mep.runs.some(r=>r.a===n.id||r.b===n.id));assert.doesNotThrow(()=>E.validate(p));
 const undo=E.validate(JSON.parse(snapshot));assert.ok(M.item(undo,'mepNode',n.id));assert.deepEqual(undo.mep,JSON.parse(snapshot).mep);
});
test('SVG layers, three-dimensional DXF and imperial CSV share the same model',()=>{
 const p=M.generate(house()),s=state(p),svg=M.plan(p,s);assert.ok(svg.includes('data-entity="mepRun"'));assert.ok(svg.includes('data-entity="mepNode"'));
 s.layers.mep_cold=false;const hidden=M.plan(p,s),n=p.mep.nodes.find(n=>n.system==='cold');assert.ok(!hidden.includes(n.id));
 const dxf=E.dxfExport(p,s.floor);assert.ok(dxf.includes('MEP_CW'));assert.ok(dxf.includes('MEP_FP'));assert.equal(dxf.match(/\nEOF/g).length,1);
 p.unit='ft';p.mep.nodes[0].label='=malicious,formula';const csv=M.csv(p);assert.ok(csv.includes('Length ft'));assert.ok(csv.includes('Diameter in'));assert.ok(csv.includes("'=malicious,formula"));
});
test('3D renders routed cylinders and selectable nodes with true metric diameters',()=>{
 const THREE=require('../dist/vendor/three.min.js'),context={THREE,BIM:E,MEP:M};context.window=context;vm.runInNewContext(fs.readFileSync('dist/view3d.js','utf8'),context);
 const view=Object.create(context.BuildingView.prototype);view.model=new THREE.Group();const p=M.generate(house()),s=state(p);view.mepMesh(p,s,new Set(p.floors.map(f=>f.id)));
 assert.equal(view.model.children.length,p.mep.nodes.length+p.mep.runs.length);
 const r=p.mep.runs[0],group=view.model.children.find(g=>g.userData.entity.id===r.id);assert.equal(group.children.length,M.path(p,r).length-1);
 assert.equal(group.children[0].geometry.parameters.radiusTop,r.diameter/2);
 const lengths=group.children.reduce((v,m)=>v+m.geometry.parameters.height,0);assert.ok(Math.abs(lengths-M.runLength(p,r))<1e-8);
});
test('generation refuses empty rooms, invalid input and oversized plans without changing project',()=>{
 assert.throws(()=>M.generate(E.newProject('Empty')),/闭合房间/);const p=house(),before=JSON.stringify(p);for(const opts of [{selected:[]},{selected:['unknown']},{outletSpacing:0},{sprinklerSpacing:Infinity},{drainSlope:-1}])assert.throws(()=>M.generate(p,opts));assert.equal(JSON.stringify(p),before);
});
test('automatic outlets attach only near real walls, never to slab-opening perimeter',()=>{
 const p=house(),f=p.floors[0].id;p.slabOpenings=[{id:E.uid(),floor:f,points:[{x:3,y:2},{x:5,y:2},{x:5,y:4},{x:3,y:4}],guard:false,guardHeight:1.05}];
 const q=M.generate(E.validate(p),{selected:['electric']});for(const n of q.mep.nodes.filter(n=>n.kind==='outlet'))assert.ok(q.walls.some(w=>E.projectPoint(M.position(q,n),w.a,w.b).distance<w.thickness/2+.12));
});
test('cross-floor visible run extents are included in plan fit and SVG export bounds',()=>{
 const p=house(),f=p.floors[0];E.duplicateFloor(p,f.id);const a=M.node(p,'cold','waterMeter',f.id,-20,1,1),b=M.node(p,'cold','inlet',p.floors[1].id,20,1,1);M.connect(p,a.id,b.id);
 for(const floor of p.floors){const box=M.bounds(p,floor.id),parts=M.floorPaths(p,p.mep.runs[0],floor.id);assert.ok(parts.length);for(const q of parts.flat())assert.ok(box.x<=q.x&&box.x+box.w>=q.x)}
});
test('MEP identities cannot collide with other model collections and CSV neutralizes whitespace formulas',()=>{
 const p=M.generate(house());E.autoRoof(p,p.floors[0].id);for(const id of [p.floors[0].id,p.roofs[0].id]){const q=E.clone(p);q.mep.nodes[0].id=id;assert.throws(()=>E.validate(q),/编号/)}
 p.mep.nodes[0].label='\t=SUM(A1)';assert.ok(M.csv(p).includes("'\t=SUM(A1)"));p.mep.nodes[0].label='  +cmd';assert.ok(M.csv(p).includes("'  +cmd"));
});
