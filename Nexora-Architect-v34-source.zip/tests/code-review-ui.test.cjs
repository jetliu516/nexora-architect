const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const E=require('../dist/geometry.js'),C=require('../dist/code-review.js');
const input={address:'1 Centre Street',city:'New York',region:'NY',postal:'10007',country:'US',scope:'alteration',use:'Test only',filingDate:'2026-12-01'};
const research=()=>({status:'candidate',queriedAt:new Date().toISOString(),profile:{...input},model:'mock',authority:{name:'Fixture agency',jurisdiction:'Fixture district',sourceIds:['s']},sources:[{id:'s',url:'https://www.nyc.gov/codes',title:'Fixture',summary:'Not live research'}],requirements:[{id:'r',topic:'structural',requirement:'Test review',section:'',edition:'',effectiveDate:'',applicability:'Unknown',sourceIds:['s']}],unresolved:[]});
const flush=()=>new Promise(r=>setImmediate(r));
const decode=value=>String(value).replaceAll('&quot;','"').replaceAll('&lt;','<').replaceAll('&gt;','>').replaceAll('&amp;','&');
const attrs=html=>Object.fromEntries([...html.matchAll(/([\w-]+)="([^"]*)"/g)].map(m=>[m[1],decode(m[2])]));
// Read controls from the actual rendered HTML. Values and namedItem share the
// same control objects, so restoring DOM fields is observable in FormData.
function parseForm(attributes,html){
  const a=attrs(attributes),fields={},values={};
  const add=(a,value,checked)=>{if(!a.name)return;const field={name:a.name,type:a.type||'text',value,checked};fields[a.name]=field;
    Object.defineProperty(values,a.name,{enumerable:true,get:()=>field.type==='checkbox'?field.checked:field.value,set:v=>{if(field.type==='checkbox')field.checked=!!v;else field.value=String(v);}});};
  for(const match of html.matchAll(/<input\b([^>]*)>/g)){const a=attrs(match[1]);add(a,a.value||(a.type==='checkbox'?'on':''),/\bchecked(?:\s|$|=)/.test(match[1]));}
  for(const match of html.matchAll(/<textarea\b([^>]*)>([\s\S]*?)<\/textarea>/g))add(attrs(match[1]),decode(match[2]));
  for(const match of html.matchAll(/<select\b([^>]*)>([\s\S]*?)<\/select>/g)){
    const options=[...match[2].matchAll(/<option\b([^>]*)>([\s\S]*?)<\/option>/g)],selected=options.find(o=>/\bselected(?:\s|$|=)/.test(o[1]))||options[0];
    add(attrs(match[1]),selected?(attrs(selected[1]).value??decode(selected[2])):'');
  }
  return {id:a.id||'',dataset:a['data-code-note']?{codeNote:a['data-code-note']}:{},isConnected:true,values,elements:{namedItem:name=>fields[name]||null}};
}
function harness(){
  let p=E.newProject('A'),form,forms=[],commits=0,deny=false;C.setProfile(p,input);
  const handlers={},elements={},requests=[],history=[],dialogs=[];
  const ctx={CodeReview:C,Drawings:{esc:v=>String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;')},NexoraI18n:{language:'en'},AbortController,setTimeout,clearTimeout,
    FormData:class{constructor(f){this.form=f;}get(k){const f=this.form.elements?.namedItem(k);if(f)return f.type==='checkbox'?(f.checked?f.value:null):f.value;return this.form.values?.[k]??null;}has(k){const f=this.form.elements?.namedItem(k);return f?f.type!=='checkbox'||f.checked:Object.hasOwn(this.form.values||{},k);}},
    document:{getElementById:id=>elements[id]||null,addEventListener:(n,f)=>handlers[n]=f},addEventListener:(n,f)=>handlers[n]=f,
    fetch:(url,options)=>new Promise((resolve,reject)=>requests.push({url,options,resolve,reject}))};
  ctx.window=ctx;elements.dialog={open:false,addEventListener:(n,f)=>handlers['dialog:'+n]=f};
  vm.runInNewContext(fs.readFileSync('dist/code-review-ui.js','utf8'),ctx);
  ctx.CodeReviewUI.init({state:()=>({p}),transact(fn){if(deny)return false;history.push(JSON.stringify(p));try{fn();C.validate(p);commits++;return true}catch(e){p=JSON.parse(history.pop());throw e}},
    dialog(title,html){for(const f of forms){f.isConnected=false;if(f.id)delete elements[f.id];}dialogs.push({title,html});
      forms=[...html.matchAll(/<form\b([^>]*)>([\s\S]*?)<\/form>/g)].map(m=>parseForm(m[1],m[2]));
      for(const f of forms)if(f.id)elements[f.id]=f;form=elements.codeProfileForm;
      elements.codeReviewPanel={querySelectorAll:selector=>{assert.equal(selector,'form[data-code-note]');return forms.filter(f=>f.dataset.codeNote);}};
      for(const id of ['codeResearchSubmit','codeResearchStatus','codeResearchLogin'])elements[id]={};elements.dialog.open=true;
    },toast:v=>elements.toast=v,action:v=>elements.action=v,exportFile:()=>{}});
  const submit=(f=form)=>handlers.submit({target:f,preventDefault(){}});
  return {ctx,requests,handlers,dialogs,get p(){return p},set p(v){p=v},get form(){return form},get confirm(){return elements.codeConfirmForm},get notes(){return forms.filter(f=>f.dataset.codeNote)},get commits(){return commits},set deny(v){deny=v},get disabled(){return elements.codeResearchSubmit.disabled},get status(){return elements.codeResearchStatus.textContent},get login(){return elements.codeResearchLogin},get html(){return dialogs.at(-1).html},get isOpen(){return elements.dialog.open},
    open(){ctx.CodeReviewUI.open()},close(){elements.dialog.open=false;handlers['dialog:close']();},language(value){ctx.NexoraI18n.language=value;handlers['nexora-language-change']();},submit,query(){form.values.share=true;submit();},
    click(dataset){handlers.click({target:{closest:()=>({dataset})}})},respond(i=0,status=200,body={research:research()}){requests[i].resolve({ok:status===200,status,headers:{get:()=> 'application/json'},json:async()=>body})},undo(){p=JSON.parse(history.pop())}};
}
test('query stores evidence atomically with undo, no model geometry in outbound data',async()=>{const h=harness();h.open();h.query();assert.equal(h.requests.length,1);assert.deepEqual(Object.keys(JSON.parse(h.requests[0].options.body)).sort(),['language','profile']);h.respond();await flush();assert.equal(h.p.codeReview.research.model,'mock');assert.equal(h.commits,2);assert.match(h.html,/Fixture agency/);h.undo();assert.equal(h.p.codeReview.research,null);});
test('old profile and note forms cannot overwrite another project, new research or changed geometry',()=>{for(const mutation of ['project','profile','geometry','research']){const h=harness();C.saveResearch(h.p,research());h.open();const old=h.form;old.values.share=true;if(mutation==='project')h.p={...E.newProject('B'),codeReview:{...C.data(h.p),profile:{...input,address:'99 Other Street'}}};if(mutation==='profile')C.setProfile(h.p,{...input,scope:'new'});if(mutation==='geometry')h.p.slabOpenings=[{w:3,d:3}];if(mutation==='research')h.p.codeReview.research.model='replacement';const before=JSON.stringify(h.p);if(mutation==='geometry'||mutation==='research')h.submit({id:'note',dataset:{codeNote:'r'},values:{by:'R',note:'Old evidence',status:'documented'}});else h.submit(old);assert.equal(JSON.stringify(h.p),before);assert.equal(h.requests.length,0);assert.equal(h.commits,0);}});
test('stop, close and superseded requests cannot apply late responses or reenable the next request',async()=>{for(const kind of ['stop','close','reopen']){const h=harness();h.open();h.query();if(kind==='stop')h.click({codeStop:''});if(kind==='close')h.close();if(kind==='reopen')h.open();assert.equal(h.requests[0].options.signal.aborted,true);h.open();h.query();assert.equal(h.disabled,true);h.respond(0);await flush();assert.equal(h.disabled,true);assert.equal(h.p.codeReview.research,null);h.respond(1);await flush();assert.equal(h.p.codeReview.research.model,'mock');}});
test('project or address changes while search is pending do not apply a late result',async()=>{for(const kind of ['project','address']){const h=harness();h.open();h.query();if(kind==='project')h.p=E.newProject('B');else C.setProfile(h.p,{...input,address:'Changed'});const before=JSON.stringify(h.p);h.respond();await flush();assert.equal(JSON.stringify(h.p),before);assert.match(h.status,/changed/);}});
test('login and storage failure are explicit; rejected transaction sends nothing',async()=>{const h=harness();h.open();h.deny=true;h.query();assert.equal(h.requests.length,0);h.deny=false;h.query();h.respond(0,401,{error:'Sign in required'});await flush();assert.equal(h.login.hidden,false);assert.match(h.status,/Sign in/);assert.equal(h.disabled,false);});
test('rendered records escape source text and preserve all three interface languages',()=>{const h=harness(),r=research();r.sources[0].title='<script>alert(1)</script>';r.requirements[0].requirement='<img onerror="bad">';C.saveResearch(h.p,r);for(const [language,title]of [['en','Project address'],['zh','项目地址'],['es','Dirección']]){h.ctx.NexoraI18n.language=language;h.open();assert.match(h.dialogs.at(-1).title,new RegExp(title));assert.ok(!h.html.includes('<script>'));assert.ok(!h.html.includes('<img onerror'));assert.ok(h.html.includes('data-no-translate'));}});

test('local-only save never contacts AI and preserves inputs when continuing to draft',()=>{const h=harness();h.open();h.form.values.address='Local draft address';h.click({codeSave:''});assert.equal(h.requests.length,0);assert.equal(h.p.codeReview.profile.address,'Local draft address');h.form.values.address='Updated draft address';h.click({codeStructure:''});assert.equal(h.requests.length,0);assert.equal(h.p.codeReview.profile.address,'Updated draft address');});
test('editing the address in the form during a request rejects the stale result',async()=>{const h=harness();h.open();h.query();h.form.values.address='Changed while waiting';h.respond();await flush();assert.equal(h.p.codeReview.research,null);assert.match(h.status,/changed/);});

test('language refresh preserves every profile, consent, confirmation and requirement draft without committing',()=>{
  const h=harness(),r=research();r.requirements.push({...r.requirements[0],id:'r2',topic:'fire',requirement:'Second independent review'});C.saveResearch(h.p,r);h.open();
  const profile={address:'77 <Unsaved> "Street" & Annex',city:'Draft City',region:'CA',postal:'90001',country:'US',scope:'addition',use:'Two-family home',filingDate:'2027-01-02'};
  Object.assign(h.form.values,profile);Object.assign(h.confirm.values,{by:'Confirmación / 审核人',note:'Unsubmitted jurisdiction rationale'});
  Object.assign(h.notes[0].values,{status:'not_applicable',by:'Reviewer one',note:'Not applicable: <draft> & evidence'});
  Object.assign(h.notes[1].values,{status:'documented',by:'',note:'Unsaved second note'});
  const confirmation={...h.confirm.values},notes=h.notes.map(f=>({id:f.dataset.codeNote,values:{...f.values}})),before=JSON.stringify(h.p);
  for(const [language,share]of [['es',true],['zh',false],['en',true]]){
    h.form.values.share=share;const old=h.form;h.language(language);
    assert.equal(old.isConnected,false);assert.notEqual(h.form,old);assert.equal(h.form.values.share,share);
    for(const [key,value]of Object.entries(profile))assert.equal(h.form.values[key],value,key);
    assert.deepEqual({...h.confirm.values},confirmation);assert.deepEqual(h.notes.map(f=>({id:f.dataset.codeNote,values:{...f.values}})),notes);
    assert.equal(JSON.stringify(h.p),before);assert.equal(h.commits,0);assert.equal(h.requests.length,0);
  }
  h.submit(h.notes[0]);assert.equal(h.p.codeReview.notes[0].note,notes[0].values.note);assert.equal(h.p.codeReview.notes[0].status,'not_applicable');
});

test('changing language leaves a closed review dialog closed and sends no request',()=>{
  const h=harness();h.open();h.form.values.address='Closed draft';h.close();const count=h.dialogs.length,before=JSON.stringify(h.p);
  for(const language of ['zh','es','en'])h.language(language);
  assert.equal(h.isOpen,false);assert.equal(h.dialogs.length,count);assert.equal(JSON.stringify(h.p),before);assert.equal(h.commits,0);assert.equal(h.requests.length,0);
  h.open();assert.equal(h.form.values.address,input.address);assert.equal(h.form.values.share,false);
});

test('language changes explicitly stop pending research, retain drafts and isolate late responses from a retry',async()=>{
  for(const [language,message]of [['en',/Research was stopped/],['zh',/切换语言已停止/],['es',/consulta se detuvo/]])for(const lateError of [false,true]){
    const h=harness();C.saveResearch(h.p,research());h.open();h.query();
    h.form.values.address='Edited during research';h.form.values.share=false;Object.assign(h.confirm.values,{by:'Pending reviewer',note:'Pending confirmation'});
    Object.assign(h.notes[0].values,{status:'not_applicable',by:'Pending note reviewer',note:'Pending note'});
    const before=JSON.stringify(h.p);h.language(language);
    assert.equal(h.requests[0].options.signal.aborted,true);assert.equal(h.form.values.address,'Edited during research');assert.equal(h.form.values.share,false);
    assert.equal(h.confirm.values.note,'Pending confirmation');assert.equal(h.notes[0].values.note,'Pending note');assert.equal(h.notes[0].values.status,'not_applicable');
    assert.match(h.status,message);assert.notEqual(h.disabled,true);assert.equal(JSON.stringify(h.p),before);assert.equal(h.commits,1);
    h.query();assert.equal(h.requests.length,2);assert.equal(h.disabled,true);const working=h.status;
    if(lateError)h.requests[0].reject(new Error('Old request failed'));else h.respond(0);
    await flush();assert.equal(h.disabled,true);assert.equal(h.status,working);assert.equal(h.p.codeReview.research,null);
    const next=research();next.profile.address='Edited during research';next.model='retry';h.respond(1,200,{research:next});await flush();
    assert.equal(h.p.codeReview.research.model,'retry');assert.equal(h.commits,3);
  }
});

test('language refresh never restores another project’s draft or consent and cancels its pending query',async()=>{
  const h=harness();C.saveResearch(h.p,research());h.open();h.query();h.form.values.address='Private project A draft';
  Object.assign(h.confirm.values,{by:'Reviewer A',note:'Private confirmation A'});Object.assign(h.notes[0].values,{by:'Reviewer A',note:'Private note A'});
  const b=E.newProject('B'),profile={...input,address:'99 Project B Street'},r=research();r.profile=profile;C.setProfile(b,profile);C.saveResearch(b,r);h.p=b;
  const before=JSON.stringify(b);h.language('es');
  assert.equal(h.requests[0].options.signal.aborted,true);assert.equal(h.form.values.address,profile.address);assert.equal(h.form.values.share,false);
  assert.equal(h.confirm.values.by,'');assert.equal(h.confirm.values.note,'');assert.equal(h.notes[0].values.note,'');assert.equal(h.notes[0].values.by,'');
  assert.match(h.status,/Cambió el proyecto/);const status=h.status;h.respond();await flush();
  assert.equal(JSON.stringify(h.p),before);assert.equal(h.status,status);assert.equal(h.commits,1);
});

test('language refresh does not renew stale model, research or address bindings',()=>{
  for(const mutation of ['geometry','research','profile']){
    const h=harness();C.saveResearch(h.p,research());h.open();h.form.values.address='Stale profile draft';Object.assign(h.notes[0].values,{by:'Old reviewer',note:'Old design evidence'});
    if(mutation==='geometry')h.p.site.width+=1;
    if(mutation==='research')h.p.codeReview.research.model='replacement';
    if(mutation==='profile')C.setProfile(h.p,{...input,address:'New stored address'});
    const before=JSON.stringify(h.p);h.language('en');assert.equal(h.form.values.address,'Stale profile draft');
    if(mutation==='profile')h.click({codeSave:''});else{assert.equal(h.notes[0].values.note,'Old design evidence');h.submit(h.notes[0]);}
    assert.equal(JSON.stringify(h.p),before);assert.equal(h.commits,0);assert.equal(h.requests.length,0);assert.match(h.status,/changed/);
  }
});

test('unchecked sharing consent survives language refresh and still prevents research',()=>{
  const h=harness();h.open();assert.equal(h.form.values.share,false);h.language('es');h.submit();
  assert.equal(h.requests.length,0);assert.equal(h.commits,0);assert.match(h.status,/Acepta compartir/);
});
