const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const E=require('../dist/geometry.js'),Core=require('../dist/beam-analysis.js'),Units=require('../dist/units.js');
const source=fs.readFileSync('dist/beam-analysis-ui.js','utf8');
const decode=v=>String(v).replaceAll('&quot;','"').replaceAll('&#39;',"'").replaceAll('&lt;','<').replaceAll('&gt;','>').replaceAll('&amp;','&');
const attrs=s=>Object.fromEntries([...s.matchAll(/([\w-]+)="([^"]*)"/g)].map(m=>[m[1],decode(m[2])]));
function project(){const p=E.newProject('Synthetic beam fixture');p.unit='m';p.structure={jurisdiction:'Fixture only',code:'Not a code approval',amendments:'',reference:'Test sources',loads:'Synthetic test loads',members:[{id:'beam-a',floor:p.floors[0].id,kind:'beam',material:'Synthetic material',note:'Not a design recommendation',x1:0,y1:0,x2:6,y2:0,z:2.7,width:.15,depth:.3}]};p.structure.members.push({...p.structure.members[0],id:'joist-b',kind:'joist',y1:1,y2:1},{...p.structure.members[0],id:'post-c',kind:'post',x2:0,y2:0});return p;}
function harness(initial=project()){
 let p=initial,form=null,commits=0,quota=false,refreshDuringCommit=false,interimExportDisabled;const elements={},handlers={},dialogs=[],exports=[],prints=[],messages=[],history=[];
 const ctx={BeamAnalysis:Core,Units,NexoraI18n:{language:'en'},URL,
  document:{getElementById:id=>elements[id]||null,addEventListener:(type,fn)=>handlers[type]=fn},addEventListener:(type,fn)=>handlers[type]=fn,
  FormData:class{constructor(f){this.form=f;}get(k){const c=this.form.elements.namedItem(k);return c?(c.type==='checkbox'?(c.checked?'on':null):c.value):null;}has(k){const c=this.form.elements.namedItem(k);return!!c&&(c.type!=='checkbox'||c.checked);}},
  fetch(){throw Error('Beam calculation must not access the network');}};
 ctx.window=ctx;elements.dialog={open:false,addEventListener:(type,fn)=>handlers['dialog:'+type]=fn};
 vm.runInNewContext(source,ctx);ctx.BeamAnalysisUI.init({state:()=>({p,s:{floor:p.floors[0].id}}),
  transact(fn){const before=JSON.stringify(p);try{fn();Core.validate(p);if(quota){p=JSON.parse(before);return false;}history.push(before);commits++;if(refreshDuringCommit){ctx.BeamAnalysisUI.refresh();interimExportDisabled=elements.beamExport.disabled;}return true;}catch(e){p=JSON.parse(before);throw e;}},
  dialog(title,html){if(form)form.isConnected=false;for(const key of Object.keys(elements))if(key!=='dialog')delete elements[key];dialogs.push({title,html});elements.dialog.open=true;
   for(const m of html.matchAll(/<[^>]+\bid="([^"]+)"[^>]*>/g))elements[decode(m[1])]={id:decode(m[1]),disabled:/\bdisabled(?:\s|>|=)/.test(m[0])};
   const content=html.match(/<form id="beamAnalysisForm">([\s\S]*?)<\/form>/)?.[1],fields={};form=content?{id:'beamAnalysisForm',isConnected:true,elements:{namedItem:name=>fields[name]||null}}:null;if(form)elements.beamAnalysisForm=form;
   function control(a,body,tag,formField){const field={...a,type:a.type||tag,value:a.value??'',checked:/\bchecked(?:\s|$|=)/.test(body),closest:selector=>selector==='#beamAnalysisForm'&&formField?form:null};
    if(tag==='textarea')field.value=decode(body);if(tag==='select'){const options=[...body.matchAll(/<option\b([^>]*)>([\s\S]*?)<\/option>/g)],selected=options.find(o=>/\bselected(?:\s|$|=)/.test(o[1]))||options[0];field.value=selected?(attrs(selected[1]).value??decode(selected[2])):'';}
    if(a.id)elements[a.id]=field;if(a.name&&formField)fields[a.name]=field;return field;
   }
   for(const m of html.matchAll(/<input\b([^>]*)>/g))control(attrs(m[1]),m[1],'input',!!content&&content.includes(m[0]));
   for(const tag of ['textarea','select'])for(const m of html.matchAll(new RegExp('<'+tag+'\\b([^>]*)>([\\s\\S]*?)<\\/'+tag+'>','g')))control(attrs(m[1]),m[2],tag,!!content&&content.includes(m[0]));
  },toast:v=>messages.push(v),exportFile:(...args)=>exports.push(args),printHtml:html=>prints.push(html)});
 const change=(name,value,event='input')=>{const field=form.elements.namedItem(name);assert.ok(field,`field ${name}`);if(field.type==='checkbox')field.checked=!!value;else field.value=String(value);handlers[event]({target:field});};
 return{ctx,handlers,dialogs,exports,prints,messages,get p(){return p},set p(v){p=v},get form(){return form},get html(){return dialogs.at(-1).html},get commits(){return commits},set quota(v){quota=v},set refreshDuringCommit(v){refreshDuringCommit=v},get interimExportDisabled(){return interimExportDisabled},get status(){return elements.beamStatus?.textContent||''},get resultStatus(){return elements.beamResultStatus?.textContent||''},element:id=>elements[id],field:name=>form.elements.namedItem(name),change,
  open:id=>ctx.BeamAnalysisUI.open(id),submit:(target=form)=>handlers.submit({target,preventDefault(){}}),click:dataset=>handlers.click({target:{closest:()=>({dataset})}}),
  unit(value){elements.beamUnits.value=value;handlers.change({target:elements.beamUnits});},member(value){elements.beamMember.value=value;handlers.change({target:elements.beamMember});},
  language(value){ctx.NexoraI18n.language=value;handlers['nexora-language-change']();},close(){elements.dialog.open=false;handlers['dialog:close']();},refresh:()=>ctx.BeamAnalysisUI.refresh(),undo(){p=JSON.parse(history.pop());}};
}
function fill(h){for(const [key,value]of Object.entries({dead:'2',variable:'3',E:'11000',G:'690',Fb:'12',Fv:'1.2',Fc:'3.5',leftBearing:'.1',rightBearing:'.12',totalLimit:'360',variableLimit:'480',loadBasis:'Synthetic loads only',materialBasis:'Synthetic mechanics fixture',criteriaBasis:'Entered limits for testing',supportsConfirmed:true,solidSectionConfirmed:true,selfWeightIncluded:true}))h.change(key,value);}
const near=(actual,expected,tol=1e-9)=>assert.ok(Math.abs(actual-expected)<=tol*Math.max(1,Math.abs(expected)),`${actual} != ${expected}`);

test('beam UI starts with explicit blank material/limits, filters supported members and provides an empty-state return',()=>{
 const h=harness();h.open();assert.equal(h.field('E').value,'');assert.equal(h.field('G').value,'');for(const key of ['Fb','Fv','Fc','totalLimit','variableLimit'])assert.equal(h.field(key).value,'');
 assert.match(h.html,/data-no-translate/);assert.match(h.html,/Actual section width/);assert.match(h.html,/readonly/);assert.ok(!h.html.includes('post-c'));assert.equal(h.element('beamExport').disabled,true);assert.equal(h.commits,0);
 h.member('joist-b');assert.equal(h.element('beamMember').value,'joist-b');h.click({beamOpen:'beam-a'});assert.equal(h.element('beamMember').value,'beam-a');
 const p=project();p.structure.members=p.structure.members.filter(m=>m.kind==='post');const empty=harness(p);empty.open();assert.match(empty.html,/data-action="structureDraft"/);assert.match(empty.html,/Add a beam/);assert.equal(empty.form,null);
});

test('beam UI saves real mechanics results, all cases/checks and six SVG diagrams, then exports only the saved current record',()=>{
 const h=harness();h.open();fill(h);h.click({beamAdd:''});h.change('point_0_x','8 ft');h.change('point_0_dead','1.5');h.change('point_0_variable','2');h.submit();
 assert.equal(h.commits,1);const record=Core.saved(h.p,'beam-a');assert.equal(record.state,'current');assert.equal(record.result.input.points[0].x,2.4384);assert.equal(record.result.input.points[0].dead,1500);
 assert.equal((h.html.match(/<svg /g)||[]).length,6);assert.ok(!/NaN|Infinity/.test(h.html));assert.match(h.html,/D \+ Q/);assert.match(h.html,/Within entered limit|Exceeds entered limit/);assert.match(h.html,/NOT FOR CONSTRUCTION/);
 assert.equal(h.element('beamExport').disabled,false);h.click({beamExport:''});h.click({beamPrint:''});assert.equal(h.exports.length,1);assert.equal(h.prints.length,1);
 const report=JSON.parse(h.exports[0][1]);assert.equal(report.units.force,'N');assert.equal(report.units.stress,'Pa');assert.equal(report.status,'draft_not_certified');assert.equal(report.checks.length,6);assert.deepEqual(Object.keys(report.cases).sort(),['total','variable']);
 const html=h.prints[0];for(const expected of ['NOT FOR CONSTRUCTION','Synthetic loads only','11000 MPa','D + Q','Wood Handbook','k = 5/6','data-no-translate'])assert.ok(html.includes(expected),expected);
 assert.ok(!/compliance passed|合规通过|cumplimiento aprobado/i.test(html));
 h.change('dead','2.5');assert.equal(h.element('beamExport').disabled,true);h.click({beamExport:''});assert.equal(h.exports.length,1);assert.match(h.status,/Recalculate/);
});

test('beam UI leaves missing optional limits unverified instead of implying a passed check',()=>{
 const h=harness();h.open();fill(h);for(const key of ['Fb','Fv','Fc','leftBearing','rightBearing','totalLimit','variableLimit'])h.change(key,'');h.submit();
 assert.equal(h.commits,1);assert.ok(Core.saved(h.p,'beam-a').result.checks.every(c=>c.status==='missing_limit'&&c.ratio===null));assert.match(h.html,/Not checked/);assert.ok(!h.html.includes('Within entered limit'));
});

test('invalid loads, material values, point positions and missing confirmations do not mutate the model',()=>{
 for(const [key,value]of [['E',''],['G','0'],['E','NaN'],['dead','-1'],['variable','Infinity'],['supportsConfirmed',false],['solidSectionConfirmed',false],['selfWeightIncluded',false]]){
  const h=harness();h.open();fill(h);const before=JSON.stringify(h.p);h.change(key,value);h.submit();assert.equal(h.commits,0,key);assert.equal(JSON.stringify(h.p),before,key);assert.ok(h.status);assert.equal(h.element('beamExport').disabled,true);
 }
 const h=harness();h.open();fill(h);for(let i=0;i<12;i++)h.click({beamAdd:''});h.click({beamAdd:''});assert.match(h.status,/12/);assert.equal((h.html.match(/data-beam-remove=/g)||[]).length,12);
 for(let i=11;i>0;i--)h.click({beamRemove:String(i)});h.change('point_0_x','6 m');h.change('point_0_dead','1');h.change('point_0_variable','0');h.submit();assert.equal(h.commits,0);h.change('point_0_x','3 m');h.submit();assert.equal(h.commits,1);
});

test('display-unit and language round trips retain exact canonical numbers, all drafts and the project unit',()=>{
 const p=project(),input={method:Core.method,dead:1234.567890123456,variable:2345.678901234567,E:12345678901.2345,G:789012345.6789,Fb:12345678.9012345,Fv:null,Fc:null,leftBearing:.123456789012345,rightBearing:null,totalLimit:333.333333333333,variableLimit:null,points:[{x:2.123456789012345,dead:789.1234567890123,variable:456.1234567890123}],loadBasis:'Precise fixture',materialBasis:'Not a material recommendation',criteriaBasis:'Test criteria',supportsConfirmed:true,solidSectionConfirmed:true,selfWeightIncluded:true};
 Core.save(p,'beam-a',input);const original=structuredClone(p.structure.members[0].analysis.input),h=harness(p);h.open();
 for(const [unit,language,label]of [['us','es','Cálculo'],['si','zh','简支梁'],['us','en','Simple-span'],['si','es','Cálculo']]){h.unit(unit);h.language(language);assert.match(h.dialogs.at(-1).title,new RegExp(label));assert.equal(h.field('loadBasis').value,'Precise fixture');assert.equal(h.field('supportsConfirmed').checked,true);assert.equal(h.element('beamExport').disabled,false);}
 h.submit();assert.deepEqual(h.p.structure.members[0].analysis.input,original);assert.equal(h.p.unit,'m');assert.equal(h.commits,1);
 const us=project();us.unit='ft';const fresh=harness(us);fresh.open();assert.equal(fresh.element('beamUnits').value,'us');
});

test('edited SI and US fields use physical conversions, and changing a value back is not ignored',()=>{
 const h=harness();h.open();fill(h);h.change('dead','4');h.change('dead','2');h.unit('us');
 assert.ok(Math.abs(Number(h.field('dead').value)-2000/(4.4482216152605/.3048))<=.5e-6,'generated display is rounded to six decimals; canonical values are checked after submission below');
 near(Number(h.field('E').value)*6894.757293168,11e9);h.change('dead','100');h.change('variable','150');h.change('leftBearing','3 1/2 in');h.change('rightBearing','90 mm');h.unit('si');h.submit();
 const v=h.p.structure.members[0].analysis.input;near(v.dead,100*4.4482216152605/.3048);near(v.variable,150*4.4482216152605/.3048);near(v.leftBearing,.0889);near(v.rightBearing,.09);near(v.E,11e9);
});

test('invalid drafts survive language switching and cannot be silently reinterpreted during unit switching',()=>{
 const h=harness();h.open();fill(h);h.change('E','unfinished parameter');h.change('loadBasis','未保存 / sin guardar');h.unit('us');assert.equal(h.element('beamUnits').value,'si');assert.equal(h.field('E').value,'unfinished parameter');
 h.language('es');assert.equal(h.field('E').value,'unfinished parameter');assert.equal(h.field('loadBasis').value,'未保存 / sin guardar');assert.equal(h.field('selfWeightIncluded').checked,true);h.submit();assert.equal(h.commits,0);
});

test('project, member, model and design-basis changes reject old submissions and exports even after translation',()=>{
 for(const change of ['project','member','geometry','basis','removed']){
  const h=harness();h.open();fill(h);h.submit();h.change('dead','2.2');
  if(change==='project')h.p=project();if(change==='member')h.p.structure.members[0].depth=.4;if(change==='geometry')h.p.site.width+=1;if(change==='basis')h.p.structure.loads='Changed basis';if(change==='removed')h.p.structure.members.shift();
  const before=JSON.stringify(h.p),commits=h.commits;h.refresh();assert.equal(h.element('beamCalculate').disabled,true);assert.equal(h.element('beamExport').disabled,true);h.submit();h.click({beamExport:''});h.click({beamPrint:''});
  assert.equal(h.commits,commits);assert.equal(JSON.stringify(h.p),before);assert.equal(h.exports.length,0);assert.equal(h.prints.length,0);
  if(change!=='project'){h.language('zh');h.submit();assert.equal(h.commits,commits);assert.match(h.status,/已变化/);}
 }
 const h=harness();h.open();fill(h);const old=h.form;h.member('joist-b');h.submit(old);assert.equal(h.commits,0);assert.equal(h.p.structure.members[0].analysis,undefined);
});

test('quota rollback retains the previous record and unsaved inputs, allows retry, and never enables stale export',()=>{
 const h=harness();h.open();fill(h);h.submit();const before=JSON.stringify(h.p);h.change('dead','9');h.quota=true;h.submit();assert.equal(JSON.stringify(h.p),before);assert.equal(h.commits,1);assert.equal(h.field('dead').value,'9');assert.match(h.status,/could not be saved/);assert.equal(h.element('beamExport').disabled,true);
 h.click({beamExport:''});assert.equal(h.exports.length,0);h.quota=false;h.submit();assert.equal(h.commits,2);assert.equal(h.p.structure.members[0].analysis.input.dead,9000);assert.equal(h.element('beamExport').disabled,false);
});

test('the workbench refresh inside a successful transaction cannot strand the new result behind stale form state',()=>{
 const h=harness();h.refreshDuringCommit=true;h.open();fill(h);h.submit();assert.equal(h.commits,1);assert.equal(h.interimExportDisabled,true);assert.equal(h.element('beamCalculate').disabled,false);assert.equal(h.element('beamExport').disabled,false);assert.match(h.status,/Calculation saved/);
 h.click({beamExport:''});assert.equal(h.exports.length,1);assert.equal(JSON.parse(h.exports[0][1]).input.dead,2000);
});

test('closing prevents language-triggered reopening and changing projects never transfers drafts',()=>{
 const h=harness();h.open();fill(h);h.change('loadBasis','Private project A draft');h.close();const count=h.dialogs.length;h.language('es');assert.equal(h.dialogs.length,count);
 h.open();h.change('loadBasis','Private project A draft');h.p=project();h.language('zh');assert.equal(h.field('loadBasis').value,'');assert.equal(h.field('E').value,'');assert.equal(h.field('supportsConfirmed').checked,false);
});

test('rendering and print reports escape hostile project/member/basis text and never produce executable source URLs',()=>{
 const h=harness();h.p.name='<script>project()</script>';h.p.structure.members[0].material='<img src=x onerror=member()>';h.p.structure.loads='</pre><script>basis()</script>';h.open();fill(h);h.change('loadBasis','</textarea><img onerror="draft()">');h.submit();h.click({beamPrint:''});
 assert.equal(h.prints.length,1);for(const html of [h.html,h.prints[0]]){assert.ok(!html.includes('<script>'));assert.ok(!html.includes('<img '));assert.ok(!html.includes('javascript:'));assert.ok(html.includes('&lt;'));}
 assert.ok(!/\bfetch\s*\(|XMLHttpRequest|sendBeacon/.test(source));
});

test('mobile stylesheet provides a single-column narrow layout without forcing wide inputs or diagrams',()=>{
 const css=fs.readFileSync('dist/beam-analysis.css','utf8');assert.match(css,/@media\(max-width:560px\)/);assert.match(css,/grid-template-columns:minmax\(0,1fr\)/);assert.match(css,/min-width:0/);assert.match(css,/\.beam-diagram svg\{[^}]*width:100%/);
});

test('geometry uses readable feet/inches, inch sections and metric millimetres without repeating the construction warning',()=>{
 const p=project();p.unit='ft';p.structure.members[0].x2=4;p.structure.members[0].width=.1;const before=JSON.stringify(p),h=harness(p);h.open();
 const readonly=()=>[...h.html.matchAll(/<input readonly value="([^"]+)"/g)].map(m=>decode(m[1]));
 assert.deepEqual(readonly(),['13′ 1 1/2″','3.937 in','11.811 in']);
 for(const m of h.html.matchAll(/<p class="beam-warning">([^<]+)<\/p>/g))assert.equal((m[1].match(/NOT FOR CONSTRUCTION/g)||[]).length,1);
 assert.ok(!h.html.includes('NOT FOR CONSTRUCTION · NOT FOR CONSTRUCTION'));h.unit('si');assert.deepEqual(readonly(),['4.000 m','100 mm','300 mm']);assert.equal(JSON.stringify(h.p),before);
 fill(h);h.submit();h.click({beamPrint:''});assert.ok(h.prints[0].includes('<dd>100 mm</dd>'));assert.ok(!h.prints[0].includes('NOT FOR CONSTRUCTION · DRAFT · NOT FOR CONSTRUCTION'));
});

test('generated input values are compact but manually entered precision survives translation, unit changes and saving',()=>{
 const h=harness();h.open();fill(h);const typed='11000.1234567890123';h.change('E',typed);h.language('es');assert.equal(h.field('E').value,typed);
 h.unit('us');assert.match(h.field('E').value,/^\d+(?:\.\d{1,6})?$/);h.unit('si');assert.equal(h.field('E').value,typed);h.submit();assert.equal(h.field('E').value,typed);assert.equal(h.p.structure.members[0].analysis.input.E,Number(typed)*1e6);
 const saved=h.p.structure.members[0].analysis.input.E;h.open();assert.match(h.field('E').value,/^\d+(?:\.\d{1,6})?$/);h.unit('us');h.unit('si');h.submit();assert.equal(h.p.structure.members[0].analysis.input.E,saved);
});

test('results, ratios, diagram labels and printed quantities use compact decimals while JSON and calculations retain precision',()=>{
 const h=harness();h.open();fill(h);h.click({beamAdd:''});h.change('point_0_x','2.123456789 m');h.change('point_0_dead','1.23456789');h.change('point_0_variable','2.34567891');h.submit();
 const result=Core.saved(h.p,'beam-a').result,deflectionMM=result.cases.total.deflection.value*1000,shown=Number(deflectionMM.toFixed(3))+' mm';
 assert.ok(h.html.includes(shown));assert.notEqual(Number(deflectionMM.toFixed(3)),deflectionMM);
 const ratio=result.checks.find(c=>c.id==='bending').ratio;assert.ok(h.html.includes('<dd>'+Number(ratio.toFixed(3))+'</dd>'));
 h.click({beamPrint:''});h.click({beamExport:''});assert.ok(h.prints[0].includes(shown));
 for(const html of [h.html,h.prints[0]]){
  const values=[...html.matchAll(/<(?:dd|text)\b[^>]*>([^<]*)<\/(?:dd|text)>/g)].map(m=>m[1]);
  for(const value of values)assert.ok(!/\d+\.\d{4,}(?!\d)/.test(value),'displayed result must have no more than 3 decimal places: '+value);
 }
 const exported=JSON.parse(h.exports[0][1]);assert.equal(exported.cases.total.deflection.value,result.cases.total.deflection.value);assert.equal(exported.checks.find(c=>c.id==='bending').ratio,ratio);
 assert.equal(exported.input.points[0].x,2.123456789);assert.equal(exported.input.points[0].dead,Number('1.23456789')*1000);
 assert.match(h.html,/<polyline points="[^"\n]*\d+\.\d{4,}/,'internal SVG coordinates retain their original precision');
});

test('tiny nonzero reactions, deflections and check ratios remain visible instead of rounding to zero',()=>{
 const h=harness();h.open();fill(h);h.change('dead','0.000001');h.change('variable','0');h.change('E','1000000');h.change('G','1000000');h.submit();
 const result=Core.saved(h.p,'beam-a').result;assert.ok(result.cases.total.deflection.value>0);assert.ok(result.checks[0].ratio>0);assert.ok(h.html.includes('3.00e-6 kN'));
 assert.match(h.html,/<dd>\d\.\d{2}e-\d+<\/dd>/);assert.match(h.html,/\d\.\d{2}e-\d+ mm/);h.click({beamPrint:''});assert.ok(h.prints[0].includes('3.00e-6 kN'));
 h.click({beamExport:''});const exported=JSON.parse(h.exports[0][1]);assert.equal(exported.cases.total.reactionLeft,.003);assert.equal(exported.cases.total.deflection.value,result.cases.total.deflection.value);
});

test('reopening a stale record offers recalculation with retained inputs and never displays the old geometry results',()=>{
 for(const mutation of ['geometry','basis']){
  const h=harness();h.open();fill(h);h.submit();assert.equal(Core.saved(h.p,'beam-a').state,'current');assert.equal((h.html.match(/<svg /g)||[]).length,6);
  if(mutation==='geometry')h.p.structure.members[0].width=.2;else h.p.structure.reference='Changed design reference';
  h.refresh();assert.match(h.resultStatus,/Reopen this calculation/);assert.equal(h.element('beamResults').hidden,true);assert.equal(h.element('beamCalculate').disabled,true);
  h.open('beam-a');assert.equal(Core.saved(h.p,'beam-a').state,'stale');assert.equal(h.element('beamCalculate').disabled,false);assert.equal(h.element('beamExport').disabled,true);assert.equal(h.field('dead').value,'2');assert.equal(h.field('E').value,'11000');
  for(const [lang,expected]of [['en',/Review inputs and calculate again/],['zh',/请复核输入并重新计算/],['es',/Revisa los datos y vuelve a calcular/]]){
   h.language(lang);assert.match(h.resultStatus,expected);assert.ok(!h.resultStatus.includes('Reopen'));assert.ok(!h.html.includes('<svg '));assert.ok(!h.html.includes('class="beam-check '));assert.equal(h.element('beamResults').hidden,true);
  }
  if(mutation==='geometry')assert.ok(h.html.includes('200 mm'));h.submit();assert.equal(Core.saved(h.p,'beam-a').state,'current');assert.equal(h.element('beamResults').hidden,false);assert.equal((h.html.match(/<svg /g)||[]).length,6);assert.equal(h.element('beamExport').disabled,false);
 }
});

test('downloadable printable HTML uses the real report handler and rejects missing, dirty and stale records',()=>{
 const h=harness();h.open();assert.equal(h.element('beamHTML').disabled,true);h.click({beamHtml:''});assert.equal(h.exports.length,0);
 fill(h);h.submit();assert.equal(h.element('beamHTML').disabled,false);
 for(const [lang,label]of [['en','Download printable HTML'],['zh','下载可打印 HTML'],['es','Descargar HTML imprimible']]){
  h.language(lang);assert.ok(h.html.includes(label));h.click({beamHtml:''});const [name,html,type]=h.exports.at(-1);
  assert.equal(name,'Nexora-beam-beam-a.html');assert.equal(type,'text/html');assert.match(html,/^<!doctype html>/);assert.ok(html.includes('NOT FOR CONSTRUCTION'));assert.ok(html.includes('Synthetic loads only'));assert.equal((html.match(/<svg /g)||[]).length,6);assert.ok(html.includes('Wood Handbook'));
 }
 assert.equal(h.prints.length,0,'downloading HTML must not depend on opening a print window');const exported=h.exports.length;
 h.change('dead','9');assert.equal(h.element('beamHTML').disabled,true);h.click({beamHtml:''});assert.equal(h.exports.length,exported);
 h.open();assert.equal(h.element('beamHTML').disabled,false);h.p.structure.members[0].width=.2;h.refresh();assert.equal(h.element('beamHTML').disabled,true);h.click({beamHtml:''});assert.equal(h.exports.length,exported);
 h.open();assert.equal(h.element('beamHTML').disabled,true);h.click({beamHtml:''});assert.equal(h.exports.length,exported);
 h.submit();assert.equal(h.element('beamHTML').disabled,false);h.click({beamHtml:''});assert.equal(h.exports.length,exported+1);assert.ok(h.exports.at(-1)[1].includes('<dd>200 mm</dd>'));
});
