const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const E = require('../dist/geometry.js');
const originalFaces = E.roofFaces;
const R = require('../dist/roof-model.js');
const C = require('../dist/vendor/polygon-clipping.min.js');
const T = require('../dist/vendor/three.min.js');
const close = (a,b,tolerance=1e-8) => assert.ok(Number.isFinite(a) && Math.abs(a-b) <= tolerance*Math.max(1,Math.abs(b)), `${a} ≠ ${b}`);
function project() {const p=E.newProject('Roof geometry test');p.floors[0].height=3;return p;}
function roof(p,id,changes={}) {const r={id,floor:p.floors[0].id,x:0,y:0,w:10,d:8,type:'gable',pitch:30,overhang:0,material:'charcoal',...changes};p.roofs.push(r);return r;}
function rawHeight(p,r,x,z) {
  const f=p.floors.find(f=>f.id===r.floor),base=f.elevation+f.height+.08+(r.elevationOffset||0),o=r.overhang;
  const X=x-r.x+o,Z=z-r.y+o,W=r.w+2*o,D=r.d+2*o,m=Math.tan(r.pitch*Math.PI/180);
  if(X<0||X>W||Z<0||Z>D)return -Infinity;
  if(r.type==='flat')return base;
  if(r.type==='hip')return base+m*Math.min(X,W-X,Z,D-Z);
  const v=r.axis==='y'?X:Z,span=r.axis==='y'?W:D;
  return base+m*(r.type==='shed'?(r.reverse?span-v:v):Math.min(v,span-v));
}
function inRing(q,ring) {
  let inside=false;
  for(let i=0,j=ring.length-1;i<ring.length;j=i++){
    const a=ring[i],b=ring[j];
    if((a[2]>q[1])!==(b[2]>q[1])&&q[0]<(b[0]-a[0])*(q[1]-a[2])/(b[2]-a[2])+a[0])inside=!inside;
  }
  return inside;
}
function surfaceHeights(model,x,z) {return model.surfaces.filter(s=>inRing([x,z],s.rings[0])&&!s.rings.slice(1).some(r=>inRing([x,z],r))).map(s=>s.plane.a*x+s.plane.b*z+s.plane.c);}
function area3(points) {
  const [a,b,c]=points,u=b.map((v,i)=>v-a[i]),v=c.map((n,i)=>n-a[i]);
  return Math.hypot(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])/2;
}
function assertEnvelope(p,model) {
  const xs=p.roofs.flatMap(r=>[r.x-r.overhang,r.x+r.w+r.overhang]),zs=p.roofs.flatMap(r=>[r.y-r.overhang,r.y+r.d+r.overhang]);
  for(let i=0;i<21;i++)for(let j=0;j<23;j++) {
    const x=Math.min(...xs)+(Math.max(...xs)-Math.min(...xs))*(i+.371)/21,z=Math.min(...zs)+(Math.max(...zs)-Math.min(...zs))*(j+.619)/23;
    const expected=Math.max(...p.roofs.map(r=>rawHeight(p,r,x,z))),actual=surfaceHeights(model,x,z);
    if(expected===-Infinity)assert.equal(actual.length,0);
    else {assert.equal(actual.length,1,`Exactly one visible surface at ${x},${z}`);close(actual[0],expected);}
  }
  close(model.area,model.triangles.reduce((sum,t)=>sum+area3(t.points),0));
  for(const t of model.triangles) {
    const [a,b,c]=t.points,ny=(b[2]-a[2])*(c[0]-a[0])-(b[0]-a[0])*(c[2]-a[2]);
    assert.ok(ny>0,'triangles have an upward normal');
    assert.ok(t.points.flat().every(Number.isFinite));
  }
}

test('roof model: raw defaults exactly retain existing shapes without replacing E.roofFaces',()=>{
  assert.equal(E.roofFaces,originalFaces);
  for(const type of ['gable','hip','shed','flat'])for(const [w,d] of [[10,8],[8,10],[8,8]])for(const pitch of [0,30,75]){
    const p=project(),r=roof(p,'roof',{type,w,d,pitch,overhang:.45});
    assert.deepEqual(R.rawFaces(p,r),originalFaces(p,r));
    const model=R.build(p),expected=(w+.9)*(d+.9)/(type==='flat'?1:Math.cos(pitch*Math.PI/180));
    close(model.area,expected);close(model.diagnostics.coverageArea,(w+.9)*(d+.9));
    close(model.area,model.diagnostics.triangulatedArea);assertEnvelope(p,model);
  }
});

test('roof model: axis, shed reversal and offsets follow independent analytic height functions',()=>{
  for(const type of ['gable','hip','shed','flat'])for(const axis of ['x','y'])for(const reverse of [false,true]){
    const p=project();roof(p,'roof',{type,axis,reverse,x:-9,y:13,w:7,d:11,pitch:37,overhang:.61,elevationOffset:2.75});
    const model=R.build(p);assertEnvelope(p,model);
    for(const s of model.surfaces)for(const q of s.rings.flat())close(q[1],s.plane.a*q[0]+s.plane.b*q[2]+s.plane.c);
  }
});

test('roof model: L and T same-floor roofs have exact union area and clipped mixed-axis valleys',()=>{
  for(const [name,x,z,coverage] of [['L',8,2,96],['T',4,3,100]]){
    const p=project();roof(p,'main',{w:12,d:6});roof(p,'wing',{axis:'y',x,y:z,w:4,d:10});
    const model=R.build(p);close(model.diagnostics.coverageArea,coverage);close(model.diagnostics.projectedArea,coverage);
    close(model.area,coverage/Math.cos(Math.PI/6));assertEnvelope(p,model);
    assert.ok(model.edges.some(e=>e.kind==='valley'),`${name} has a real valley`);
    assert.ok(model.edges.some(e=>e.kind==='ridge'));
    assert.ok(model.diagnostics.removedProjectedArea>0);
  }
});

test('roof model: mixed pitch crossing has the exact valley location, section height and surface area',()=>{
  const p=project();roof(p,'gentle',{type:'shed',w:10,d:10,pitch:Math.atan(.5)*180/Math.PI});
  roof(p,'steep',{type:'shed',w:10,d:10,pitch:45,reverse:true});
  const model=R.build(p),z=20/3,expected=10*(z*Math.sqrt(2)+(10-z)*Math.sqrt(1.25));
  close(model.area,expected);close(model.diagnostics.coverageArea,100);assertEnvelope(p,model);
  const valleys=model.edges.filter(e=>e.kind==='valley');assert.equal(valleys.length,1);
  close(valleys[0].a[2],z);close(valleys[0].b[2],z);close(valleys[0].a[1],3.08+10/3);
  close(Math.abs(valleys[0].b[0]-valleys[0].a[0]),10);
  for(const z of [.13,1.5,5,6.6,6.7,8,9.87])close(surfaceHeights(model,4.123,z)[0],3.08+Math.max(.5*z,10-z));
});

test('roof model: cross-floor clipping compares actual heights, including lower-floor peaks above an upper flat roof',()=>{
  const p=project(),upper={...p.floors[0],id:E.uid(),name:'Upper',elevation:2};p.floors.push(upper);
  roof(p,'lower',{pitch:45,w:10,d:10});roof(p,'upper',{floor:upper.id,x:2,y:1,w:6,d:8,type:'flat'});
  const model=R.build(p);assertEnvelope(p,model);close(model.diagnostics.coverageArea,100);
  assert.equal(surfaceHeights(model,5.11,1.5)[0],5.08);
  close(surfaceHeights(model,5.11,4.9)[0],7.98);
  assert.ok(model.surfaces.some(s=>s.roofId==='lower'&&s.rings.some(r=>r.some(q=>q[0]===2))));
  assert.ok(model.edges.some(e=>e.kind==='step'));
  const heights=R.faces(p,p.roofs[0]).flat().map(q=>q[1]);assert.ok(Math.max(...heights)>5.08);
});

test('roof model: a raised inset roof creates a true hole with exact triangulation and separate step boundaries',()=>{
  const p=project();roof(p,'lower',{type:'flat',w:12,d:10});roof(p,'upper',{type:'flat',x:3,y:2,w:5,d:4,elevationOffset:2});
  const model=R.build(p),lower=model.surfaces.find(s=>s.roofId==='lower');
  assert.equal(lower.rings.length,2);close(model.area,120);close(model.diagnostics.coverageArea,120);
  close(model.triangles.filter(t=>t.roofId==='lower').reduce((s,t)=>s+area3(t.points),0),100);
  close(model.triangles.filter(t=>t.roofId==='upper').reduce((s,t)=>s+area3(t.points),0),20);
  assert.equal(model.edges.filter(e=>e.kind==='step').length,8);assert.equal(model.edges.filter(e=>e.kind==='eave').length,4);
  assertEnvelope(p,model);
  for(const t of model.triangles.filter(t=>t.roofId==='lower')){
    const x=t.points.reduce((s,q)=>s+q[0],0)/3,z=t.points.reduce((s,q)=>s+q[2],0)/3;
    assert.ok(!(x>3&&x<8&&z>2&&z<6),'hole is not covered by a fan triangulation');
  }
});

test('roof model: coplanar duplicate and partial overlap ownership is deterministic and has no interior fake seams',()=>{
  const p=project();roof(p,'roof-b',{type:'flat',w:8,d:8});roof(p,'roof-a',{type:'flat',w:8,d:8});
  let model=R.build(p);assert.deepEqual([...new Set(model.surfaces.map(s=>s.roofId))],['roof-a']);close(model.area,64);
  const original=model;p.roofs.reverse();assert.equal(R.build(p),original,'array reordering does not invalidate a geometric signature');
  p.roofs.find(r=>r.id==='roof-b').x=4;model=R.build(p);close(model.area,96);assertEnvelope(p,model);
  assert.ok(model.edges.every(e=>e.kind==='eave'));
  const boundaryLength=model.edges.reduce((s,e)=>s+Math.hypot(e.b[0]-e.a[0],e.b[2]-e.a[2]),0);close(boundaryLength,40);
});

test('roof model: exact orthogonal 45-degree junctions split seams at every collinear boundary vertex',()=>{
  const p=project();roof(p,'roof-1',{w:8,d:8,pitch:45});roof(p,'roof-2',{w:8,d:8,pitch:45,axis:'y'});
  const model=R.build(p);close(model.area,64*Math.sqrt(2));assertEnvelope(p,model);
  assert.equal(model.edges.filter(e=>e.kind==='valley').length,4);
  assert.ok(model.diagnostics.discardedProjectedArea<1e-10);
  const vertices=model.edges.flatMap(e=>[e.a,e.b]);
  for(const e of model.edges)for(const q of vertices){
    const dx=e.b[0]-e.a[0],dz=e.b[2]-e.a[2],length=Math.hypot(dx,dz),t=((q[0]-e.a[0])*dx+(q[2]-e.a[2])*dz)/(length*length);
    const distance=Math.abs((q[0]-e.a[0])*dz-(q[2]-e.a[2])*dx)/length;
    assert.ok(!(t>1e-7&&t<1-1e-7&&distance<1e-8),'no junction vertex remains in the middle of an unsplit seam');
  }
  assert.ok(model.edges.length<model.triangles.length*3,'triangle diagonals are not exported as seams');
});

test('roof model: join=false explicitly retains overlapping raw surfaces and original area',()=>{
  const p=project();roof(p,'roof-1');roof(p,'roof-2');p.roofSettings={join:false};
  const model=R.build(p);assert.equal(model.diagnostics.join,false);assert.equal(model.surfaces.length,4);
  close(model.area,160/Math.cos(Math.PI/6));close(model.diagnostics.projectedArea,160);close(model.diagnostics.coverageArea,80);
  assert.equal(model.diagnostics.clippingOperations,0);assert.ok(model.diagnostics.warnings.length);
  p.roofSettings.join=true;const joined=R.build(p);assert.notEqual(joined,model);close(joined.area,model.area/2);
});

test('roof model: cache is immutable, tracks floor and roof geometry, and faces returns safe consumer copies',()=>{
  const p=project(),r=roof(p,'roof');let model=R.build(p);assert.equal(R.build(p),model);assert.ok(Object.isFrozen(model.surfaces[0].rings[0][0]));
  const faces=R.faces(p,r);faces[0][0][1]=999;assert.notEqual(R.faces(p,r)[0][0][1],999);
  for(const mutate of [()=>p.floors[0].height+=.25,()=>p.floors[0].elevation+=1,()=>r.axis='y',()=>r.pitch=45,()=>r.elevationOffset=1,()=>r.reverse=true,()=>r.x+=.5,()=>r.material='white']){
    mutate();const next=R.build(p);assert.notEqual(next,model);model=next;assertEnvelope(p,model);
  }
  assert.equal(model.surfaces[0].material,'white');assert.throws(()=>R.faces(p,'missing'),e=>e.code==='INVALID_ROOF_INPUT');
});

test('roof model: raw finite validation precedes engine cloning and preserves valid optional parameters on save/load',()=>{
  for(const [key,value] of [['pitch',Infinity],['pitch',NaN],['pitch',76],['x',501],['w',0],['overhang',4],['axis','z'],['axis',null],['reverse',1],['elevationOffset',Infinity],['elevationOffset',-51],['elevationOffset',201]]){
    const p=project();roof(p,'roof',{[key]:value});const before=structuredClone(p);
    assert.throws(()=>E.validate(p),e=>e.code==='INVALID_ROOF_INPUT');assert.throws(()=>R.build(p),e=>e.code==='INVALID_ROOF_INPUT');assert.deepEqual(p,before);
  }
  for(const join of [0,'true',null,Infinity]){const p=project();roof(p,'roof');p.roofSettings={join};assert.throws(()=>E.validate(p),/join/);}
  for(const floors of [null,{},[{}]]){const p=project();p.floors=floors;assert.throws(()=>R.build(p),e=>e.code==='INVALID_ROOF_INPUT');}
  const nonfiniteFloor=project();nonfiniteFloor.floors[0].height=Infinity;assert.throws(()=>E.validate(nonfiniteFloor),e=>e.code==='INVALID_ROOF_INPUT');
  const p=project();roof(p,'roof',{axis:'y',reverse:true,elevationOffset:-2.25});p.roofSettings={join:false};
  const checked=E.validate(p),restored=E.validate(JSON.parse(JSON.stringify(checked)));
  assert.deepEqual(restored.roofs,p.roofs);assert.deepEqual(restored.roofSettings,p.roofSettings);close(R.build(restored).area,R.build(p).area);
  const duplicate=E.clone(p);duplicate.roofs.push({...duplicate.roofs[0]});assert.throws(()=>R.build(duplicate),/Duplicate/);
  const tooMany=E.clone(p);tooMany.roofs=Array.from({length:101},(_,i)=>({...p.roofs[0],id:'roof-'+i}));assert.throws(()=>R.build(tooMany),/maximum/);
});

test('roof model: browser globals reproduce node geometry, while missing dependencies fail explicitly',()=>{
  const source=fs.readFileSync(require.resolve('../dist/roof-model.js'),'utf8');
  const context={window:{BIM:{...E},polygonClipping:C,THREE:T}};vm.runInNewContext(source,context);
  const p=project();roof(p,'lower',{type:'flat'});roof(p,'upper',{type:'flat',x:2,y:2,w:3,d:3,elevationOffset:2});
  const native=R.build(p),browser=context.window.RoofModel.build(p);
  close(browser.area,native.area);assert.equal(JSON.stringify(browser),JSON.stringify(native));
  const missing={window:{BIM:{...E},polygonClipping:C}};vm.runInNewContext(source,missing);
  assert.throws(()=>missing.window.RoofModel.build(p),e=>e.code==='ROOF_TRIANGULATOR_UNAVAILABLE');
  const noClip={window:{BIM:{...E},THREE:T}};vm.runInNewContext(source,noClip);
  assert.throws(()=>noClip.window.RoofModel.build(p),e=>e.code==='ROOF_CLIPPER_UNAVAILABLE');
});

test('roof model: tiny real overlaps survive analytical clipping and translated models preserve area',()=>{
  const p=project();roof(p,'a',{type:'flat',w:10,d:8});roof(p,'b',{type:'flat',x:10-.00001,w:4,d:8,elevationOffset:.2});
  const model=R.build(p);close(model.area,(14-.00001)*8);assertEnvelope(p,model);
  const q=E.clone(p);q.roofs.forEach(r=>{r.x+=390;r.y-=210});const shifted=R.build(q);
  close(shifted.area,model.area);close(shifted.diagnostics.coverageArea,model.diagnostics.coverageArea);assertEnvelope(q,shifted);
  const empty=R.build(project());assert.deepEqual(empty.surfaces,[]);assert.deepEqual(empty.triangles,[]);assert.deepEqual(empty.edges,[]);assert.equal(empty.area,0);
});

test('roof model: 120 deterministic mixed roofs retain closed envelopes at shared hip/flat cuts',()=>{
  // This seed includes former zero-width hip/flat spurs and Boolean sweep failures
  // at examples 0, 13 and 72. The independent height oracle checks every result.
  let seed=72931;
  const random=()=>{seed=(1664525*seed+1013904223)>>>0;return seed/4294967296;};
  for(let i=0;i<120;i++){
    const p=E.newProject();p.floors.push({...p.floors[0],id:E.uid(),elevation:3.3});
    for(let j=0;j<2+i%5;j++)roof(p,'roof-'+j,{
      floor:p.floors[j%2].id,x:Math.floor(random()*18)-9,y:Math.floor(random()*18)-9,
      w:3+Math.floor(random()*13),d:3+Math.floor(random()*13),overhang:[0,.45][j%2],
      type:['gable','hip','shed','flat'][Math.floor(random()*4)],axis:j%2?'x':'y',
      pitch:[0,20,30,37,45,60][Math.floor(random()*6)],reverse:random()>.5,elevationOffset:[0,-2,1.1][j%3]
    });
    const model=R.build(p);assertEnvelope(p,model);close(model.diagnostics.projectedArea,model.diagnostics.coverageArea);
    assert.equal(model.diagnostics.coordinateSnap,1e-9);assert.ok(model.edges.every(e=>e.a.concat(e.b).every(Number.isFinite)));
  }
});
