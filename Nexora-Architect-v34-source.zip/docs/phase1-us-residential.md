# Phase 1 — North American residential presentation and USD takeoff

## Delivered

- Retained the four report fixes (endpoint drag, stable edit/delete, visible JSON import, decimal fields) and their regression suite.
- Procedural repeatable texture maps for oak/walnut planks, quartz, subway tile, painted lap siding, concrete, grass and woven fabric. Standard physically based materials use world-scale UVs, bump mapping and roughness. White Shaker sample cabinets have actual recessed-panel geometry and satin fronts. Quartz tops, tiled backsplash strips, baseboards, rugs and small island accessories are modeled into the scene.
- Three daylight presets (daylight, golden hour, overcast), soft sun shadows, gradient/cloud sky, sky lighting, lawn, trees, foundation shrubs, driveway and walk. Interior/Exterior actions and landscape toggle are available in the model toolbar. These are presentation context, not terrain grading or a certified landscape plan.
- Separate USD pricing data. Area items use sq ft, cabinets linear ft, concrete cubic yards, doors each. Added geometric countertop area and an explicitly labeled 18-inch backsplash allowance. Floor finish excludes bare-concrete rooms. Currency formatting uses en-US USD, two decimals; CSV and printed takeoff use the same data. Editable sample allowances are not market quotes or converted CNY prices; legacy rates remain untouched.
- English is the first-visit default, with saved language preferences respected. New projects default to imperial. Primary length fields accept mixed feet/inches and fractional inches, without changing internal metric geometry. Area readouts use sq ft. Existing projects keep their own unit and design.
- Four independently editable North American style samples: Ranch, Colonial-inspired, Craftsman, Modern Farmhouse. Above-grade living area is within 1,500–2,500 sq ft; garage and unfinished basement are separately classified. Includes front porch, Main Floor/Basement, Living Room, Primary Bedroom, Mudroom, Laundry Room, garage opening and linked basement stairwell. Colonial is a style-inspired single-main-floor concept, not a traditional two-story Colonial plan.

## Verification

203 automated tests pass, including full Three.js geometry rebuilds for all four homes, finite mesh buffers, texture UVs, roof and landscape meshes, stair/slab-hole linkage, per-unit USD conversions, preservation of legacy rates, and the actual inspector feet/inch and USD-price handlers.

Browser verified: English UI selection, all four sample entries, Ranch loaded in ft with English room names, 6′ 6″ dimension committed, USD material table, sq ft and above-grade living area, real canvas texture previews and application entry point. The cloud browser cannot create a WebGL context, so final interactive 3D shading, GPU shader compilation, image quality and frame rate are NOT visually accepted here. A supported desktop browser is needed for that final review. No claim of Chief Architect X18 parity or photorealistic ray tracing is made.

## User acceptance steps

1. Refresh without clearing site data. Open Home templates and choose a featured US home; the previous project remains in the project library.
2. Verify Imperial ft, English room names, Main Floor and Basement. Select a room/object; input feet and inches and press Enter. Drag a wall endpoint, undo; resize/move furniture, switch view/reload, delete once and undo. Export JSON and reimport it through Open project > Import project.
3. In 3D choose Interior; inspect wood grain, Shaker fronts, quartz, subway backsplash, rugs and baseboards. Choose Exterior, compare daylight/golden/overcast and toggle Landscape. Confirm sky, grass, trees, driveway and shadows in a browser with WebGL.
4. Open Materials to preview/apply maps. Open Materials & openings: verify USD, sq ft, linear ft, cu yd and each; change a unit price, press Enter, then compare total and exported CSV. Area summary separates all enclosed floor area from above-grade living area.
5. Confirm old projects retain their original geometry and units; legacy CNY rates were not silently relabeled or currency-converted.

## Next phases (not implemented by this release)

Phase 2: engineered wall/floor/roof framing and trusses, framing plans and coordinated sheets including details/site plan. Permit-ready output requires jurisdiction-specific design, engineering checks and applicable professional review; generating a title block alone does not make it permit-ready.

Phase 3: actual terrain/slope tools, designed site/landscape/driveway/decks, complete coordinated MEP documentation, DWG/DXF/IFC interoperability, durable cloud sync and collaboration, tested mobile room capture, and licensed manufacturer product libraries. Existing concept MEP and basic exchange tools remain available but are not represented as completion of this phase.
