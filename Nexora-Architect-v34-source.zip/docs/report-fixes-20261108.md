# November 8 test-report fixes

Based on the supplied nexora-architect-test-report.md. Existing project IDs, public audience, data schema, and server API integrations are preserved.

1. Wall endpoints: render handles last, over adjacent walls and opening graphics. Freeze the SVG frame and inverse transform throughout a geometry drag, ignore the moving node as a snap target, commit one transaction, and restore on cancellation/Escape. No-motion selection no longer creates undo entries.
2. Furniture: commit in-flight drags before commands. Keep a clicked button alive while the active field's blur commits its value, so changing a dimension and immediately clicking delete or changing view does not lose the first click. Position/dimension/deletion transactions persist before updating views; cancellation restores snapshots.
3. Import: a dedicated modal contains a visible, labeled file input and format/size guidance. Reuse validated JSON/DXF/scan/library parsing, reject invalid data, and import project JSON as a fresh ID, preserving the original. Cancel is non-mutating.
4. Decimal fields: core workbench numeric fields use decimal text inputs, formatted to at most 3 decimal places, with required/finite/min/max validation. This avoids Chromium's float32 accessibility spinbutton output without rounding the stored geometry.
5. Zoom: normalize wheel pixel/line/page units; limit each event to about 9% and keep existing 20–800% bounds.
6. Auto dimensions: explicitly enable all wall-segment, opening-width, and overall dimensions, with visible feedback. Toggle off preserves manual annotations. The same generated SVG feeds screen, print/PDF and SVG export.
7. Roofs: persistent warning for any wall footprint extending outside the combined roof coverage on the current floor. Explicit fit action expands selected roof to the floor's wall-thickness-aware bounding rectangle, preserving roof ID, pitch, style and material. Rectangular roofs remain an explicit limitation; no concave roof union is claimed.
8. Section: add cut hatching, heavier outlines, floor datums, level labels, storey-height and slab labels. Existing wall/opening/slab-hole/roof intersection geometry retained. Clearly marked as a preview, not a construction section or full hidden-line drawing.
9. Counts: footer explicitly scopes counts to the current floor, separates walls/closed spaces/independent objects/openings, and explains that hidden layers remain counted. Object changes use the same saved model as all views.

Additional: first manual save reminds users to export JSON because browser storage is local. Asset query versions and service-worker cache were bumped. Matching iOS web assets updated; this does not publish an App Store build.

## Verification completed

- 197 Node tests passed, including 6 new report-regression tests for drag commit/cancel, no-motion selection, furniture persistence/deletion/reload, roof coverage, bounded page-wheel zoom, exact decimal output, final handle overlay, print dimensions and section datums.
- Browser: wall length 12 m -> 13 m, endpoint X=13; actual keyboard dimension entry persisted across view changes; one-click furniture deletion persisted after reload; typing a dimension then directly deleting worked once; exported JSON was imported as a separate project with matching 8 walls / 17 objects / 13 openings; generated dimensions appeared in the sheet SVG; roof fit removed the warning; section showed levels, 2.80 m storey height and 0.20 m slab.
- Browser environment could not create WebGL. 3D visual validation remains unverified here. No authenticated AI/API flow or phone-width physical-device test is claimed.

## User regression checklist

Refresh the website, retaining browser data. Select a wall and drag a round endpoint; verify coordinates and length, then undo. Move/resize an object, switch plan/3D, reload, then delete once and undo. Export JSON, use Open project > Import project, choose that same file, and compare geometry in the new project. Enter 1.2, 2.8 and 0.2 in the relevant fields. Scroll two wheel steps and verify controlled scaling. In Sheets choose Auto dimensions twice and compare, then export SVG/PDF. Add walls outside an existing roof, observe warning and use Expand roof to all walls on this floor. Open Section A—A, change Y, and inspect cut fills/levels. Place/delete furniture on either floor and compare the scoped counts.
