# v32 — 2026-11-09

The supervisor reported seeing the v28 behavior and no v31 marker despite the previous browser checks. Do not infer that these reports are false or call the five items passed based only on tests.

Release delivery: every script/style URL uses the v32 release identifier. The Worker sends no-store and X-Nexora-Build: 20261109-r32; version.json is embedded as application/json. The service worker bypasses HTTP cache, never supplies cached version.json, and registers with updateViaCache:none and a release URL. Header/footer badges show a check mark only after a no-store server version check matches the running build. A release query URL can bypass a previously cached navigation without clearing project data.

Driveway plan and material gallery retain the corrected v31 geometry/order; v32 includes their code in the uniquely versioned release. Plan label width is 80% of slab width. 3D DRIVEWAY is now a horizontal plane 0.05m above the landscape datum, sized within the slab, with opaque unlit high-contrast texture, normal depth testing/writing, no overlay render order and a small polygon offset. It is not a camera-facing sprite.

Inspector structural fix: the right sidebar no longer scrolls. Tabs are a nonshrinking separate flex row; each tabpanel scrolls independently. Switching dock/project resets relevant scroll positions. Saved project view is restored without first rendering default Floor Plan. Existing long-title wrapping remains.

Pre-publication checks: scroll inspector to 789px, switch project, observe scrollTop 0 and complete title; 12 switches show no title clipping; returning to the Ranch restores 3D. Four material card labels are before their images. Server-matching badge verified in preview. 374 automated tests pass, including ground-mesh occlusion ordering and uncached build verification. Production visual checks must be performed after deployment. WebGL is not available in the browser environment, so actual GPU appearance cannot be claimed as visually passed.
