# Template inspection and local-code research — 2.12.0

The structural-design entry now starts with project address, jurisdiction fields, occupancy/use, work scope and intended filing date. Saving locally needs no account. Explicitly selecting the sharing control and submitting queries the existing authenticated AI backend with live web search. The application does not submit permit applications or contact officials.

## Implemented

- `/api/ai/codes` reuses existing authentication, origin checks, rate limiting, request-size limits, cancellation and configured model. Only the address/profile and interface language are transmitted; project geometry and owner identity are excluded.
- Candidate authority, adoption, local-amendment, structural, load, foundation and submission requirements link to sources actually returned by the search tool. Model-written URLs absent from the tool's consulted-source list are discarded. Accepted evidence domains currently cover .gov, .gc.ca, canada.ca and LADBS.org; unsupported official domains remain unresolved rather than silently accepted.
- Edits to address, use, scope or filing date clear previous research and reviews. Old forms and late responses cannot write into another project or replace newer research. Changing model geometry, slab openings, penetrations or MEP invalidates design-review notes.
- Research and review notes persist with project JSON and undo/redo; a separate JSON review report includes gaps and the current structural drafting data. Import checks reject malformed dates and unreferenced findings. Every report remains `not_certified` and retains an engineering-review gap.
- English, Chinese and Spanish labels. Responsive address form, local-only saving, explicit login/offline feedback. Beginner and professional modes both expose structural design.
- All template entry points now use the same 100-template North American catalog. Each template has a read-only, actual-model floor/3D preview, separate living/garage/basement/outdoor areas, floor/unit switching, a room list and creation of an independent editable copy.
- Preview camera correctly frames basement-only geometry. WebGL failures and modal closure release owned resources; unit/language changes preserve the preview camera.

## Verification

- Full regression suite: 370/370 passed on Nov 8. The new code-review tests use explicit mock provider responses and never impersonate real official findings.
- Local browser: Colonial main-floor and basement preview rendered; existing project remained intact. A separate QA project saved public civic-address test data locally; the static preview produced an explicit unavailable-AI message. Exported `Nexora-code-review.json` parsed successfully with `research: null`, `status: not_certified`, and four outstanding gaps.
- Mobile: 390×844 address form inspected. Desktop and mobile screenshots captured in the delivery folder.
- iOS 2.12.0 (9): simulator build with signing disabled passed. This is not an App Store/TestFlight upload.

## Remaining limits

A consulted official URL does not by itself establish that every interpreted clause, edition, filing transition or parcel jurisdiction is correct. Candidate findings require qualified applicability review. The application does not yet run structural capacity, load combinations, connections, foundation or jurisdiction-specific permit validation. No claim is made that generated drawings comply with all codes or will be approved. Live authenticated research must be validated separately from mocked API tests.

Official references used to design the workflow: NYC DOB Codes (https://www.nyc.gov/site/buildings/codes/codes.page), NYC Existing Building Code FAQs (https://www.nyc.gov/site/buildings/codes/ebc-faqs.page), OpenAI web-search source-list documentation (https://developers.openai.com/api/docs/guides/tools-web-search). No code edition is hardcoded as universally applicable.
