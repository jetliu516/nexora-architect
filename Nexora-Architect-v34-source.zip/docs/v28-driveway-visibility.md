# V28 — Driveway visibility

- 3D labels: opaque white backing, #14251c heavy 104px canvas glyphs, white SpriteMaterial tint, no tone mapping or fog. DRIVEWAY uses a camera-facing sprite with size attenuation disabled, retaining its projected size when zooming. Existing slab, curb and expansion joint geometry is unchanged.
- 2D: shared E.siteDriveway footprint is now drawn on the ground-floor plan with a gray slab, dark border and expansion joints. The label uses dark bold type with a 15px screen minimum; bounds include the driveway so normal fit does not crop it. Labels follow the Labels layer; site graphics follow Landscape and are not repeated on basement/upper floors. Exported plan SVG bounds include the site footprint.
- Kitchen suggestion: move SUBWAY TILE label above the backsplash so its lower edge clears the tile field. Widen running-bond grout from 1/8 inch to 3/16 inch. Keep physical non-tone-mapped grout faces and opening clipping.

Validation: 298 automated tests pass. New tests check texture ink and sprite tint/tone mapping/size settings, shared saved and fallback driveway footprints, fit bounds, ground-floor/layer visibility and 15px plan label scaling. Browser confirms driveway slab and readable DRIVEWAY at 28% with all layers on. WebGL is unavailable in the test browser, so final 3D appearance remains for user GPU retest.

Existing JSON restore, area formatting and numeric-field code are unchanged. iOS web bundle and offline asset versions synchronized.
