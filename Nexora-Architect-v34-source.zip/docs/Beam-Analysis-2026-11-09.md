# 梁计算交付与自查 · 2026-11-09

本轮增加的是可复算的构件力学计算，不能据此宣称整栋结构符合当地 code、可以施工或已经超过 Chief Architect 全部功能。

## 已实现

- 入口：结构设计 → 项目地址与当地法规 → 继续结构草案 → 添加梁/楼板搁栅/过梁 → 梁计算。
- 输入实际跨度和矩形截面、永久/可变均布线荷载、最多 12 个集中荷载及位置、独立 E/G、允许应力、支承长度和挠度限值。材料和荷载没有自动猜测的默认设计值。
- 两个未分项使用工况 D+Q / Q 分别求反力、弯矩、剪力、弯曲与剪切总挠度的共同最大位置。显示六张曲线，提供 JSON 和可打印 HTML 下载，并保留系统打印入口。
- 缺少允许值时显示“未校核”，不是“通过”。等值比较仅使用机器精度级容差；1e-10 相对超限仍报告超限。
- 几何、材料、项目地址/法规研究和结构依据变化后，旧记录失效。旧结果隐藏、下载禁止，保留输入供复核重算。切换项目、过期表单、存储失败均有保护。
- 英/中/西界面，SI/US 显示单位。只读英制跨度用英尺英寸、截面用英寸；结果最多三位小数，内部/JSON 保留计算精度。

## 验证证据

整套 Node 回归 **454/454**；新增 38 项（核心 7、独立数值 12、界面真实事件 19）。iOS 2.13.0 (11) 模拟器 Debug 构建成功；未做真机或 TestFlight 上传。

独立数值基准采用人为指定的测试参数，不能作为木材等级参数使用：L=4 m、b=0.1 m、h=0.3 m、E=10 GPa、G=0.625 GPa。四工况总挠度依次为 3.218962963、6.565925926、4.503740982、7.674153273 mm。包含均布、跨中集中、偏心集中及混合荷载。

浏览器中在独立 QA 项目实际录入 q=2 kN/m 与 P=10 kN@1 m：左/右反力 11.5/6.5 kN，最大弯矩 10.5 kN·m，最大总挠度 7.674153273083643 mm（x=1.8303559928354463 m）。JSON 实际下载并解析，六项缺限值均为 missing_limit。随后截面高度改为 0.25 m，列表显示需重算、旧结果隐藏且导出禁用；重算恢复有效记录，刷新后数据保留。

390×844 视口截图确认表单单列和完整输入宽度；这是浏览器窄屏检查，不等于触屏真机验收。计算及下载前浏览器捕获的错误日志为空。

系统打印按钮在内置浏览器中未产生可验证的新页面，后续浏览器控制发生阻塞。**实际 PDF 打印未通过验收**。新增“下载可打印 HTML”由真实事件测试验证文件内容、三语、六张图与过期保护；最终新增按钮的浏览器下载尚未复验。原 JSON 下载已实测。

登录后的 AI 法规检索、地区法规实时性、当地主管部门认定和完整结构工程复核不属于已通过项目。

## 对标与公式来源

- [Chief Creating a Beam](https://www.chiefarchitect.com/support/article/KB-00457/creating-a-beam.html)：手动梁及尺寸/叠拼建模。
- [Chief Changing Joist Directions](https://www.chiefarchitect.com/support/article/KB-02932/changing-joist-directions.html)：搁栅方向及自动排布。
- [Chief Controlling Door and Window Framing](https://www.chiefarchitect.com/support/article/KB-00985/controlling-door-and-window-framing.html)：按洞口宽度配置过梁深度规则。
- [Chief Manually Modifying Deck Framing](https://www.chiefarchitect.com/support/article/KB-01245/manually-modifying-deck-framing.html)：官方说明其不执行荷载工程计算。
- [USDA Wood Handbook 2021 第 9 章](https://research.fs.usda.gov/download/treesearch/62251.pdf)：截面性质、弯曲/剪切应力及变形的力学依据。
- [AWC Beam Design Formulas](https://awc.org/wp-content/uploads/2021/12/AWC-DA6-BeamFormulas-0710.pdf)：简单支承荷载工况交叉核验。

这些公式资料不是所在地采用的法定规范。当前模型仅覆盖简支、实心等截面矩形、向下静载；不处理连续/悬臂梁、工字搁栅、完整荷载组合、侧扭屈曲、连接、孔洞、基础、土壤或整栋传力。E 必须不含剪切变形，避免与独立 G 重复计入。仍需工程师核定输入、适用规范和整体结构。
