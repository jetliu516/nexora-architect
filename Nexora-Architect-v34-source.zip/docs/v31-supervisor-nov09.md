# v31 — Supervisor retest, 2026-11-09

1. Plan DRIVEWAY label: removed the fixed screen-size minimum. Physical label width is 80% of the saved driveway width, so both scale together. Browser at 28%: slab 44.01 px, label 35.21 px; horizontal bounds are inside the slab.
2. Material gallery: all four cards previously used image-first/title-below markup. All four now consistently put titles above images. Browser measured each title bottom at or above the corresponding image top. The existing 3D backsplash sign above the tile field is unchanged.
3. Visible build identifier: footer badge reads v31 · 2026-11-09 and is excluded from translation. Native web copy uses the same identifier. Offline cache is bumped.
4. 3D driveway: retain opaque white backing and dark text, use real world width and enable normal depth testing. Sprite remains camera-facing but roof/wall depth can occlude it; no always-on-top overlay. Explicit driveway width capped at 80% of the slab width.
5. Attributes: repeated switching between the Ranch and a long-title blank project did not reproduce persistent title overlap. Added normal wrapping, automatic height, line-height 1.3 and no title transforms/animation/transition. Browser measured title inside inspector bounds and the following metadata below the title after switches.

372 automated tests pass. Tests updated for the requested scale/depth behavior and added for material card order and visible version/layout. Browser verified plan geometry at 28%, material order, version badge and project switching. WebGL is unavailable in this test browser, so the final GPU occlusion appearance needs user retest.

Preserves the v30 source updates (including joined roofs and AI assistant) and the passed geometry/import/numeric functionality. Import code unchanged.
