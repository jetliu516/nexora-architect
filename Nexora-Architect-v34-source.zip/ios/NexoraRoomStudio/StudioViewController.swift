import UIKit
import WebKit
import RoomPlan
import AVFoundation

final class StudioViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate {
    private var webView: WKWebView!
    private var activeScan: CaptureViewController?
    private let handlerName = "roomplan"

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.96, green: 0.96, blue: 0.94, alpha: 1)
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.userContentController.add(WeakScriptHandler(target: self), name: handlerName)
        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = view.backgroundColor
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        guard let url = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Web") else {
            showError("缺少 Web/index.html，请检查项目中的 Web 资源目录。")
            return
        }
        webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        // Only bundled main-frame content can invoke the native bridge.
        guard message.frameInfo.isMainFrame,
              message.frameInfo.request.url?.isFileURL == true,
              let body = message.body as? [String: Any], let action = body["action"] as? String else { return }
        switch action {
        case "scan": startScan(context: body["context"] as? [String: Any] ?? [:])
        case "scanLibrary", "exportScan":
            guard presentedViewController == nil else { return }
            let library = ScanLibraryViewController(style: .insetGrouped)
            present(UINavigationController(rootViewController: library), animated: true)
        case "export":
            guard let name = body["name"] as? String, let text = body["text"] as? String,
                  text.utf8.count < 20_000_000 else { return }
            let allowed = ["json", "svg", "dxf", "obj", "csv", "html"]
            guard allowed.contains((name as NSString).pathExtension.lowercased()) else { return }
            let safeName = URL(fileURLWithPath: name).lastPathComponent
            do {
                let url = FileManager.default.temporaryDirectory.appendingPathComponent(safeName)
                try text.write(to: url, atomically: true, encoding: .utf8)
                share([url])
            } catch { showError(error.localizedDescription) }
        case "exportPDF":
            guard let encoded = body["base64"] as? String,
                  encoded.count < 96_000_000,
                  let data = Data(base64Encoded: encoded),
                  data.starts(with: Data("%PDF-".utf8)) else {
                showError("无法导出此PDF，请降低分辨率或分批导出。")
                return
            }
            do {
                let filename = (body["name"] as? String).map { URL(fileURLWithPath: $0).lastPathComponent } ?? "Nexora-drawing-set.pdf"
                let safeName = filename.lowercased().hasSuffix(".pdf") ? filename : "Nexora-drawing-set.pdf"
                let url = FileManager.default.temporaryDirectory.appendingPathComponent(safeName)
                try data.write(to: url, options: .atomic)
                share([url])
            } catch { showError(error.localizedDescription) }
        case "exportImage":
            guard let encoded = body["base64"] as? String,
                  encoded.count < 28_000_000,
                  let data = Data(base64Encoded: encoded),
                  UIImage(data: data) != nil else { return }
            do {
                let filename = (body["name"] as? String).map { URL(fileURLWithPath: $0).lastPathComponent } ?? "Nexora-view.png"
                let safeName = filename.lowercased().hasSuffix(".png") ? filename : "Nexora-view.png"
                let url = FileManager.default.temporaryDirectory.appendingPathComponent(safeName)
                try data.write(to: url, options: .atomic)
                share([url])
            } catch { showError(error.localizedDescription) }
        case "print":
            guard let html = body["html"] as? String, html.utf8.count < 20_000_000 else { return }
            let printer = UIPrintInteractionController.shared
            let info = UIPrintInfo(dictionary: nil)
            info.jobName = "Nexora 房屋设计报告"
            info.outputType = .general
            printer.printInfo = info
            printer.printFormatter = UIMarkupTextPrintFormatter(markupText: html)
            printer.present(animated: true, completionHandler: nil)
        default: break
        }
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        if url.isFileURL { decisionHandler(.allow) }
        else {
            // Never load remote pages into the privileged web view.
            decisionHandler(.cancel)
            if navigationAction.navigationType == .linkActivated, ["https", "http"].contains(url.scheme ?? "") {
                UIApplication.shared.open(url)
            }
        }
    }

    private func startScan(context: [String: Any]) {
        guard activeScan == nil else { return }
        guard RoomCaptureSession.isSupported else {
            showError("当前设备不支持 RoomPlan 激光量房。请使用带 LiDAR 的 iPhone / iPad，或手动输入测距仪读数。")
            return
        }
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: presentScanner(context: context)
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                DispatchQueue.main.async {
                    if granted { self?.presentScanner(context: context) }
                    else { self?.showError("需要相机权限才能扫描。可以在系统设置中允许相机访问。") }
                }
            }
        default: showError("相机权限未开启，请到「设置 → Nexora Architect → 相机」开启。")
        }
    }

    private func presentScanner(context: [String: Any]) {
        guard presentedViewController == nil else { return }
        let scanner = CaptureViewController()
        scanner.onCancel = { [weak self] in
            self?.activeScan = nil
            self?.webView.callAsyncJavaScript("window.nexoraScanCancelled?.();", arguments: [:], in: nil, in: .page, completionHandler: nil)
        }
        scanner.onComplete = { [weak self] room in
            guard let self = self else { return }
            self.activeScan = nil
            self.consume(room, context: context)
        }
        activeScan = scanner
        let navigation = UINavigationController(rootViewController: scanner)
        navigation.modalPresentationStyle = .fullScreen
        present(navigation, animated: true)
    }

    private func consume(_ room: CapturedRoom, context: [String: Any]) {
        do {
            let captureID = UUID().uuidString
            let info = ScanInfo(id: captureID, context: context)
            let folder = try ScanStore.root().appendingPathComponent(captureID, isDirectory: true)
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            var payload = ScanExport.payload(room)
            payload["name"] = info.name
            payload["captureId"] = captureID
            var warnings: [String] = []
            var savedJSON = false
            let normalizedURL = folder.appendingPathComponent("Nexora-Scan.json")
            do {
                let normalized = try JSONSerialization.data(withJSONObject: payload, options: [.prettyPrinted, .sortedKeys])
                try normalized.write(to: normalizedURL, options: .atomic)
                savedJSON = true
            } catch { warnings.append("Nexora JSON 保存失败：" + error.localizedDescription) }
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            encoder.dateEncodingStrategy = .iso8601
            let rawURL = folder.appendingPathComponent("RoomPlan-Raw.json")
            do {
                try encoder.encode(room).write(to: rawURL, options: .atomic)
                savedJSON = true
            } catch { warnings.append("RoomPlan 原始 JSON 保存失败：" + error.localizedDescription) }
            guard savedJSON else {
                showError("原始扫描文件未能保存。请先释放设备存储空间，再重新扫描。\n" + warnings.joined(separator: "\n"))
                return
            }
            do {
                try encoder.encode(info).write(to: folder.appendingPathComponent("Scan-Info.json"), options: .atomic)
            } catch { warnings.append("名称信息未能保存；仍可从扫描记录中按时间找到原始文件。") }
            do {
                let modelURL = folder.appendingPathComponent("Room.usdz")
                try room.export(to: modelURL, exportOptions: .parametric)
            } catch {
                try? FileManager.default.removeItem(at: folder.appendingPathComponent("Room.usdz"))
                warnings.append("3D 模型生成失败，已保存的 JSON 不受影响：" + error.localizedDescription)
            }
            // JSON goes through a WKWebView argument, never JavaScript string interpolation.
            let saveWarnings = warnings
            webView.callAsyncJavaScript("if (window.nexoraReceiveScan(payload) !== true) { throw new Error('设计端未确认导入'); } return true;", arguments: ["payload": payload], in: nil, in: .page) { [weak self] result in
                var messages = saveWarnings
                if case .failure(let error) = result {
                    messages.append("扫描文件已保存，但导入设计端失败：\(error.localizedDescription)。请打开「扫描记录」导出备份。")
                }
                if !messages.isEmpty { self?.showError(messages.joined(separator: "\n\n")) }
            }
        } catch { showError("保存扫描失败：\(error.localizedDescription)") }
    }

    private func share(_ urls: [URL]) {
        let controller = UIActivityViewController(activityItems: urls, applicationActivities: nil)
        controller.popoverPresentationController?.sourceView = view
        controller.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        present(controller, animated: true)
    }

    private func showError(_ message: String) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            let alert = UIAlertController(title: "Nexora Architect", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "知道了", style: .default))
            (self.presentedViewController ?? self).present(alert, animated: true)
        }
    }
}

private final class WeakScriptHandler: NSObject, WKScriptMessageHandler {
    weak var target: WKScriptMessageHandler?
    init(target: WKScriptMessageHandler) { self.target = target }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        target?.userContentController(userContentController, didReceive: message)
    }
}
