(function(root){'use strict';const T=THREE,E=BIM,R=root.RoofModel||(typeof require==='function'?require('./roof-model.js'):null),RD=root.RoofDisplay||(typeof require==='function'?require('./roof-display.js'):null);
class BuildingView{
constructor(host,onSelect,onStatus){try{this.host=host;this.onSelect=onSelect;this.onStatus=onStatus;this.scene=new T.Scene();this.scene.background=new T.Color('#d8e9f2');this.scene.fog=new T.Fog('#d8e9f2',80,180);this.renderer=new T.WebGLRenderer({antialias:true,alpha:false,preserveDrawingBuffer:true});this.renderer.setPixelRatio(Math.min(devicePixelRatio,2));this.renderer.shadowMap.enabled=true;this.renderer.shadowMap.type=T.PCFSoftShadowMap;this.renderer.localClippingEnabled=true;this.renderer.outputColorSpace=T.SRGBColorSpace;this.renderer.toneMapping=T.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.05;host.append(this.renderer.domElement);this.camera=new T.PerspectiveCamera(42,1,.05,2000);this.target=new T.Vector3(6,0,4.5);this.distance=24;this.theta=.68;this.phi=.8;this.scene.add(new T.HemisphereLight(0xf6f2e8,0x839b80,1.35));this.sun=new T.DirectionalLight(0xfff4df,3.5);this.sun.position.set(-12,22,16);this.sun.castShadow=true;this.sun.shadow.mapSize.set(2048,2048);Object.assign(this.sun.shadow.camera,{left:-30,right:30,top:30,bottom:-30,near:.5,far:80});this.sun.shadow.bias=-.0003;this.scene.add(this.sun);this.model=new T.Group();this.scene.add(this.model);this.ground=new T.Mesh(new T.PlaneGeometry(2000,2000),root.ResidentialMaterials?root.ResidentialMaterials.material('grass'):new T.MeshStandardMaterial({color:0x77925b,roughness:1}));if(root.ResidentialMaterials)root.ResidentialMaterials.uv(this.ground.geometry,.5);this.ground.rotation.x=-Math.PI/2;this.ground.position.y=-.25;this.ground.receiveShadow=true;this.scene.add(this.ground);this.landscape=new T.Group();this.scene.add(this.landscape);root.ResidentialRendering?.setup(this);this.ray=new T.Raycaster();this.pointer=new T.Vector2();this.resizeObs=new ResizeObserver(()=>this.resize());this.resizeObs.observe(host);this.bind();this.setCamera();this.resize();this.render()}catch(error){try{this.dispose()}catch{}throw error}}
resize(){if(this.disposed)return;let w=this.host.clientWidth,h=this.host.clientHeight;if(w<2||h<2)return;this.renderer.setSize(w,h);this.camera.aspect=w/h;this.camera.updateProjectionMatrix();this.render()}
dispose(){if(this.disposed)return;this.disposed=true;this.resizeObs?.disconnect();const geometries=new Set(),materials=new Set(),maps=new Set();this.scene?.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material)for(const m of Array.isArray(o.material)?o.material:[o.material]){materials.add(m);if(m.userData?.ownsMap&&m.map)maps.add(m.map)}o.shadow?.map?.dispose();o.shadow?.mapPass?.dispose();});for(const g of geometries)g.dispose();for(const m of materials)m.dispose();for(const t of maps)t.dispose();this.scene?.clear();this.renderer?.setAnimationLoop?.(null);this.renderer?.renderLists?.dispose();this.renderer?.dispose();this.renderer?.forceContextLoss?.();this.renderer?.domElement.remove();}
setCamera(){if(this.walk)return;this.camera.position.set(this.target.x+this.distance*Math.sin(this.phi)*Math.cos(this.theta),this.target.y+this.distance*Math.cos(this.phi),this.target.z+this.distance*Math.sin(this.phi)*Math.sin(this.theta));this.camera.lookAt(this.target);this.render()}
render(){if(!this.disposed)this.renderer.render(this.scene,this.camera)}
bind(){const el=this.renderer.domElement;el.style.touchAction='none';let drag=null,pointers=new Map,pinch=null;el.addEventListener('contextmenu',e=>e.preventDefault());el.addEventListener('pointerdown',e=>{el.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});drag={x:e.clientX,y:e.clientY,ox:e.clientX,oy:e.clientY,button:e.button,shift:e.shiftKey};if(pointers.size===2){let a=[...pointers.values()];pinch=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y)}});el.addEventListener('pointermove',e=>{if(!drag)return;let dx=e.clientX-drag.x,dy=e.clientY-drag.y;pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(pointers.size===2){let a=[...pointers.values()],d=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);this.distance=Math.max(2,Math.min(300,this.distance*pinch/d));pinch=d;this.setCamera()}else if(this.walk){this.yaw-=dx*.005;this.pitch=Math.max(-1.2,Math.min(1.2,this.pitch-dy*.005));this.walkLook()}else if(drag.button===2||drag.shift){const scale=this.distance/700;this.target.x+=(-dx*Math.sin(this.theta)+dy*Math.cos(this.theta))*scale;this.target.z+=(dx*Math.cos(this.theta)+dy*Math.sin(this.theta))*scale;this.setCamera()}else{this.theta-=dx*.008;this.phi=Math.max(.08,Math.min(1.55,this.phi+dy*.008));this.setCamera()}drag.x=e.clientX;drag.y=e.clientY});el.addEventListener('pointerup',e=>{if(drag&&Math.hypot(e.clientX-drag.ox,e.clientY-drag.oy)<5&&pointers.size===1){const r=el.getBoundingClientRect();this.pointer.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);this.ray.setFromCamera(this.pointer,this.camera);let hits=this.ray.intersectObjects(this.model.children,true);for(const hit of hits){let obj=hit.object;while(obj&&!obj.userData.entity)obj=obj.parent;if(obj){if(this.onSelect(obj.userData.entity)!==false)break}}}pointers.delete(e.pointerId);drag=null;pinch=null});el.addEventListener('pointercancel',e=>{pointers.delete(e.pointerId);drag=null});el.addEventListener('wheel',e=>{e.preventDefault();if(this.walk)this.move(e.deltaY<0?'forward':'back');else{this.distance=Math.max(2,Math.min(300,this.distance*Math.exp(Math.max(-100,Math.min(100,e.deltaY))*.0009531)));this.setCamera()}},{passive:false})}
fit(p,floor,options={}){if(options.singleFloor){
 const f=p.floors.find(f=>f.id===floor);if(!f)return;
 const bounds=new T.Box3().setFromObject(this.model),b=E.bounds(p,floor);
 if(bounds.isEmpty()){bounds.min.set(b.x,f.elevation-f.slab,b.y);bounds.max.set(b.x+b.w,f.elevation+f.height,b.y+b.d)}
 if(this.s?.cutaway)bounds.max.y=Math.max(bounds.min.y,Math.min(bounds.max.y,f.elevation+(this.s.cutHeight||1.35)));
 this.walk=false;this.phi=.82;this.theta=.68;bounds.getCenter(this.target);
 const u=new T.Vector3(Math.sin(this.phi)*Math.cos(this.theta),Math.cos(this.phi),Math.sin(this.phi)*Math.sin(this.theta)),right=new T.Vector3(Math.sin(this.theta),0,-Math.cos(this.theta)),up=new T.Vector3(-Math.cos(this.phi)*Math.cos(this.theta),Math.sin(this.phi),-Math.cos(this.phi)*Math.sin(this.theta)),tanY=Math.tan(this.camera.fov*Math.PI/360),tanX=tanY*Math.max(.1,this.camera.aspect);let distance=1;
 for(const x of [bounds.min.x,bounds.max.x])for(const y of [bounds.min.y,bounds.max.y])for(const z of [bounds.min.z,bounds.max.z]){const v=new T.Vector3(x,y,z).sub(this.target);distance=Math.max(distance,v.dot(u)+Math.abs(v.dot(right))/tanX,v.dot(u)+Math.abs(v.dot(up))/tanY)}
 this.distance=distance*1.12;this.setCamera();return;
}const b=root.MEP?root.MEP.bounds(p,floor):E.bounds(p,floor);this.walk=false;const f=p.floors.find(f=>f.id===floor),base=f?.elevation||0;
if(p.template?.id?.startsWith('NA-')){this.phi=1.18;this.theta=1.18;const height=Math.max(base+(f?.height||2.8),...R.build(p).triangles.flatMap(t=>t.points.map(v=>v[1])));this.target.set(b.x+b.w/2,(Math.max(0,base)+height)/2,b.y+b.d/2);const u=new T.Vector3(Math.sin(this.phi)*Math.cos(this.theta),Math.cos(this.phi),Math.sin(this.phi)*Math.sin(this.theta)),right=new T.Vector3(Math.sin(this.theta),0,-Math.cos(this.theta)),up=new T.Vector3(-Math.cos(this.phi)*Math.cos(this.theta),Math.sin(this.phi),-Math.cos(this.phi)*Math.sin(this.theta)),tanY=Math.tan(this.camera.fov*Math.PI/360),tanX=tanY*Math.max(.1,this.camera.aspect);let distance=1;for(const x of [b.x-1,b.x+b.w+1])for(const y of [Math.max(0,base)-.3,height])for(const z of [b.y-1,b.y+b.d+3]){const v=new T.Vector3(x,y,z).sub(this.target);distance=Math.max(distance,v.dot(u)+Math.abs(v.dot(right))/tanX,v.dot(u)+Math.abs(v.dot(up))/tanY)}this.distance=distance*1.12;
}else{this.target.set(b.x+b.w/2,base+.7,b.y+b.d/2);this.distance=(Math.max(b.w,b.d)*1.65+5)/Math.min(1,this.camera.aspect);this.phi=.82}this.setCamera()}

view(direction,p,floor){this.walk=false;const b=E.bounds(p,floor),f=p.floors.find(f=>f.id===floor);this.target.set(b.x+b.w/2,(f?.elevation||0)+1,b.y+b.d/2);if(direction==='top'){this.phi=.015}else{this.phi=direction==='iso'?.8:1.5;this.theta={front:Math.PI/2,back:-Math.PI/2,left:Math.PI,right:0,iso:.68}[direction]??.68}this.setCamera()}
walkMode(p,floor){this.walk=!this.walk;if(this.walk){const b=E.bounds(p,floor),f=p.floors.find(f=>f.id===floor);this.camera.position.set(b.x+b.w*.35,(f?.elevation||0)+1.65,b.y+b.d*.7);this.yaw=Math.PI;this.pitch=0;this.walkLook()}else this.fit(p,floor);return this.walk}
walkLook(){this.camera.lookAt(this.camera.position.clone().add(new T.Vector3(Math.sin(this.yaw)*Math.cos(this.pitch),Math.sin(this.pitch),Math.cos(this.yaw)*Math.cos(this.pitch))));this.render()}
move(direction){if(!this.walk)return;let a=this.yaw+(direction==='left'?Math.PI/2:direction==='right'?-Math.PI/2:direction==='back'?Math.PI:0);this.camera.position.x+=Math.sin(a)*.35;this.camera.position.z+=Math.cos(a)*.35;this.walkLook()}
captureCamera(name){const target=this.walk?this.camera.position.clone().add(new T.Vector3(Math.sin(this.yaw)*Math.cos(this.pitch),Math.sin(this.pitch),Math.cos(this.yaw)*Math.cos(this.pitch))):this.target;return{name,position:this.camera.position.toArray(),target:target.toArray(),walk:!!this.walk,...(this.walk?{yaw:this.yaw,pitch:this.pitch}:{})}}
restoreCamera(c){if(!c||![c.position,c.target].every(v=>Array.isArray(v)&&v.length===3&&v.every(n=>Number.isFinite(n)&&Math.abs(n)<=10000)))return false;const offset=new T.Vector3().fromArray(c.position).sub(new T.Vector3().fromArray(c.target)),distance=offset.length();if(distance<.001)return false;if(c.walk&&(!Number.isFinite(c.yaw)||!Number.isFinite(c.pitch)||Math.abs(c.pitch)>1.5))return false;this.walk=!!c.walk;this.target.fromArray(c.target);this.distance=distance;this.phi=Math.acos(Math.max(-1,Math.min(1,offset.y/distance)));this.theta=Math.atan2(offset.z,offset.x);if(this.walk){this.camera.position.fromArray(c.position);this.yaw=c.yaw;this.pitch=c.pitch;this.walkLook()}else this.setCamera();return true}
material(key,options={}){if(root.ResidentialMaterials)return root.ResidentialMaterials.material(key,options);const color=E.materials[key]?.color||key;return new T.MeshStandardMaterial({color,roughness:.72,metalness:0,...options})}
box(parent,w,h,d,x,y,z,material){const mesh=new T.Mesh(new T.BoxGeometry(Math.max(.005,w),Math.max(.005,h),Math.max(.005,d)),typeof material==='string'?this.material(material):material);if(root.ResidentialMaterials)root.ResidentialMaterials.uv(mesh.geometry,mesh.material.userData.textureScale??.5);mesh.position.set(x,y,z);mesh.castShadow=true;mesh.receiveShadow=true;parent.add(mesh);return mesh}
poly(parent,points,color){let geo=new T.BufferGeometry(),positions=[];const ps=points.map(p=>new T.Vector3(...p));for(let i=1;i<ps.length-1;i++)positions.push(...ps[0].toArray(),...ps[i].toArray(),...ps[i+1].toArray());geo.setAttribute('position',new T.Float32BufferAttribute(positions,3));geo.computeVertexNormals();const uv=[];for(let i=0;i<positions.length;i+=3)uv.push(positions[i]*.5,positions[i+2]*.5);geo.setAttribute('uv',new T.Float32BufferAttribute(uv,2));let m=new T.Mesh(geo,this.material(color,{side:T.DoubleSide}));m.castShadow=m.receiveShadow=true;parent.add(m);return m}
floorMesh(room, elevation, slab) {
      for (const polygon of room.surfaceGeometry) {
        const shape = new T.Shape(
          polygon[0].map(([x, y]) => new T.Vector2(x, -y)),
        );
        shape.holes = polygon
          .slice(1)
          .map((r) => new T.Path(r.map(([x, y]) => new T.Vector2(x, -y))));
        const geo = new T.ExtrudeGeometry(shape, {
          depth: slab,
          bevelEnabled: false,
        });
        const mesh = new T.Mesh(geo, this.material(room.roomType==='bath'?'tile':room.material));
        mesh.rotation.x = -Math.PI / 2;
        mesh.position.y = elevation - slab;
        mesh.receiveShadow = mesh.castShadow = true;
        mesh.userData.entity = { type: "room", id: room.id };
        this.model.add(mesh);
      }
    }
    rail(parent, a, b, height = 1.05) {
      const v = new T.Vector3().subVectors(b, a),
        length = v.length();
      if (length < 0.01) return;
      const bar = new T.Mesh(
        new T.CylinderGeometry(0.022, 0.022, length, 8),
        this.material("charcoal"),
      );
      bar.position.copy(a).add(b).multiplyScalar(0.5);
      bar.quaternion.setFromUnitVectors(new T.Vector3(0, 1, 0), v.normalize());
      parent.add(bar);
      const count = Math.max(1, Math.ceil(length / 0.15));
      for (let i = 0; i <= count; i++) {
        const q = a.clone().lerp(b, i / count);
        this.box(
          parent,
          0.025,
          height,
          0.025,
          q.x,
          q.y - height / 2,
          q.z,
          "charcoal",
        );
      }
    }
rebuild(p,s){this.p=p;this.s=s;this.model.traverse(obj=>{if(obj.geometry)obj.geometry.dispose();if(obj.material){const mats=Array.isArray(obj.material)?obj.material:[obj.material];mats.forEach(m=>{if(m.userData?.ownsMap)m.map?.dispose();m.dispose()})}});this.model.clear();let floors=p.floors.filter(f=>s.allFloors||f.id===s.floor);const visible=new Set(floors.map(f=>f.id));this.ground.position.y=(root.ResidentialRendering?.siteFloor(p)?.elevation??p.floors.find(f=>f.elevation>=0)?.elevation??0)-.28;this.buildLandscape(p);for(const f of floors){const rooms=E.detectRooms(p,f.id);if(s.layers.rooms)rooms.forEach(r=>this.floorMesh(r,f.elevation,f.slab));if(s.foundation){const b=E.bounds(p,f.id);if(f.elevation===Math.min(...p.floors.map(f=>f.elevation)))this.box(this.model,b.w+.3,.35,b.d+.3,b.x+b.w/2,f.elevation-f.slab-.175,b.y+b.d/2,'concrete')}}
if(s.layers.walls||s.layers.openings)for(const w of p.walls.filter(w=>visible.has(w.floor))){const f=p.floors.find(f=>f.id===w.floor),len=E.dist(w.a,w.b),g=new T.Group();g.position.set(w.a.x,f.elevation,w.a.y);g.rotation.y=-Math.atan2(w.b.y-w.a.y,w.b.x-w.a.x);g.userData.entity={type:'wall',id:w.id};this.model.add(g);if(s.layers.walls&&s.framing){this.box(g,len,.045,w.thickness, len/2,.0225,0,'oak');this.box(g,len,.09,w.thickness,len/2,w.height-.045,0,'oak');const panels=E.wallPanels(p,w);for(let x=.025;x<len;x+=.4){for(const v of panels.filter(v=>!v.recess&&x>=v.x&&x<=v.x+v.w))if(v.h>.1)this.box(g,.045,Math.max(.04,v.h-.09),Math.max(.045,w.thickness-.02),x,v.z+v.h/2,0,'oak')}for(const o of p.openings.filter(o=>o.wall===w.id)){this.box(g,o.width+.09,.14,w.thickness,o.offset+o.width/2,o.sill+o.height+.07,0,'oak');if(o.sill>.05)this.box(g,o.width,.045,w.thickness,o.offset+o.width/2,o.sill-.023,0,'oak')}}else if(s.layers.walls)E.wallPanels(p,w).forEach(v=>this.box(g,v.w,v.h,v.depth??w.thickness,v.x+v.w/2,v.z+v.h/2,v.y||0,w.material));if(s.layers.openings)for(const o of p.openings.filter(o=>o.wall===w.id)){const og=new T.Group();og.position.x=o.offset;og.userData.entity={type:'opening',id:o.id};g.add(og);for(const part of Openings.parts(o,w.thickness)){const dx=part.b[0]-part.a[0],dy=part.b[1]-part.a[1],length=Math.hypot(dx,dy);const mat=part.material==='glass'?this.material('#aacbd3',{transparent:true,opacity:.35,metalness:.15,roughness:.1,depthWrite:false}):part.material==='metal'?'charcoal':part.material;const mesh=this.box(og,length,part.height,part.depth,(part.a[0]+part.b[0])/2,part.bottom+part.height/2,(part.a[1]+part.b[1])/2,mat);mesh.rotation.y=-Math.atan2(dy,dx);}}}
if(s.layers.objects)for(const o of p.objects.filter(o=>visible.has(o.floor))){if(E.catalog[o.kind].group==='电气'&&!s.layers.electrical)continue;this.objectMesh(o,p.floors.find(f=>f.id===o.floor).elevation)}if(s.roof&&s.layers.roofs){const roofs=R.build(p),groups=new Map();for(const r of p.roofs.filter(r=>visible.has(r.floor))){const g=new T.Group;g.userData.entity={type:'roof',id:r.id};g.name=r.id;groups.set(r.id,g);this.model.add(g)}for(const face of roofs.triangles){const g=groups.get(face.roofId);if(!g)continue;const mesh=this.poly(g,face.points,face.material==='charcoal'?'shingle':face.material);mesh.userData.roofSurface=true;mesh.userData.entity={type:'roof',id:face.roofId};mesh.name=face.roofId}for(const face of RD.closures(p)){const g=groups.get(face.roofId);if(!g)continue;const mesh=this.poly(g,face.points,face.material||'white');mesh.userData.roofClosure=true}}
      for (const hole of (p.slabOpenings || []).filter(
        (o) => s.layers.rooms && visible.has(o.floor) && o.guard,
      )) {
        const g = new T.Group();
        g.userData.entity = { type: "slabOpening", id: hole.id };
        this.model.add(g);
        const level = p.floors.find((f) => f.id === hole.floor).elevation,
          height = hole.guardHeight || 1.05;
        const stair = p.objects.find((o) => o.id === hole.sourceStair),
          last = stair && E.stairLayout(stair).slice(-1)[0];
        for (const poly of E.openingGeometry(p, hole))
          for (const boundary of poly)
            for (let i = 0; i < boundary.length - 1; i++) {
              const a = boundary[i],
                b = boundary[i + 1],
                middle = { x: (a[0] + b[0]) / 2, y: (a[1] + b[1]) / 2 };
              if (
                last &&
                last.points.some(
                  (q, j) =>
                    E.projectPoint(middle, q, last.points[(j + 1) % 4])
                      .distance < 0.005,
                ) &&
                E.dist({ x: a[0], y: a[1] }, { x: b[0], y: b[1] }) <
                  Math.max(last.w, last.d) + 0.01
              )
                continue;
              this.rail(
                g,
                new T.Vector3(a[0], level + height, a[1]),
                new T.Vector3(b[0], level + height, b[1]),
                height,
              );
            }
      }
if(root.MEP)this.mepMesh(p,s,visible);
if(root.Penetrations&&s.layers.penetrations!==false)for(const h of root.Penetrations.data(p).filter(h=>visible.has(h.floor))){const g=new T.Group();g.userData.entity={type:'penetration',id:h.id};this.model.add(g);for(const part of root.Penetrations.parts(p,h)){const mesh=new T.Mesh(new T.BoxGeometry(part.w,part.h,part.d),this.material('#ad8758'));mesh.position.set(part.x,part.z,part.y);mesh.rotation.y=-part.angle;mesh.castShadow=true;mesh.receiveShadow=true;g.add(mesh);}}
const cutHeight=(p.floors.find(f=>f.id===s.floor)?.elevation||0)+(s.cutHeight||1.35);const clips=s.cutaway?[new T.Plane(new T.Vector3(0,-1,0),cutHeight)]:[];this.model.traverse(obj=>{if(obj.material){let mats=Array.isArray(obj.material)?obj.material:[obj.material];mats.forEach(m=>{m.clippingPlanes=clips;if(s.style==='clay'){m.map=null;m.bumpMap=null;m.color.set('#e4e0d6');m.roughness=1;m.metalness=0}if(s.style==='wire'){m.map=null;m.bumpMap=null;m.wireframe=true;m.color.set('#53636a')}m.needsUpdate=true})}});if(s.selected){let target;this.model.traverse(obj=>{if(obj.userData.entity?.id===s.selected.id)target=obj});if(target){const box=new T.BoxHelper(target,0xc68a4a);this.model.add(box)}}this.sun.intensity=s.style==='clay'?2:3.0;root.ResidentialRendering?.environment(this,p,s);this.render()}
mepMesh(p,s,visible){
 const M=root.MEP;for(const r of M.data(p).runs){if(s.layers[M.layer(r.system)]===false)continue;const parts=M.visiblePaths(p,r,visible);if(!parts.length)continue;const group=new T.Group();group.userData.entity={type:'mepRun',id:r.id};this.model.add(group);for(const path of parts)for(let i=1;i<path.length;i++){const a=new T.Vector3(path[i-1].x,path[i-1].z,path[i-1].y),b=new T.Vector3(path[i].x,path[i].z,path[i].y),v=b.clone().sub(a),length=v.length();if(length<.000001)continue;const mesh=new T.Mesh(new T.CylinderGeometry(r.diameter/2,r.diameter/2,length,10),this.material(M.systems[r.system].color));mesh.position.copy(a).add(b).multiplyScalar(.5);mesh.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),v.normalize());group.add(mesh)}}
 for(const n of M.data(p).nodes){if(!visible.has(n.floor)||s.layers[M.layer(n.system)]===false)continue;const q=M.position(p,n),g=new T.Group();g.userData.entity={type:'mepNode',id:n.id};this.model.add(g);const source=M.systems[n.system].source===n.kind||n.kind==='panel';this.box(g,source?.28:.10,source?.35:.08,source?.18:.10,q.x,q.z,q.y,M.systems[n.system].color)}
}
objectMesh(o,elevation){const g=new T.Group();g.position.set(o.x+o.w/2,elevation+o.z,o.y+o.d/2);g.rotation.y=-o.angle*Math.PI/180;g.userData.entity={type:'object',id:o.id};this.model.add(g);const w=o.w,d=o.d,h=o.h,mat=o.material;const box=(W,H,D,x,y,z,m=mat)=>this.box(g,W,H,D,x,y,z,m),legs=(top)=>{for(const x of [-w/2+.07,w/2-.07])for(const z of [-d/2+.07,d/2-.07])box(.055,top,.055,x,top/2,z,'walnut')};if(Cabinets.isCabinet(o)){
const geometry=Cabinets.geometry(o);for(const part of geometry.parts)box(part.w,part.h,part.d,part.x,part.y,part.z,part.material==='white'?this.material('white',{roughness:.38}):part.material);
if(o.kind==='sink'||o.kind==='vanity'){box(w*.65,.012,d*.6,0,h+.006,0,'charcoal');box(w*.58,.014,d*.5,0,h+.016,0,'white');box(.025,.23,.025,0,h+.12,-d*.3,'charcoal');box(.025,.025,d*.18,0,h+.23,-d*.21,'charcoal')}
if(o.kind==='stove'){box(w*.85,.012,d*.8,0,h+.006,0,'charcoal');for(let x of [-w*.2,w*.2])for(let z of [-d*.18,d*.18]){let m=new T.Mesh(new T.CylinderGeometry(.075,.075,.01,24),this.material('#727b78'));m.position.set(x,h+.018,z);g.add(m)}}
}
else if(o.kind==='wardrobe'){box(w,h,d,0,h/2,0);for(let x of [-w/4,w/4]){box(w/2-.012,h-.02,.022,x,h/2,d/2);box(.02,.18,.03,x+Math.sign(x)*-.06,h/2,d/2+.025,'charcoal')}}
else if(o.kind==='sofa'||o.kind==='armchair'){
 const upholstered=(W,H,D,x,y,z,color=E.materials[mat]?.color||'#ddd3c2')=>{const shape=new T.Shape(),radius=Math.min(.07,W/5,H/5);shape.moveTo(-W/2+radius,-H/2);shape.lineTo(W/2-radius,-H/2);shape.quadraticCurveTo(W/2,-H/2,W/2,-H/2+radius);shape.lineTo(W/2,H/2-radius);shape.quadraticCurveTo(W/2,H/2,W/2-radius,H/2);shape.lineTo(-W/2+radius,H/2);shape.quadraticCurveTo(-W/2,H/2,-W/2,H/2-radius);shape.lineTo(-W/2,-H/2+radius);shape.quadraticCurveTo(-W/2,-H/2,-W/2+radius,-H/2);const geo=new T.ExtrudeGeometry(shape,{depth:D-.04,bevelEnabled:true,bevelSize:.02,bevelThickness:.02,bevelSegments:2,steps:1});geo.translate(0,0,-D/2+.02);root.ResidentialMaterials?.uv(geo,2);const mesh=new T.Mesh(geo,this.material('fabric',{color}));mesh.position.set(x,y,z);mesh.castShadow=mesh.receiveShadow=true;g.add(mesh)};
 for(const x of [-w/2+.12,w/2-.12])for(const z of [-d/2+.12,d/2-.12])box(.045,.15,.045,x,.075,z,'walnut');
 upholstered(w,.18,d,0,.22,0);upholstered(w-.1,h*.55,.18,0,h*.64,-d/2+.08);for(const x of [-w/2+.08,w/2-.08])upholstered(.16,h*.53,d,x,h*.48,0);
 const count=o.kind==='sofa'?3:1;for(let i=0;i<count;i++)upholstered((w-.32)/count-.012,.16,d-.24,-(w-.32)/2+(i+.5)*(w-.32)/count,.39,.06);
 for(const x of [-w*.3,w*.3])upholstered(Math.min(.35,w*.32),.32,.13,x,.62,-d*.2,x<0?'#b1bda7':'#425c70');
 // Keep the complete upholstered silhouette inside the editable footprint and height.
 const bounds=new T.Box3();for(const child of g.children){child.updateMatrix();child.geometry.computeBoundingBox();bounds.union(child.geometry.boundingBox.clone().applyMatrix4(child.matrix))}const size=bounds.getSize(new T.Vector3()),center=bounds.getCenter(new T.Vector3());for(const child of g.children)child.position.sub(new T.Vector3(center.x,bounds.min.y,center.z));g.scale.set(w/size.x,h/size.y,d/size.z);
}
else if(o.kind==='bed'){box(w,.18,d,0,.18,0,'walnut');box(w*.98,.22,d*.98,0,.38,0,'white');box(w+.05,1.1,.09,0,.55,-d/2,'walnut');box(w*.94,.06,d*.65,0,.51,d*.15,'sage');for(let x of [-w*.24,w*.24])box(w*.42,.12,.4,x,.55,-d*.32,'white')}
else if(['table','coffee','desk'].includes(o.kind)){legs(h-.06);box(w,.06,d,0,h-.03,0);if(o.kind==='table')for(let x of [-w*.33,w*.33])for(let z of [-d/2-.25,d/2+.25]){box(.4,.06,.4,x,.45,z,'sage');box(.4,.4,.04,x,.68,z+Math.sign(z)*.18,'sage')}}
else if (o.kind === "stairs") {
        const count=o.steps||17, riser=o.h/count;
        for(const part of E.stairPanels(o)) box(part.w,part.h,part.d,part.x+part.w/2-w/2,part.top-part.h/2,part.y+part.d/2-d/2,"oak");
        // Continuous sloping handrails, with open flight entrances and exits.
        const rail=(x1,y1,h1,x2,y2,h2)=>this.rail(g,new T.Vector3(x1-w/2,h1+.9,y1-d/2),new T.Vector3(x2-w/2,h2+.9,y2-d/2),.9);
        const fw=o.flightWidth||1.05, run=d-fw, mid=o.h*Math.floor(count/2)/count;
        if(!o.stairShape||o.stairShape==='straight') for(const x of [0,w]) rail(x,0,riser,x,d,o.h);
        else {
          for(const x of [0,fw]) rail(x,0,riser,x,run,mid);
          rail(0,run,mid,0,d,mid);
          if(o.stairShape==='u'){
            for(const x of [w-fw,w]) rail(x,run,mid,x,0,o.h);
            rail(w,run,mid,w,d,mid);rail(0,d,mid,w,d,mid);
          } else {
            for(const y of [run,d]) rail(fw,y,mid,w,y,o.h);
            rail(0,d,mid,fw,d,mid);
          }
        }
      } else if(o.kind==='bath'){box(w,h,d,0,h/2,0,'white');box(w*.76,.03,d*.8,0,h+.01,0,'stone');box(w*.65,.035,d*.7,0,h+.03,0,'white')}
else if(o.kind==='toilet'){box(w,.36,d*.65,0,.25,d*.1,'white');box(w,.7,.18,0,.35,-d*.32,'white');let seat=new T.Mesh(new T.CylinderGeometry(w*.48,w*.4,.08,24),this.material('white'));seat.scale.z=1.3;seat.position.set(0,.46,d*.18);g.add(seat)}
else if(o.kind==='shower'){box(w,.08,d,0,.04,0,'stone');for(let x of [-w/2,w/2])box(.02,h,d,x,h/2,0,this.material('#bed6d9',{transparent:true,opacity:.2,depthWrite:false}));box(w,h,.02,0,h/2,d/2,this.material('#bed6d9',{transparent:true,opacity:.2,depthWrite:false}))}
else if(o.kind==='plant'||o.kind==='tree'){let pot=new T.Mesh(new T.CylinderGeometry(w*.32,w*.25,h*.25,14),this.material('terracotta'));pot.position.y=h*.125;g.add(pot);let leaf=new T.Mesh(new T.IcosahedronGeometry(w*.55,2),this.material('sage'));leaf.scale.set(.8,h/(w*.8),.8);leaf.position.y=h*.65;leaf.castShadow=true;g.add(leaf)}
else if(o.kind==='light'){let m=new T.Mesh(new T.CylinderGeometry(w/2,w/2,h,24),this.material('white',{emissive:'#fff4c5',emissiveIntensity:.5}));m.position.y=h/2;g.add(m)}
else if(o.kind==='cornerUnit'){
  const sign=o.cornerMirror?-1:1;
  const face=[[-w/2,-d/2],[w/2,-d/2],[w/2,d/2],[w/2-w*.66,d/2],[-w/2,-d/2+d*.66]].map(([x,z])=>[x*sign,z]);
  const cap=(y,m)=>this.poly(g,face.map(([x,z])=>[x,y,z]),m);
  cap(h,'stone');for(let i=0;i<face.length;i++){const a=face[i],b=face[(i+1)%face.length];this.poly(g,[[a[0],0,a[1]],[b[0],0,b[1]],[b[0],h,b[1]],[a[0],h,a[1]]],mat);}
}
else if(o.kind==='dishwasher'||o.kind==='ovenUnit'){box(w,h,d,0,h/2,0,'white');const oven=o.kind==='ovenUnit';box(w*.88,h*(oven?.31:.78),.015,0,h*(oven?.57:.48),d/2,oven?'charcoal':'stone');box(w*.68,.03,.045,0,h*(oven?.73:.87),d/2+.015,'charcoal')}
else if(o.kind==='fridge'){box(w,h,d,0,h/2,0,'white');box(w-.02,.015,.025,0,h*.35,d/2+.012,'charcoal');box(.025,.45,.035,w*.35,h*.65,d/2+.03,'charcoal')}
else box(w,h,d,0,h/2,0);this.objectDetails(o,elevation);return g}
objectDetails(o,elevation){
 // Presentation accessories have no entity identity and do not enlarge the
 // editable object's selection box. They follow its layer and rebuild lifetime.
 const detailGroup=(detail)=>{const g=new T.Group();g.userData={presentationFor:o.id,detail};this.model.add(g);return g};
 const finish=g=>g.traverse(mesh=>{if(mesh.isMesh){mesh.raycast=()=>{};mesh.userData.presentationFor=o.id}});
 if(o.kind==='bed'&&Math.abs(o.z)<.1){const rug=detailGroup('rug');rug.position.set(o.x+o.w/2,elevation,o.y+o.d/2);rug.rotation.y=-o.angle*Math.PI/180;this.box(rug,o.w+1,.012,o.d+.8,0,.009,.15,this.material('fabric',{color:'#d9c9ad'}));finish(rug)}
 if(!this.p||this.s?.layers?.walls===false||Math.abs(o.z)>=.1||!['baseCabinet','drawerCabinet','sink','stove'].includes(o.kind)||!Cabinets.config(o).countertop)return;
 const angle=o.angle*Math.PI/180,axis={x:Math.cos(angle),y:Math.sin(angle)},forward={x:-axis.y,y:axis.x},back={x:o.x+o.w/2-forward.x*o.d/2,y:o.y+o.d/2-forward.y*o.d/2};
 let host=null;
 for(const w of this.p.walls.filter(w=>w.floor===o.floor)){
  const length=E.dist(w.a,w.b),u={x:(w.b.x-w.a.x)/length,y:(w.b.y-w.a.y)/length};if(Math.abs(axis.x*u.x+axis.y*u.y)<.99999)continue;
  const offset=(back.x-w.a.x)*u.x+(back.y-w.a.y)*u.y,signed=-(back.x-w.a.x)*u.y+(back.y-w.a.y)*u.x,side=Math.sign(signed),gap=Math.abs(signed)-w.thickness/2;
  if(gap<-.02||gap>.12||side*(-forward.x*u.y+forward.y*u.x)<.99999||offset+o.w/2<=0||offset-o.w/2>=length)continue;
  if(!host||Math.abs(gap)<host.gap)host={w,u,offset,side,gap:Math.abs(gap)};
 }
 if(!host)return;
 const {w,u,offset,side}=host,bottom=o.z+o.h,top=Math.min(w.height,bottom+.4572),parts=[];
 for(const panel of E.wallPanels(this.p,w)){if(panel.recess)continue;const left=Math.max(offset-o.w/2,panel.x),right=Math.min(offset+o.w/2,panel.x+panel.w),low=Math.max(bottom,panel.z),high=Math.min(top,panel.z+panel.h);if(right-left>.001&&high-low>.001)parts.push({left,right,low,high})}
 if(!parts.length)return;
 const splash=detailGroup('backsplash');splash.position.set(w.a.x,elevation,w.a.y);splash.rotation.y=-Math.atan2(u.y,u.x);
 for(const v of parts){
 const z=side*(w.thickness/2+.008),tw=.1524,th=.0762,gap=.0047625;this.box(splash,v.right-v.left,v.high-v.low,.016,(v.left+v.right)/2,(v.low+v.high)/2,z,'#7d847d');
 for(let row=0;row<6;row++){const low=Math.max(v.low,bottom+row*th+gap/2),high=Math.min(v.high,bottom+(row+1)*th-gap/2);if(high-low<=.001)continue;
 for(let x=offset-o.w/2-(row%2?tw/2:0);x<v.right;x+=tw){const left=Math.max(v.left,x+gap/2),right=Math.min(v.right,x+tw-gap/2);if(right-left<=.001)continue;const tile=this.box(splash,right-left,high-low,.012,(left+right)/2,(low+high)/2,z+side*.012,this.material('#fafaf6',{roughness:.24}));tile.userData.surface='subway-tile';}}
 // Explicit grout faces sit clear of both the host wall and tile fronts.
 // Unlit dark grout stays legible under bright sunlight and ACES tone mapping.
 const grout=new T.MeshBasicMaterial({color:'#66736e',toneMapped:false});
 const seam=(width,height,x,y)=>{if(width<=.0001||height<=.0001)return;const mesh=new T.Mesh(new T.BoxGeometry(width,height,.001),grout);mesh.position.set(x,y,z+side*.019);mesh.userData.surface='subway-grout';mesh.userData.rowHeight=th;splash.add(mesh)};
 for(let row=1;row<6;row++){const y=bottom+row*th,lo=Math.max(v.low,y-gap/2),hi=Math.min(v.high,y+gap/2);if(hi>lo)seam(v.right-v.left,hi-lo,(v.left+v.right)/2,(lo+hi)/2)}
 for(let row=0;row<6;row++){const low=Math.max(v.low,bottom+row*th),high=Math.min(v.high,bottom+(row+1)*th);if(high<=low)continue;for(let x=offset-o.w/2-(row%2?tw/2:0);x<=v.right;x+=tw){const left=Math.max(v.left,x-gap/2),right=Math.min(v.right,x+gap/2);if(right>left)seam(right-left,high-low,(left+right)/2,(low+high)/2)}}
 }finish(splash);
 if(o.kind==='sink'&&root.ResidentialRendering?.label){const g=detailGroup('backsplash-label');g.position.copy(splash.position);g.rotation.copy(splash.rotation);const sign=root.ResidentialRendering.label('SUBWAY TILE · 3 × 6 in',offset,top+.16,side*(w.thickness/2+.04),Math.min(1.25,o.w*1.6));if(sign){sign.raycast=()=>{};g.add(sign)}}
}
buildLandscape(p){
 const f=root.ResidentialRendering?.siteFloor(p)||p.floors.find(f=>f.elevation>=0)||p.floors[0],b=E.bounds(p,f.id),y=this.ground.position.y;
 this.sun.position.set(b.x-12,y+22,b.y+b.d+16);this.sun.target.position.set(b.x+b.w/2,y,b.y+b.d/2);this.scene.add(this.sun.target);this.sun.target.updateMatrixWorld();
 this.landscape.visible=p.site?.landscape!==false&&this.s?.landscape!==false;if(!this.landscape.visible)return;
 const driveway=E.siteDriveway(p);
 const signature=JSON.stringify([b,y,driveway]);if(signature===this.landscapeSignature)return;this.landscapeSignature=signature;
 this.landscape.traverse(o=>{o.geometry?.dispose();if(o.material)for(const m of Array.isArray(o.material)?o.material:[o.material]){if(m.userData?.ownsMap)m.map?.dispose();m.dispose()}});this.landscape.clear();
 const slab=this.box(this.landscape,driveway.w,.035,driveway.d,driveway.x+driveway.w/2,y+.018,driveway.y+driveway.d/2,'concrete');slab.userData.surface='driveway';
 for(const x of [driveway.x+.04,driveway.x+driveway.w-.04])this.box(this.landscape,.08,.09,driveway.d,x,y+.045,driveway.y+driveway.d/2,'stone');
 for(let z=driveway.y+2;z<driveway.y+driveway.d;z+=2)this.box(this.landscape,driveway.w-.15,.008,.012,driveway.x+driveway.w/2,y+.042,z,'charcoal');
 if(root.ResidentialRendering?.label){const sign=root.ResidentialRendering.label('DRIVEWAY',driveway.x+driveway.w/2,y+.05,driveway.y+driveway.d*.6,Math.min(3.2,driveway.w*.8),{surface:true});if(sign)this.landscape.add(sign)}
 this.box(this.landscape,1.2,.04,3,b.x+b.w*.45,y+.025,b.y+b.d+1.5,'stone');
 for(const [x,z,h]of [[b.x-4,b.y+2,4.5],[b.x+b.w+4,b.y+b.d-1,5],[b.x-2,b.y+b.d+7,3.8]]){
 const trunk=new T.Mesh(new T.CylinderGeometry(.12,.2,h*.58,9),this.material('walnut'));trunk.position.set(x,y+h*.29,z);trunk.castShadow=true;this.landscape.add(trunk);
 for(let i=0;i<5;i++){const leaf=new T.Mesh(new T.IcosahedronGeometry(h*.28,2),this.material(i%2?'#66854b':'#789557'));leaf.position.set(x+Math.sin(i*2.4)*.55,y+h*.68+(i%2)*.5,z+Math.cos(i*2.4)*.55);leaf.scale.set(1,1.15,.95);leaf.castShadow=leaf.receiveShadow=true;this.landscape.add(leaf)}
 }
}
focusObject(o,elevation){this.walk=false;this.target.set(o.x+o.w/2,elevation+o.z+o.h*.5,o.y+o.d/2);this.distance=Math.max(2.5,Math.max(o.w,o.h,o.d)*3)/Math.min(1,this.camera.aspect);this.theta=o.angle*Math.PI/180+Math.PI/2+.25;this.phi=1.22;this.setCamera()}
image(){this.render();return this.renderer.domElement.toDataURL('image/png')}
obj(){this.model.updateMatrixWorld(true);let lines=['# Nexora Architect model, units: meters'],offset=1;this.model.traverse(o=>{if(!o.isMesh||!o.geometry?.attributes.position)return;const g=o.geometry.index?o.geometry.toNonIndexed():o.geometry,arr=g.attributes.position;lines.push('o '+(o.userData.entity?.id||'part'));for(let i=0;i<arr.count;i++){let v=new T.Vector3().fromBufferAttribute(arr,i).applyMatrix4(o.matrixWorld);lines.push(`v ${v.x.toFixed(7)} ${v.y.toFixed(7)} ${v.z.toFixed(7)}`)}for(let i=0;i<arr.count;i+=3)lines.push(`f ${offset+i} ${offset+i+1} ${offset+i+2}`);offset+=arr.count;if(g!==o.geometry)g.dispose()});return lines.join('\n')}
}
root.BuildingView=BuildingView;
})(window);
