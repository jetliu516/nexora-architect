(function(root){
  'use strict';
  const IN=.0254, EPS=.0001;
  const widths=Array.from({length:14},(_,i)=>9+3*i);
  const names={base:'地柜',pantry:'Pantry 高柜',sink:'水槽柜',dishwasher:'洗碗机',range:'炉头',oven:'烤箱',fridge:'冰箱',upper:'上柜',corner:'角柜',filler:'Filler'};
  const defaults={base:24,pantry:24,sink:36,dishwasher:24,range:30,oven:30,fridge:36};
  const priority={sink:1,range:2,oven:2,fridge:3,dishwasher:4,pantry:5,base:6};
  const num=(v,name,min,max)=>{if(!Number.isFinite(v)||v<min||v>max)throw Error(name+'尺寸无效，请确认英寸数。');return v};
  const fmt=n=>Number(n.toFixed(3));
  const sku=(kind,w)=>({base:'B',upper:'W',pantry:'P',sink:'SB',corner:'COR',dishwasher:'DW',range:'R',oven:'OV',fridge:'REF',filler:'F'})[kind]+String(fmt(w)).padStart(2,'0');
  // Minimize the number of standard cabinets without turning a 3-8 in gap into a filler.
  function stock(span){
    const whole=Math.floor((span+EPS)/3)*3;
    if(whole<9)return [];
    const count=Math.ceil(whole/48);
    const parts=[];let remaining=whole;
    for(let i=count;i>0;i--){const w=Math.min(48,remaining-9*(i-1));parts.push(w);remaining-=w;}
    return parts;
  }
  function plan(spec){
    if(!Array.isArray(spec?.runs)||spec.runs.length<1||spec.runs.length>3)throw Error('请提供一至三段柜墙的长度和转向。');
    const corner=num(spec.cornerIn??36,'角柜',30,48);
    const turn=spec.turn??'right';
    if(!['left','right'].includes(turn))throw Error('请说明转向。');
    const rows=[],notes=[],runs=[],taken=new Set();
    const upper=spec.uppers!==false;
    if(spec.runs.length>1&&spec.cornerIn==null)notes.push('转角暂按 36″ × 36″ 占位。');
    if(upper)notes.push('上柜暂按 30″ 高、底边离地 54″；炉头上方预留。');
    const add=(run,level,kind,start,w,extra={})=>{
      const row={run,level,kind,label:names[kind],start:fmt(start),width:fmt(w),sku:sku(kind,w),...extra};
      rows.push(row);return row;
    };
    for(const [i,r] of spec.runs.entries()){
      const L=num(r.lengthIn,'第'+(i+1)+'段柜墙',9,600);
      const start=i?corner:0,end=i+1<spec.runs.length?L-corner:L;
      if(end<start-EPS)throw Error('第'+(i+1)+'段在预留角柜后短了 '+fmt(start-end)+' 英寸。');
      if(!r||!Array.isArray(r.items)||r.items.length>35)throw Error('请说明各段的设备与柜体顺序。');
      const windows=(r.windows||[]).map((win,k)=>{
        const w=num(win.widthIn,'窗宽',3,240),h=num(win.heightIn,'窗高',3,108),at=num(win.atIn,'窗位置',0,L);
        if(!['start','center','end'].includes(win.reference))throw Error('窗的位置量到窗左边、中心还是右边？');
        const left=at-({start:0,center:w/2,end:w})[win.reference];
        const sill=num(win.sillIn??42,'窗台高度',0,110);
        if(left<0||left+w>L+EPS)throw Error('第'+(i+1)+'段窗户超出墙端。');
        if(win.sillIn==null)notes.push('第'+(i+1)+'段窗台暂按 42″，待现场确认。');
        return {id:win.id||'window'+(k+1),start:left,width:w,height:h,sill};
      });
      if(new Set(windows.map(w=>w.id)).size!==windows.length)throw Error('同一段墙的窗户名称重复。');
      const items=r.items.map((item,k)=>{
        if(!Object.hasOwn(defaults,item.kind))throw Error('目前不能自动排这种构件，请说明设备或柜体类型。');
        const w=num(item.widthIn??defaults[item.kind],names[item.kind],3,96);
        if(['base','pantry','sink'].includes(item.kind)&&!widths.includes(w))throw Error(names[item.kind]+'宽度应使用 9″ 至 48″ 的三寸递增型号。');
        const id=item.id||'r'+i+'i'+k;if(taken.has(id))throw Error('柜体或设备标识重复。');taken.add(id);
        if(item.widthIn==null&&item.kind!=='pantry')notes.push(names[item.kind]+'暂按 '+w+'″。');
        let center=item.centerIn??null;
        if(center!=null)num(center,'设备中心',0,L);
        if(item.window){
          const win=windows.find(x=>x.id===item.window);if(!win)throw Error('请确认水槽对应的是哪扇窗。');
          const c=win.start+win.width/2;
          if(center!=null&&Math.abs(center-c)>EPS)throw Error('窗中心和指定设备中心相差 '+fmt(Math.abs(center-c))+'″，请确认保留哪个位置。');
          center=c;
        }
        for(const point of item.services||[]){
          if(!['water','drain','electric','gas'].includes(point.kind))throw Error('请说明接口类型。');
          const c=num(point.atIn,'接口中心',0,L);
          // Only an explicitly required alignment is a hard center constraint.
          if(point.align==='center'){
            if(center!=null&&Math.abs(center-c)>EPS)throw Error(names[item.kind]+'的指定中心与接口中心相差 '+fmt(Math.abs(center-c))+'″。');
            center=c;
          }
        }
        if(['sink','range','oven','fridge','dishwasher'].includes(item.kind)&&!item.services?.length)
          notes.push(names[item.kind]+'接口位置待现场确认。');
        return {...item,id,w,center,flex:item.kind==='pantry'&&item.widthIn==null};
      });
      // Find feasible ranges around fixed service points before distributing ordinary cabinets.
      const constraints=items.map(a=>{
        const w=a.flex?12:a.w,pts=(a.services||[]).map(v=>v.atIn);
        let lo=start,hi=end-w;
        if(a.center!=null)lo=hi=a.center-w/2;
        else if(pts.length){lo=Math.max(lo,Math.max(...pts)-w);hi=Math.min(hi,Math.min(...pts));}
        return {w,lo,hi,pts};
      });
      const pinned=items.map((a,k)=>({a,k})).filter(({a,k})=>a.center==null&&constraints[k].pts.length)
        .sort((x,y)=>priority[x.a.kind]-priority[y.a.kind]);
      for(const {a,k} of pinned){
        let next=start;const lower=constraints.map(c=>{const x=Math.max(next,c.lo);next=x+c.w;return x;});
        let prev=end;const upperBounds=Array(items.length);
        for(let j=items.length-1;j>=0;j--){const c=constraints[j];prev=Math.min(prev-c.w,c.hi);upperBounds[j]=prev;}
        const missing=lower[k]-upperBounds[k];
        if(missing>EPS)throw Error(names[a.kind]+'的接口与可用位置相差 '+fmt(missing)+'″，请确认接口位置或柜宽。');
        const c=constraints[k],mid=(Math.min(...c.pts)+Math.max(...c.pts))/2;
        const x=Math.max(lower[k],Math.min(upperBounds[k],mid-c.w/2));
        c.lo=c.hi=x;a.w=c.w;a.flex=false;a.center=x+c.w/2;
      }
      const anchored=items.map((a,k)=>({a,k})).filter(({a})=>a.center!=null)
        .sort((x,y)=>priority[x.a.kind]-priority[y.a.kind]);
      const fixed=[];
      for(const {a,k} of anchored){
        const x=a.center-a.w/2;
        if(x<start-EPS||x+a.w>end+EPS)throw Error(names[a.kind]+'与墙端或角柜冲突，差 '+fmt(Math.max(start-x,x+a.w-end))+'″。');
        for(const b of fixed){const overlap=Math.min(x+a.w,b.x+b.w)-Math.max(x,b.x);if(overlap>EPS)throw Error(names[a.kind]+'与固定的'+names[b.kind]+'重叠 '+fmt(overlap)+'″。');}
        fixed.push({k,x,w:a.w,kind:a.kind});
      }
      function fillGap(a,b,level){
        if(b-a<EPS)return;
        const parts=stock(b-a),rem=b-a-parts.reduce((n,x)=>n+x,0);
        const wallStart=a<EPS&&(r.startWall===true),wallEnd=Math.abs(b-L)<EPS&&(r.endWall===true);
        const atStart=wallStart&&!wallEnd;let cursor=a;
        const remainder=()=>{
          if(rem<EPS)return;
          if(rem<3-EPS&&(wallStart||wallEnd)){add(i,level,'filler',cursor,rem); }
          else notes.push('第'+(i+1)+'段'+(level==='upper'?'上柜':'底柜')+' '+fmt(cursor)+'″ 处留 '+fmt(rem)+'″，'+(rem<3?'需确认靠墙端才能放 filler。':'不足 B09/W09 或有固定设备，需调整分配。'));
          cursor+=rem;
        };
        if(atStart)remainder();
        for(const w of parts){add(i,level,level==='upper'?'upper':'base',cursor,w);cursor+=w}
        if(!atStart)remainder();
      }
      function place(a,x){
        if(a.services?.some(v=>v.align!=='center'&&(v.atIn<x-EPS||v.atIn>x+a.w+EPS)))throw Error(names[a.kind]+'未覆盖指定接口，请确认设备或接口位置。');
        add(i,'base',a.kind,x,a.w,{id:a.id,services:a.services||[]});
      }
      // Resolve order between fixed points. Compact toward the next anchor, or from the previous one.
      let cursor=start,index=0;
      function between(stop,until,anchoredEnd){
        const group=items.slice(index,until);
        let space=stop-cursor;
        const flex=group.filter(q=>q.flex);
        for(const q of flex)q.w=12;
        const need=group.reduce((n,q)=>n+q.w,0);
        if(need>space+EPS)throw Error('第'+(i+1)+'段固定位置之间还差 '+fmt(need-space)+'″。请调整设备宽度、位置或顺序。');
        for(const q of flex){const grow=Math.min(24,Math.floor((space-group.reduce((n,x)=>n+x.w,0)+EPS)/3)*3);q.w+=Math.max(0,grow);}
        const used=group.reduce((n,q)=>n+q.w,0);
        const left=anchoredEnd?stop-used:cursor;
        fillGap(cursor,left,'base');
        let pos=left;for(const q of group){place(q,pos);pos+=q.w;}
        fillGap(pos,stop,'base');
      }
      for(const f of fixed.sort((a,b)=>a.k-b.k)){
        between(f.x,f.k,true);place(items[f.k],f.x);cursor=f.x+f.w;index=f.k+1;
      }
      between(end,items.length,false);
      if(i<spec.runs.length-1)add(i,'base','corner',end,corner);
      const current=rows.filter(a=>a.run===i&&a.level==='base');
      for(const win of windows)for(const a of current){
        const h=['pantry','fridge','oven'].includes(a.kind)?84:36;
        if(a.start<win.start+win.width-EPS&&a.start+a.width>win.start+EPS&&h>win.sill+EPS)
          throw Error(names[a.kind]+'遮挡窗户，请调整窗台或设备位置。');
      }
      if(upper){
        const blocked=[...windows.map(w=>[w.start,w.start+w.width]),...current.filter(a=>['pantry','range','oven','fridge'].includes(a.kind)).map(a=>[a.start,a.start+a.width])].sort((a,b)=>a[0]-b[0]);
        let x=start;
        for(const [a,b] of blocked){if(a>x)fillGap(x,Math.min(a,end),'upper');x=Math.max(x,b);}
        if(x<end)fillGap(x,end,'upper');
      }
      runs.push({length:L,start,end,windows});
    }
    if(runs.length===3&&runs[1].length<2*24+EPS)throw Error('两排柜体相交，请增加中间墙段长度。');
    return {runs,rows,notes:[...new Set(notes)],turn,corner};
  }
  function build(spec,E){
    const layout=plan(spec),p=E.newProject('口述厨房 · '+['一字形','L 形','U 形'][layout.runs.length-1]),floor=p.floors[0].id;
    p.unit='ft';p.kitchenBrief=JSON.parse(JSON.stringify(spec));p.kitchenNotes=layout.notes;
    const side=layout.turn==='right'?1:-1;
    const dirs=[[1,0],[0,side],[-1,0]],norms=dirs.map(([dx,dy])=>[-dy*side,dx*side]);
    let origin=[0,0];const half=2.25;
    layout.runs.forEach((r,i)=>{
      const [dx,dy]=dirs[i],[nx,ny]=norms[i],end=[origin[0]+dx*r.length,origin[1]+dy*r.length];
      const xy=(at,depth)=>({x:(origin[0]+dx*at+nx*depth)*IN,y:(origin[1]+dy*at+ny*depth)*IN});
      const lead=i?half:0,tail=i<layout.runs.length-1?half:0;
      const w=E.wall(p,xy(-lead,-half),xy(r.length+tail,-half),floor,'interior');w.thickness=2*half*IN;
      for(const win of r.windows){
        const o={id:E.uid(),wall:w.id,kind:'window',offset:(win.start+lead)*IN,width:win.width*IN,height:win.height*IN,sill:win.sill*IN,style:'double',flip:false};
        E.validateOpening(p,o);p.openings.push(o);
      }
      for(const row of layout.rows.filter(a=>a.run===i)){
        const kind={base:'baseCabinet',upper:'wallCabinet',sink:'sink',range:'stove',oven:'ovenUnit',pantry:'tallCabinet',fridge:'fridge',dishwasher:'dishwasher',corner:'cornerUnit',filler:'cabinetFiller'}[row.kind];
        const depth=row.kind==='corner'?row.width:row.level==='upper'?12:row.kind==='fridge'?30:24;
        const height=row.level==='upper'?30:['pantry','oven'].includes(row.kind)?84:row.kind==='fridge'?72:row.kind==='dishwasher'?34.5:36;
        const mid=xy(row.start+row.width/2,depth/2);
        const obj=E.object(p,kind,0,0,floor);
        Object.assign(obj,{x:mid.x-row.width*IN/2,y:mid.y-depth*IN/2,w:row.width*IN,d:depth*IN,h:height*IN,z:row.level==='upper'?54*IN:0,angle:Math.atan2(dy,dx)*180/Math.PI+(side<0?180:0),kitchenSku:row.sku,cornerMirror:side<0});
        if(obj.cabinet){obj.cabinet.overhang=0;if(obj.kind==='tallCabinet')obj.cabinet.countertop=false;}
      }
      origin=end;
    });
    return {project:E.validate(p),layout};
  }
  const sample={turn:'right',uppers:true,runs:[
    {lengthIn:120,startWall:true,windows:[{id:'win',atIn:48,reference:'start',widthIn:36,heightIn:24}],
      items:[{kind:'pantry'},{kind:'dishwasher',widthIn:24},{kind:'sink',widthIn:36,window:'win'}]},
    {lengthIn:144,endWall:true,items:[{kind:'range',widthIn:30},{kind:'fridge',widthIn:36}]}]};
  const api={widths,plan,build,sample};
  root.KitchenLayout=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
