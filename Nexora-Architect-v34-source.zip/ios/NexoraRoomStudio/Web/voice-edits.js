(function(root){
  'use strict';
  function createBridge({state,transact,undo,BIM,Cabinets}){
    let inspected=null,lastEdit=null;
    const units={mm:.001,cm:.01,m:1,in:.0254,ft:.3048};
    const directions={left:[-1,0],right:[1,0],up:[0,-1],down:[0,1]};
    const cabinet=e=>Cabinets.isCabinet(e)||e?.kind==='wardrobe';
    const entityFloor=s=>s.selectionType==='opening'?s.project.walls.find(w=>w.id===s.entity?.wall)?.floor:s.entity?.floor;
    const token=s=>({projectId:s.project.id,project:s.project,floorId:s.floorId,revision:s.selectionRevision,fingerprint:JSON.stringify(s.project)});
    function current(t,s,selection=true){return t&& !s.busy&&t.projectId===s.project.id&&t.project===s.project&&t.floorId===s.floorId&&t.fingerprint===JSON.stringify(s.project)&&(!selection||t.revision===s.selectionRevision&&t.id===s.entity?.id&&entityFloor(s)===s.floorId);}
    function facts(s){const e=s.entity;
      if(s.selectionType==='wall')return {kind:'wall',thicknessM:e.thickness,lengthM:BIM.dist(e.a,e.b)};
      if(s.selectionType==='opening')return {kind:e.kind,style:e.style,hostWall:e.wall,widthM:e.width,heightM:e.height,sillM:e.sill,offsetM:e.offset,openAngle:e.openAngle,openRatio:e.openRatio,hingeRight:e.hingeRight,flip:e.flip,projectionM:e.projection,recessDepthM:e.recessDepth};
      return {kind:'cabinet',name:BIM.catalog[e.kind].label,xM:e.x,yM:e.y};
    }
    function selected(){const s=state(),kind=s.selectionType;
      if(s.busy||!s.entity||entityFloor(s)!==s.floorId||!(kind==='wall'||kind==='opening'||kind==='object'&&cabinet(s.entity))){inspected=null;return {ok:false,message:s.busy?'请先结束当前拖动操作。':'请在当前楼层点选一面墙、一个门窗或一个柜子。'};}
      inspected={...token(s),id:s.entity.id};return {ok:true,target:s.entity.id,...facts(s)};
    }
    function ready(args){const s=state();return args&&current(inspected,s)&&inspected.id===args.target?s:null;}
    const stale=()=>({ok:false,message:'选择或图纸已经改变，请重新查看当前选择再修改。'});
    function apply(s,fn,action){const before=facts(s);let failure;
      const ok=transact(fn,'已应用 AI 修改 · 可撤销',err=>failure=err.message);
      inspected=null;
      if(!ok)return {ok:false,message:failure||'图纸校验或保存未通过，修改未应用。'};
      const now=state();lastEdit={...token(now),selectionType:s.selectionType,target:s.entity.id};
      return {ok:true,action,before,after:facts(now),unit:'m'};
    }
    function edit(args){const s=ready(args);if(!s)return stale();
      const factor=Object.hasOwn(units,args.unit)&&units[args.unit];
      if(!factor||!Number.isFinite(args.amount)||!args.amount)return {ok:false,message:'请说明数值和单位。'};
      const e=s.entity,meters=args.amount*factor,isWall=s.selectionType==='wall',moving=args.action==='move_cabinet',thickness=args.action==='wall_thickness';
      if(moving?!(s.selectionType==='object'&&cabinet(e))||!Object.hasOwn(directions,args.direction)||meters<=0:!isWall||(!thickness&&args.action!=='wall_length')||!['set','change'].includes(args.mode))return {ok:false,message:'对象、方向或尺寸含义不明确，请确认后再修改。'};
      return apply(s,()=>{if(moving){const [dx,dy]=directions[args.direction];e.x+=dx*meters;e.y+=dy*meters;}else{const before=thickness?e.thickness:BIM.dist(e.a,e.b),after=args.mode==='change'?before+meters:meters;if(after===before)throw Error('尺寸已经相同。');if(after<=0)throw Error('尺寸必须大于零。');if(thickness)e.thickness=after;else BIM.moveNode(s.project,s.floorId,e.b,BIM.add(e.a,BIM.mul(BIM.sub(e.b,e.a),after/before)));}},args.action);
    }
    function editOpening(args){const s=ready(args);if(!s)return stale();if(s.selectionType!=='opening')return {ok:false,message:'请先选中要修改的门窗或壁龛。'};
      const changes=args.changes,allowed=['width','height','sill','offset','projection','recessDepth','openAngle','openRatio','style','flip','hingeRight'],dim=['width','height','sill','offset','projection','recessDepth'];
      if(!changes||typeof changes!=='object'||Array.isArray(changes)||!Object.keys(changes).length||Object.keys(changes).some(k=>!allowed.includes(k)))return {ok:false,message:'门窗修改参数无效。'};
      if(Object.keys(changes).some(k=>dim.includes(k))&&!Object.hasOwn(units,args.unit))return {ok:false,message:'尺寸修改需要明确单位。'};
      const e=s.entity,O=root.Openings||(typeof require==='function'?require('./openings.js'):null);
      return apply(s,()=>{for(const [key,value]of Object.entries(changes)){
        if(key==='style'){if(!O.types[value])throw Error('门窗样式无效');e.style=value;e.kind=O.types[value].kind;}
        else if(['flip','hingeRight'].includes(key)){if(typeof value!=='boolean')throw Error('门窗方向无效');e[key]=value;}
        else{if(!Number.isFinite(value))throw Error('门窗尺寸必须是有限数值');e[key]=value*(dim.includes(key)?units[args.unit]:1);}
      }},'edit_opening');
    }
    function undoVoice(){const s=state();if(!current(lastEdit,s,false))return {ok:false,message:'最近一步或楼层已改变，无法单独撤销这次 AI 操作。'};
      try{if(undo(lastEdit.selectionType,lastEdit.target)!==true)return {ok:false,message:'撤销未成功，请检查图层锁定和保存状态后重试。'};}catch(e){return {ok:false,message:e.message||'撤销未成功。'};}
      lastEdit=null;inspected=null;return {ok:true,message:'上一次 AI 修改已撤销。'};
    }
    return {inspect_selection:selected,edit_selection:edit,edit_opening:editOpening,undo_voice_edit:undoVoice};
  }
  root.ArchitectVoiceEdits={createBridge};if(typeof module!=='undefined')module.exports=root.ArchitectVoiceEdits;
})(typeof window==='undefined'?globalThis:window);
