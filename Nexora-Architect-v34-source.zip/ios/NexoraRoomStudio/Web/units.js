(function (root) {
  "use strict";
  const FT = 0.3048,
    IN = 0.0254,
    SQFT = 1 / (FT * FT),
    CUFT = 1 / (FT * FT * FT);
  function length(m, unit = "m", digits = 2) {
    if (unit !== "ft") return Number(m).toFixed(digits) + " m";
    const sign = m < 0 ? "-" : "",
      ticks = Math.round((Math.abs(m) / IN) * 16),
      feet = Math.floor(ticks / 192),
      remainder = ticks % 192,
      inches = Math.floor(remainder / 16),
      fraction = remainder % 16;
    let den = 16,
      num = fraction;
    while (num && num % 2 === 0) {
      num /= 2;
      den /= 2;
    }
    return (
      sign + feet + "′ " + inches + (num ? " " + num + "/" + den : "") + "″"
    );
  }
  function parse(text, unit = "m") {
    const s = String(text)
      .trim()
      .toLowerCase()
      .replace(/[′’]/g, "'")
      .replace(/[″”]/g, '"');
    const metric = s.match(/^([+-]?(?:\d+\.?\d*|\.\d+))\s*(mm|cm|m)$/);
    if (metric) return +metric[1] * { mm: 0.001, cm: 0.01, m: 1 }[metric[2]];
    if (/^[+-]?(?:\d+\.?\d*|\.\d+)$/.test(s))
      return Number(s) * (unit === "ft" ? FT : 1);
    const feet = s.match(
      /^(-)?(?:(\d+(?:\.\d+)?)\s*(?:'|ft|feet)\s*)?(?:(\d+(?:\.\d+)?)\s*)?(?:(\d+)\s*\/\s*(\d+)\s*)?(?:"|in|inches)?$/,
    );
    if (
      !feet ||
      (!feet[2] && !feet[3] && !feet[4]) ||
      (feet[4] && +feet[5] === 0)
    )
      throw Error("尺寸格式无效。示例：2.5 m、2500 mm、8′ 2 1/2″。");
    const result =
      (+(feet[2] || 0) * FT +
        (+(feet[3] || 0) + (feet[4] ? +feet[4] / +feet[5] : 0)) * IN) *
      (feet[1] ? -1 : 1);
    if (!Number.isFinite(result)) throw Error("尺寸必须为有限数值");
    return result;
  }
  const area = (v, u = "m", digits = 2) =>
    (v * (u === "ft" ? SQFT : 1)).toLocaleString("en-US", {minimumFractionDigits:digits,maximumFractionDigits:digits}) +
    (u === "ft" ? " sq ft" : " m²");
  const volume = (v, u = "m", digits = 2) =>
    (v * (u === "ft" ? CUFT : 1)).toFixed(digits) +
    (u === "ft" ? " cu ft" : " m³");
  const quantity = (v, kind, u = "m") =>
    v *
    (u === "ft"
      ? kind === "m²"
        ? SQFT
        : kind === "m³"
          ? CUFT
          : kind === "m"
            ? 1 / FT
            : 1
      : 1);
  const label = (kind, u = "m") =>
    u === "ft" ? { m: "ft", "m²": "ft²", "m³": "ft³" }[kind] || kind : kind;
  root.Units = {
    FT,
    IN,
    SQFT,
    CUFT,
    length,
    parse,
    area,
    volume,
    quantity,
    label,
  };
  if (typeof module !== "undefined") module.exports = root.Units;
})(typeof window !== "undefined" ? window : globalThis);
