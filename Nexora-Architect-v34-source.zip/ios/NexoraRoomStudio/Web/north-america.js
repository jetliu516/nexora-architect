(function (root) {
  'use strict';
  const E = root.BIM || (typeof require === 'function' ? require('./geometry.js') : null);
  const C = root.Cabinets || (typeof require === 'function' ? require('./cabinets.js') : null);
  const FT = .3048, SQFT = 1 / (FT * FT), inch = FT / 12;
  const m = v => Math.round(v * FT * 1e6) / 1e6;
  const escape = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  // Original schematic plans. Coordinates below are feet; BIM stores meters.
  // No vendor plans, symbols or models are embedded in this library.
  const room = (name, x, y, w, d, role = 'living', extra = {}) => ({ name, x, y, w, d, role, ...extra });
  const hall = (name, x, y, w, d, stairCore = false) => room(name, x, y, w, d, 'hall', { stairCore });
  const garage = (x, y) => room('Garage', x, y, 22, 22, 'garage');
  const privateBath = (x, y, w, d) => room('Primary Bathroom', x, y, w, d, 'bath', { ensuite: true });
  const ranchRooms = (width, left, kitchen, bedroom2) => [
    room('Primary Bedroom', 0, 0, 18, 14, 'bedroom'), privateBath(18, 0, 10, 7),
    room('Bathroom', 18, 7, 10, 7, 'bath'), room('Bedroom 2', 28, 0, bedroom2, 14, 'bedroom'),
    room('Bedroom 3', 28 + bedroom2, 0, width - 28 - bedroom2, 14, 'bedroom'),
    hall('Hall', 0, 14, width, 5), room('Living Room', 0, 19, left, 13),
    room('Kitchen', left, 19, kitchen, 13, 'kitchen'),
    room('Dining Room', left + kitchen, 19, width - left - kitchen, 13, 'dining')
  ];
  function basement(width, depth, coreX) {
    return { name: 'Basement', basement: true, rooms: [
      room('Unfinished Basement', 0, 0, coreX, depth, 'storage'),
      hall('Basement Stair Hall', coreX, 0, 12, 18, true),
      hall('Basement Storage', coreX, 18, 12, depth - 18),
      room('Mechanical Room', coreX + 12, 0, width - coreX - 12, depth, 'storage')
    ], stair: [coreX + 1, 4.5] };
  }
  const basePlans = [
    {
      id: 'NA-RANCH', name: 'Ranch', tagline: 'Single level living with a private bedroom wing', wall: 'white', floor: 'oak', bedrooms: 3,
      levels: [{ name: 'Main Floor', rooms: ranchRooms(60, 26, 18, 16).map(c => c.y === 19 ? { ...c, d: 15 } : c).concat(garage(60, 12)) }],
      links: [[0, 'Primary Bedroom', 'Primary Bathroom'], [0, 'Living Room', 'Kitchen', 6], [0, 'Kitchen', 'Dining Room', 6], [0, 'Hall', 'Garage']],
      exterior: [[0, 'Living Room', 'south', 13, 3, 'hinged', 'entry'], [0, 'Dining Room', 'south', 52, 6, 'sliding', 'deck'], [0, 'Garage', 'south', 71, 16, 'garage']],
      outdoor: [['Front Porch', 5, 34, 16, 8], ['Deck', 44, 34, 16, 10]],
      roofs: [[0, 0, 0, 60, 34, 'gable', 18.435], [0, 60, 12, 22, 22, 'gable', 18.435], [0, 5, 34, 16, 8, 'shed', 10]],
      driveway: [61, 34, 20, 23]
    },
    {
      id: 'NA-COLONIAL', name: 'Colonial', tagline: 'Two balanced stories and an unfinished basement', wall: 'white', floor: 'oak', bedrooms: 3,
      levels: [
        { name: 'Main Floor', rooms: [room('Kitchen', 0, 0, 13, 18, 'kitchen'), hall('Stair Hall', 13, 0, 12, 18, true), room('Dining Room', 25, 0, 13, 11, 'dining'), room('Powder Room', 25, 11, 13, 7, 'powder'), room('Living Room', 0, 18, 13, 14), hall('Foyer', 13, 18, 12, 14), room('Family Room', 25, 18, 13, 14), garage(-22, 10)], stair: [14, 4.5] },
        { name: 'Second Floor', rooms: [room('Primary Bedroom', 0, 0, 13, 18, 'bedroom'), hall('Landing', 13, 0, 12, 18, true), room('Bedroom 2', 25, 0, 13, 18, 'bedroom'), room('Bedroom 3', 0, 18, 13, 14, 'bedroom'), hall('Upper Hall', 13, 18, 12, 14), room('Bathroom', 25, 18, 13, 8, 'bath'), room('Laundry', 25, 26, 13, 6, 'laundry')] },
        basement(38, 32, 13)
      ],
      links: [[0, 'Kitchen', 'Garage']],
      exterior: [[0, 'Foyer', 'south', 19, 3, 'hinged', 'entry'], [0, 'Family Room', 'south', 31.5, 6, 'sliding', 'deck'], [0, 'Garage', 'south', -11, 16, 'garage']],
      outdoor: [['Front Porch', 13, 32, 12, 7], ['Deck', 25, 32, 13, 10]],
      roofs: [[1, 0, 0, 38, 32, 'gable', 35], [0, -22, 10, 22, 22, 'gable', 18.435], [0, 13, 32, 12, 7, 'shed', 10]],
      driveway: [-21, 32, 20, 23]
    },
    {
      id: 'NA-CRAFTSMAN', name: 'Craftsman', tagline: 'An L shaped home with a family room, deep porch and deck', wall: 'sage', floor: 'oak', bedrooms: 3,
      levels: [{ name: 'Main Floor', rooms: ranchRooms(52, 24, 16, 12).concat(room('Family Room', 0, 32, 24, 12), garage(52, 10)) }],
      links: [[0, 'Primary Bedroom', 'Primary Bathroom'], [0, 'Living Room', 'Kitchen', 6], [0, 'Kitchen', 'Dining Room', 5], [0, 'Living Room', 'Family Room', 6], [0, 'Hall', 'Garage']],
      exterior: [[0, 'Dining Room', 'south', 46, 3, 'hinged', 'entry'], [0, 'Family Room', 'south', 12, 6, 'sliding', 'deck'], [0, 'Garage', 'south', 63, 16, 'garage']],
      outdoor: [['Front Porch', 24, 32, 28, 8], ['Deck', 0, 44, 24, 10]],
      roofs: [[0, 0, 0, 52, 32, 'gable', 22.62], [0, 0, 32, 24, 12, 'gable', 22.62], [0, 52, 10, 22, 22, 'gable', 22.62], [0, 24, 32, 28, 8, 'shed', 10]],
      driveway: [53, 32, 20, 23]
    },
    {
      id: 'NA-FARMHOUSE', name: 'Modern Farmhouse', tagline: 'Main floor primary suite, upstairs bedrooms and a full width porch', wall: 'white', floor: 'oak', bedrooms: 3,
      levels: [
        { name: 'Main Floor', rooms: [room('Kitchen', 0, 0, 14, 10, 'kitchen'), privateBath(0, 10, 14, 8), room('Primary Bedroom', 0, 18, 14, 14, 'bedroom', { wardrobeWidth: 4.5 }), hall('Stair Hall', 14, 0, 12, 18, true), hall('Foyer', 14, 18, 12, 14), room('Dining Room', 26, 0, 18, 18, 'dining'), room('Living Room', 26, 18, 18, 14), garage(-22, 0)], stair: [15, 4.5] },
        { name: 'Second Floor', rooms: [room('Bathroom', 0, 0, 14, 8, 'bath'), room('Bedroom 2', 0, 8, 14, 16, 'bedroom'), hall('Landing', 14, 0, 12, 24, true), room('Study', 26, 0, 18, 8, 'study'), room('Bedroom 3', 26, 8, 18, 16, 'bedroom')] },
        basement(44, 32, 14)
      ],
      links: [[0, 'Primary Bedroom', 'Primary Bathroom'], [0, 'Kitchen', 'Garage']],
      exterior: [[0, 'Foyer', 'south', 20, 3, 'hinged', 'entry'], [0, 'Dining Room', 'east', 9, 6, 'sliding', 'deck'], [0, 'Garage', 'south', -11, 16, 'garage']],
      outdoor: [['Front Porch', 0, 32, 44, 8], ['Deck', 44, 0, 12, 18]],
      roofs: [[1, 0, 0, 44, 24, 'gable', 40], [0, 0, 24, 44, 8, 'shed', 10], [0, -22, 0, 22, 22, 'gable', 22.62], [0, 0, 32, 44, 8, 'shed', 10]],
      driveway: [-21, 22, 20, 25]
    },
    {
      id: 'NA-CONTEMPORARY', name: 'Contemporary', tagline: 'Offset upper story, broad glazing and a connected outdoor living deck', wall: 'concrete', floor: 'walnut', bedrooms: 3,
      levels: [
        { name: 'Main Floor', rooms: [room('Bathroom', 0, 0, 15, 7, 'bath'), room('Kitchen', 0, 7, 15, 11, 'kitchen'), hall('Stair Hall', 15, 0, 12, 18, true), room('Dining Room', 27, 0, 15, 18, 'dining'), room('Breakfast Room', 0, 18, 15, 12, 'dining'), hall('Foyer', 15, 18, 12, 12), room('Living Room', 27, 18, 15, 12), garage(42, 8)], stair: [16, 4.5] },
        { name: 'Second Floor', rooms: [room('Bedroom 2', 4, 0, 11, 13, 'bedroom'), room('Bedroom 3', 4, 13, 11, 13, 'bedroom'), hall('Landing', 15, 0, 12, 26, true), room('Primary Bedroom', 27, 0, 15, 16, 'bedroom'), room('Bathroom', 27, 16, 15, 10, 'bath')] }
      ],
      links: [[0, 'Kitchen', 'Breakfast Room', 5], [0, 'Dining Room', 'Garage']],
      exterior: [[0, 'Foyer', 'south', 21, 3, 'hinged', 'entry'], [0, 'Living Room', 'south', 34.5, 6, 'sliding', 'deck'], [0, 'Garage', 'south', 53, 16, 'garage']],
      outdoor: [['Front Porch', 15, 30, 12, 6], ['Deck', 27, 30, 15, 12]],
      roofs: [[1, 4, 0, 38, 26, 'shed', 7], [0, 0, 0, 4, 26, 'flat', 0], [0, 0, 26, 42, 4, 'flat', 0], [0, 42, 8, 22, 22, 'flat', 0], [0, 15, 30, 12, 6, 'flat', 0]],
      driveway: [43, 30, 20, 23]
    }
  ];
  const clone = value => JSON.parse(JSON.stringify(value));
  function replaceRoom(t, index, name, replacement) {
    const rooms = t.levels[index].rooms, at = rooms.findIndex(c => c.name === name);
    if (at < 0) throw Error('Missing configuration room: ' + name);
    rooms.splice(at, 1, ...replacement);
  }
  function renameRoom(t, index, from, to, role) {
    const c = t.levels[index].rooms.find(c => c.name === from);
    c.name = to; if (role) c.role = role;
    for (const link of t.links) if (link[0] === index) for (const i of [1, 2]) if (link[i] === from) link[i] = to;
    for (const e of t.exterior) if (e[0] === index && e[1] === from) e[1] = to;
  }
  function configure(base, program) {
    const t = clone(base);
    if (base.id === 'NA-RANCH') {
      if (program === 1) replaceRoom(t, 0, 'Bedroom 3', [room('Home Office', 44, 0, 10, 14, 'study'), room('Laundry', 54, 0, 6, 14, 'laundry')]);
      if (program === 2) {
        replaceRoom(t, 0, 'Living Room', [room('Bedroom 4', 0, 19, 12, 15, 'bedroom'), room('Living Room', 12, 19, 14, 15)]);
        t.exterior.find(e => e[6] === 'entry')[3] = 19;
        t.outdoor[0] = ['Front Porch', 14, 34, 12, 8]; t.roofs[t.roofs.length - 1].splice(1, 4, 14, 34, 12, 8);
      }
      if (program === 3) {
        replaceRoom(t, 0, 'Kitchen', [room('Kitchen', 26, 19, 18, 9, 'kitchen', { noHallDoor: true, kitchenRun: 'north' }), room('Pantry', 26, 28, 8, 6, 'pantry'), room('Laundry', 34, 28, 10, 6, 'laundry')]);
        t.links = t.links.filter(link => !(link.includes('Kitchen') && link.includes('Dining Room')));
        t.links.push([0, 'Kitchen', 'Pantry'], [0, 'Kitchen', 'Laundry']);
      }
    }
    if (base.id === 'NA-COLONIAL') {
      if (program === 1) {
        replaceRoom(t, 1, 'Bedroom 3', [room('Home Office', 0, 18, 13, 8, 'study'), room('Utility Storage', 0, 26, 13, 6, 'closet')]);
      }
      if (program === 2) {
        renameRoom(t, 0, 'Living Room', 'Bedroom 4', 'bedroom'); renameRoom(t, 0, 'Family Room', 'Living Room', 'living');
        replaceRoom(t, 0, 'Kitchen', [room('Kitchen', 0, 0, 13, 12, 'kitchen'), room('Mudroom', 0, 12, 13, 6, 'mudroom')]);
        t.links = [[0, 'Kitchen', 'Mudroom'], [0, 'Mudroom', 'Garage']];
      }
      if (program === 3) {
        replaceRoom(t, 1, 'Primary Bedroom', [room('Primary Bedroom', 0, 0, 13, 12, 'bedroom', { hasCloset: true }), room('Walk-in Closet', 0, 12, 13, 6, 'closet', { ensuite: true })]);
        replaceRoom(t, 1, 'Bedroom 3', [privateBath(0, 18, 13, 8), room('Dressing Room', 0, 26, 13, 6, 'closet')]);
        t.links.push([1, 'Primary Bedroom', 'Walk-in Closet'], [1, 'Walk-in Closet', 'Primary Bathroom']);
      }
    }
    if (base.id === 'NA-CRAFTSMAN') {
      if (program === 1) {
        renameRoom(t, 0, 'Bedroom 3', 'Home Office', 'study');
        replaceRoom(t, 0, 'Family Room', [room('Family Room', 0, 32, 18, 12), room('Laundry', 18, 32, 6, 12, 'laundry')]);
        t.links.push([0, 'Living Room', 'Laundry']);
      }
      if (program === 2) {
        replaceRoom(t, 0, 'Family Room', [room('Bedroom 4', 0, 32, 12, 12, 'bedroom', { wardrobeWidth: 3.5 }), room('Family Room', 12, 32, 12, 12, 'living', { sofaWidth: 5.5, coffeeWidth: 2.5 })]);
        t.links.push([0, 'Living Room', 'Bedroom 4']); t.exterior.find(e => e[6] === 'deck')[3] = 18;
      }
      if (program === 3) {
        replaceRoom(t, 0, 'Kitchen', [room('Kitchen', 24, 19, 16, 7, 'kitchen', { noHallDoor: true, cabinetWidth: 2, kitchenRun: 'north' }), room('Pantry', 24, 26, 8, 6, 'pantry'), room('Laundry', 32, 26, 8, 6, 'laundry')]);
        t.links = t.links.filter(link => !(link.includes('Kitchen') && link.includes('Dining Room')));
        t.links.push([0, 'Kitchen', 'Pantry'], [0, 'Kitchen', 'Laundry']);
      }
    }
    if (base.id === 'NA-FARMHOUSE') {
      if (program === 1) {
        replaceRoom(t, 1, 'Bedroom 3', [room('Home Office', 26, 8, 18, 10, 'study'), room('Laundry', 26, 18, 18, 6, 'laundry')]);
        renameRoom(t, 1, 'Study', 'Hobby Room', 'study');
      }
      if (program === 2) {
        replaceRoom(t, 1, 'Study', [room('Bedroom 3', 26, 0, 18, 12, 'bedroom')]);
        const duplicate = t.levels[1].rooms.findIndex(c => c.name === 'Bedroom 3' && c.y === 8);
        t.levels[1].rooms.splice(duplicate, 1, room('Bedroom 4', 26, 12, 18, 12, 'bedroom'));
      }
      if (program === 3) {
        replaceRoom(t, 0, 'Dining Room', [room('Dining Room', 26, 0, 18, 12, 'dining'), room('Laundry', 26, 12, 9, 6, 'laundry'), room('Pantry', 35, 12, 9, 6, 'pantry')]);
        replaceRoom(t, 1, 'Study', [room('Home Office', 26, 0, 11, 8, 'study'), room('Walk-in Closet', 37, 0, 7, 8, 'closet', { ensuite: true })]);
        t.links.push([0, 'Dining Room', 'Pantry'], [1, 'Bedroom 3', 'Walk-in Closet']);
      }
    }
    if (base.id === 'NA-CONTEMPORARY') {
      if (program === 1) replaceRoom(t, 1, 'Bedroom 3', [room('Home Office', 4, 13, 11, 8, 'study'), room('Laundry', 4, 21, 11, 5, 'laundry')]);
      if (program === 2) {
        replaceRoom(t, 0, 'Breakfast Room', [room('Laundry', 0, 18, 5, 12, 'laundry'), room('Bedroom 4', 5, 18, 10, 12, 'bedroom', { wardrobeWidth: 3.5 })]);
        t.links = t.links.filter(link => !link.includes('Breakfast Room'));
        t.links.push([0, 'Kitchen', 'Laundry']);
        // Shift the stair flights to create a clear west circulation passage to the kitchen.
        t.levels[0].stair[0] = 19;
      }
      if (program === 3) {
        replaceRoom(t, 0, 'Breakfast Room', [room('Laundry', 0, 18, 7.5, 12, 'laundry'), room('Breakfast Room', 7.5, 18, 7.5, 12, 'dining')]);
        replaceRoom(t, 1, 'Primary Bedroom', [room('Primary Bedroom', 27, 0, 15, 11, 'bedroom', { hasCloset: true }), room('Walk-in Closet', 27, 11, 15, 5, 'closet', { ensuite: true })]);
        t.links.push([0, 'Kitchen', 'Laundry'], [1, 'Primary Bedroom', 'Walk-in Closet']);
      }
    }
    return t;
  }
  const sizes = [
    { left: 0, right: 0, front: 0, garageW: 22, garageD: 22, garageY: 0 },
    { left: 1, right: 0, front: 1, garageW: 24, garageD: 22, garageY: 1 },
    { left: 0, right: 2, front: 0, garageW: 22, garageD: 24, garageY: 0 },
    { left: 2, right: 0, front: 1, garageW: 20, garageD: 22, garageY: 2 },
    { left: 1, right: 1, front: 2, garageW: 24, garageD: 24, garageY: -1 }
  ];
  const sizeBands = [[18, 44, 60, 19, 34], [13, 25, 38, 18, 32], [18, 40, 52, 19, 32], [14, 26, 44, 18, 32], [15, 27, 42, 18, 30]];
  const programs = ['Family Living', 'Work from Home', 'Four Bedroom', 'Suite and Utility'];
  function sizePlan(t, styleIndex, sizeIndex) {
    const s = sizes[sizeIndex], [left, right, width, front, depth] = sizeBands[styleIndex];
    const grow = (n, a, b, amount) => amount * Math.max(0, Math.min(1, (n - a) / (b - a)));
    const X = n => n + grow(n, 0, left, s.left) + grow(n, right, width, s.right), Y = n => n + grow(n, front, depth, s.front);
    const resize = c => { const x = X(c.x), y = Y(c.y); c.w = X(c.x + c.w) - x; c.d = Y(c.y + c.d) - y; c.x = x; c.y = y; };
    for (const l of t.levels) { l.rooms.forEach(resize); if (l.stair) l.stair = [X(l.stair[0]), Y(l.stair[1])]; }
    for (const e of t.exterior) e[3] = ['north', 'south'].includes(e[2]) ? X(e[3]) : Y(e[3]);
    for (const r of t.roofs) { const c = { x: r[1], y: r[2], w: r[3], d: r[4] }; resize(c); r.splice(1, 4, c.x, c.y, c.w, c.d); }
    for (const r of t.outdoor) { const c = { x: r[1], y: r[2], w: r[3], d: r[4] }; resize(c); r.splice(1, 4, c.x, c.y, c.w, c.d); }
    const g = t.levels[0].rooms.find(c => c.role === 'garage');
    const garageRoof = t.roofs.find(r => r[0] === 0 && Math.abs(r[1] - g.x) < .001 && Math.abs(r[2] - g.y) < .001 && Math.abs(r[3] - g.w) < .001 && Math.abs(r[4] - g.d) < .001);
    if (g.x < 0) g.x = -s.garageW;
    g.w = s.garageW; g.d = s.garageD; g.y += s.garageY;
    garageRoof.splice(1, 4, g.x, g.y, g.w, g.d);
    t.exterior.find(e => e[1] === 'Garage')[3] = g.x + g.w / 2;
    t.driveway = [g.x + 1, g.y + g.d, g.w - 2, 23 + sizeIndex];
    const door = t.exterior.find(e => e[6] === 'deck'), host = t.levels[door[0]].rooms.find(c => c.name === door[1]);
    const deck = t.outdoor.find(o => o[0] === 'Deck');
    if (door[2] === 'south') {
      const w = Math.min(host.w, [12, 14, 16, 18, 20][sizeIndex]);
      deck.splice(1, 4, Math.max(host.x, Math.min(host.x + host.w - w, door[3] - w / 2)), host.y + host.d, w, [10, 12, 8, 10, 12][sizeIndex]);
    } else {
      const d = Math.min(host.d, [12, 14, 16, 18, 20][sizeIndex]);
      deck.splice(1, 4, host.x + host.w, Math.max(host.y, Math.min(host.y + host.d - d, door[3] - d / 2)), [10, 12, 14, 10, 12][sizeIndex], d);
    }
    t.outdoor[0][4] += sizeIndex * .5;
    t.roofs[t.roofs.length - 1].splice(1, 4, ...t.outdoor[0].slice(1));
    return t;
  }
  const plans = basePlans.flatMap((base, si) => programs.flatMap((program, pi) => sizes.map((size, vi) => {
    const t = sizePlan(configure(base, pi), si, vi), number = String(pi * 5 + vi + 1).padStart(2, '0');
    t.baseId = base.id; t.id = base.id + '-' + number; t.style = base.name; t.styleId = base.id.replace('NA-', '').toLowerCase();
    t.name = base.name + ' · ' + program + ' ' + (vi + 1); t.configurationId = t.styleId + '-' + pi; t.configuration = program;
    t.bedrooms = t.levels.flatMap(l => l.rooms).filter(c => c.role === 'bedroom').length;
    t.features = [...new Set(t.levels.filter(l => !l.basement).flatMap(l => l.rooms.filter(c => ['study', 'laundry', 'pantry', 'mudroom', 'closet'].includes(c.role)).map(c => c.name)))];
    t.tagline = base.tagline + (t.features.length ? ' · ' + t.features.join(' · ') : '');
    return t;
  })));
  const resolveId = value => { const id = typeof value === 'object' ? value.id : value; return basePlans.some(t => t.id === id) ? id + '-01' : id; };
  const entries = plans.map(t => ({ id: t.id, name: t.name, style: t.style, styleId: t.styleId, bedrooms: t.bedrooms,
    configurationId: t.configurationId, configuration: t.configuration, features: t.features,
    floors: t.levels.filter(f => !f.basement).length, basement: t.levels.some(f => f.basement), summary: t.tagline,
    areaSqFt: 0, areaM2: 0, areaBasis: 'Inside wall faces; excludes garage, basement, porch, deck and stair openings.' }));

  const rectIntersects = (a, b, margin = 0) => a.x < b.x + b.w + margin - 1e-6 && a.x + a.w + margin > b.x + 1e-6 && a.y < b.y + b.d + margin - 1e-6 && a.y + a.d + margin > b.y + 1e-6;
  const inCell = (c, q) => q.x > c.x - .001 && q.x < c.x + c.w + .001 && q.y > c.y - .001 && q.y < c.y + c.d + .001;
  const box = pts => { const xs = pts.map(p => p.x), ys = pts.map(p => p.y), x = Math.min(...xs), y = Math.min(...ys); return { x, y, w: Math.max(...xs) - x, d: Math.max(...ys) - y }; };
  function wallsFor(p, level, material) {
    const lines = new Map();
    function edge(axis, fixed, from, to, cell) {
      const key = axis + ':' + fixed.toFixed(6);
      if (!lines.has(key)) lines.set(key, { axis, fixed, segments: [] });
      lines.get(key).segments.push({ from, to, cell });
    }
    for (const c of level.cells) {
      edge('h', c.y, c.x, c.x + c.w, c); edge('h', c.y + c.d, c.x, c.x + c.w, c);
      edge('v', c.x, c.y, c.y + c.d, c); edge('v', c.x + c.w, c.y, c.y + c.d, c);
    }
    const edges = [];
    for (const line of lines.values()) {
      const cuts = [...new Set(line.segments.flatMap(s => [s.from, s.to]).map(n => +n.toFixed(6)))].sort((a, b) => a - b);
      for (let i = 1; i < cuts.length; i++) {
        const a = cuts[i - 1], b = cuts[i], mid = (a + b) / 2;
        const cells = line.segments.filter(s => s.from < mid && s.to > mid).map(s => s.cell);
        if (!cells.length) continue;
        if (cells.length > 2) throw Error('Overlapping room boundaries');
        const P = n => line.axis === 'h' ? { x: n, y: line.fixed } : { x: line.fixed, y: n };
        const w = E.wall(p, P(a), P(b), level.floor.id, cells.length === 2 ? 'interior' : 'exterior');
        if (cells.length === 2 && cells.some(c => c.role === 'garage')) w.thickness = .24;
        w.material = material;
        edges.push({ wall: w, axis: line.axis, fixed: line.fixed, cells });
      }
    }
    return edges;
  }
  function clearance(w, offset, width) {
    const horizontal = Math.abs(w.a.y - w.b.y) < .001;
    return horizontal ? { x: w.a.x + offset - .08, y: w.a.y - .85, w: width + .16, d: 1.7 }
      : { x: w.a.x - .85, y: w.a.y + offset - .08, w: 1.7, d: width + .16 };
  }
  function obstacles(p, floor) {
    const stairs = p.objects.filter(o => o.floor === floor && o.kind === 'stairs').map(o => box(E.objectFootprint(o)));
    for (const h of p.slabOpenings || []) if (h.floor === floor) {
      const s = p.objects.find(o => o.id === h.sourceStair);
      if (s) stairs.push(box(E.objectFootprint(s)));
    }
    return stairs;
  }
  function door(p, edge, width = 32 * inch, style = 'hinged', at) {
    const w = edge.wall, length = E.dist(w.a, w.b), blocked = obstacles(p, w.floor);
    width = Math.min(width, length - .28);
    if (width < .7) return null;
    const min = .14, max = length - width - .14, preferred = at == null ? (length - width) / 2 : at - width / 2;
    const candidates = [Math.max(min, Math.min(max, preferred))];
    if (at == null) for (let n = min; n <= max + .001; n += .025) candidates.push(n);
    candidates.sort((a, b) => Math.abs(a - preferred) - Math.abs(b - preferred));
    const offset = candidates.find(n => !blocked.some(b => rectIntersects(clearance(w, n, width), b)));
    if (offset == null) return null;
    const o = E.opening(p, w.id, (offset + width / 2) / length, style === 'doorway' ? 'opening' : 'door', style);
    o.width = width; o.offset = offset; o.height = (style === 'garage' ? 84 : 80) * inch; o.sill = 0;
    o.frameMaterial = 'white'; o.panelMaterial = style === 'sliding' ? 'glass' : 'white';
    E.validateOpening(p, o);
    return o;
  }
  function connect(p, level, first, second, width, optional = false) {
    const candidates = level.edges.filter(e => e.cells.length === 2 && e.cells.some(c => c.name === first) && e.cells.some(c => c.name === second)).sort((a, b) => E.dist(b.wall.a, b.wall.b) - E.dist(a.wall.a, a.wall.b));
    if (candidates.some(e => p.openings.some(o => o.wall === e.wall.id && o.kind !== 'window'))) return;
    for (const edge of candidates) {
      const o = door(p, edge, width ? m(width) : 32 * inch, width ? 'doorway' : 'hinged');
      if (o) return o;
    }
    if (!optional) throw Error('No clear doorway: ' + first + ' / ' + second);
  }
  function furnish(p, level, style) {
    const portals = p.openings.filter(o => o.kind !== 'window').map(o => ({ o, w: p.walls.find(w => w.id === o.wall) })).filter(v => v.w.floor === level.floor.id).map(v => clearance(v.w, v.o.offset, v.o.width));
    const occupied = obstacles(p, level.floor.id), rooms = E.detectRooms(p, level.floor.id);
    for (const c of level.cells) {
      const r = rooms.find(r => inCell(c, r.center));
      const kinds = ({ bedroom: ['bed', 'wardrobe'], kitchen: ['sink', 'stove', 'fridge', 'baseCabinet'], living: ['sofa', 'coffee'], dining: ['table'], bath: ['vanity', 'toilet', 'shower'], powder: ['vanity', 'toilet'], study: ['desk', 'armchair'], laundry: ['baseCabinet'], pantry: ['baseCabinet'], mudroom: ['baseCabinet'], closet: ['wardrobe'] })[c.role] || [];
      for (const kind of kinds.filter(kind => !(kind === 'wardrobe' && c.hasCloset))) {
        const o = E.object(p, kind, 0, 0, level.floor.id);
        if (kind === 'wardrobe' && c.wardrobeWidth) o.w = m(c.wardrobeWidth);
        if (c.role === 'closet') o.w = m(4);
        if (kind === 'baseCabinet' && c.cabinetWidth) o.w = m(c.cabinetWidth);
        if (kind === 'sofa' && c.sofaWidth) o.w = m(c.sofaWidth);
        if (kind === 'coffee' && c.coffeeWidth) o.w = m(c.coffeeWidth);
        o.name = c.name + ' — ' + kind;
        if (C.isCabinet(o)) { o.material = 'white'; o.cabinet = { ...C.defaults(o), style: 'shaker', topMaterial: 'quartz' }; }
        else if (['table', 'coffee', 'desk'].includes(kind)) o.material = style.floor;
        let found;
        // Favor the perimeter, and reserve door approaches before placing furniture.
        const candidates = [];
        for (let y = c.y + .19; y + o.d < c.y + c.d - .14; y += .14) for (let x = c.x + .19; x + o.w < c.x + c.w - .14; x += .14)
          candidates.push({ x, y });
        candidates.sort((a, b) => Math.min(a.x - c.x, a.y - c.y, c.x + c.w - a.x - o.w, c.y + c.d - a.y - o.d) - Math.min(b.x - c.x, b.y - c.y, c.x + c.w - b.x - o.w, c.y + c.d - b.y - o.d));
        if (c.kitchenRun === 'north') candidates.sort((a, b) => a.y - b.y || a.x - b.x);
        for (const q of candidates) {
          o.x = q.x; o.y = q.y;
          if (E.objectFootprint(o).every(pt => E.containsGeometry(r.netGeometry, pt)) && !occupied.some(v => rectIntersects(o, v, .12)) && !portals.some(v => rectIntersects(o, v))) { found = true; break; }
        }
        if (!found) { p.objects.pop(); throw Error('Furniture does not fit: ' + c.name + ' / ' + kind); }
        occupied.push({ x: o.x, y: o.y, w: o.w, d: o.d });
      }
    }
  }
  function build(id) {
    const t = plans.find(t => t.id === resolveId(id));
    if (!t) throw Error('Unknown North America template');
    const p = E.newProject(t.name + ' House');
    p.unit = 'ft'; p.currency = 'USD';
    p.rates = { floor: 12 * SQFT, wall: 3.5 * SQFT, concrete: 175 / .764554857984, door: 350, window: 48 * SQFT, cabinet: 220 / FT, waste: 10 };
    p.rateBasis = 'Illustrative USD unit prices; not converted from another currency.';
    p.floors = [];
    const levels = t.levels.map((l, i) => {
      const floor = { id: E.uid(), name: l.name, elevation: l.basement ? -(m(8) + 10 * inch) : i * (m(9) + 10 * inch), height: m(l.basement ? 8 : 9), slab: 10 * inch };
      p.floors.push(floor);
      const cells = l.rooms.map(c => ({ ...c, x: m(c.x), y: m(c.y), w: m(c.w), d: m(c.d) }));
      const level = { ...l, cells, floor };
      level.edges = wallsFor(p, level, t.wall);
      return level;
    });
    for (const l of levels) if (l.stair) {
      const s = E.object(p, 'stairs', m(l.stair[0]), m(l.stair[1]), l.floor.id);
      s.name = l.basement ? 'Basement Stair' : 'Main Stair'; s.stairShape = 'u'; s.flightWidth = 1.05; s.material = 'oak';
      E.fitStair(p, s); E.addStairwell(p, s).name = 'Stair Opening';
    }
    for (const l of levels) {
      const detected = E.detectRooms(p, l.floor.id);
      if (detected.length !== l.cells.length) throw Error('Room topology mismatch: ' + t.id + ' / ' + l.name);
      for (const r of detected) {
        const c = l.cells.find(c => inCell(c, r.center));
        if (!c) throw Error('Unmapped room');
        E.roomMeta(p, r, { name: c.name, material: ['bath', 'powder', 'garage', 'laundry', 'storage'].includes(c.role) ? (['bath', 'powder'].includes(c.role) ? 'stone' : 'concrete') : t.floor,
          roomType: c.role === 'powder' ? 'bath' : ['bedroom', 'kitchen', 'bath', 'garage'].includes(c.role) ? c.role : 'living', includeLiving: !l.basement && c.role !== 'garage' });
      }
      const pairs = new Set();
      for (const e of l.edges) if (e.cells.length === 2 && e.cells.some(c => c.role === 'hall') && !e.cells.some(c => c.ensuite || c.noHallDoor || c.role === 'garage')) {
        const names = e.cells.map(c => c.name).sort(), key = names.join('|');
        if (pairs.has(key)) continue; pairs.add(key);
        connect(p, l, names[0], names[1], undefined, true);
      }
    }
    for (const [index, a, b, width] of t.links) connect(p, levels[index], a, b, width);
    let entryDoor;
    for (const [index, name, side, position, width, style, purpose] of t.exterior) {
      const l = levels[index], c = l.cells.find(c => c.name === name), horizontal = side === 'north' || side === 'south';
      const fixed = horizontal ? c.y + (side === 'south' ? c.d : 0) : c.x + (side === 'east' ? c.w : 0), center = m(position);
      const e = l.edges.find(e => e.cells.length === 1 && e.cells[0] === c && e.axis === (horizontal ? 'h' : 'v') && Math.abs(e.fixed - fixed) < .001 && center > (horizontal ? e.wall.a.x : e.wall.a.y) && center < (horizontal ? e.wall.b.x : e.wall.b.y));
      if (!e) throw Error('Exterior opening has no wall: ' + name);
      const o = door(p, e, m(width), style, center - (horizontal ? e.wall.a.x : e.wall.a.y));
      if (!o) throw Error('Exterior door does not fit');
      o.name = purpose === 'entry' ? 'Front Entry' : purpose === 'deck' ? 'Deck Door' : 'Garage Door';
      if (purpose === 'entry') entryDoor = o.id;
    }
    for (const l of levels) if (!l.basement) for (const e of l.edges) {
      const c = e.cells[0], length = E.dist(e.wall.a, e.wall.b);
      if (e.cells.length !== 1 || c.role === 'garage' || c.role === 'hall' || length < m(4) || p.openings.some(o => o.wall === e.wall.id)) continue;
      const o = E.opening(p, e.wall.id, .5, 'window');
      o.width = Math.min(m(['bath', 'powder'].includes(c.role) ? 2 : t.baseId === 'NA-CONTEMPORARY' ? 6 : 4), length - .5);
      o.offset = (length - o.width) / 2; o.sill = m(['bath', 'powder'].includes(c.role) ? 5 : 3); o.height = m(['bath', 'powder'].includes(c.role) ? 2 : 4);
      o.frameMaterial = ['NA-CONTEMPORARY', 'NA-FARMHOUSE'].includes(t.baseId) ? 'charcoal' : 'white';
      E.validateOpening(p, o);
    }
    for (const l of levels) if (!l.basement) furnish(p, l, t);
    const outdoorSpaces = t.outdoor.map(([name, x, y, w, d]) => {
      const o = E.object(p, 'deck', m(x), m(y), levels[0].floor.id);
      Object.assign(o, { name, w: m(w), d: m(d), h: m(.5), z: -m(.5), material: name === 'Front Porch' ? 'stone' : 'oak' });
      p.annotations.push({ id: E.uid(), kind: 'text', floor: o.floor, a: { x: o.x + o.w / 2, y: o.y + o.d / 2 }, b: { x: o.x + o.w / 2, y: o.y + o.d / 2 }, text: name });
      if (name === 'Front Porch') for (const offset of [.3, o.w - .6]) {
        const column = E.object(p, 'column', o.x + offset, o.y + o.d - .6, o.floor);
        column.name = 'Porch Column'; column.material = t.baseId === 'NA-CRAFTSMAN' ? 'stone' : 'white'; column.h = levels[0].floor.height;
      }
      return { name, object: o.id, x: o.x, y: o.y, w: o.w, d: o.d, includeLiving: false };
    });
    for (const [index, x, y, w, d, type, pitch] of t.roofs) p.roofs.push({ id: E.uid(), floor: levels[index].floor.id, x: m(x), y: m(y), w: m(w), d: m(d), type, pitch, overhang: 0, material: 'charcoal' });
    const net = E.estimate(p).livingNetArea;
    if (net * SQFT < 1500 || net * SQFT > 2500) throw Error('Template living area outside 1500–2500 sq ft');
    p.template = { id: t.id, style: t.style, configuration: t.configuration, configurationId: t.configurationId, origin: 'Original Nexora schematic plan', stage: 'editable-schematic', entryDoorId: entryDoor,
      livingNetAreaM2: net, livingNetAreaSqFt: net * SQFT, areaBasis: entries.find(e => e.id === t.id).areaBasis,
      outdoorSpaces, note: 'Editable planning model. Roofs are simplified masses. Structural, energy, accessibility, site and permit design are not established.' };
    p.structure = { jurisdiction: '', code: '', amendments: '', reference: '', loads: '', members: [] };
    const bounds = E.bounds(p), site = { width: bounds.w + 16, depth: bounds.d + 20, north: 0, landscape: true,
      driveway: { x: m(t.driveway[0]), y: m(t.driveway[1]), w: m(t.driveway[2]), d: m(t.driveway[3]) },
      note: 'Grass, trees and driveway are presentation only; not surveyed site design or measured construction quantities.' };
    p.site = site;
    const valid = E.validate(p);
    // Older project validators retain only the three base site fields.
    valid.site = { ...valid.site, ...site };
    return valid;
  }
  function preview(value) {
    const t = plans.find(t => t.id === resolveId(value));
    if (!t) throw Error('Unknown North America template');
    const label = ({ zh: '主层平面预览', es: 'vista previa de la planta principal' })[root.NexoraI18n?.language] || 'main floor preview';
    const cells = t.levels[0].rooms, all = [...cells, ...t.outdoor.map(([name, x, y, w, d]) => ({ name, x, y, w, d, role: 'outdoor' }))];
    const x = Math.min(...all.map(c => c.x)) - 1, y = Math.min(...all.map(c => c.y)) - 1, w = Math.max(...all.map(c => c.x + c.w)) - x + 1, d = Math.max(...all.map(c => c.y + c.d)) - y + 1;
    return `<svg viewBox="${x} ${y} ${w} ${d}" role="img" aria-label="${escape(t.name)} ${label}"><title>${escape(t.name)} — ${label}</title>${all.map(c => `<rect x="${c.x}" y="${c.y}" width="${c.w}" height="${c.d}" fill="${({ hall: '#e7dfcd', bath: '#c9dfe2', bedroom: '#e5e9dc', garage: '#ced0cb', outdoor: '#d4b992' })[c.role] || '#f7f3e9'}" stroke="#385348" stroke-width=".36"/><text x="${c.x + c.w / 2}" y="${c.y + c.d / 2}" font-family="system-ui,sans-serif" font-size="1.35" text-anchor="middle" dominant-baseline="middle" fill="#263c32">${escape(c.name.replace('Primary ', 'Primary\u00a0'))}</text>`).join('')}</svg>`;
  }
  const galleryText = {
    en: { intro: '100 original North American homes · 20 per style · English rooms · feet and inches · USD', all: 'All', style: 'Style', bedrooms: 'Bedrooms', bedroomUnit: 'bedrooms', stories: 'Stories', story: 'story', storyPlural: 'stories', basement: 'basement', area: 'Net living area', areaUnit: 'sq ft net living', search: 'Search', searchHint: 'Style, room, or plan ID', matching: 'matching homes', page: 'Page', of: 'of', perPage: '20 per page', preview: 'Explore floors & 3D', open: 'Open editable home', previous: 'Previous', next: 'Next', empty: 'No homes match these filters.', local: 'Template geometry is generated locally in your browser. Loading creates a separate project and preserves existing projects.', basis: 'Living area is measured inside wall faces and excludes garages, basements, porches, decks and stair openings. These editable schematic starting points are not permit or construction documents.', review: 'Automated checks cover model geometry and circulation. Professional construction review and sign-off have not been obtained.' },
    zh: { intro: '100 套原创北美住宅 · 每种风格 20 套 · 英文房间名 · 英尺与英寸 · USD 美元', all: '全部', style: '建筑风格', bedrooms: '卧室数量', bedroomUnit: '间卧室', stories: '地上层数', story: '层', storyPlural: '层', basement: '地下室', area: '净居住面积', areaUnit: 'sq ft 净居住面积', search: '搜索', searchHint: '风格、英文房间名或样板编号', matching: '套符合条件', page: '页', of: '/', perPage: '每页 20 套', preview: '查看各层与 3D', open: '载入并编辑', previous: '上一页', next: '下一页', empty: '没有符合筛选条件的样板。', local: '样板模型在当前浏览器内生成。载入会创建独立项目，保留已有项目。', basis: '净居住面积按墙体内表面计算，排除车库、地下室、前廊、露台及楼梯洞口。这些可编辑的方案起点不属于报批图或施工图。', review: '自动检查覆盖模型几何和通行关系；尚未取得专业人员的施工审查与签审。' },
    es: { intro: '100 viviendas originales de Norteamérica · 20 por estilo · Habitaciones en inglés · Pies y pulgadas · USD', all: 'Todos', style: 'Estilo', bedrooms: 'Dormitorios', bedroomUnit: 'dormitorios', stories: 'Plantas sobre rasante', story: 'planta', storyPlural: 'plantas', basement: 'sótano', area: 'Superficie habitable neta', areaUnit: 'sq ft habitables netos', search: 'Buscar', searchHint: 'Estilo, habitación en inglés o ID del plano', matching: 'viviendas encontradas', page: 'Página', of: 'de', perPage: '20 por página', preview: 'Explorar plantas y 3D', open: 'Abrir y editar vivienda', previous: 'Anterior', next: 'Siguiente', empty: 'Ninguna vivienda coincide con estos filtros.', local: 'La geometría se genera localmente en el navegador. Al cargarla se crea un proyecto independiente y se conservan los proyectos existentes.', basis: 'La superficie habitable neta se mide entre las caras interiores de los muros y excluye garajes, sótanos, porches, terrazas y huecos de escalera. Estos modelos editables son esquemas iniciales, no planos para permisos ni para construcción.', review: 'Las comprobaciones automáticas cubren la geometría y la circulación del modelo. No se ha obtenido revisión ni aprobación profesional para construcción.' }
  };
  function gallery(options = {}) {
    const text = galleryText[root.NexoraI18n?.language] || galleryText.en;
    const style = String(options.style || ''), bedrooms = String(options.bedrooms || ''), floors = String(options.floors || ''), area = String(options.area || ''), search = String(options.search || '').trim().slice(0, 100);
    const ranges = { '1500-1800': [1500, 1800], '1800-2100': [1800, 2100], '2100-2500': [2100, 2500.000001] };
    const list = entries.filter(t => (!style || t.styleId === style) && (!bedrooms || t.bedrooms === Number(bedrooms)) && (!floors || t.floors === Number(floors)) && (!ranges[area] || t.areaSqFt >= ranges[area][0] && t.areaSqFt < ranges[area][1]) && (!search || [t.id, t.name, t.summary].join(' ').toLowerCase().includes(search.toLowerCase())));
    if (!style) list.sort((a, b) => Number(a.id.slice(-2)) - Number(b.id.slice(-2)) || entries.indexOf(a) - entries.indexOf(b));
    const pageCount = Math.max(1, Math.ceil(list.length / 20)), page = Math.max(1, Math.min(pageCount, Math.floor(Number(options.page) || 1))), shown = list.slice((page - 1) * 20, page * 20);
    const select = (id, label, value, values) => `<label class="field">${label}<select id="${id}"><option value="">${text.all}</option>${values.map(([key, label]) => `<option value="${key}"${value === String(key) ? ' selected' : ''}>${escape(label)}</option>`).join('')}</select></label>`;
    return `<section class="north-america-gallery" data-no-translate><p>${text.intro}</p><p>${text.local}</p><div class="pair">${select('naStyle', text.style, style, basePlans.map(t => [t.id.replace('NA-', '').toLowerCase(), t.name]))}${select('naBedrooms', text.bedrooms, bedrooms, [2, 3, 4].map(n => [n, n + ' ' + text.bedroomUnit]))}${select('naFloors', text.stories, floors, [[1, '1 ' + text.story], [2, '2 ' + text.storyPlural]])}${select('naArea', text.area, area, [['1500-1800', '1,500–1,799 sq ft'], ['1800-2100', '1,800–2,099 sq ft'], ['2100-2500', '2,100–2,500 sq ft']])}<label class="field">${text.search}<input id="naSearch" type="search" maxlength="100" value="${escape(search)}" placeholder="${text.searchHint}"></label></div><p>${list.length} ${text.matching} · ${text.page} ${page} ${text.of} ${pageCount} · ${text.perPage}</p><div class="template-grid">${shown.map(t => `<article class="template-card">${preview(t)}<small>${t.id} · ${t.areaSqFt.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})} ${text.areaUnit} · ${t.bedrooms} ${text.bedroomUnit} · ${t.floors} ${t.floors === 1 ? text.story : text.storyPlural}${t.basement ? ' + ' + text.basement : ''}</small><h3>${escape(t.name)}</h3><p>${escape(t.summary)}</p><div class="template-card-actions"><button class="primary" data-preview-north-america="${t.id}">${text.preview}</button><button data-load-north-america="${t.id}">${text.open}</button></div></article>`).join('')}</div>${shown.length ? '' : '<p>' + text.empty + '</p>'}<div class="dialog-actions"><button data-na-page="${page - 1}"${page <= 1 ? ' disabled' : ''}>${text.previous}</button><label>${text.page} <select id="naPage">${Array.from({ length: pageCount }, (_, i) => `<option value="${i + 1}"${i + 1 === page ? ' selected' : ''}>${i + 1}</option>`).join('')}</select></label><button data-na-page="${page + 1}"${page >= pageCount ? ' disabled' : ''}>${text.next}</button></div><p>${text.basis}</p><p>${text.review}</p></section>`;
  }
  // Geometry regression tests compare these measured gallery values with fresh builds.
  // Avoid constructing 100 complete BIM projects just to render their cards.
  const measured = [1889.014198028396,1980.8645917291833,1953.8645917291833,2014.2897885795771,2074.7149854299714,1883.7348874697752,1975.5852811705624,1948.585281170563,2009.0104780209565,2069.435674871351,1883.3411866823735,1974.797879595759,1948.1915803831607,2008.2230764461526,2068.254572509146,1879.9528799057598,1971.6457932915862,1944.803273606547,2005.0709901419807,2065.3387066774135,2076.94208155083,2213.4302705272084,2198.642868952405,2277.068065802798,2353.131057928783,2072.056471779611,2208.1509599685874,2193.7572591811854,2271.3950544567756,2347.851747370162,2072.0564717796105,2208.150959968587,2193.7572591811854,2271.3950544567756,2347.851747370162,2067.1708620083914,2202.8716494099667,2188.871649409966,2265.722043110753,2342.5724368115407,1798.2133424266854,1891.6700353400702,1859.063736127472,1934.7015314030627,1975.5204290408583,1793.7214334428677,1887.1781263562525,1854.5718271436544,1930.2096224192444,1971.02852005704,1793.7214334428672,1887.1781263562527,1854.5718271436547,1930.2096224192449,1971.0285200570402,1789.9394258788525,1883.2144106371545,1850.78981957964,1926.2459067001466,1966.883096182859,2116.42859652386,2231.7087475716617,2223.704187075042,2286.381414894496,2350.239599324199,2109.574482815633,2224.854633863434,2216.0626717920113,2279.5273011862687,2342.9917848285695,2116.4285965238605,2231.708747571662,2223.704187075042,2286.3814148944966,2350.239599324199,2104.450172567012,2219.7303236148136,2210.9383615433903,2274.4029909376486,2337.8674745799494,1985.5468875937754,2098.3701596847645,2092.8224781449567,2146.4847703584296,2221.5388385999,1981.4486793973592,2093.983237577587,2088.72426994854,2141.8091343404913,2217.151916492723,1981.0549786099577,2093.484549913545,2088.330569161139,2141.599160587211,2216.259528041279,1975.381967263935,2087.8115385675223,2081.870156240313,2135.926149241188,2210.1928159078543];
  entries.forEach((e, i) => { e.areaSqFt = measured[i] || 0; e.areaM2 = e.areaSqFt / SQFT; });
  const defaultProject = () => build('NA-RANCH');
  root.NorthAmerica = { entries, build, preview, gallery, defaultProject };
  if (typeof module === 'object') module.exports = root.NorthAmerica;
})(typeof globalThis !== 'undefined' ? globalThis : this);
