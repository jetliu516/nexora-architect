(function(root){
  'use strict';
  const M=root.MEP,E=root.BIM,U=root.Units,esc=root.Drawings.esc,t=x=>root.NexoraI18n?.t(x)||x,txt=x=>esc(t(x));
  let bridge,draft,preview;
  const current=()=>bridge.state();
  const buttons=(id,onlyAvoid=false)=>`${onlyAvoid?'':`<button data-mep-edit-route="${esc(id)}">${txt('编辑路点')}</button>`}<button data-mep-avoid="${esc(id)}">${txt('搜索绕障路线')}</button>`;
  const precise=(v,unit)=>unit==='ft'?(v/.3048).toFixed(3)+' ft':v.toFixed(3)+' m';
  function ensure(){if(!draft||draft.before!==JSON.stringify(current().p))throw Error('模型已变化，请重新预览')}
  function editor(id,keep=false){const {p}=current(),r=M.item(p,'mepRun',id);if(!r)return;if(!keep){const elevation=p.floors.find(f=>f.id===r.floor).elevation;draft={id,before:JSON.stringify(p),points:M.path(p,r).slice(1,-1).map(q=>({...q,z:q.z-elevation}))}}
    bridge.dialog('编辑路点',`<form id="mepRouteEditForm"><p>${txt('两端保持连接；中间路点固定在起点楼层坐标中，设备移动后请重新检查。')}</p><p>${txt('Z 为相对起点楼层的高度，支持公制或英制输入。')}</p><div class="table-scroll"><table class="schedule-table"><thead><tr><th>#</th><th>X</th><th>Y</th><th>Z</th><th></th></tr></thead><tbody>${draft.points.map((q,i)=>`<tr data-route-row><td>${i+1}</td>${['x','y','z'].map(k=>`<td><input aria-label="${k.toUpperCase()} ${i+1}" data-route-coordinate="${k}" value="${esc(precise(q[k],p.unit))}" data-numeric-source="${q[k]/(p.unit==='ft'?.3048:1)} ${p.unit}" data-numeric-display="${esc(precise(q[k],p.unit))}" required style="width:110px"></td>`).join('')}<td><button type="button" data-route-remove="${i}">${txt('删除')}</button></td></tr>`).join('')}</tbody></table></div><div class="dialog-actions"><button type="button" data-route-add ${draft.points.length>=64?'disabled':''}>＋ ${txt('添加路点')}</button><button class="primary">${txt('预览路线')}</button></div><p class="note">${txt('手工路线可以保留碰撞；预览会列出检查数量，应用后可撤销。')}</p></form>`);
  }
  function read(){const {p}=current();return[...document.querySelectorAll('#mepRouteEditForm [data-route-row]')].map(row=>Object.fromEntries([...row.querySelectorAll('[data-route-coordinate]')].map(el=>[el.dataset.routeCoordinate,U.parse(root.NumericFields?.read(el)??el.value,p.unit)])))}
  function avoid(id){const {p}=current(),r=M.item(p,'mepRun',id);if(!r)return;draft={id,before:JSON.stringify(p)};
    bridge.dialog('搜索绕障路线',`<form id="mepRouteAvoidForm"><p>${txt('保持两端、系统和管径，搜索可避开当前实体及其他管线的路线。')}</p><label class="field">${txt('附加几何净距')}<input name="clearance" value="${esc(precise(.05,p.unit))}" required></label><label class="field">${txt('两端外扩搜索范围')}<input name="detour" value="${esc(precise(2,p.unit))}" required></label><p>${txt('排水保持向终点下降，并检查设定最小坡度。')}</p><p class="note">${txt('受限搜索不保证找到所有可行解；不自动创建墙洞、套管或楼板洞口。净距为自定几何参数。')}</p><button class="primary">${txt('计算候选路线')}</button></form>`);
  }
  function show(next,id,automatic){const {p}=current(),r=M.item(next,'mepRun',id),old=M.item(p,'mepRun',id),points=M.path(next,r),oldPoints=M.path(p,old),issues=M.clashes(next,{onlyRunIds:[id]}),checks=M.checks(next).filter(i=>i.id===id),xs=points.concat(oldPoints).map(q=>q.x),ys=points.concat(oldPoints).map(q=>q.y),box={x:Math.min(...xs)-1,y:Math.min(...ys)-1,w:Math.max(...xs)-Math.min(...xs)+2,h:Math.max(...ys)-Math.min(...ys)+2};
    preview={before:JSON.stringify(p),next};const path=ps=>ps.map((q,i)=>(i?'L':'M')+q.x+' '+q.y).join('');
    bridge.dialog('路线修改预览',`<p>${txt(automatic?'候选路线通过当前几何检查':'手工路线预览')} · ${txt('三维实际长度')} ${U.length(M.runLength(p,old),p.unit)} → ${U.length(M.runLength(next,r),p.unit)}</p><p>${txt('几何提示')}：${issues.issues.length}${issues.truncated?'＋':''} · ${txt('坡度与流向提示')}：${checks.length}</p><svg aria-label="路线平面预览" viewBox="${box.x} ${box.y} ${box.w} ${box.h}" style="width:100%;height:220px;background:#f5f7f8">${p.walls.filter(w=>w.floor===r.floor).map(w=>`<path d="M${w.a.x} ${w.a.y}L${w.b.x} ${w.b.y}" stroke="#a0a9ac" stroke-width="${w.thickness}"/>`).join('')}<path d="${path(oldPoints)}" fill="none" stroke="#9d7580" stroke-width=".04" stroke-dasharray=".12 .08"/><path d="${path(points)}" fill="none" stroke="#087c64" stroke-width=".06"/>${points.map(q=>`<circle cx="${q.x}" cy="${q.y}" r=".09" fill="#087c64"/>`).join('')}</svg><p>${txt('虚线为原路线，绿色为候选路线；下表列出真实三维坐标。')}</p><div class="table-scroll"><table class="schedule-table"><thead><tr><th>#</th><th>X</th><th>Y</th><th>${txt('世界标高')}</th></tr></thead><tbody>${points.map((q,i)=>`<tr><td>${i+1}</td><td>${U.length(q.x,p.unit,4)}</td><td>${U.length(q.y,p.unit,4)}</td><td>${U.length(q.z,p.unit,4)}</td></tr>`).join('')}</tbody></table></div>${checks.map(i=>`<p class="callout">${txt(i.text)}</p>`).join('')}<p class="note">${txt('几何检查不代替工程计算或规范审查；修改模型后需重新检查。')}</p><button class="primary" data-route-apply>${txt('应用方案（可撤销）')}</button>`);
  }
  function init(b){bridge=b;
    document.addEventListener('click',e=>{const button=e.target.closest('button');if(!button)return;const d=button.dataset;try{
      if(d.mepEditRoute){editor(d.mepEditRoute);return}if(d.mepAvoid){avoid(d.mepAvoid);return}
      if(d.routeApply!=null){const {p,s}=current();if(!preview||preview.before!==JSON.stringify(p))throw Error('模型已变化，请重新预览');if(bridge.transact(()=>Object.assign(p,E.clone(preview.next)),'路线已更新，可撤销')){preview=null;s.selected=null;bridge.close();bridge.refresh()}return}
      if(d.routeAdd!=null||d.routeRemove!=null){ensure();draft.points=read();if(d.routeRemove!=null)draft.points.splice(Number(d.routeRemove),1);else if(draft.points.length<64){const {p}=current(),r=M.item(p,'mepRun',draft.id),f=p.floors.find(f=>f.id===r.floor),start=M.position(p,M.item(p,'mepNode',r.a)),last=draft.points.at(-1)||{...start,z:start.z-f.elevation},end=M.position(p,M.item(p,'mepNode',r.b));draft.points.push({x:(last.x+end.x)/2,y:(last.y+end.y)/2,z:(last.z+end.z-f.elevation)/2})}editor(draft.id,true)}
    }catch(error){bridge.toast(error.message)}});
    document.addEventListener('submit',e=>{const form=e.target;if(!['mepRouteEditForm','mepRouteAvoidForm'].includes(form.id))return;e.preventDefault();try{ensure();const {p}=current(),id=draft.id;
      if(form.id==='mepRouteEditForm')show(M.setRoute(p,id,read()),id,false);
      else{const data=new FormData(form),result=M.avoid(p,id,{clearance:U.parse(data.get('clearance'),p.unit),detour:U.parse(data.get('detour'),p.unit)});if(!result.ok)throw Error(result.reason);show(result.next,id,true)}
    }catch(error){bridge.toast(error.message)}});
  }
  root.MEPRouteUI={init,buttons};
})(window);
