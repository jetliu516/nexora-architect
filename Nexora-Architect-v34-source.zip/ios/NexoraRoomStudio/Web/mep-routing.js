(function(root){
  'use strict';
  const E=root.BIM||require('./geometry.js'),M=root.MEP||require('./mep.js');
  const abs=Math.abs,epsilon=1e-7;
  // One canonical coordinate rule for scoring, graph keys and every edge.
  const quantize=n=>Math.round(n*1e6)/1e6;
  const point=q=>({x:quantize(q.x),y:quantize(q.y)});
  const key=q=>q.x+':'+q.y;
  function groups(origin,points,axis,other,cross){
    const map=new Map();
    for(const q of [origin,...points]){if(!map.has(q[axis]))map.set(q[axis],new Set([cross]));map.get(q[axis]).add(q[other])}
    return map;
  }
  function comb(rawOrigin,rawPoints){
    const origin=point(rawOrigin),points=rawPoints.map(point);let best;
    // Bounded rectilinear comb heuristic; not globally optimal Steiner routing.
    // Branch intervals are unioned, including the origin's entry stem.
    for(const axis of ['x','y']){
      const other=axis==='x'?'y':'x',coords=[...new Set([origin[other],...points.map(q=>q[other])])];
      const lo=Math.min(origin[axis],...points.map(q=>q[axis])),hi=Math.max(origin[axis],...points.map(q=>q[axis]));
      for(const cross of coords){let cost=hi-lo;for(const values of groups(origin,points,axis,other,cross).values())cost+=Math.max(...values)-Math.min(...values);if(!best||cost<best.cost-epsilon)best={axis,other,cross,cost}}
    }return best;
  }
  function combTree(rawOrigin,rawPoints){
    const origin=point(rawOrigin),points=rawPoints.map(point),{axis,other,cross}=comb(origin,points),graph=new Map();
    const vertex=q=>{const k=key(q);if(!graph.has(k))graph.set(k,{q,edges:new Set()});return k};
    const edge=(a,b)=>{const ka=vertex(a),kb=vertex(b);if(ka!==kb){graph.get(ka).edges.add(kb);graph.get(kb).edges.add(ka)}};
    const chain=list=>{list.forEach(vertex);for(let i=1;i<list.length;i++)edge(list[i-1],list[i])};
    const branches=groups(origin,points,axis,other,cross),coords=[...branches.keys()].sort((a,b)=>a-b);
    chain(coords.map(value=>({[axis]:value,[other]:cross})));
    for(const [value,values]of branches)chain([...values].sort((a,b)=>a-b).map(v=>({[axis]:value,[other]:v})));
    const root=key(origin),order=[root],distances=new Map([[root,0]]),parents=new Map();
    for(let i=0;i<order.length;i++){const k=order[i],v=graph.get(k);for(const next of v.edges)if(!distances.has(next)){const q=graph.get(next).q;parents.set(next,k);distances.set(next,distances.get(k)+abs(v.q.x-q.x)+abs(v.q.y-q.y));order.push(next)}}
    return{graph,root,order,distances,parents,terminalKeys:points.map(key)};
  }
  function mergeVertical(p,system,source){
    const runs=p.mep.runs.filter(r=>r.system===system),groups=new Map(),removed=new Set();
    for(const r of runs){if(r.routing!=='direct')continue;const a=M.position(p,M.item(p,'mepNode',r.a)),b=M.position(p,M.item(p,'mepNode',r.b)),k=key(point(a));if(k!==key(point(b)))continue;
      if(!groups.has(k))groups.set(k,{nodes:new Set(),spans:[]});const g=groups.get(k);g.nodes.add(r.a);g.nodes.add(r.b);g.spans.push([Math.min(a.z,b.z),Math.max(a.z,b.z)]);removed.add(r.id);
    }
    p.mep.runs=p.mep.runs.filter(r=>!removed.has(r.id));
    for(const g of groups.values()){
      const nodes=[...g.nodes].map(id=>M.item(p,'mepNode',id)).sort((a,b)=>M.position(p,a).z-M.position(p,b).z);
      for(let i=1;i<nodes.length;i++){const a=nodes[i-1],b=nodes[i],z=(M.position(p,a).z+M.position(p,b).z)/2;if(g.spans.some(([lo,hi])=>z>=lo-1e-9&&z<=hi+1e-9))M.connect(p,a.id,b.id,{generated:true,routing:'direct',level:a.z})}
    }
    // Unioning vertical intervals can create cycles. Root a spanning tree at the
    // actual source so drainage direction and zero-length coincident ports stay connected.
    const edges=p.mep.runs.filter(r=>r.system===system),adj=new Map();
    for(const r of edges)for(const id of [r.a,r.b]){if(!adj.has(id))adj.set(id,[]);adj.get(id).push(r)}
    const seen=new Set([source.id]),queue=[source.id],keep=new Set();
    for(let i=0;i<queue.length;i++)for(const r of adj.get(queue[i])||[]){const child=r.a===queue[i]?r.b:r.a;if(seen.has(child))continue;seen.add(child);queue.push(child);keep.add(r.id);r.a=system==='drain'?child:queue[i];r.b=system==='drain'?queue[i]:child;r.floor=M.item(p,'mepNode',r.a).floor}
    if(seen.size!==p.mep.nodes.filter(n=>n.system===system).length)throw Error('端口未连接到系统源点');
    p.mep.runs=p.mep.runs.filter(r=>r.system!==system||keep.has(r.id));
  }
  function optimize(raw,{selected=Object.keys(M.systems),drainSlope=.02,moveOutlet=false}={}){
    if(!Array.isArray(selected)||!selected.length||new Set(selected).size!==selected.length||selected.some(k=>!Object.hasOwn(M.systems,k)))throw Error('请选择有效机电系统');
    if(!Number.isFinite(drainSlope)||drainSlope<.001||drainSlope>.1)throw Error('机电参数超出范围');
    const p=E.clone(raw);if(!p.mep)return E.validate(p);
    for(const system of selected){
      const oldNodes=M.data(p).nodes.filter(n=>n.system===system);if(!oldNodes.length)continue;
      const roots=oldNodes.filter(n=>n.kind===M.systems[system].source),panels=oldNodes.filter(n=>n.kind==='panel');
      if(roots.length!==1||(system==='electric'&&panels.length!==1))throw Error('每个系统需要一个源点，电气系统还需要一个配电箱');
      const source=roots[0],supply=system==='electric'?panels[0]:source;
      const terminals=oldNodes.filter(n=>n!==source&&n!==supply&&!(n.kind==='junction'&&n.generated));
      p.mep.nodes=p.mep.nodes.filter(n=>n.system!==system||n===source||n===supply||terminals.includes(n));
      p.mep.runs=p.mep.runs.filter(r=>r.system!==system);
      const origin=M.position(p,supply),isDrain=system==='drain',floorEntries=[];
      const join=(a,b,extra={})=>M.connect(p,a.id,b.id,{generated:true,...extra});
      if(source!==supply)join(source,supply,{level:source.z,routing:'xy'});
      for(const f of p.floors){
        const endpoints=terminals.filter(n=>n.floor===f.id);if(!endpoints.length)continue;
        const tree=combTree(origin,endpoints.map(n=>M.position(p,n)));
        const maxDistance=Math.max(...tree.terminalKeys.map(k=>tree.distances.get(k)));
        const level=isDrain?-.25-drainSlope*maxDistance-.05:Math.min(M.systems[system].level,f.height-.2);
        const nodes=new Map();
        for(const k of tree.order){const q=tree.graph.get(k).q;nodes.set(k,M.node(p,system,'junction',f.id,q.x,q.y,level+(isDrain?tree.distances.get(k)*drainSlope:0),{generated:true}))}
        floorEntries.push(nodes.get(tree.root));
        for(const [childKey,parentKey]of tree.parents){const parent=nodes.get(parentKey),child=nodes.get(childKey);join(isDrain?child:parent,isDrain?parent:child,{routing:'direct',level:parent.z,slope:isDrain?drainSlope:0})}
        endpoints.forEach((n,i)=>{const junction=nodes.get(tree.terminalKeys[i]);join(isDrain?n:junction,isDrain?junction:n,{routing:'direct',level:junction.z,slope:isDrain?drainSlope:0})});
      }
      if(isDrain&&moveOutlet&&floorEntries.length){const f=p.floors.find(f=>f.id===source.floor);source.z=Math.min(source.z,...floorEntries.map(n=>M.position(p,n).z-f.elevation-.25))}
      // A single shaft connects floor entries once. No overlapping home runs.
      if(isDrain){const shaft=[...floorEntries].sort((a,b)=>M.position(p,b).z-M.position(p,a).z);shaft.push(supply);for(let i=0;i<shaft.length-1;i++)join(shaft[i],shaft[i+1],{routing:'direct',level:shaft[i].z,slope:drainSlope})}
      else {const shaft=[supply,...floorEntries].sort((a,b)=>M.position(p,a).z-M.position(p,b).z);for(let i=1;i<shaft.length;i++)join(shaft[i-1],shaft[i],{routing:'direct',level:shaft[i-1].z,slope:0})}
      mergeVertical(p,system,source);
    }
    return E.validate(p);
  }
  const generateHomeRuns=M.generate;
  M.generateHomeRuns=generateHomeRuns;
  M.generate=(raw,options={})=>optimize(generateHomeRuns(raw,options),{selected:options.selected,drainSlope:options.drainSlope,moveOutlet:true});
  Object.assign(M,{comb,optimize});
  root.MEP=M;if(typeof module!=='undefined')module.exports=M;
})(typeof window!=='undefined'?window:globalThis);
