(function (root) {
  "use strict";
  // Re-render the actual scene at the requested size, then restore the editor.
  function capture(view, width = 2560, height = 1440) {
    if (![width, height].every(v => Number.isInteger(v) && v >= 256 && v <= 4096))
      throw new Error("图片尺寸须在 256–4096 像素之间。");
    const renderer = view.renderer, camera = view.camera;
    const gl = renderer.getContext();
    if (gl.isContextLost()) throw new Error("三维视图暂不可用，请刷新后重试。");
    const limit = Math.min(renderer.capabilities.maxTextureSize,
      gl.getParameter(gl.MAX_RENDERBUFFER_SIZE));
    if (Math.max(width, height) > limit)
      throw new Error("当前设备不支持这个尺寸，请选择较小的图片。");
    const size = renderer.getSize({ set(x, y) { this.x = x; this.y = y; return this; } });
    const ratio = renderer.getPixelRatio(), aspect = camera.aspect;
    try {
      renderer.setPixelRatio(1);
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      view.render();
      if (gl.isContextLost() || renderer.domElement.width !== width || renderer.domElement.height !== height)
        throw new Error("高清图片生成失败，请选择较小的尺寸重试。");
      const url = renderer.domElement.toDataURL("image/png");
      if (!url.startsWith("data:image/png;base64,") || url.length < 40)
        throw new Error("图片未生成，请选择较小的尺寸重试。");
      return url;
    } finally {
      renderer.setPixelRatio(ratio);
      renderer.setSize(size.x, size.y, false);
      camera.aspect = aspect;
      camera.updateProjectionMatrix();
      if (!gl.isContextLost()) view.render();
    }
  }
  const api = { capture };
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.NexoraImageExport = api;
})(typeof window === "object" ? window : globalThis);
