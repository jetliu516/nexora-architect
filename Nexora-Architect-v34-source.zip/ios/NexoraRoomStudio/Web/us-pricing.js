(function(root){'use strict';
const E=root.BIM||(typeof require==='function'?require('./geometry.js'):null),C=root.Cabinets||(typeof require==='function'?require('./cabinets.js'):null);
const SQFT=1/.09290304,FT=1/.3048,YD3=1/ .764554857984;
const defaults={floor:7.5,wall:3.25,concrete:185,door:280,window:55,cabinet:350,countertop:75,backsplash:18};
const names={floor:'Floor finish incl. waste',wall:'Wall finish, both sides less openings',concrete:'Concrete floor slabs',door:'Doors',window:'Windows',cabinet:'Cabinet runs',countertop:'Quartz countertops',backsplash:'Kitchen tile backsplash allowance'};
function rates(p){const saved=p.pricing?.currency==='USD'?p.pricing.rates:{};return {...defaults,...saved}}
function validate(p){if(p.pricing!=null){if(p.pricing.currency!=='USD'||!p.pricing.rates||typeof p.pricing.rates!=='object')throw Error('Invalid USD pricing');for(const [key,value]of Object.entries(p.pricing.rates))if(!Object.hasOwn(defaults,key)||!Number.isFinite(value)||value<0||value>1e6)throw Error('Invalid USD unit price')}return p}
function estimate(p,floor){validate(p);const base=E.estimate(p,floor),price=rates(p);let rows=base.rows.map(r=>{const factor=r.unit==='m²'?SQFT:r.unit==='m³'?YD3:r.unit==='m'?FT:1;return{key:r.key,name:names[r.key]||r.name,quantity:r.quantity*factor,unit:r.unit==='m²'?'sq ft':r.unit==='m³'?'cu yd':r.unit==='m'?'linear ft':'each',rate:price[r.key]}});
const finishArea=p.floors.filter(f=>!floor||f.id===floor).flatMap(f=>E.detectRooms(p,f.id)).filter(r=>r.material!=='concrete').reduce((sum,r)=>sum+r.netArea,0);rows.find(r=>r.key==='floor').quantity=finishArea*(1+p.rates.waste/100)*SQFT;
const cabinets=C.schedule(p).filter(r=>!floor||r.object.floor===floor);rows.push({key:'countertop',name:names.countertop,quantity:cabinets.reduce((s,r)=>s+r.countertopArea,0)*SQFT,unit:'sq ft',rate:price.countertop});
rows.push({key:'backsplash',name:names.backsplash,quantity:cabinets.filter(r=>['baseCabinet','drawerCabinet','sink','stove'].includes(r.object.kind)).reduce((s,r)=>s+r.object.w*.4572,0)*SQFT,unit:'sq ft',rate:price.backsplash});
return{...base,rows:rows.map(r=>({...r,amount:r.quantity*r.rate})),total:rows.reduce((s,r)=>s+r.quantity*r.rate,0),currency:'USD'};}
const money=v=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',minimumFractionDigits:2,maximumFractionDigits:2}).format(v);
const api={defaults,rates,estimate,validate,money};root.USPricing=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
