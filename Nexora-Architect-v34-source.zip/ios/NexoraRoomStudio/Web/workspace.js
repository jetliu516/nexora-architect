(function(root){
  'use strict';
  const $=id=>document.getElementById(id),esc=x=>Drawings.esc(String(x)),t=x=>root.NexoraI18n?.t(x)||x;
  const menus={
    '文件':[['新建项目','action:new','⌘/Ctrl N'],['打开项目','action:projects','⌘/Ctrl O'],['保存','action:save','⌘/Ctrl S'],['另存副本','action:variant'],['重命名项目','action:renameProject'],['关闭标签','closeTab'],['导入项目','action:import'],['导出 / 交付','action:export'],['回收站','action:trash'],['项目恢复','action:recovery']],
    '编辑':[['撤销','action:undo','⌘/Ctrl Z'],['重做','action:redo','⌘/Ctrl ⇧ Z'],['删除选中','action:delete','Delete'],['复制构件','action:duplicate'],['旋转 90°','action:rotateObject'],['选择','tool:select','V'],['取消当前工具','tool:select','Esc']],
    '建筑':[['外墙','tool:wall','W'],['内墙','tool:partition'],['矩形房间','tool:rectangle'],['门','tool:door','D'],['窗','tool:window'],['开口','tool:opening'],['楼梯','kind:stairs'],['屋顶','action:roof'],['楼层管理','action:floorSettings']],
    '室内与橱柜':[['地柜','kind:baseCabinet'],['吊柜','kind:wallCabinet'],['高柜','kind:tallCabinet'],['中岛','kind:island'],['连续橱柜','action:cabinetRun'],['构件库','dock:library'],['语音排柜','action:kitchenPlanner']],
    '机电':[['机电工作区','action:mep'],['自动生成机电方案','action:mepGenerate'],['添加机电节点','action:mepNode'],['连接两个端口','action:mepConnect']],
    '3D':[['三维','mode:3d'],['平面 + 3D','mode:split'],['轴测总览','camera:iso'],['正顶视图','camera:top'],['前视','camera:front'],['漫游','action:walk'],['剖切','action:cutaway'],['框架示意','action:framing'],['高清三维图','action:image']],
    'CAD':[['尺寸','tool:dimension','M'],['CAD 线','tool:line'],['文字','tool:text'],['自动尺寸','action:dimensions'],['立面','mode:elevation'],['剖面','mode:section'],['图纸','mode:layout'],['DXF导出','action:dxf'],['打印图纸','action:print']],
    '工具':[['工具搜索','search','⌘/Ctrl K'],['AI 助手','action:aiAssistant'],['住宅模板库','action:homeTemplates'],['结构设计','action:structure'],['模型检查','action:validate'],['材料用量','action:schedule'],['门窗表','action:openingSchedule'],['柜体表','action:cabinetSchedule'],['现场扫描','action:scan']],
    '视图':[['平面图','mode:plan'],['适应窗口','action:fit'],['放大','action:zoomIn'],['缩小','action:zoomOut'],['平移','tool:pan'],['保存工作视图','saveView'],['项目浏览器','dock:project'],['图层','dock:layers'],['属性检查器','dock:properties'],['收起 / 展开面板','toggleDock']],
    '帮助':[['操作指南','action:help'],['功能覆盖与边界','action:coverage']]
  };
  let bridge,opened=[],dock='project',lastSelection='',lastTool='',paletteGroup='walls',treeQuery='',activeSaved=null;
  const prefKey='nexora-workspace-tabs-v1';
  const palettes={
    walls:{name:'墙体与房间',rows:[['外墙','tool:wall'],['内墙','tool:partition'],['矩形房间','tool:rectangle'],['屋顶','action:roof'],['楼层管理','action:floorSettings']]},
    doors:{name:'门与洞口',rows:Object.entries(Openings.types).filter(([k,v])=>v.kind==='door'||k==='doorway').map(([k,v])=>[v.label,'opening:'+k]).concat([['翻转开启方向','action:flipDoor'],['门窗表','action:openingSchedule']])},
    windows:{name:'窗',rows:Object.entries(Openings.types).filter(([k,v])=>v.kind==='window'||['passThrough','niche'].includes(k)).map(([k,v])=>[v.label,'opening:'+k]).concat([['门窗表','action:openingSchedule']])},
    cabinets:{name:'橱柜',rows:[]},
    objects:{name:'构件库',rows:[['沙发','kind:sofa'],['床','kind:bed'],['餐桌','kind:table'],['楼梯','kind:stairs'],['水槽','kind:sink'],['灶台','kind:stove'],['浴缸','kind:bath'],['构件库','dock:library']]},
    electrical:{name:'机电与电气',rows:[['机电工作区','action:mep'],['自动生成机电方案','action:mepGenerate'],['添加机电节点','action:mepNode'],['连接两个端口','action:mepConnect'],['顶灯','kind:light'],['插座','kind:socket'],['开关','kind:switch']]},
    cad:{name:'制图',rows:[['尺寸','tool:dimension'],['CAD 线','tool:line'],['文字','tool:text'],['立面','mode:elevation'],['剖面','mode:section'],['图纸','mode:layout']]}
  };
  function persistTabs(){try{localStorage.setItem(prefKey,JSON.stringify(opened))}catch{}}
  function open(id){if(!opened.includes(id))opened.push(id);persistTabs();activeSaved=null}
  function commandButton(label,command,extra=''){return `<button data-ws-command="${esc(command)}" ${extra}><span>${esc(t(label))}</span></button>`}
  function setDock(name){const panel=$('dock-'+name);if(panel)panel.scrollTop=0;dock=name;document.body.classList.remove('dock-collapsed');for(const key of ['project','library','layers','properties']){$('dock-'+key).hidden=key!==name;document.querySelector(`[data-ws-dock="${key}"]`).setAttribute('aria-selected',String(key===name))}bridge?.resize()}
  function closeTab(id){
    if(id===bridge.state().p.id){const other=opened.find(k=>k!==id&&bridge.state().db.projects.some(p=>p.id===k));if(other&&!bridge.openProject(other))return}
    opened=opened.filter(k=>k!==id);persistTabs();render();
  }
  function run(command){
    document.querySelectorAll('.workspace-menu[open]').forEach(el=>el.open=false);
    if($('commandDialog').open)$('commandDialog').close();
    const [kind,value]=command.split(':');
    if(kind==='action')bridge.action(value);
    else if(kind==='tool'){open(bridge.state().p.id);bridge.tool(value)}
    else if(kind==='opening'){open(bridge.state().p.id);bridge.opening(value)}
    else if(kind==='kind'){open(bridge.state().p.id);bridge.place(value)}
    else if(kind==='mode'){open(bridge.state().p.id);bridge.mode(value)}
    else if(kind==='camera')bridge.camera(value);else if(kind==='legacyCamera')bridge.legacyCamera(Number(value));
    else if(kind==='dock')setDock(value);
    else if(command==='search')showSearch();
    else if(command==='saveView')editView();
    else if(command==='closeTab')closeTab(bridge.state().p.id);
    else if(command==='toggleDock'){document.body.classList.toggle('dock-collapsed');bridge.resize()}
    render();
  }
  function renderPalette(){
    if(!bridge)return;const {s}=bridge.state();
    const identity=s.tool+':'+(s.placeKind||'')+':'+s.ribbon+':'+s.openingStyle;
    if(identity!==lastTool){lastTool=identity;
      if(['wall','partition','rectangle'].includes(s.tool))paletteGroup='walls';
      else if(s.tool==='opening')paletteGroup=['passThrough','niche'].includes(s.openingStyle)?'windows':'doors';
      else if(s.tool==='door')paletteGroup='doors';
      else if(s.tool==='window')paletteGroup='windows';
      else if(['dimension','line','text'].includes(s.tool)||s.ribbon==='document')paletteGroup='cad';
      else if(s.tool==='object')paletteGroup=Cabinets.isCabinet({kind:s.placeKind})?'cabinets':BIM.catalog[s.placeKind]?.group==='电气'?'electrical':'objects';
      else if(s.ribbon==='interior')paletteGroup='cabinets';
    }
    $('toolCategory').value=paletteGroup;
    const rows=palettes[paletteGroup].rows;
    $('contextTools').innerHTML=rows.map(([label,cmd])=>commandButton(label,cmd,`class="${cmd==='tool:'+s.tool||['door','window','opening'].includes(s.tool)&&cmd==='opening:'+s.openingStyle||s.tool==='object'&&cmd==='kind:'+s.placeKind?'active':''}"`)).join('');
    $('paletteHint').textContent=t(paletteGroup==='doors'||paletteGroup==='windows'?'点击墙体放置，选中后在属性中调整尺寸。':paletteGroup==='cabinets'||paletteGroup==='objects'||paletteGroup==='electrical'?'选择构件后点击平面放置；选中可移动和编辑。':'点击起点和终点；Esc 结束，V 返回选择。');
  }
  function render(){
    if(!bridge)return;const {p,s,db}=bridge.state();
    opened=opened.filter(id=>db.projects.some(v=>v.id===id));
    $('projectTabs').innerHTML=opened.map(id=>{const v=db.projects.find(q=>q.id===id);return `<div class="workspace-tab ${id===p.id?'active':''}"><button data-ws-project="${esc(id)}" title="${esc(v.name)}" data-no-translate>${esc(v.name)}</button><button data-ws-close="${esc(id)}" aria-label="${esc(t('关闭标签')+' '+v.name)}">×</button></div>`}).join('')+commandButton('新建项目','action:new','class="new-tab" aria-label="'+esc(t('新建项目'))+'"');
    $('workspaceWelcome').hidden=opened.includes(p.id);
    $('workspaceWelcome').parentElement.classList.toggle('workspace-closed',!opened.includes(p.id));
    const selection=s.selected?.type+':'+s.selected?.id;
    if(s.selected&&selection!==lastSelection)setDock('properties');lastSelection=selection;
    const projects=db.projects.filter(v=>v.name.toLocaleLowerCase().includes(treeQuery.toLocaleLowerCase()));
    $('projectTree').innerHTML=projects.map(v=>`<div class="tree-project ${v.id===p.id?'current':''}"><button data-ws-project="${esc(v.id)}"><span aria-hidden="true">${v.id===p.id?'▾':'▸'} ▱</span><span data-no-translate>${esc(v.name)}</span></button>${v.id===p.id?`<div class="tree-children">${v.floors.map(f=>`<button data-ws-floor="${esc(f.id)}" class="${f.id===s.floor&&s.mode==='plan'?'active':''}"><span>▧</span> <span data-no-translate>${esc(f.name)}</span> · <span>${esc(t('平面图'))}</span></button>`).join('')}${commandButton('三维','mode:3d')}${commandButton('图纸','mode:layout')}${commandButton('材料与门窗表','mode:schedule')}</div>`:''}</div>`).join('')||`<p class="note">${esc(t('没有匹配的项目'))}</p>`;
    renderViews();renderPalette();document.querySelectorAll('[data-ws-command]').forEach(b=>b.disabled=!bridge.can(b.dataset.wsCommand));
  }
  function renderViews(){if(!bridge)return;const {p}=bridge.state();
    $('viewsPanel').innerHTML=`<div class="group-title">${esc(t('保存的工作视图'))}</div>${(p.savedViews||[]).map(v=>`<div class="saved-view-row ${activeSaved===v.id?'active':''}"><button data-ws-view="${esc(v.id)}" data-no-translate>☆ ${esc(v.name)}</button><button data-ws-view-edit="${esc(v.id)}" aria-label="${esc(t('管理视图')+' '+v.name)}">⋯</button></div>`).join('')}${commandButton('保存工作视图','saveView','class="wide"')}${p.cameras?.length?'<div class="group-title">'+esc(t('保存的视角'))+'</div>'+p.cameras.map((c,i)=>commandButton(c.name,'legacyCamera:'+i,'data-no-translate')).join(''):''}<p class="note">${esc(t('保存楼层、图层、相机和图纸设置，随项目备份。'))}</p>`;
  }
  function editView(id){const {p}=bridge.state(),v=p.savedViews?.find(v=>v.id===id);
    bridge.dialog(v?'管理视图':'保存工作视图',`<form id="workspaceViewForm"><input type="hidden" name="viewId" value="${esc(id||'')}"><label class="field">${esc(t('视图名称'))}<input name="name" maxlength="100" required value="${esc(v?.name||t('工作视图')+' '+((p.savedViews?.length||0)+1))}"></label>${v?`<label class="field"><input type="checkbox" name="replace">${esc(t('用当前画面更新视图设置'))}</label>`:''}<p class="note">${esc(t('保存楼层、图层、相机和图纸设置，随项目备份。'))}</p><div class="dialog-actions"><button type="button" data-action="close">${esc(t('取消'))}</button><button class="primary">${esc(t('保存'))}</button></div>${v?`<button type="button" class="danger" data-ws-view-delete="${esc(id)}">${esc(t('删除视图（可撤销）'))}</button>`:''}</form>`);
  }
  function commands(){const seen=new Set;return Object.entries({...menus,'门窗样式':[...palettes.doors.rows,...palettes.windows.rows]}).flatMap(([group,rows])=>rows.flatMap(([label,cmd,key])=>{if(seen.has(cmd)||cmd==='search')return[];seen.add(cmd);return[{label,cmd,key,group}]})).concat(Object.entries(BIM.catalog).filter(([k])=>!seen.has('kind:'+k)).map(([k,v])=>({label:v.label,cmd:'kind:'+k,group:'构件库'})))}
  function searchResults(){const q=$('commandSearch').value.trim().toLocaleLowerCase();const rows=commands().filter(v=>!q||[v.label,t(v.label),v.cmd,v.group,t(v.group)].some(x=>x.toLocaleLowerCase().includes(q))).slice(0,60);
    $('commandResults').innerHTML=rows.map(v=>`<button data-ws-command="${esc(v.cmd)}" ${bridge.can(v.cmd)?'':'disabled'}><span>${esc(t(v.label))}<small>${esc(t(v.group))}</small></span><kbd>${esc(v.key||'↵')}</kbd></button>`).join('')||`<p>${esc(t('没有匹配的命令'))}</p>`;
  }
  function showSearch(){$('commandSearch').value='';searchResults();$('commandDialog').showModal();$('commandSearch').focus()}
  function init(api){bridge=api;const {p}=api.state();try{const raw=JSON.parse(localStorage.getItem(prefKey));opened=Array.isArray(raw)?raw.filter(x=>typeof x==='string'):[]}catch{}open(p.id);
    document.body.classList.add('cad-workspace');
    for(const [k,c] of Object.entries(BIM.catalog))if(c.group==='橱柜')palettes.cabinets.rows.push([c.label,'kind:'+k]);
    palettes.cabinets.rows.push(['连续橱柜','action:cabinetRun'],['柜体展开','mode:cabinet']);
    const bar=document.createElement('nav');bar.className='workspace-menubar';bar.setAttribute('aria-label','应用菜单');bar.innerHTML=Object.entries(menus).map(([label,rows])=>`<details class="workspace-menu"><summary>${esc(t(label))}</summary><div class="workspace-dropdown">${rows.map(([label,cmd,key])=>`<button data-ws-command="${esc(cmd)}"><span>${esc(t(label))}</span><kbd>${esc(key||'')}</kbd></button>`).join('')}</div></details>`).join('')+`<button class="tool-search-button" data-ws-command="search">⌕ <span>${esc(t('工具搜索'))}</span><kbd>⌘/Ctrl K</kbd></button>`;document.querySelector('header').after(bar);
    bar.addEventListener('toggle',e=>{if(e.target.open){const menu=e.target.querySelector('.workspace-dropdown');if(menu)menu.style.top=innerWidth<=850?bar.getBoundingClientRect().bottom+'px':'';bar.querySelectorAll('details').forEach(d=>{if(d!==e.target)d.open=false})}},true);
    const right=document.querySelector('.sidebar.right'),left=document.querySelector('.sidebar.left'),props=document.createElement('section');props.id='dock-properties';props.setAttribute('role','tabpanel');props.append(...right.childNodes);
    right.innerHTML=`<div class="dock-tabs" role="tablist">${[['project','项目'],['library','构件库'],['layers','图层'],['properties','属性']].map(([key,label])=>`<button role="tab" data-ws-dock="${key}" aria-controls="dock-${key}" aria-selected="${key==='project'}">${esc(t(label))}</button>`).join('')}</div><section id="dock-project" role="tabpanel"><div class="panel-title">${esc(t('项目浏览器'))}${commandButton('打开项目','action:projects')}</div><div class="tree-search"><input id="treeSearch" type="search" placeholder="${esc(t('搜索项目名称'))}" aria-label="${esc(t('搜索项目名称'))}"></div><div id="projectTree"></div><div id="workspaceViews"></div><div class="tree-actions">${commandButton('新建项目','action:new')}${commandButton('回收站','action:trash')}</div></section><section id="dock-library" role="tabpanel"></section><section id="dock-layers" role="tabpanel"><div class="panel-title">${esc(t('图层显示与锁定'))}</div><p class="note">${esc(t('隐藏或锁定的构件不可编辑。锁定也保护关联修改。'))}</p></section>`;
    right.append(props);$('dock-library').append($('libraryPanel'));$('dock-layers').append($('layerPanel'));$('workspaceViews').append($('viewsPanel'));for(const id of ['libraryPanel','layerPanel','viewsPanel'])$(id).hidden=false;
    left.innerHTML=`<div class="panel-title">${esc(t('工具面板'))}<button data-action="toggleLeft" aria-label="${esc(t('收起工具面板'))}">◧</button></div><div class="palette-top">${commandButton('选择','tool:select')}${commandButton('平移','tool:pan')}</div><label class="palette-category"><span>${esc(t('工具分类'))}</span><select id="toolCategory">${Object.entries(palettes).map(([key,v])=>`<option value="${key}">${esc(t(v.name))}</option>`).join('')}</select></label><div id="contextTools"></div><p id="paletteHint" class="note"></p><div id="floorList" hidden></div><div class="palette-bottom">${commandButton('模型检查','action:validate')}${commandButton('操作指南','action:help')}</div>`;
    const center=document.querySelector('.center');center.insertAdjacentHTML('afterbegin','<div id="projectTabs" class="project-tabs" aria-label="打开的项目"></div><section id="workspaceWelcome" hidden><div><span>NEXORA ARCHITECT</span><h2>'+esc(t('开始设计'))+'</h2><p>'+esc(t('关闭标签保留项目，可从项目浏览器重新打开。'))+'</p>'+commandButton('新建项目','action:new')+commandButton('打开项目','action:projects')+'</div></section>');
    document.body.insertAdjacentHTML('beforeend',`<dialog id="commandDialog"><div class="command-head"><input id="commandSearch" type="search" aria-label="${esc(t('工具搜索'))}" placeholder="${esc(t('搜索命令、工具或构件'))}"><button data-ws-search-close aria-label="${esc(t('关闭'))}">Esc</button></div><div id="commandResults"></div></dialog>`);
    document.addEventListener('click',e=>{
      const b=e.target.closest('button');if(b){const d=b.dataset;
        if(d.wsCommand)run(d.wsCommand);
        else if(d.wsDock)setDock(d.wsDock);
        else if(d.wsProject){bridge.openProject(d.wsProject);render()}
        else if(d.wsClose)closeTab(d.wsClose);
        else if(d.wsFloor){open(bridge.state().p.id);bridge.floor(d.wsFloor)}
        else if(d.wsView){const v=bridge.state().p.savedViews.find(v=>v.id===d.wsView);if(v){open(bridge.state().p.id);bridge.restore(v.state);activeSaved=v.id;render()}}
        else if(d.wsViewEdit)editView(d.wsViewEdit);
        else if(d.wsViewDelete){if(bridge.changeViews(v=>v.filter(x=>x.id!==d.wsViewDelete),'视图已删除，可撤销'))$('dialog').close()}
        else if('wsSearchClose'in d)$('commandDialog').close();
      }
      if(!e.target.closest('.workspace-menu'))document.querySelectorAll('.workspace-menu[open]').forEach(el=>el.open=false);
    });
    document.addEventListener('submit',e=>{if(e.target.id!=='workspaceViewForm')return;e.preventDefault();const data=new FormData(e.target),id=String(data.get('viewId')),name=String(data.get('name')).trim();if(!name)return;
      const ok=bridge.changeViews(views=>{const old=views.find(v=>v.id===id);if(old){old.name=name;if(data.has('replace'))old.state=bridge.capture();return views}return [...views,{id:BIM.uid(),name,state:bridge.capture()}]},'工作视图已保存');if(ok){$('dialog').close();setDock('project')}
    });
    $('toolCategory').addEventListener('change',e=>{paletteGroup=e.target.value;renderPalette()});$('treeSearch').addEventListener('input',e=>{treeQuery=e.target.value;render()});$('commandSearch').addEventListener('input',searchResults);
    document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();showSearch();return}if(e.key==='Escape')document.querySelectorAll('.workspace-menu[open]').forEach(d=>d.open=false);
      if($('commandDialog').open&&(e.key==='ArrowDown'||e.key==='ArrowUp'||e.key==='Enter')){const buttons=[...$('commandResults').querySelectorAll('button:not(:disabled)')];if(!buttons.length)return;e.preventDefault();if(e.key==='Enter'){(document.activeElement.closest?.('[data-ws-command]')||buttons[0]).click();return}const at=buttons.indexOf(document.activeElement),next=e.key==='ArrowDown'?(at+1)%buttons.length:(at-1+buttons.length)%buttons.length;buttons[next].focus()}
    });
    setDock('project');render();
    root.addEventListener('nexora-language-change',render);
    document.addEventListener('DOMContentLoaded',render,{once:true});
  }
  root.WorkspaceUI={init,render,renderPalette,renderViews,open,setDock,run};
})(window);
