(function(root){'use strict';const E=root.BIM||(typeof require==='function'?require('./engine.js'):null),C=root.Cabinets;
function kitchenDemo(){
 const next=E.newProject('Atelier Kitchen · 厨卫设计样板'),f=next.floors[0].id;
 E.addRectangle(next,0,0,8.6,4.8,f);E.wall(next,{x:6,y:0},{x:6,y:4.8},f,'interior');
 for(const r of E.detectRooms(next,f))E.roomMeta(next,r,{name:r.center.x<6?'开放厨房':'主卫',material:r.center.x<6?'oak':'stone'});
 E.opening(next,next.walls[2].id,.52,'door');E.opening(next,next.walls[2].id,.12,'door');
 const win=E.opening(next,next.walls[0].id,.22,'window');win.sill=1.15;win.height=1.2;
 const add=(kind,x,y,w,mat,config={})=>{const o=E.object(next,kind,x,y,f);if(w)o.w=w;if(mat)o.material=mat;if(C.isCabinet(o))o.cabinet={...C.defaults(o),style:'shaker',...config};return o};
 add('drawerCabinet',.2,.17,.6,'sage');add('sink',.8,.17,.9,'sage');add('baseCabinet',1.7,.17,.9,'sage');add('stove',2.6,.17,.9,'sage');add('baseCabinet',3.5,.17,.9,'sage',{layout:'mixed'});add('tallCabinet',4.4,.17,.6,'sage');
 add('wallCabinet',.2,.17,.6,'white',{layout:'single'});add('wallCabinet',3.5,.17,.9,'white');
 const island=add('island',2.1,2.65,2,'walnut',{layout:'drawers',drawerCount:3,topMaterial:'white'});island.d=.9;
 add('fridge',.2,3.2,null,null);add('vanity',6.2,.17,1.2,'oak',{layout:'mixed',topMaterial:'white'});
 const shower=add('shower',7.4,3.35,null,null);shower.d=1.2;add('toilet',7.8,.35,null,null);
 return E.validate(next);
}
root.ArchitectTemplates={kitchen:kitchenDemo};if(typeof module!=='undefined')module.exports=root.ArchitectTemplates;
})(typeof window!=='undefined'?window:globalThis);
