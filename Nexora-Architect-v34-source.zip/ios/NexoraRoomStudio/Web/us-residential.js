(function(root){'use strict';
const E=root.BIM||(typeof require==='function'?require('./geometry.js'):null),C=root.Cabinets||(typeof require==='function'?require('./cabinets.js'):null),FT=.3048;
const entries=[{id:'ranch',name:'Ranch',width:54,depth:44,pitch:22,roof:'hip',wall:'white'},{id:'colonial',name:'Colonial',width:56,depth:44,pitch:36,roof:'gable',wall:'white'},{id:'craftsman',name:'Craftsman',width:52,depth:44,pitch:28,roof:'gable',wall:'sage'},{id:'farmhouse',name:'Modern Farmhouse',width:54,depth:46,pitch:40,roof:'gable',wall:'white'}];
function build(id='ranch'){
const t=entries.find(t=>t.id===id);if(!t)throw Error('Unknown North American home');const p=E.newProject(t.name+' · North American Home');p.unit='ft';const f=p.floors[0];f.name='Main Floor';f.height=9*FT;f.slab=6*.0254;
p.site={width:90*FT,depth:100*FT,north:0};p.pricing={currency:'USD',rates:{}};
const W=t.width*FT,D=t.depth*FT,X=22*FT,Y=22*FT,H=3.5*FT;
E.addRectangle(p,0,0,W,D,f.id);
const wall=(ax,ay,bx,by)=>E.wall(p,{x:ax,y:ay},{x:bx,y:by},f.id,'interior');
wall(0,Y,W,Y);wall(X,0,X,Y);wall(37*FT,0,37*FT,Y);wall(0,Y+H,W,Y+H);wall(16*FT,Y+H,16*FT,D);wall(34*FT,Y+H,34*FT,D);
// Split the service wing into a primary bath, laundry and mudroom, all accessed from the hall.
wall(37*FT,11*FT,W,11*FT);wall(46*FT,11*FT,46*FT,Y);
for(const r of E.detectRooms(p,f.id)){
const x=r.center.x/FT,y=r.center.y/FT;let name,type='living',material='oak';
if(y<22){if(x<22){name='Garage';type='garage';material='concrete'}else if(x<37){name='Primary Bedroom';type='bedroom'}else if(y<11){name='Primary Bath';type='bath';material='stone'}else if(x<46){name='Laundry Room';material='stone'}else {name='Mudroom';material='stone'}}else if(y<25.5)name='Hallway';else if(x<16)name='Kitchen & Dining';else if(x<34)name='Living Room';else {name='Bedroom 2';type='bedroom'}
E.roomMeta(p,r,{name,roomType:type,includeLiving:type!=='garage',material});}
for(const w of p.walls){w.material=w.kind==='exterior'?(t.wall==='white'?'siding':t.wall):'white';const L=E.dist(w.a,w.b);}
for(const [x,y]of [[11,22],[29,22],[41,22],[50,22],[8,25.5],[25,25.5],[43,25.5],[37,6]]){const q={x:x*FT,y:y*FT},w=p.walls.find(w=>w.kind==='interior'&&E.projectPoint(q,w.a,w.b).distance<.001);if(w)E.opening(p,w.id,E.projectPoint(q,w.a,w.b).t,'door')}
for(const w of p.walls.filter(w=>w.kind==='exterior')){for(const at of [.2,.7]){try{const o=E.opening(p,w.id,at,'window');o.width=36*.0254;o.height=48*.0254;o.sill=36*.0254;E.validateOpening(p,o)}catch{}}}
const front=p.walls[2];try{E.opening(p,front.id,.48,'door')}catch{}
// Garage opening faces the driveway; remove windows in its opening range.
const back=p.walls[0];p.openings=p.openings.filter(o=>o.wall!==back.id||o.offset>20*FT);const garage=E.opening(p,back.id,11/t.width,'opening');garage.width=16*FT;garage.height=7*FT;garage.offset=3*FT;garage.style='doorway';E.validateOpening(p,garage);
const add=(kind,x,y,w,d)=>{const o=E.object(p,kind,x*FT,y*FT,f.id);if(w)o.w=w*FT;if(d)o.d=d*FT;if(C.isCabinet(o)){o.material='white';o.cabinet={...C.defaults(o),style:'shaker',topMaterial:'quartz'}}return o};
add('bed',25,2,6,6.7);add('wardrobe',23,17,8,2);add('bed',39,32,5,6.5);add('sofa',19,36,8,3.2);add('coffee',21,32,4,2);add('armchair',29,34,3,3);add('plant',17,40,2,2);
add('fridge',1,27,3,2.7);add('baseCabinet',1,26,2.5,2);add('sink',3.5,26,3,2);add('stove',6.5,26,2.5,2);add('wallCabinet',1,26,2.5,1);add('wallCabinet',9,26,2.5,1);const island=add('island',7,31,5,3);island.cabinet.style='shaker';add('table',7,38,5,3);
add('vanity',39,1,5,2);add('toilet',50,1);add('shower',49,6,3,3);
const porch=add('deck',18,t.depth,18,6);porch.material='walnut';porch.z=-.15;porch.h=.15;
for(const x of [18.4,35]){const o=add('column',x,t.depth+5, .6,.6);o.material='white'}
// Basement is separate from above-grade living area and has its own floor and stair opening.
const basement={id:E.uid(),name:'Basement',elevation:-9*FT,height:8.5*FT,slab:.1524};p.floors.push(basement);E.addRectangle(p,0,0,W,D,basement.id);for(const w of p.walls.filter(w=>w.floor===basement.id)){w.height=basement.height;w.material='concrete'}
for(const r of E.detectRooms(p,basement.id))E.roomMeta(p,r,{name:'Unfinished Basement',includeLiving:false,material:'concrete'});
const stair=E.object(p,'stairs',46*FT,27*FT,basement.id);stair.w=3.6*FT;stair.d=13.8*FT;stair.h=9*FT;E.fitStair(p,stair);E.addStairwell(p,stair);
const roof=E.autoRoof(p,f.id,t.roof);roof.pitch=t.pitch;roof.material='charcoal';roof.overhang=18*.0254;
p.usHome={style:t.id,aboveGradeSqFt:E.estimate(p,f.id).livingNetArea/FT**2,garage:true,basement:true,frontPorch:true};
return E.validate(p);
}
const summaries=new Map();function summary(id){if(!summaries.has(id)){const p=build(id);summaries.set(id,{livingSqFt:Number(p.usHome.aboveGradeSqFt.toFixed(2))})}return {...summaries.get(id)}}
const api={entries,build,summary};root.USResidential=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
