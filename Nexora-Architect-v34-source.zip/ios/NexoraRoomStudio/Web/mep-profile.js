(function(root){
  'use strict';
  const M=typeof module!=='undefined'?require('./mep-avoidance.js'):root.MEP;
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
  const length=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
  // Read-only, directed network traversal. A profile follows existing pipes; it never reroutes them.
  function profile(p,{start,end,runId}={}){
    const data=M.data(p),nodes=new Map(data.nodes.filter(n=>n.system==='drain').map(n=>[n.id,n]));
    const runs=data.runs.filter(r=>r.system==='drain'),byId=new Map(runs.map(r=>[r.id,r]));
    const paths=new Map(),path=r=>{if(!paths.has(r.id))paths.set(r.id,M.path(p,r));return paths.get(r.id)};
    let selected=[];
    if(runId){const r=byId.get(runId);if(!r)throw Error('请选择排水管线');selected=[r];start=r.a;end=r.b}
    else{
      if(!nodes.has(start)||!nodes.has(end)||start===end)throw Error('请选择两个不同的排水节点');
      const outgoing=new Map(),cost=new Map([[start,0]]),parent=new Map(),done=new Set();
      for(const r of [...runs].sort((a,b)=>a.id.localeCompare(b.id))){if(!outgoing.has(r.a))outgoing.set(r.a,[]);outgoing.get(r.a).push(r)}
      while(done.size<nodes.size){let id=null,best=Infinity;for(const [n,c]of cost)if(!done.has(n)&&c<best){id=n;best=c}if(id===null||id===end)break;done.add(id);
        for(const r of outgoing.get(id)||[]){if(done.has(r.b))continue;const ps=path(r),weight=ps.reduce((s,q,i)=>s+(i?length(ps[i-1],q):0),0),next=best+weight;if(next<(cost.get(r.b)??Infinity)){cost.set(r.b,next);parent.set(r.b,r)}}
      }
      if(!parent.has(end))throw Error('按排水流向未找到连接路径');
      for(let id=end;id!==start;){const r=parent.get(id);if(!r||selected.length>=nodes.size)throw Error('按排水流向未找到连接路径');selected.push(r);id=r.a}selected.reverse();
    }
    const segments=[],markers=[],branchNodes=[],startPoint=M.position(p,nodes.get(start));let station=0,developed=0,requiredDrop=0;
    markers.push({id:start,label:nodes.get(start).label,station,z:startPoint.z});
    for(const r of selected){let ps=path(r);if(ps.length<2)ps=[M.position(p,nodes.get(r.a)),M.position(p,nodes.get(r.b))];
      if(runs.filter(v=>v.a===r.a).length>1)branchNodes.push(r.a);
      for(let i=1;i<ps.length;i++){
        if(segments.length>=4096)throw Error('路径超过4096段，请选择较短区间');
        const a=ps[i-1],b=ps[i],horizontal=Math.hypot(b.x-a.x,b.y-a.y),actual=length(a,b),drop=a.z-b.z;
        const status=actual<1e-6?'zero':drop<-.00001?'uphill':drop+1e-6<horizontal*r.slope?'slope':'ok';
        segments.push({runId:r.id,label:r.label,index:i,a:{...a},b:{...b},stationStart:station,stationEnd:station+horizontal,length:actual,horizontal,drop,slope:horizontal>1e-7?drop/horizontal:null,minimumSlope:r.slope,diameter:r.diameter,bottomStart:a.z-r.diameter/2,bottomEnd:b.z-r.diameter/2,status});
        station+=horizontal;developed+=actual;requiredDrop+=horizontal*r.slope;
      }
      const n=nodes.get(r.b),q=M.position(p,n);markers.push({id:n.id,label:n.label,station,z:q.z});
    }
    const endPoint=M.position(p,nodes.get(end));
    return{start,end,runIds:selected.map(r=>r.id),segments,markers,branchNodes:[...new Set(branchNodes)],horizontal:station,length:developed,drop:startPoint.z-endPoint.z,requiredDrop,issues:segments.filter(s=>s.status!=='ok').length};
  }
  const statusText={ok:'达到设定坡度',uphill:'逆坡',slope:'低于设定坡度',zero:'零长度连接'};
  function profileLocation(p,segment){
    const r=M.item(p,'mepRun',segment.runId),mid={x:(segment.a.x+segment.b.x)/2,y:(segment.a.y+segment.b.y)/2,z:(segment.a.z+segment.b.z)/2};
    const floors=[...new Set([M.floorAtZ(p,mid.z),r.floor,...p.floors.map(f=>f.id)])];let best;
    for(const floor of floors)for(const ps of M.floorPaths(p,r,floor))for(let i=0;i<ps.length;i++){
      const a=ps[i],b=ps[i+1]||a,dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z,den=dx*dx+dy*dy+dz*dz,k=den?Math.max(0,Math.min(1,((mid.x-a.x)*dx+(mid.y-a.y)*dy+(mid.z-a.z)*dz)/den)):0;
      const point={x:a.x+k*dx,y:a.y+k*dy,z:a.z+k*dz},distance=length(mid,point);if(!best||distance<best.distance-1e-8)best={floor,point,distance};
    }
    if(!best){const node=M.item(p,'mepNode',r.a);return{type:'mepNode',id:node.id,floor:node.floor,point:M.position(p,node),distance:0}}
    return{...best,type:'mepRun',id:r.id};
  }
  function profileCSV(p,report,t=x=>x){
    const unit=p.unit==='ft'?'ft':'m',scale=unit==='ft'?1/.3048:1,num=v=>Number((v*scale).toFixed(6));
    const rows=[[t('管线编号'),t('名称'),t('管段'),t('起始累计水平长度')+' '+unit,t('终止累计水平长度')+' '+unit,t('三维实际长度')+' '+unit,t('起点中心标高')+' '+unit,t('终点中心标高')+' '+unit,t('起点管外底标高')+' '+unit,t('终点管外底标高')+' '+unit,t('管线外径')+' '+unit,t('落差')+' '+unit,t('实际坡度 %'),t('设定最小坡度 %'),t('检查结果')]];
    for(const s of report.segments)rows.push([s.runId,s.label,s.index,num(s.stationStart),num(s.stationEnd),num(s.length),num(s.a.z),num(s.b.z),num(s.bottomStart),num(s.bottomEnd),num(s.diameter),num(s.drop),s.slope===null?'':Number((s.slope*100).toFixed(6)),s.minimumSlope*100,t(statusText[s.status])]);
    const cell=v=>{let s=String(v);if(typeof v!=='number'&&/^(?:\s*[=+@-]|[\t\r\n])/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"'};
    return '\uFEFF'+rows.map(row=>row.map(cell).join(',')).join('\r\n');
  }
  function profileSVG(p,report,t=x=>x){
    const unit=p.unit==='ft'?'ft':'m',scale=unit==='ft'?1/.3048:1,n=v=>(v*scale).toFixed(3),tr=s=>esc(t(s));
    const points=report.segments.flatMap(s=>[s.a.z,s.b.z,s.bottomStart,s.bottomEnd]),low=Math.min(...points),high=Math.max(...points),margin=Math.max(.2,(high-low)*.12),bottom=low-margin,top=high+margin;
    const x=v=>110+v/Math.max(report.horizontal,1)*1030,y=v=>165+(top-v)/(top-bottom)*395;
    const text=(px,py,value,size=13,color='#34454c',anchor='start')=>`<text x="${px}" y="${py}" font-size="${size}" fill="${color}" text-anchor="${anchor}">${value}</text>`;
    let body=`<rect width="1280" height="720" fill="white"/>${text(50,43,tr('排水展开纵剖面'),25)}${text(50,72,esc(p.name),16)}${text(50,103,tr('累计水平长度')+' '+n(report.horizontal)+' '+unit+' · '+tr('三维实际长度')+' '+n(report.length)+' '+unit+' · '+tr('落差')+' '+n(report.drop)+' '+unit,14)}${text(50,129,tr('问题管段')+' '+report.issues+' · '+tr('横纵比例不同，以数值为准'),13)}`;
    for(let i=0;i<=5;i++){const z=bottom+(top-bottom)*i/5,yy=y(z);body+=`<path d="M110 ${yy}H1140" stroke="#e0e7e9"/>`+text(98,yy+4,n(z),12,'#52636c','end')}
    for(let i=0;i<=8;i++){const s=Math.max(report.horizontal,1)*i/8,xx=x(s);body+=`<path d="M${xx} 165V560" stroke="#edf1f3"/>`+text(xx,583,n(s),12,'#52636c','middle')}
    for(const f of p.floors.filter(f=>f.elevation>=bottom&&f.elevation<=top).slice(0,20)){const yy=y(f.elevation);body+=`<path d="M110 ${yy}H1140" stroke="#7c90a0" stroke-dasharray="7 5"/>`+text(1135,yy-4,esc(f.name.length>24?f.name.slice(0,24)+'…':f.name),11,'#52636c','end')}
    for(const s of report.segments){const color=s.status==='ok'?'#087c64':'#b63239',title=esc(s.label)+' · '+tr(statusText[s.status])+' · '+(s.slope===null?tr('竖向管段'):(s.slope*100).toFixed(3)+'%');body+=`<g><title>${title}</title><path d="M${x(s.stationStart)} ${y(s.bottomStart)}L${x(s.stationEnd)} ${y(s.bottomEnd)}" stroke="#879aa1" stroke-width="1.5" stroke-dasharray="5 4" fill="none"/><path d="M${x(s.stationStart)} ${y(s.a.z)}L${x(s.stationEnd)} ${y(s.b.z)}" stroke="${color}" stroke-width="3" fill="none"/><circle cx="${x(s.stationStart)}" cy="${y(s.a.z)}" r="3" fill="${color}"/><circle cx="${x(s.stationEnd)}" cy="${y(s.b.z)}" r="3" fill="${color}"/></g>`}
    body+=text(625,611,tr('累计水平长度')+' / '+unit,14,'#34454c','middle');
    body+=`<text x="27" y="370" transform="rotate(-90 27 370)" font-size="14" text-anchor="middle">${tr('世界标高')} / ${unit}</text>`;
    body+=text(50,645,tr('实线：中心线；灰虚线：中心标高减外径一半；红色：坡度或零长度问题。'),13);
    body+=text(50,674,tr('管外底不是管内底；未包含壁厚、水力或规范校核。'),13);
    body+=text(50,699,'NEXORA ARCHITECT · '+tr('按既有管线展开，转弯不保留平面方向。'),12);
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1280 720" width="1280" height="720" role="img" aria-label="${tr('排水展开纵剖面')}" style="font-family:Arial,sans-serif">${body}</svg>`;
  }
  Object.assign(M,{drainProfile:profile,profileCSV,profileSVG,profileLocation,profileStatus:statusText});root.MEP=M;if(typeof module!=='undefined')module.exports=M;
})(typeof window!=='undefined'?window:globalThis);
