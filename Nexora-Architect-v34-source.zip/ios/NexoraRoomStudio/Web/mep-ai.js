(function(root){
 'use strict';
 const E=root.BIM||require('./geometry.js'),M=typeof module!=='undefined'?require('./mep-profile.js'):root.MEP;
 function scopeFor(p,systems,selected=null,allowRebuild=false){
  if(!Array.isArray(systems)||!systems.length||new Set(systems).size!==systems.length||systems.some(k=>!Object.hasOwn(M.systems,k)))throw Error('请选择有效机电系统');
  if(selected){if(!['mepNode','mepRun'].includes(selected.type))throw Error('请选择机电对象');const v=M.item(p,selected.type,selected.id);if(!v||!systems.includes(v.system))throw Error('所选对象不在修改范围内')}
  return{systems:[...systems],selected:selected?{type:selected.type,id:selected.id}:null,allowRebuild:allowRebuild===true};
 }
 function context(p,scope){
  scope=scopeFor(p,scope.systems,scope.selected,scope.allowRebuild);const d=M.data(p),selected=scope.selected;let nodes=d.nodes.filter(n=>scope.systems.includes(n.system)),runs=d.runs.filter(r=>scope.systems.includes(r.system));
  if(selected?.type==='mepRun'){runs=runs.filter(r=>r.id===selected.id);nodes=nodes.filter(n=>runs.some(r=>r.a===n.id||r.b===n.id))}
  if(selected?.type==='mepNode'){nodes=nodes.filter(n=>n.id===selected.id);runs=[]}
  const counts={nodes:nodes.length,runs:runs.length};nodes=nodes.slice(0,60);runs=runs.slice(0,60);
  return{units:'m',displayUnits:p.unit,scope,counts,omitted:{nodes:counts.nodes-nodes.length,runs:counts.runs-runs.length},summary:M.schedule(p),nodes:nodes.map(n=>({id:n.id,system:n.system,kind:n.kind,label:n.label,zM:n.z,world:M.position(p,n),heightReference:n.fixtureId?'fixture base':'floor elevation',loadW:n.loadW||0,flowLpm:n.flowLpm||0,gasKW:n.gasKW||0})),runs:runs.map(r=>({id:r.id,system:r.system,label:r.label,a:r.a,b:r.b,diameterM:r.diameter,slope:r.slope,routing:r.routing,lengthM:M.runLength(p,r)})),issues:M.checks(p).filter(i=>nodes.some(n=>n.id===i.id)||runs.some(r=>r.id===i.id)).slice(0,30),engineeringVerified:false};
 }
 const fields={set_run:['type','runId','diameterM','slope'],set_node:['type','nodeId','zM','loadW','flowLpm','gasKW'],avoid:['type','runId','clearanceM','detourM'],optimize:['type','systems','drainSlope'],generate:['type','systems','replace','outletSpacingM','sprinklerSpacingM','drainSlope']};
 function proposal(raw,plan,scope){
  scope=scopeFor(raw,scope.systems,scope.selected,scope.allowRebuild);const ctx=context(raw,scope),ids={mepNode:new Set(ctx.nodes.map(n=>n.id)),mepRun:new Set(ctx.runs.map(r=>r.id))};
  if(!plan||typeof plan.summary!=='string'||plan.summary.length>3000||!Array.isArray(plan.assumptions)||plan.assumptions.length>12||plan.assumptions.some(x=>typeof x!=='string'||x.length>500)||!Array.isArray(plan.operations)||plan.operations.length>12)throw Error('AI 修改方案格式无效');
  let next=E.clone(raw);const value=(v,min,max)=>{if(typeof v!=='number'||!Number.isFinite(v)||v<min||v>max)throw Error('机电参数超出范围');return v};
  const target=(type,id)=>{if(!ids[type].has(id))throw Error('AI 引用了范围外或未知对象');const v=M.item(next,type,id);if(!v)throw Error('AI 引用了范围外或未知对象');return v};
  for(const op of plan.operations){const keys=fields[op?.type];if(!keys||Object.keys(op).some(k=>!keys.includes(k))||keys.some(k=>!Object.hasOwn(op,k)))throw Error('AI 修改操作无效');
   if(op.type==='set_run'){const r=target('mepRun',op.runId);if(op.diameterM!==null)r.diameter=value(op.diameterM,.001,2);if(op.slope!==null){if(r.system!=='drain')throw Error('只有排水管线支持坡度参数');r.slope=value(op.slope,0,.2)}}
   else if(op.type==='set_node'){const n=target('mepNode',op.nodeId);if(op.zM!==null)n.z=value(op.zM,-500,500);for(const [key,systems]of [['loadW',['electric']],['flowLpm',['cold','hot','fire']],['gasKW',['gas']]])if(op[key]!==null){if(!systems.includes(n.system))throw Error('参数不适用于此机电系统');n[key]=value(op[key],0,1000000)}}
   else if(op.type==='avoid'){target('mepRun',op.runId);const result=M.avoid(next,op.runId,{clearance:value(op.clearanceM,0,1),detour:value(op.detourM,.1,20)});if(!result.ok)throw Error(result.reason);next=result.next}
   else{
    if(scope.selected||!Array.isArray(op.systems)||!op.systems.length||new Set(op.systems).size!==op.systems.length||op.systems.some(k=>!scope.systems.includes(k)))throw Error('AI 重建操作超出所选范围');
    if(op.type==='optimize'){if(!scope.allowRebuild)throw Error('尚未允许重建现有管线');next=M.optimize(next,{selected:op.systems,drainSlope:value(op.drainSlope,.001,.1)})}
    else{if(typeof op.replace!=='boolean'||op.replace&&!scope.allowRebuild)throw Error('尚未允许重建现有管线');next=M.generate(next,{selected:op.systems,replace:op.replace,outletSpacing:value(op.outletSpacingM,1,10),sprinklerSpacing:value(op.sprinklerSpacingM,1,10),drainSlope:value(op.drainSlope,.001,.1)})}
   }
  }
  next=E.validate(next);const changes=[];
  const facts=(p,type,v)=>!v?null:type==='mepNode'?{system:v.system,zM:v.z,world:M.position(p,v),loadW:v.loadW||0,flowLpm:v.flowLpm||0,gasKW:v.gasKW||0}:{system:v.system,a:v.a,b:v.b,diameterM:v.diameter,slope:v.slope,routing:v.routing,lengthM:M.runLength(p,v),path:M.path(p,v)};
  for(const [key,type]of [['nodes','mepNode'],['runs','mepRun']]){const a=new Map(M.data(raw)[key].map(v=>[v.id,v])),b=new Map(M.data(next)[key].map(v=>[v.id,v]));for(const id of new Set([...a.keys(),...b.keys()])){const before=facts(raw,type,a.get(id)),after=facts(next,type,b.get(id));if(JSON.stringify(before)!==JSON.stringify(after))changes.push({id,type,label:(b.get(id)||a.get(id)).label,before,after})}}
  const beforeClashes=M.clashes(raw),afterClashes=M.clashes(next);
  return{next,changes,beforeChecks:M.checks(raw),afterChecks:M.checks(next),beforeClashes:{count:beforeClashes.issues.length,truncated:beforeClashes.truncated},afterClashes:{count:afterClashes.issues.length,truncated:afterClashes.truncated},beforeSummary:M.schedule(raw),afterSummary:M.schedule(next)};
 }
 root.MEPAI={scopeFor,context,proposal};if(typeof module!=='undefined')module.exports=root.MEPAI;
})(typeof window!=='undefined'?window:globalThis);
