(function(root) {
  'use strict';
  const C = root.Cabinets, D = root.Drawings, E = root.BIM;
  function front(o, { dimensions = true, unit = 'm' } = {}) {
    const g = C.geometry(o), color = key => E.materials[key]?.color || '#eeeae0';
    const rect = (x, y, w, h, fill, extra = '') => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}" stroke="#596960" stroke-width=".008" ${extra}/>`;
    let out = rect(-o.w / 2, -g.bodyTop, o.w, g.bodyTop - g.bodyBottom, color(o.material));
    if (g.bodyBottom) out += rect(-o.w / 2 + .01, -g.bodyBottom, o.w - .02, g.bodyBottom, '#4d5653');
    for (const part of g.parts.filter(p => p.role === 'shelf' || p.role === 'countertop'))
      out += rect(part.x - part.w / 2, -part.y - part.h / 2, part.w, part.h, color(part.material));
    for (const f of g.fronts) {
      out += rect(f.x - f.w / 2, -f.y - f.h / 2, f.w, f.h, color(o.material));
      if (f.rail) out += rect(f.x - f.w / 2 + f.rail, -f.y - f.h / 2 + f.rail, f.w - 2 * f.rail, f.h - 2 * f.rail, color(o.material), 'fill-opacity=".6"');
      if (f.handle) out += rect(f.handle.x - f.handle.w / 2, -f.handle.y - f.handle.h / 2, f.handle.w, f.handle.h, '#3d4748');
    }
    if (dimensions) {
      const len = v => unit === 'ft' ? D.length(v, unit) : Math.round(v * 1000) + ' mm';
      out += D.dim({ x: o.w / 2, y: 0 }, { x: -o.w / 2, y: 0 }, len(o.w), .27).replace('font-size="0.15"','font-size="0.1"');
      const dx=o.w/2+.28;out += `<path d="M${o.w/2} ${-o.h}H${dx+.05}M${o.w/2} 0H${dx+.05}M${dx} ${-o.h}V0" fill="none" stroke="#91a087" stroke-width=".008"/>` + D.text(dx-.045,-o.h/2,len(o.h),.1,`text-anchor="middle" transform="rotate(-90 ${dx-.045} ${-o.h/2})"`);
      out += D.text(0, -o.h - .18, '深 ' + len(o.d), .1, 'text-anchor="middle"');
    }
    return { markup: out, box: { x: -o.w / 2 - .18, y: -o.h - .38, w: o.w + .8, h: o.h + .9 } };
  }
  function sheet(p, objects) {
    let x = 0, out = '', height = 0;
    const rows = C.schedule(p);
    for (const o of objects) {
      const r = rows.find(r => r.object.id === o.id), f = front(o, { unit: p.unit });
      out += `<g transform="translate(${x + o.w / 2 + .18},0)">${f.markup}${D.text(0, .48, r.number + ' · ' + E.catalog[o.kind].label, .11, 'text-anchor="middle"')}</g>`;
      x += f.box.w + .15; height = Math.max(height, o.h);
    }
    return { markup: out, box: { x: 0, y: -height - .5, w: Math.max(1, x), h: height + 1.2 }, title: '柜体正面展开图' };
  }
  root.CabinetDrawings = { front, sheet };
  if (typeof module !== 'undefined') module.exports = root.CabinetDrawings;
})(typeof window !== 'undefined' ? window : globalThis);
