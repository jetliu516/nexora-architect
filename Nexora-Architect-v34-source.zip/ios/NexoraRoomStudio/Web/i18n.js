(function(){'use strict';
const names={zh:'中文',en:'English',es:'Español',ja:'日本語',de:'Deutsch',fr:'Français',it:'Italiano'};
let lang=typeof navigator!=='undefined'?(navigator.language||'en').toLowerCase().split('-')[0]:'en';try{lang=localStorage.getItem('nexora-language-preference-v2')||localStorage.getItem('nexora-language')||lang}catch{}if(!names[lang])lang='en';
const original=new WeakMap(),attrs=new WeakMap();
// User-authored data and drawings are never translated by this UI adapter.
const excluded='script,style,textarea,svg,canvas,pre,[contenteditable],#projectMenu,#floorList,#floorSelect,#aiMessages,#aiSummary,#aiAttachmentList,.ai-attachment-chip,.room-directory,[data-camera-index],.sheet-title,#inspector>.meta,.project-card h3,[data-no-translate]';
function t(text){if(lang==='zh')return text;const dict=window.NexoraLocales?.[lang]||{};if(dict[text])return dict[text];const trimmed=text.trim();if(dict[trimmed])return text.replace(trimmed,dict[trimmed]); // Match whole labels, unit suffixes, or fully known CJK fragments in UI text.
const unit=trimmed.match(/^(.*?) (\/ (?:ft \/ in|m|ft|cm|mm|in))$/);if(unit&&dict[unit[1]])return text.replace(trimmed,dict[unit[1]]+' '+unit[2]);
const m=trimmed.match(/^([^\p{L}\p{N}]*)(.*?)([^\p{L}\p{N}]*)$/u);if(m&&dict[m[2]])return text.replace(trimmed,m[1]+dict[m[2]]+m[3]);const chunks=trimmed.match(/[\u3400-\u9fff]+/g);if(chunks?.length&&chunks.every(x=>dict[x]))return text.replace(/[\u3400-\u9fff]+/g,x=>dict[x]);return text;}
function skip(el){return !el||!!el.closest(excluded)}
function text(node){if(skip(node.parentElement))return;const now=node.nodeValue;let rec=original.get(node);if(!rec||now!==rec.output)rec={source:now};rec.output=t(rec.source);original.set(node,rec);if(now!==rec.output)node.nodeValue=rec.output;}
// Control labels are UI even when their values, options or drawing contents are user data.
function element(el){if(el.closest('script,style,[contenteditable],[data-no-translate]'))return;let rec=attrs.get(el)||{};for(const key of ['title','placeholder','aria-label']){if(!el.hasAttribute(key))continue;const now=el.getAttribute(key);if(!rec[key]||now!==rec[key].output)rec[key]={source:now};rec[key].output=t(rec[key].source);if(now!==rec[key].output)el.setAttribute(key,rec[key].output)}attrs.set(el,rec);}
function scan(root){if(root.nodeType===3){text(root);return}if(root.nodeType!==1)return;element(root);const walk=document.createTreeWalker(root,NodeFilter.SHOW_ELEMENT|NodeFilter.SHOW_TEXT);let node;while(node=walk.nextNode())node.nodeType===3?text(node):element(node);}
function apply(){document.documentElement.lang=lang==='zh'?'zh-CN':lang;scan(document.body);document.title='Nexora Architect';document.getElementById('languageSelect').value=lang;}
window.NexoraI18n={t,get language(){return lang},set(value){if(!names[value])return;lang=value;try{localStorage.setItem('nexora-language-preference-v2',lang)}catch{}apply();window.dispatchEvent(new CustomEvent('nexora-language-change',{detail:lang}))}};
const select=document.createElement('select');select.id='languageSelect';select.setAttribute('aria-label','Language / 语言');select.setAttribute('data-no-translate','');for(const [value,name]of Object.entries(names)){const option=document.createElement('option');option.value=value;option.textContent=name;select.append(option)}select.onchange=()=>window.NexoraI18n.set(select.value);document.querySelector('.header-end').prepend(select);apply();
new MutationObserver(records=>{for(const r of records){if(r.type==='childList')r.addedNodes.forEach(scan);else if(r.type==='characterData')text(r.target);else element(r.target)}}).observe(document.body,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['title','placeholder','aria-label']});
})();
