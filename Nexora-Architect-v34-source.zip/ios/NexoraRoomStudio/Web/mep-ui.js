(function(root){
  'use strict';
  const M=root.MEP,E=root.BIM,U=root.Units,esc=root.Drawings.esc,t=x=>root.NexoraI18n?.t(x)||x;
  let bridge,preview,placing,clashReport;
  const current=()=>bridge.state(),txt=x=>esc(t(x)),options=(entries,value)=>(value==='waypoints'?[...entries,['waypoints','自定义路点']]:entries).map(([k,v])=>`<option value="${esc(k)}" ${k===value?'selected':''}>${txt(v)}</option>`).join('');
  function field(label,key,value,{length=false,min,max,disabled=false}={}){
    const p=current().p,display=length?U.length(value,p.unit,3):value;
    return `<label class="field">${txt(label)}${length?' / '+(p.unit==='ft'?'ft':'m'):''}<input data-mep-field="${key}" ${length?'data-mep-length':''} ${disabled?'disabled':''} type="${length?'text':'number'}" value="${esc(display)}" required ${min!=null?'min="'+min+'"':''} ${max!=null?'max="'+max+'"':''} step="any"></label>`;
  }
  function inspector(p,type,v){
    const spec=M.systems[v.system];let out=`<div class="eyebrow">MEP / ${spec.code}</div><h2>${txt(type==='mepNode'?M.kinds[v.kind]:'管线')}</h2><p>${txt(spec.label)}</p><label class="field">${txt('名称')}<input data-mep-field="label" type="text" maxlength="100" value="${esc(v.label)}"></label>`;
    if(type==='mepNode'){
      out+=`<div class="pair">${field('X','x',v.x,{length:true,disabled:!!v.fixtureId})}${field('Y','y',v.y,{length:true,disabled:!!v.fixtureId})}</div>${field(v.fixtureId?'距宿主底部高度':'离地高度','z',v.z,{length:true})}`;
      if(v.fixtureId)out+=`<button class="wide" data-mep-host="${esc(v.fixtureId)}">${txt('定位关联构件')}</button><p class="note">${txt('端口随宿主移动；删除宿主会同时删除端口和相连管线，可撤销。')}</p>`;
      if(v.system==='electric')out+=field('额定功率 W','loadW',v.loadW||0,{min:0,max:1000000});
      if(['cold','hot','fire'].includes(v.system))out+=field('设计流量 L/min','flowLpm',v.flowLpm||0,{min:0,max:1000000});
      if(v.system==='gas')out+=field('燃气负荷 kW','gasKW',v.gasKW||0,{min:0,max:1000000});
      out+=`<button class="wide" data-mep-action="connect">${txt('连接两个端口')}</button>`;
    }else{
      const nodes=M.data(p).nodes.filter(n=>n.system===v.system),choices=nodes.map(n=>[n.id,n.label+' · '+p.floors.find(f=>f.id===n.floor).name+' · '+n.id.slice(-5)]);
      out+=`<p>${txt('三维实际长度')} <b>${U.length(M.runLength(p,v),p.unit)}</b></p><label class="field">${txt('起点')}<select data-mep-field="a">${options(choices,v.a)}</select></label><label class="field">${txt('终点')}<select data-mep-field="b">${options(choices,v.b)}</select></label><label class="field">${txt('正交走向')}<select data-mep-field="routing">${options([['xy','X → Y'],['yx','Y → X'],['direct','直接连接端点']],v.routing)}</select></label>${v.routing==='waypoints'?'<p class="note">'+txt('两端保持连接；中间路点固定在起点楼层坐标中，设备移动后请重新检查。')+'</p>':v.routing==='direct'?'<p class="note">'+txt('此管段直接连接两端标高；修改节点高度可改变坡度。')+'</p>':field('管线起始高度','level',v.level,{length:true})}${field('管线外径','diameter',v.diameter,{length:true})}`;
      out+=`<div class="pair"><button data-mep-select="${esc(v.a)}" data-mep-type="mepNode">${txt('定位起点')}</button><button data-mep-select="${esc(v.b)}" data-mep-type="mepNode">${txt('定位终点')}</button></div>`;
      if(v.system==='drain')out+=field('排水坡度 %','slopePercent',v.slope*100,{min:0,max:20})+`<p class="note">${txt('排水从起点流向终点；逆坡会列入检查。')}</p>`;
    }
    if(type==='mepRun')out+=root.MEPRouteUI?.buttons(v.id)||'';
    if(type==='mepRun'&&v.system==='drain')out+=root.MEPProfileUI?.button(v.id)||'';
    out+=root.MEPAIUI?.button()||'';if(type==='mepRun')out+=root.PenetrationUI?.button(v.id)||'';
    return out+`<button class="wide danger" data-action="delete">${txt('删除选中')}</button><button class="wide" data-mep-action="open">${txt('机电工作区')}</button><p class="note">${txt('管径、标高与间距是方案参数，尚未通过负荷、压力、流速、消防水力或规范校核。')}</p>`;
  }
  function overview(){
    preview=null;const {p}=current(),d=M.data(p),rows=M.schedule(p),issues=M.checks(p);
    bridge.dialog('机电工作区',`<div class="mep-overview"><p>${txt('电气、冷水、热水、排水、燃气、消防喷淋共用可编辑连接模型。')}</p><div class="callout">${txt('方案布置 · 工程计算待完成')}<p>${txt('管径、标高与间距是方案参数，尚未通过负荷、压力、流速、消防水力或规范校核。')}</p></div><div class="dialog-actions"><button data-mep-action="generate" class="primary">${txt('自动生成机电方案')}</button><button data-mep-action="optimize" ${!d.runs.length?'disabled':''}>${txt('优化共享干管')}</button><button data-mep-action="clashes" ${!d.runs.length?'disabled':''}>${txt('碰撞检查')}</button>${root.MEPProfileUI?.button()||''}${root.MEPAIUI?.button()||''}${root.PenetrationUI?.button()||''}<button data-mep-action="node">${txt('添加机电节点')}</button><button data-mep-action="connect" ${d.nodes.length<2?'disabled':''}>${txt('连接两个端口')}</button><button data-mep-action="csv">CSV</button><button data-action="dxf">DXF</button></div><div class="table-scroll"><table class="schedule-table"><thead><tr><th>${txt('系统')}</th><th>${txt('节点')}</th><th>${txt('管线')}</th><th>${txt('三维实际长度')}</th><th></th></tr></thead><tbody>${rows.map(r=>`<tr><td>${txt(r.label)}</td><td>${r.nodes}</td><td>${r.runs}</td><td>${U.length(r.length,p.unit)}</td><td><button data-mep-show="${r.system}">${txt('单独查看')}</button></td></tr>`).join('')}</tbody></table></div><p class="note">${txt('长度按独立管段累计，未包含损耗与配件；手工重合管段仍可能重复计数。')}</p><div class="dialog-actions"><button data-mep-show="all">${txt('显示全部机电系统')}</button><button data-mep-action="checks">${txt('检查连接与参数')} (${issues.length})</button></div><details><summary>${txt('机电对象列表')} (${d.nodes.length+d.runs.length})</summary><div class="mep-object-list">${[...d.nodes.map(n=>({v:n,type:'mepNode'})),...d.runs.map(r=>({v:r,type:'mepRun'}))].slice(0,160).map(({v,type})=>`<button data-mep-select="${esc(v.id)}" data-mep-type="${type}"><span>${txt(M.systems[v.system].label)} · <span data-no-translate>${esc(v.label)}</span></span><small data-no-translate>${esc(p.floors.find(f=>f.id===v.floor).name)} · ${v.id.slice(-5)}</small></button>`).join('')}</div>${d.nodes.length+d.runs.length>160?`<p>${txt('列表显示前 160 项，其余对象可在平面中选择。')}</p>`:''}</details></div>`);
  }
  function generation(){
    const {p}=current();bridge.dialog('自动生成机电方案',`<form id="mepGenerateForm"><p>${txt('为全部楼层生成概念布置。厨卫管线绑定已有设备；电气按房间布置，喷头避开楼板洞口。')}</p><p>${txt('采用共享干管与逐层立管，分支节点可逐个编辑；不自动避障。')}</p><div class="mep-systems">${Object.entries(M.systems).map(([key,spec])=>`<label><input type="checkbox" name="systems" value="${key}" checked>${txt(spec.label)}</label>`).join('')}</div><div class="pair"><label class="field">${txt('插座布置间距')} / ${p.unit==='ft'?'ft':'m'}<input name="outletSpacing" value="${esc(U.length(3,p.unit))}" required></label><label class="field">${txt('喷头网格间距')} / ${p.unit==='ft'?'ft':'m'}<input name="sprinklerSpacing" value="${esc(U.length(3,p.unit))}" required></label></div><label class="field">${txt('排水坡度 %')}<input name="slope" type="number" min=".1" max="10" step="any" value="2" required></label><label class="mep-replace"><input type="checkbox" name="replace">${txt('替换所选系统的全部机电对象，包括手工编辑；其他系统保持原样。')}</label><p class="note">${txt('燃气端口按灶台候选生成，需确认设备使用燃气。热水器补水、通气、阀门、保护装置与回路分配需继续深化。')}</p><button class="primary">${txt('预览生成结果')}</button></form>`);
  }
  function optimizeForm(){
    const {p}=current(),rows=M.schedule(p);bridge.dialog('优化共享干管',`<form id="mepOptimizeForm"><p>${txt('保留源点和设备端口；重建所选系统的全部管线及自动分支节点。')}</p><div class="mep-systems">${rows.map(r=>`<label><input type="checkbox" name="systems" value="${r.system}" checked>${txt(r.label)}</label>`).join('')}</div><label class="field">${txt('排水坡度 %')}<input name="slope" type="number" min=".1" max="10" step="any" value="2" required></label><p class="note">${txt('比较横向和纵向干管的几何长度，不代表全局最短或已避开障碍。请继续运行碰撞检查。')}</p><button class="primary">${txt('预览生成结果')}</button></form>`);
  }
  function showClashes(){
    const {p}=current(),report=M.clashes(p);clashReport={...report,signature:JSON.stringify(p)};
    bridge.dialog('碰撞检查',`<p>${txt('检查管线与管线、墙体实体、楼板实体及构件外包体；扣除已有墙洞和楼板洞口。')}</p><p>${txt('几何提示')}：${report.issues.length}${report.truncated?'＋':''} · ${txt('检查管段')}：${report.segments}</p>${report.truncated?`<p class="callout">${txt('结果达到上限，请先解决已列问题后重新检查；尚未检查完全部模型。')}</p>`:''}${report.issues.length?`<ol class="mep-issues">${report.issues.slice(0,100).map((issue,i)=>`<li><span>${txt(issue.text)}</span><div><button data-mep-clash="${i}">${txt('定位管线')}</button><button data-mep-clash="${i}" data-mep-other="true">${txt('定位相交对象')}</button>${root.MEPRouteUI?.buttons(issue.id,true)||''}</div><small>X ${U.length(issue.point.x,p.unit)} · Y ${U.length(issue.point.y,p.unit)} · Z ${U.length(issue.point.z,p.unit)}</small></li>`).join('')}</ol>`:`<p>${txt('在当前几何检查范围内未发现碰撞；净距要求、套管、防火封堵及规范校核仍需确认。')}</p>`}${report.issues.length>100?`<p>${txt('列表显示前 100 项。修改模型后请重新检查。')}</p>`:''}<p class="note">${txt('构件采用旋转外包体近似，宿主内部接管不报碰撞；尚未检查屋顶、结构构件和规定净距。')}</p><button data-mep-action="open">${txt('机电工作区')}</button>`);
  }
  function locateClash(index,other){
    const {p,s}=current();if(!clashReport||clashReport.signature!==JSON.stringify(p)){bridge.toast('模型已变化，请重新检查');return}
    const issue=clashReport.issues[index];if(!issue)return;const id=other?issue.otherId:issue.id,type=other?issue.otherType:issue.type;
    const value=type==='mepRun'?M.item(p,type,id):type==='object'?p.objects.find(o=>o.id===id):null,layer=WorkspaceModel.layerFor(type,value);if(layer)s.layers[layer]=true;if(type==='object')s.layers.objects=true;
    if(!WorkspaceModel.canSelect(p,s,type,id)){bridge.toast('请先显示并解锁图层：'+WorkspaceModel.labels[layer]);return}
    bridge.close();s.mode='plan';bridge.select(type,id);s.floor=issue.floor;s.center={x:issue.point.x,y:issue.point.y};s.zoom=2;s.mepClash={point:issue.point,floor:issue.floor,signature:clashReport.signature};bridge.refresh();
  }
  function nodeForm(){
    bridge.dialog('添加机电节点',`<form id="mepNodeForm"><label class="field">${txt('系统')}<select name="system" id="mepNewSystem">${options(Object.entries(M.systems).map(([k,v])=>[k,v.label]),'cold')}</select></label><label class="field">${txt('类型')}<select name="kind" id="mepNewKind">${options(M.allowed.cold.map(k=>[k,M.kinds[k]]),'inlet')}</select></label><label class="field">${txt('离地高度')}<input name="z" value="0.5 m" required></label><button class="primary">${txt('在平面选择位置')}</button></form>`);
  }
  function connectForm(){
    const {p,s}=current(),d=M.data(p);if(d.nodes.length<2){bridge.toast('请先添加至少两个节点');return}
    const start=s.selected?.type==='mepNode'?M.item(p,'mepNode',s.selected.id):d.nodes[0];
    const choices=d.nodes.map(n=>[n.id,t(M.systems[n.system].label)+' · '+n.label+' · '+p.floors.find(f=>f.id===n.floor).name+' · '+n.id.slice(-5)]);
    bridge.dialog('连接两个端口',`<form id="mepConnectForm"><label class="field">${txt('起点')}<select name="a">${options(choices,start?.id)}</select></label><label class="field">${txt('终点')}<select name="b">${options(choices,d.nodes.find(n=>n.system===start?.system&&n.id!==start.id)?.id)}</select></label><p>${txt('排水从起点流向终点；逆坡会列入检查。')}</p><button class="primary">${txt('创建连接')}</button></form>`);
  }
  function showChecks(){
    const {p}=current(),issues=M.checks(p);bridge.dialog('检查连接与参数',`<p>${txt('方案布置 · 工程计算待完成')}</p><p>${txt('连接或输入提示')}：${issues.length}</p>${issues.length?`<ul class="mep-issues">${issues.slice(0,100).map(v=>`<li>${txt(v.text)} <button data-mep-select="${esc(v.id)}" data-mep-type="${v.type}">${txt('定位')}</button></li>`).join('')}</ul>`:`<p>${txt('当前网络没有断连、逆坡或缺少用量输入；这不代表工程计算或规范审查通过。')}</p>`}<p class="note">${txt('还需完成：电压与回路保护、给水压力、热水器补水、排水通气、燃气设备确认、消防水力、穿墙套管和碰撞校核。')}</p><button data-mep-action="open">${txt('机电工作区')}</button>`);
  }
  function action(name){switch(name){case'open':overview();break;case'optimize':optimizeForm();break;case'clashes':showClashes();break;case'generate':generation();break;case'node':nodeForm();break;case'connect':connectForm();break;case'checks':showChecks();break;case'csv':bridge.exportFile('Nexora-MEP.csv',M.csv(current().p,t),'text/csv;charset=utf-8');break;case'apply':{
    const {p,s}=current();if(!preview||preview.before!==JSON.stringify(p)){bridge.toast('模型已变化，请重新预览');return}
    const next=preview.next;if(bridge.transact(()=>Object.assign(p,E.clone(next)),'机电方案已应用，可整体撤销')){preview=null;s.selected=null;for(const key of Object.keys(M.systems))s.layers[M.layer(key)]=true;bridge.close();bridge.refresh()}break;
  }}}
  function pointer(q){const {p,s}=current();if(s.tool!=='mepNode'||!placing)return false;
    const params=placing;let added;const ok=bridge.transact(()=>{added=M.node(p,params.system,params.kind,s.floor,q.x,q.y,params.z)},'机电节点已添加');if(ok){bridge.tool('select');bridge.select('mepNode',added.id)}return true;
  }
  function init(b){bridge=b;root.MEPRouteUI?.init(b);root.MEPProfileUI?.init(b);root.MEPAIUI?.init(b);root.PenetrationUI?.init(b);
    document.addEventListener('click',e=>{const button=e.target.closest('button');if(!button)return;const d=button.dataset;
      if(d.mepAction)action(d.mepAction);
      if(d.mepClash!=null){locateClash(Number(d.mepClash),d.mepOther==='true');return}
      if(d.mepSelect){const {p,s}=current();if(!WorkspaceModel.canSelect(p,s,d.mepType,d.mepSelect)){const v=M.item(p,d.mepType,d.mepSelect);bridge.toast('请先显示并解锁图层：'+M.systems[v.system].label);return}bridge.close();s.mode='plan';bridge.select(d.mepType,d.mepSelect)}
      if(d.mepHost){bridge.close();bridge.select('object',d.mepHost)}
      if(d.mepShow){const {s}=current();for(const key of Object.keys(M.systems))s.layers[M.layer(key)]=d.mepShow==='all'||d.mepShow===key;s.mode='plan';s.selected=null;bridge.close();bridge.refresh()}
    });
    document.addEventListener('change',e=>{const el=e.target,{p,s}=current();
      if(el.id==='mepNewSystem'){document.getElementById('mepNewKind').innerHTML=options(M.allowed[el.value].map(k=>[k,M.kinds[k]]));return}
      if(!el.dataset.mepField)return;
      if(!el.checkValidity()){el.reportValidity();bridge.refresh();return}
      const v=s.selected&&M.item(p,s.selected.type,s.selected.id);if(!v)return;
      bridge.transact(()=>{const key=el.dataset.mepField;const value=el.hasAttribute('data-mep-length')?U.parse(el.value,p.unit):(el.type==='number'||el.dataset.numericControl==='true')?Number(el.value):el.value;
        if(key==='slopePercent')v.slope=value/100;else v[key]=value;if(key==='a')v.floor=M.item(p,'mepNode',v.a).floor;
      },'机电参数已更新');
    });
    document.addEventListener('submit',e=>{const form=e.target;if(!form.id.startsWith('mep'))return;e.preventDefault();const data=new FormData(form),{p,s}=current();
      try{if(form.id==='mepOptimizeForm'){
        const selected=data.getAll('systems'),next=M.optimize(p,{selected,drainSlope:Number(data.get('slope'))/100});preview={before:JSON.stringify(p),next};
        const old=new Map(M.schedule(p).map(r=>[r.system,r]));bridge.dialog('共享干管优化预览',`<p>${txt('保留源点和设备端口；重建所选系统的全部管线及自动分支节点。')}</p><div class="table-scroll"><table class="schedule-table"><thead><tr><th>${txt('系统')}</th><th>${txt('当前线路总长')}</th><th>${txt('候选线路总长')}</th></tr></thead><tbody>${M.schedule(next).filter(r=>selected.includes(r.system)).map(r=>`<tr><td>${txt(r.label)}</td><td>${U.length(old.get(r.system)?.length||0,p.unit)}</td><td>${U.length(r.length,p.unit)}</td></tr>`).join('')}</tbody></table></div><p class="note">${txt('比较横向和纵向干管的几何长度，不代表全局最短或已避开障碍。请继续运行碰撞检查。')}</p><button class="primary" data-mep-action="apply">${txt('应用方案（可撤销）')}</button>`);
      }else if(form.id==='mepGenerateForm'){
        const next=M.generate(p,{selected:data.getAll('systems'),replace:data.has('replace'),outletSpacing:U.parse(data.get('outletSpacing'),p.unit),sprinklerSpacing:U.parse(data.get('sprinklerSpacing'),p.unit),drainSlope:Number(data.get('slope'))/100});
        preview={before:JSON.stringify(p),next};const selected=data.getAll('systems'),before=M.data(p),after=M.data(next),count=(list)=>list.filter(n=>selected.includes(n.system)).length;
        bridge.dialog('机电生成预览',`<p>${txt('所选系统现有对象将替换为下列新方案，原建筑和其他系统保持原样。')}</p><p>${txt('替换节点')}：${count(before.nodes)} → ${count(after.nodes)} · ${txt('替换管线')}：${count(before.runs)} → ${count(after.runs)}</p><div class="table-scroll"><table class="schedule-table"><tbody>${M.schedule(next).filter(r=>selected.includes(r.system)).map(r=>`<tr><td>${txt(r.label)}</td><td>${r.nodes} ${txt('节点')}</td><td>${U.length(r.length,p.unit)}</td></tr>`).join('')}</tbody></table></div>${selected.filter(k=>!after.nodes.some(n=>n.system===k)).map(k=>`<p>${txt(M.systems[k].label)}：${txt('未发现适用设备，未生成该系统。')}</p>`).join('')}<p class="note">${txt('管径、标高与间距是方案参数，尚未通过负荷、压力、流速、消防水力或规范校核。')}</p><button class="primary" data-mep-action="apply">${txt('应用方案（可撤销）')}</button>`);
      }else if(form.id==='mepNodeForm'){
        const system=String(data.get('system'));if(!WorkspaceModel.available(s,M.layer(system)))throw Error('请先显示并解锁图层：'+M.systems[system].label);
        placing={system,kind:String(data.get('kind')),z:U.parse(data.get('z'),p.unit)};bridge.close();bridge.tool('mepNode');bridge.toast('请在平面点击放置机电节点');
      }else if(form.id==='mepConnectForm'){
        let r;if(bridge.transact(()=>{r=M.connect(p,String(data.get('a')),String(data.get('b')))},'管线已连接')){bridge.close();bridge.select('mepRun',r.id)}
      }}catch(error){bridge.toast(error.message)}
    });
  }
  root.MEPUI={init,action,inspector,pointer};
})(window);
