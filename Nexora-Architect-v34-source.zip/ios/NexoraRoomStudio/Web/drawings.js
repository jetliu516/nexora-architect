(function (root) {
  "use strict";
  const E = BIM,
    R=root.RoofModel||(typeof require==="function"?require("./roof-model.js"):null),
    RD=root.RoofDisplay||(typeof require==="function"?require("./roof-display.js"):null),
    U =
      root.Units ||
      (typeof require === "function" ? require("./units.js") : null),
    esc = (s) =>
      String(s ?? "").replace(
        /[&<>"']/g,
        (c) =>
          ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;",
          })[c],
      ),
    n = (v) => E.round(v, 4),
    pts = (ps) => ps.map((p) => n(p.x) + "," + n(p.y)).join(" "),
    length = (v, unit) => U.length(v, unit),
    text = (x, y, s, size = 0.18, extra = "") =>
      `<text x="${n(x)}" y="${n(y)}" font-family="Arial,PingFang SC,sans-serif" font-size="${size}" ${extra.includes('fill="')?'':'fill="#64705e"'} ${extra}>${esc(s)}</text>`;
  function dim(a, b, label, offset = 0.4) {
    const L = E.dist(a, b);
    if (L < 0.001) return "";
    let v = E.mul(E.sub(b, a), 1 / L),
      q = { x: v.y * offset, y: -v.x * offset },
      A = E.add(a, q),
      B = E.add(b, q),
      C = E.lerp(A, B, 0.5),
      tick = E.mul({ x: v.x + v.y, y: v.y - v.x }, 0.055);
    return `<g fill="none" stroke="#91a087" stroke-width=".012"><path d="M${a.x} ${a.y}L${A.x + q.x * 0.2} ${A.y + q.y * 0.2}M${b.x} ${b.y}L${B.x + q.x * 0.2} ${B.y + q.y * 0.2}M${A.x} ${A.y}L${B.x} ${B.y}M${A.x - tick.x} ${A.y - tick.y}L${A.x + tick.x} ${A.y + tick.y}M${B.x - tick.x} ${B.y - tick.y}L${B.x + tick.x} ${B.y + tick.y}"/></g>${text(C.x, C.y - 0.07, label, 0.15, 'text-anchor="middle" paint-order="stroke" stroke="#fcfdf9" stroke-width=".07"')}`;
  }
  function wallPoly(w) {
    const L = E.dist(w.a, w.b),
      v = E.mul(E.sub(w.b, w.a), w.thickness / (2 * L)),
      normal = { x: -v.y, y: v.x };
    return [
      E.add(w.a, normal),
      E.add(w.b, normal),
      E.sub(w.b, normal),
      E.sub(w.a, normal),
    ];
  }
  function objectShape(o, selected) {
    if (o.kind === "stairs") {
      const parts = E.stairLayout(o),
        path = parts
          .map(
            (t) =>
              `<polygon points="${pts(t.points)}" fill="${E.materials[o.material]?.color || "#c9af88"}" fill-opacity=".65" stroke="${selected ? "#bf864e" : "#758574"}" stroke-width=".025"/>`,
          )
          .join("");
      const first = parts[0].points,
        last = parts[parts.length - 1].points,
        center = (ps) => ({
          x: ps.reduce((s, p) => s + p.x, 0) / ps.length,
          y: ps.reduce((s, p) => s + p.y, 0) / ps.length,
        }),
        a = center(first),
        b = center(last);
      return `<g data-entity="object" data-id="${o.id}" style="cursor:move"><rect x="${o.x}" y="${o.y}" width="${o.w}" height="${o.d}" fill="transparent" transform="rotate(${o.angle},${o.x+o.w/2},${o.y+o.d/2})"/>${path}${text(a.x, a.y, "起", 0.16)}${text(b.x, b.y, "↑ 上", 0.16)}</g>`;
    }

    const group = E.catalog[o.kind].group,
      c = E.materials[o.material]?.color || "#bac3ac",
      cx = o.x + o.w / 2,
      cy = o.y + o.d / 2;
    if(o.kind==='cornerUnit'){
      const outline=[[0,0],[1,0],[1,1],[.34,1],[0,.66]].map(([x,y])=>[o.x+(o.cornerMirror?1-x:x)*o.w,o.y+y*o.d]);
      return `<g data-entity="object"data-id="${o.id}" transform="rotate(${o.angle},${cx},${cy})"><polygon points="${outline.map(q=>q.join(',')).join(' ')}" fill="${c}" stroke="${selected?'#bf864e':'#778774'}" stroke-width=".025"/>${text(cx,cy,'角',.12,'text-anchor="middle"')}</g>`;
    }
    let s = `<g data-entity="object" data-id="${o.id}" transform="rotate(${o.angle},${cx},${cy})" style="cursor:move"><rect x="${o.x}" y="${o.y}" width="${o.w}" height="${o.d}" rx=".035" fill="${c}" fill-opacity=".68" stroke="${selected ? "#bf864e" : "#778774"}" stroke-width="${selected ? 0.045 : 0.022}"/>`;
    const path = (d) =>
      `<path d="${d}" fill="none" stroke="#758574" stroke-width=".025"/>`;
    if (o.kind === "bed")
      s +=
        `<rect x="${o.x + 0.1}" y="${o.y + 0.12}" width="${o.w - 0.2}" height=".4" rx=".06" fill="#fff" stroke="#afb9a6" stroke-width=".015"/>` +
        path(`M${o.x + 0.06} ${o.y + 0.7}h${o.w - 0.12}`);
    else if (o.kind === "sofa" || o.kind === "armchair")
      s +=
        `<rect x="${o.x + 0.14}" y="${o.y + 0.18}" width="${Math.max(0.05, o.w - 0.28)}" height="${Math.max(0.05, o.d - 0.28)}" rx=".06" fill="#c5cdbb"/>` +
        path(`M${cx} ${o.y + 0.18}v${o.d - 0.28}`);
    else if (group === "橱柜" || ["sink", "stove", "vanity"].includes(o.kind)) {
      s += path(
        `M${o.x + 0.04} ${o.y + o.d - 0.08}h${o.w - 0.08}M${cx} ${o.y + 0.04}v${o.d - 0.08}`,
      );
      if (["sink", "vanity"].includes(o.kind))
        s += `<rect x="${o.x + o.w * 0.2}" y="${o.y + o.d * 0.2}" width="${o.w * 0.6}" height="${o.d * 0.6}" rx=".07" fill="#f9fcf7" stroke="#6d8073" stroke-width=".02"/>`;
      if (o.kind === "stove")
        for (let x of [0.3, 0.7])
          for (let y of [0.3, 0.7])
            s += `<circle cx="${o.x + o.w * x}" cy="${o.y + o.d * y}" r=".075" fill="#79827a"/>`;
    } else if (o.kind === "stairs") {
      for (let i = 1; i < (o.steps || 17); i++)
        s += path(`M${o.x} ${o.y + (o.d * i) / (o.steps || 17)}h${o.w}`);
      s += path(
        `M${cx} ${o.y + o.d - 0.15}V${o.y + 0.2}l-.12 .2M${cx} ${o.y + 0.2}l.12 .2`,
      );
    } else if (o.kind === "table")
      for (let x of [0.25, 0.75])
        for (let y of [-0.15, 1.15])
          s += `<rect x="${o.x + o.w * x - 0.18}" y="${o.y + o.d * y - 0.18}" width=".36" height=".36" rx=".07" fill="#e7e6d6" stroke="#85917d" stroke-width=".02"/>`;
    else if (["tree", "plant"].includes(o.kind))
      s += `<circle cx="${cx}" cy="${cy}" r="${Math.min(o.w, o.d) * 0.45}" fill="#99b092" stroke="#6d8b65" stroke-width=".03"/>`;
    else if (group === "电气")
      s += text(
        cx,
        cy + 0.08,
        o.kind === "light" ? "⊗" : o.kind === "switch" ? "S" : "⊙",
        0.23,
        'text-anchor="middle"',
      );
    if(o.kitchenSku && typeof o.kitchenSku==='string' && o.kind!=='cabinetFiller') s+=text(cx,cy+.03,o.kitchenSku.slice(0,16),Math.min(.1,o.w/5),'text-anchor="middle"');
    s += "</g>";
    return s;
  }
  const geometryPath = (geometry) =>
    geometry
      .map((poly) =>
        poly
          .map(
            (r) =>
              r
                .map((v, i) => (i ? "L" : "M") + n(v[0]) + " " + n(v[1]))
                .join(" ") + "Z",
          )
          .join(" "),
      )
      .join(" ");
  function plan(p, s, { print = false } = {}) {
    const selected = s.selected,
      rs = E.detectRooms(p, s.floor),
      ws = p.walls.filter((w) => w.floor === s.floor),
      layers = s.layers;
    let out = `<defs><pattern id="wood" width=".6" height=".24" patternUnits="userSpaceOnUse"><path d="M0 .24H.6" stroke="#b8a78a" stroke-width=".009" opacity=".5"/></pattern><pattern id="tile" width=".5" height=".5" patternUnits="userSpaceOnUse"><path d="M0 0H.5V.5" fill="none" stroke="#a8b7b0" stroke-width=".013" opacity=".5"/></pattern></defs>`;
    for (const u of (p.underlays || []).filter(
      (v) => v.floor === s.floor && v.visible !== false,
    ))
      out += `<image href="${u.data}" x="${u.x}" y="${u.y}" width="${u.w}" height="${u.d}" opacity="${u.opacity}" transform="rotate(${u.angle},${u.x + u.w / 2},${u.y + u.d / 2})" pointer-events="none"/>`;
    const siteVisible=s.landscape!==false && E.siteFloor?.(p)?.id===s.floor && p.walls.some(w=>w.floor===s.floor),driveway=siteVisible?E.siteDriveway(p):null;
    if(driveway){const d=driveway;out+=`<g data-site-driveway="true" pointer-events="none"><rect x="${d.x}" y="${d.y}" width="${d.w}" height="${d.d}" fill="#d4d8d1" stroke="#34453d" stroke-width="1.8" vector-effect="non-scaling-stroke"/>`;for(let y=d.y+2;y<d.y+d.d;y+=2)out+=`<path d="M${d.x} ${y}h${d.w}" stroke="#7e8980" stroke-width="1" vector-effect="non-scaling-stroke"/>`;out+='</g>'}
    if (s.reference && !print) {
      const current = p.floors.find((f) => f.id === s.floor),
        below = p.floors
          .filter((f) => f.elevation < current.elevation)
          .sort((a, b) => b.elevation - a.elevation)[0];
      if (below) {
        for (const w of p.walls.filter((w) => w.floor === below.id))
          out += `<path d="M${w.a.x} ${w.a.y}L${w.b.x} ${w.b.y}" stroke="#c7807b" stroke-width=".035" stroke-dasharray=".12 .08" opacity=".6" pointer-events="none"/>`;
      }
    }
    if (layers.rooms)
      rs.forEach((r) => {
        out += `<g data-entity="room" data-id="${esc(r.id)}"><path d="${geometryPath(r.surfaceGeometry)}" fill="${print ? "#fff" : E.materials[r.material]?.color || "#e5e0cd"}" fill-rule="evenodd" fill-opacity="${print ? 1 : 0.22}" stroke="none"/><path d="${geometryPath(r.netGeometry)}" fill-rule="evenodd" fill="url(#${r.material === "stone" ? "tile" : "wood"})"/></g>`;
      });
    for (const h of (p.slabOpenings || []).filter((v) => layers.rooms && v.floor === s.floor))
      out += `<g data-entity="slabOpening" data-id="${h.id}"><path d="${geometryPath(E.openingGeometry(p, h))}" fill="#9bb6bf" fill-opacity=".12" fill-rule="evenodd" stroke="${selected?.id === h.id ? "#bd8047" : "#758e9b"}" stroke-width=".04" stroke-dasharray=".12 .08"/></g>`;
    if (s.roof && layers.roofs) {
      const roofModel=R.build(p);
      for(const surface of roofModel.surfaces.filter(r=>r.floor===s.floor))out+=`<path data-entity="roof" data-id="${esc(surface.roofId)}" data-roof-id="${esc(surface.roofId)}" data-roof-role="surface" d="${surface.rings.map(r=>r.map((v,i)=>(i?'L':'M')+n(v[0])+' '+n(v[2])).join('')+'Z').join('')}" fill="${selected?.id===surface.roofId?'#cbb393':'#e2dfd5'}" fill-opacity=".18" fill-rule="evenodd" stroke="none"/>`;
      for(const edge of roofModel.edges.filter(e=>e.floors.includes(s.floor)))out+=`<path data-entity="roof" data-id="${esc(edge.roofIds[0])}" data-roof-id="${esc(edge.roofIds[0])}" data-roof-role="edge" data-roof-edge="${edge.kind}" d="M${n(edge.a[0])} ${n(edge.a[2])}L${n(edge.b[0])} ${n(edge.b[2])}" fill="none" stroke="${edge.kind==='valley'?'#427d91':'#9a7150'}" stroke-width=".035" ${edge.kind==='valley'?'stroke-dasharray=".16 .08"':''}/>`;
    }
    if (layers.walls)
      for (const w of ws) {
        const sel = selected?.id === w.id;
        out += `<g data-entity="wall" data-id="${w.id}" style="cursor:pointer"><polygon points="${pts(wallPoly(w))}" fill="${sel ? "#ba8b54" : print ? "#3d4b3d" : "#586e58"}" stroke="${sel ? "#916a40" : "#435d48"}" stroke-width=".015"/><path d="M${w.a.x} ${w.a.y}L${w.b.x} ${w.b.y}" stroke="transparent" stroke-width="${Math.max(0.16, w.thickness)}"/></g>`;
        if (layers.dimensions && (s.autoDimensions || sel || w.kind === "exterior"))
          out += dim(
            w.a,
            w.b,
            length(E.dist(w.a, w.b), p.unit),
            sel ? 0.55 : 0.46,
          );

      }
    if (layers.openings)
      for (const o of p.openings) {
        const w = ws.find((w) => w.id === o.wall);
        if (!w) continue;
        let L = E.dist(w.a, w.b),
          a = E.lerp(w.a, w.b, o.offset / L),
          deg = (Math.atan2(w.b.y - w.a.y, w.b.x - w.a.x) * 180) / Math.PI,
          sel = selected?.id === o.id,
          th = w.thickness;
        out += `<g data-entity="opening" data-id="${o.id}" transform="translate(${a.x},${a.y}) rotate(${deg})" style="cursor:pointer">${Openings.plan(o,th,sel)}</g>`;
      }
    if (layers.objects)
      p.objects
        .filter(
          (o) =>
            o.floor === s.floor &&
            (E.catalog[o.kind].group !== "电气" || layers.electrical),
        )
        .forEach((o) => (out += objectShape(o, selected?.id === o.id)));
    if (layers.labels)
      rs.forEach((r) => {
        const sel = selected?.id === r.id;
        out += `<g pointer-events="none">${text(r.center.x, r.center.y + 0.09, r.name, 0.22, `data-user-content="true" text-anchor="middle" font-weight="500" fill="${sel ? "#ad7841" : "#4e654f"}"`)}${text(r.center.x, r.center.y + 0.37, (r.netArea * (p.unit === "ft" ? 10.76391 : 1)).toFixed(1) + (p.unit === "ft" ? " sq ft" : " m²"), 0.14, 'text-anchor="middle"')}</g>`;
      });
    if (layers.annotations)
      p.annotations
        .filter((a) => a.floor === s.floor)
        .forEach((a) => {
          out += `<g data-entity="annotation" data-id="${a.id}">`;
          if (a.kind === "dimension")
            out += dim(a.a, a.b, length(E.dist(a.a, a.b), p.unit), 0.3);
          else if (a.kind === "line")
            out += `<path d="M${a.a.x} ${a.a.y}L${a.b.x} ${a.b.y}" stroke="#7293a0" stroke-width=".025"/>`;
          else out += text(a.a.x, a.a.y, a.text, 0.22);
          out += "</g>";
        });
    if(selected?.type === "room" && root.RoomDimensions && layers.dimensions){
      const r=rs.find(r=>r.id===selected.id), m=r && root.RoomDimensions.measure(p,r);
      if(m) out += `<g pointer-events="none">${dim({x:m.left,y:m.top+.5},{x:m.right,y:m.top+.5},"净宽 "+length(m.width,p.unit),0)}${dim({x:m.left+.45,y:m.bottom},{x:m.left+.45,y:m.top},"净深 "+length(m.depth,p.unit),0)}</g>`;
    }
    if(driveway&&layers.labels!==false){const d=driveway,width=d.w*.8,size=width/6.8,height=size*1.65,x=d.x+d.w/2,y=d.y+d.d*.6;out+=`<g data-site-driveway-label="true" pointer-events="none" data-no-translate><rect x="${x-width/2}" y="${y-height/2}" width="${width}" height="${height}" rx="${size*.2}" fill="#ffffff" stroke="#14251c" stroke-width="1.5" vector-effect="non-scaling-stroke"/>${text(x,y,'DRIVEWAY',size,'fill="#14251c" font-weight="900" text-anchor="middle" dominant-baseline="central"')}</g>`}
    if(root.MEP)out+=root.MEP.plan(p,s);
    if(root.Penetrations)out+=root.Penetrations.plan(p,s);
    if(s.autoDimensions&&layers.dimensions){
      const bounds=E.bounds(p,s.floor);
      out+='<g data-auto-dimensions="true" pointer-events="none">'+dim({x:bounds.x,y:bounds.y},{x:bounds.x+bounds.w,y:bounds.y},'总宽 '+length(bounds.w,p.unit),1.1)+dim({x:bounds.x,y:bounds.y+bounds.d},{x:bounds.x,y:bounds.y},'总深 '+length(bounds.d,p.unit),1.1);
      for(const o of p.openings){const w=ws.find(w=>w.id===o.wall);if(!w)continue;const L=E.dist(w.a,w.b);out+=dim(E.lerp(w.a,w.b,o.offset/L),E.lerp(w.a,w.b,(o.offset+o.width)/L),length(o.width,p.unit),.8)}out+='</g>';
    }
    if (!print && layers.walls && selected?.type === 'wall') {
      const w=ws.find(w=>w.id===selected.id);
      if(w) for(const end of ['a','b']) { const q=w[end],radius=s.handleRadius||.11;
        out+=`<g data-handle="${end}" data-id="${w.id}" style="cursor:crosshair"><circle cx="${q.x}" cy="${q.y}" r="${radius*2}" fill="transparent" pointer-events="all"/><circle cx="${q.x}" cy="${q.y}" r="${radius}" fill="#fff" stroke="#be8650" stroke-width="${radius*.35}" pointer-events="none"/></g>`;
      }
    }
    return out;
  }
  function elevation(p, s, direction = "front") {
    let fs = p.floors,
      front = direction === "front" || direction === "back",
      sign = ["back", "right"].includes(direction) ? -1 : 1,
      project = (q) => ({ x: (front ? q[0] : q[2]) * sign, y: -q[1] }),
      polys = [],
      lines = [];
    for (const w of p.walls) {
      if (w.kind !== "exterior") continue;
      let f = fs.find((f) => f.id === w.floor),
        a = [w.a.x, f.elevation, w.a.y],
        b = [w.b.x, f.elevation, w.b.y],
        depth = front ? (w.a.y + w.b.y) / 2 : (w.a.x + w.b.x) / 2;
      polys.push({
        depth: depth * sign,
        wall: w,
        points: [
          project(a),
          project(b),
          project([b[0], b[1] + w.height, b[2]]),
          project([a[0], a[1] + w.height, a[2]]),
        ],
      });
    }
    polys.sort((a, b) => a.depth - b.depth);
    let out = "";
    for (const v of polys) {
      out += `<polygon points="${pts(v.points)}" fill="#f7f8f2" stroke="#53664f" stroke-width=".025"/>`;
      let w = v.wall,
        f = fs.find((f) => f.id === w.floor),
        L = E.dist(w.a, w.b);
      for(const h of (p.penetrations||[]).filter(h=>h.kind==='wall'&&h.host===w.id)){const a=E.lerp(w.a,w.b,h.u/L),b=E.lerp(w.a,w.b,(h.u+h.width)/L),ps=[[a.x,f.elevation+h.v,a.y],[b.x,f.elevation+h.v,b.y],[b.x,f.elevation+h.v+h.height,b.y],[a.x,f.elevation+h.v+h.height,a.y]].map(project);out+=`<polygon data-penetration="${esc(h.id)}" points="${pts(ps)}" fill="white" stroke="#9c672f" stroke-width=".015"/>`;}
      for (const o of p.openings.filter((o) => o.wall === w.id)) {
        let a = E.lerp(w.a, w.b, o.offset / L),
          b = E.lerp(w.a, w.b, (o.offset + o.width) / L),
          ps = [
            [a.x, f.elevation + o.sill, a.y],
            [b.x, f.elevation + o.sill, b.y],
            [b.x, f.elevation + o.sill + o.height, b.y],
            [a.x, f.elevation + o.sill + o.height, a.y],
          ].map(project);
        out += `<polygon points="${pts(ps)}" fill="${o.kind === "window" ? "#dfeaed" : "#ece4d3"}" stroke="#667e70" stroke-width=".025"/>`;
        const ux=(w.b.x-w.a.x)/L,uy=(w.b.y-w.a.y)/L;
        for(const part of Openings.parts(o,w.thickness)){
          const world=(v,z)=>[a.x+ux*v[0]-uy*v[1],f.elevation+z,a.y+uy*v[0]+ux*v[1]];
          const corners=[world(part.a,part.bottom),world(part.b,part.bottom),world(part.b,part.bottom+part.height),world(part.a,part.bottom+part.height)].map(project);
          out+=`<polygon points="${pts(corners)}" fill="${part.material==='glass'?'#dfeaed':'#e9e3d6'}" stroke="#667e70" stroke-width=".018"/>`;
        }
      }
    }
    for(const face of RD.closures(p))out+=`<polygon data-roof-id="${esc(face.roofId)}" data-roof-role="closure" points="${pts(face.points.map(project))}" fill="#f7f8f2" stroke="#53664f" stroke-width=".015"/>`;
    const roofDepth=points=>points.reduce((sum,v)=>sum+(front?v[2]:v[0]),0)/points.length;
    const roofSurfaces=R.build(p).surfaces;
    for(const surface of [...roofSurfaces].sort((a,b)=>(roofDepth(a.rings[0])-roofDepth(b.rings[0]))*(direction==='front'||direction==='right'?1:-1))){
      const path=surface.rings.map(r=>r.map((v,i)=>{const q=project(v);return(i?'L':'M')+n(q.x)+' '+n(q.y)}).join('')+'Z').join('');
      out+=`<path data-roof-id="${esc(surface.roofId)}" data-roof-role="surface" d="${path}" fill="#d7dfd5" fill-rule="evenodd" stroke="#546d53" stroke-width=".025"/>`;
    }
    const b = E.bounds(p),
      range = front ? { a: Math.min(b.x,...roofSurfaces.flatMap(s=>s.rings.flat().map(v=>v[0]))), b: Math.max(b.x+b.w,...roofSurfaces.flatMap(s=>s.rings.flat().map(v=>v[0]))) } : { a: Math.min(b.y,...roofSurfaces.flatMap(s=>s.rings.flat().map(v=>v[2]))), b: Math.max(b.y+b.d,...roofSurfaces.flatMap(s=>s.rings.flat().map(v=>v[2]))) },
      levels = [...fs.flatMap((f) => [f.elevation, f.elevation + f.height]),...roofSurfaces.flatMap(s=>s.rings.flat().map(v=>v[1]))],
      top = Math.max(
        ...levels,
        ...R.build(p).triangles.flatMap(t=>t.points.map(v=>v[1])),
      ),
      x0 = Math.min(range.a * sign, range.b * sign) - 1.5;
    for (const f of fs) {
      let y = -f.elevation;
      out +=
        `<path d="M${x0} ${y}H${x0 + Math.abs(range.b - range.a) + 3}" stroke="#a7b39f" stroke-width=".015" stroke-dasharray=".15 .1"/>` +
        text(x0, y - 0.12, f.name + " ± " + f.elevation.toFixed(2), 0.16);
    }
    return {
      markup: out,
      box: {
        x: x0,
        y: -top - 1,
        w: Math.abs(range.b - range.a) + 3,
        h: top - Math.min(...levels) + 2,
      },
      title:
        { front: "南", back: "北", left: "西", right: "东" }[direction] +
        "立面",
    };
  }
  function section(p, s, cutY) {
    const axis=s.sectionAxis==='x'?'x':'y',project=q=>axis==='x'?{x:q.y,y:q.x}:q,originalBounds=E.bounds(p),b=axis==='x'?{x:originalBounds.y,y:originalBounds.x,w:originalBounds.d,d:originalBounds.w}:originalBounds,fs=p.floors,wallMeasures=new Map();
    let out = '<defs><pattern id="sectionHatch" width=".12" height=".12" patternUnits="userSpaceOnUse"><path d="M0 .12L.12 0" stroke="#e2e9df" stroke-width=".018"/></pattern></defs>',
      top = Math.max(...fs.map((f) => f.elevation + f.height),...p.walls.map(w=>fs.find(f=>f.id===w.floor).elevation+w.height));
    for (const f of fs) {
      for (const r of E.detectRooms(p, f.id)) {
        for (const [a, b] of E.sectionIntervals(axis==='x'?r.surfaceGeometry.map(poly=>poly.map(ring=>ring.map(([x,y])=>[y,x]))):r.surfaceGeometry, cutY))
          out += `<rect x="${a}" y="${-f.elevation}" width="${b - a}" height="${f.slab}" fill="#acb8a5" stroke="#52674f" stroke-width=".025"/>`;
      }
      for (const w of p.walls.filter((w) => w.floor === f.id)) {
        const len=E.dist(w.a,w.b),ux=(w.b.x-w.a.x)/len,uy=(w.b.y-w.a.y)/len;
        const world=([x,y])=>project({x:w.a.x+ux*x-uy*y,y:w.a.y+uy*x+ux*y});
        function cut(poly,z,h,role,fill){
          const hits=[];poly.forEach((a,i)=>{const b=poly[(i+1)%poly.length];
            if((a.y<=cutY&&b.y>cutY)||(b.y<=cutY&&a.y>cutY))hits.push(a.x+(b.x-a.x)*(cutY-a.y)/(b.y-a.y));
          });
          if(hits.length>=2&&h>.00001){const left=Math.min(...hits),right=Math.max(...hits);if(role==='wall'&&right-left>.00001)wallMeasures.set(w.id,{left,right,height:w.height,elevation:f.elevation});if(right-left>.00001)out+=`<rect data-section-role="${role}" x="${left}" y="${-f.elevation-z-h}" width="${right-left}" height="${h}" fill="${fill}" style="stroke:#344b32;stroke-width:.025"/><rect x="${left}" y="${-f.elevation-z-h}" width="${right-left}" height="${h}" fill="url(#sectionHatch)"/>`;}
        }
        for(const v of E.wallPanels(p,w)){const y=v.y||0,depth=v.depth??w.thickness;
          cut([[v.x,y-depth/2],[v.x+v.w,y-depth/2],[v.x+v.w,y+depth/2],[v.x,y+depth/2]].map(world),v.z,v.h,v.recess?'backing':'wall','#526b50');
        }
        for(const o of p.openings.filter(o=>o.wall===w.id))for(const v of Openings.parts(o,w.thickness)){
          const dx=v.b[0]-v.a[0],dy=v.b[1]-v.a[1],L=Math.hypot(dx,dy),nx=-dy/L*v.depth/2,ny=dx/L*v.depth/2;
          const poly=[[v.a[0]+nx,v.a[1]+ny],[v.b[0]+nx,v.b[1]+ny],[v.b[0]-nx,v.b[1]-ny],[v.a[0]-nx,v.a[1]-ny]].map(([x,y])=>world([x+o.offset,y]));
          cut(poly,v.bottom,v.height,v.role,v.material==='glass'?'#b9d8dd':'#c7bba1');
        }
      }
      if(root.Penetrations)for(const h of root.Penetrations.data(p).filter(h=>h.floor===f.id))for(const part of root.Penetrations.parts(p,h)){
        const c=Math.cos(part.angle),s=Math.sin(part.angle),poly=[[-part.w/2,-part.d/2],[part.w/2,-part.d/2],[part.w/2,part.d/2],[-part.w/2,part.d/2]].map(([x,y])=>({x:part.x+x*c-y*s,y:part.y+x*s+y*c})).map(project),hits=[];
        poly.forEach((a,i)=>{const b=poly[(i+1)%4];if((a.y<=cutY&&b.y>cutY)||(b.y<=cutY&&a.y>cutY))hits.push(a.x+(b.x-a.x)*(cutY-a.y)/(b.y-a.y))});
        if(hits.length>=2)out+=`<rect data-section-role="sleeve" x="${Math.min(...hits)}" y="${-part.z-part.h/2}" width="${Math.max(...hits)-Math.min(...hits)}" height="${part.h}" fill="#ad8758"/>`;
      }
      for (const o of p.objects.filter((o) => o.floor === f.id)) {
        const drawCut = (polygon, height, bottom=0) => {
          let hits = [];
          polygon.map(project).forEach((a, i, polygon) => {
            const b = polygon[(i + 1) % polygon.length];
            if ((a.y <= cutY && b.y > cutY) || (b.y <= cutY && a.y > cutY))
              hits.push(a.x + ((b.x - a.x) * (cutY - a.y)) / (b.y - a.y));
          });
          hits.sort((a, b) => a - b);
          if (hits.length >= 2)
            out += `<rect x="${hits[0]}" y="${-f.elevation - o.z - height}" width="${hits[hits.length - 1] - hits[0]}" height="${height-bottom}" fill="#eeeae0" stroke="#9b9f89" stroke-width=".015"/>`;
        };
        if (o.kind === "stairs") {
          E.stairPanels(o).forEach((part) => drawCut(part.points, part.top, part.top-part.h));
        } else drawCut(E.objectFootprint(o), o.h);
      }
    }

    const roofCuts=RD.section(p,cutY,axis).map(s=>axis==='x'?{...s,a:[s.a[2],s.a[1],s.a[0]],b:[s.b[2],s.b[1],s.b[0]]}:s);
    for(const segment of roofCuts)out+=`<path data-roof-id="${esc(segment.roofId)}" data-roof-role="section" data-roof-section="${esc(segment.roofId)}" data-roof-pitch="${p.roofs.find(r=>r.id===segment.roofId).pitch}" d="M${segment.a[0]} ${-segment.a[1]}L${segment.b[0]} ${-segment.b[1]}" fill="none" stroke="#55734f" stroke-width=".09"/>`;
    top=Math.max(top,...R.build(p).triangles.flatMap(t=>t.points.map(v=>v[1])));
    for(const [id,w] of wallMeasures)out+='<g data-wall-height="'+id+'" data-height-m="'+w.height+'">'+dim({x:w.left-.12,y:-w.elevation},{x:w.left-.12,y:-w.elevation-w.height},'Wall height '+length(w.height,p.unit),.2)+'</g>';
    for(const [i,r] of p.roofs.filter(r=>roofCuts.some(s=>s.roofId===r.id)).entries())out+=text(b.x+.15,-top-.35-i*.22,'Roof pitch '+Number(r.pitch.toFixed(2))+'° · cut '+axis.toUpperCase(),.16);
    for(const f of fs){
      out+=`<path data-section-datum="${f.id}" d="M${b.x-.4} ${-f.elevation}h${b.w+.8}" stroke="#9caaa0" stroke-width=".012" stroke-dasharray=".15 .1"/>`;
      out+=text(b.x,-f.elevation-.12,esc(f.name)+' · ± '+length(f.elevation,p.unit),.14);
      out+=dim({x:b.x+b.w+1.5,y:-f.elevation},{x:b.x+b.w+1.5,y:-f.elevation-f.height},'Floor setting '+length(f.height,p.unit),0);
      out+=text(b.x+b.w+.15,-f.elevation+f.slab+.2,(p.language==='zh'?'楼板 ':'Slab ')+length(f.slab,p.unit),.12);
    }
    for (const f of fs)
      out += text(
        b.x - 0.7,
        -f.elevation - 0.1,
        f.elevation.toFixed(2) + " m",
        0.14,
      );
    return {
      markup: out,
      box: {
        x: Math.min(b.x,...roofCuts.flatMap(s=>[s.a[0],s.b[0]])) - 1.5,
        y: -top - 1,
        w: Math.max(b.x+b.w,...roofCuts.flatMap(s=>[s.a[0],s.b[0]]))-Math.min(b.x,...roofCuts.flatMap(s=>[s.a[0],s.b[0]]))+4.5,
        h: top - Math.min(...fs.map((f) => f.elevation),...roofCuts.flatMap(s=>[s.a[1],s.b[1]])) + 2,
      },
      title: (p.language==='zh'?"剖面 A—A（预览） · ":"Section A—A (Preview) · ") + axis.toUpperCase()+" = " + length(cutY,p.unit),
    };
  }
  function svg(content, box) {
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${box.x} ${box.y} ${box.w} ${box.h}" role="img" aria-label="建筑图纸">${content}</svg>`;
  }
  root.Drawings = {
    esc,
    pts,
    text,
    dim,
    plan,
    elevation,
    section,
    svg,
    length,
    wallPoly,
    geometryPath,
  };
  if (typeof module !== "undefined") module.exports = root.Drawings;
})(typeof window !== "undefined" ? window : globalThis);
