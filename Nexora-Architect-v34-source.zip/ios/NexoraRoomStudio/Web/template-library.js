// Compatibility entry point: every template picker now uses the rebuilt North American library.
(function(root){'use strict';
const N=root.NorthAmerica||(typeof require==='function'?require('./north-america.js'):null);
const styles=[...new Map(N.entries.map(t=>[t.styleId,{id:t.styleId,name:t.style}])).values()];
root.HomeTemplates={styles,entries:N.entries,build:N.build,preview:N.preview,gallery:options=>N.gallery(typeof options==='string'?{style:options}:options)};
if(typeof module==='object')module.exports=root.HomeTemplates;
})(typeof globalThis!=='undefined'?globalThis:this);
