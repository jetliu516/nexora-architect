(function(root){
'use strict';const T=root.THREE,cache=new Map();
function rand(seed){return()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296}}
function texture(kind){if(cache.has(kind))return cache.get(kind);const c=document.createElement('canvas');c.width=c.height=512;const x=c.getContext('2d'),r=rand(731+kind.length*97);
if(kind==='oak'||kind==='walnut'){
 const dark=kind==='walnut';x.fillStyle=dark?'#705039':'#c8a775';x.fillRect(0,0,512,512);
 for(let row=0;row<8;row++){const y=row*64,light=dark?30:60;x.fillStyle=`hsl(${dark?26:34} 34% ${light+r()*12}%)`;x.fillRect(0,y,512,63);
 for(let k=0;k<40;k++){const yy=y+r()*63;x.strokeStyle=`rgba(${dark?'32,17,9':'97,66,32'},${.015+r()*.12})`;x.lineWidth=.3+r();x.beginPath();x.moveTo(0,yy);x.bezierCurveTo(150,yy+4*r(),360,yy-5*r(),512,yy);x.stroke()}
 x.fillStyle='rgba(48,33,21,.2)';x.fillRect(0,y,512,1);const joint=(row%3)*173;x.fillRect(joint,y,1,64);x.fillStyle='rgba(255,245,218,.15)';x.fillRect(0,y+1,512,1);
 }
}else if(kind==='stone'||kind==='quartz'){
 x.fillStyle='#eeeae2';x.fillRect(0,0,512,512);for(let i=0;i<7000;i++){const gray=120+Math.floor(r()*90);x.fillStyle=`rgba(${gray},${gray},${gray},${r()*.18})`;const size=.4+r()*1.5;x.fillRect(r()*512,r()*512,size,size)}
 for(let i=0;i<9;i++){x.strokeStyle='rgba(138,135,127,.10)';x.lineWidth=.5+r()*1.8;let px=r()*512,py=0;x.beginPath();x.moveTo(px,py);for(let j=0;j<10;j++){px+=(r()-.5)*100;py+=58;x.lineTo(px,py)}x.stroke()}
}else if(kind==='subway'){
 x.fillStyle='#7d847d';x.fillRect(0,0,512,512);for(let y=0;y<512;y+=64)for(let xx=-128;xx<512;xx+=128){const px=xx+(y/64%2)*64;x.fillStyle='#faf9f5';x.fillRect(px+2,y+2,124,60);x.fillStyle='rgba(220,220,214,.7)';x.fillRect(px+2,y+59,124,3);x.fillStyle='#fff';x.fillRect(px+3,y+3,122,2)}
}else if(kind==='siding'){
 x.fillStyle='#e9e7de';x.fillRect(0,0,512,512);for(let y=0;y<512;y+=48){x.fillStyle='#b9b9af';x.fillRect(0,y,512,2);x.fillStyle='#faf9f3';x.fillRect(0,y+2,512,3)}
}else if(kind==='tile'){
 x.fillStyle='#e7e5df';x.fillRect(0,0,512,512);for(let row=0;row<8;row++)for(let col=-1;col<4;col++){x.fillStyle=row%2?'#fafaf7':'#f3f5f2';x.fillRect(col*192+(row%2)*96+2,row*64+2,188,60)}
}else if(kind==='grass'){
 x.fillStyle='#729355';x.fillRect(0,0,512,512);for(let i=0;i<60000;i++){x.strokeStyle=`hsla(${78+r()*22},${22+r()*26}%,${27+r()*30}%,.55)`;const px=r()*512,py=r()*512;x.beginPath();x.moveTo(px,py);x.lineTo(px+(r()-.5)*3,py-1-r()*6);x.stroke()}
}else if(kind==='fabric'){
 x.fillStyle='#ded6c8';x.fillRect(0,0,512,512);for(let i=0;i<512;i+=2){x.strokeStyle=i%4?'#cdc5b9':'#e7e0d4';x.lineWidth=.6;x.beginPath();x.moveTo(i,0);x.lineTo(i,512);x.moveTo(0,i);x.lineTo(512,i);x.stroke()}
}else if(kind==='shingle'){
 x.fillStyle='#464a4a';x.fillRect(0,0,512,512);for(let row=0;row<16;row++)for(let col=-1;col<8;col++){const v=57+r()*9;x.fillStyle=`rgb(${v},${v+3},${v+3})`;x.fillRect(col*80+(row%2)*40,row*32+2,78,30)}
}else{
 x.fillStyle='#d5d3cb';x.fillRect(0,0,512,512);for(let i=0;i<16000;i++){x.fillStyle=r()>.5?'#c8c6bf':'#dfddd7';x.fillRect(r()*512,r()*512,1,1)}
}
const tex=new T.CanvasTexture(c);tex.wrapS=tex.wrapT=T.RepeatWrapping;tex.colorSpace=T.SRGBColorSpace;tex.anisotropy=4;cache.set(kind,tex);return tex;
}
function material(key,options={}){const kinds={oak:'oak',walnut:'walnut',stone:'stone',quartz:'quartz',subway:'subway',siding:'siding',concrete:'concrete',fabric:'fabric',tile:'tile',grass:'grass',shingle:'shingle'};const kind=kinds[key],color=kind?'#ffffff':(root.BIM.materials[key]?.color||key);const m=new T.MeshStandardMaterial({color,roughness:kind==='quartz'?.24:kind==='subway'?.2:kind==='stone'?.33:kind==='fabric'?.96:.78,metalness:0,...(kind?{map:texture(kind),bumpMap:texture(kind),bumpScale:['stone','quartz','shingle'].includes(kind)?.001:kind==='fabric'?.002:.004}:{}),...options});m.userData.textureScale=kind==='subway'?1/.8128:['quartz','siding'].includes(kind)?1/1.5:.5;return m}
// Physical texture coordinates prevent a long wall/table from stretching one small tile.
function uv(geometry,scale=1){const p=geometry.attributes.position,n=geometry.attributes.normal,a=geometry.attributes.uv;if(!a)return;for(let i=0;i<p.count;i++){const x=p.getX(i),y=p.getY(i),z=p.getZ(i);if(Math.abs(n.getY(i))>.5)a.setXY(i,x*scale,z*scale);else if(Math.abs(n.getX(i))>.5)a.setXY(i,z*scale,y*scale);else a.setXY(i,x*scale,y*scale)}a.needsUpdate=true}
root.ResidentialMaterials={texture,material,uv};
})(window);
