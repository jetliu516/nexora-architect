(function(root){
 'use strict';
 // Raster pages retain browser font/layout fidelity; SVG remains the vector deliverable.
 async function build(p,sheets,{dpi=150,t=x=>x,onProgress=()=>{},signal}={}){
  if(![150,300].includes(dpi))throw Error('PDF分辨率无效');
  root.Sheets.printHTML(p,sheets,t); // Same preflight as print/export, including missing sources.
  const check=()=>{if(signal?.aborted)throw Error('PDF导出已取消')};check();
  await document.fonts?.ready;
  let pdf=null,totalBytes=0;
  for(let i=0;i<sheets.length;i++){
   check();const sheet=sheets[i],[w,h]=root.Sheets.dims(sheet),pw=Math.ceil(w*dpi/25.4),ph=Math.ceil(h*dpi/25.4);
   if(pw*ph>20000000||pw>10000||ph>10000)throw Error('此图幅在当前分辨率下过大，请选择150 DPI或较小图幅');
   const svg=root.Sheets.svg(p,sheet,{t}),url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml'}));
   const canvas=document.createElement('canvas');canvas.width=pw;canvas.height=ph;
   try{
    const image=new Image();await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{image.src='';reject(Error('图纸图片加载超时'))},20000);image.onload=()=>{clearTimeout(timer);resolve()};image.onerror=()=>{clearTimeout(timer);reject(Error('图纸图片无法渲染'))};image.src=url});check();
    const ctx=canvas.getContext('2d');if(!ctx)throw Error('设备无法创建图纸画布');ctx.fillStyle='white';ctx.fillRect(0,0,pw,ph);ctx.drawImage(image,0,0,pw,ph);
    const jpeg=canvas.toDataURL('image/jpeg',.96);if(!jpeg.startsWith('data:image/jpeg;base64,'))throw Error('设备无法导出此图幅，请降低分辨率');totalBytes+=jpeg.length*.75;if(totalBytes>64*1024*1024)throw Error('PDF内容过大，请分批导出或降低分辨率');
    const orientation=w>=h?'landscape':'portrait';if(!pdf)pdf=new root.jspdf.jsPDF({orientation,unit:'mm',format:[w,h],compress:true});else pdf.addPage([w,h],orientation);
    pdf.addImage(jpeg,'JPEG',0,0,w,h,'sheet-'+i,'FAST');onProgress(i+1,sheets.length);
   }finally{URL.revokeObjectURL(url);canvas.width=canvas.height=1}
   await new Promise(resolve=>setTimeout(resolve,0));
  }
  check();return new Uint8Array(pdf.output('arraybuffer'));
 }
 root.SheetPDF={build};
})(window);
