(function(root){
  'use strict';
  const E=root.BIM||require('./geometry.js'),M=typeof module!=='undefined'?require('./mep-avoidance.js'):root.MEP;
  const P=root.Penetrations||(typeof require==='function'?require('./penetrations.js'):null);
  const labels={walls:'墙体',rooms:'房间与楼板',objects:'家具与构件',openings:'门窗',dimensions:'自动尺寸',labels:'房间标签',roofs:'屋顶',electrical:'电气符号',annotations:'CAD 与标注',penetrations:'机电预留'};
  Object.assign(labels,Object.fromEntries(Object.entries(M.systems).map(([k,v])=>[M.layer(k),v.label])));
  const modes=['plan','split','3d','elevation','cabinet','section','schedule','layout'];
  const defaults=()=>({floor:null,mode:'plan',layers:Object.fromEntries(Object.keys(labels).map(k=>[k,true])),locks:{},cutaway:true,cutHeight:1.35,roof:false,allFloors:false,foundation:true,reference:false,framing:false,style:'material',daylight:'day',landscape:true,autoDimensions:false,elevation:'front',sectionY:4.5,sectionAxis:'x',schedule:'materials',scale:100,snap:true,ortho:true});
  const clone=x=>JSON.parse(JSON.stringify(x));
  function numeric(v,min,max){if(typeof v!=='number'||!Number.isFinite(v)||v<min||v>max)throw Error('视图参数无效');return v}
  function camera(c){
    if(!c)return null;
    for(const k of ['position','target'])if(!Array.isArray(c[k])||c[k].length!==3||!c[k].every(n=>Number.isFinite(n)&&Math.abs(n)<=10000))throw Error('相机坐标无效');
    if(Math.hypot(...c.position.map((n,i)=>n-c.target[i]))<.001)throw Error('相机位置与目标点不能重合');
    const out={name:String(c.name||'').slice(0,100),position:[...c.position],target:[...c.target],walk:c.walk===true};
    if(out.walk){out.yaw=numeric(c.yaw,-100000,100000);out.pitch=numeric(c.pitch,-1.5,1.5)}
    return out;
  }
  function normalizeState(raw,p){
    if(!raw||typeof raw!=='object'||Array.isArray(raw))throw Error('保存视图格式无效');
    const out=defaults();if(raw.sectionAxis==null)out.sectionAxis='y';out.floor=p.floors.some(f=>f.id===raw.floor)?raw.floor:p.floors[0].id;
    if(raw.mode!=null&&!modes.includes(raw.mode))throw Error('视图类型无效');out.mode=raw.mode||'plan';
    for(const k of ['layers','locks']){
      if(raw[k]!=null&&(typeof raw[k]!=='object'||Array.isArray(raw[k])))throw Error('图层设置无效');
      for(const name of Object.keys(labels))if(raw[k]?.[name]!=null){if(typeof raw[k][name]!=='boolean')throw Error('图层设置无效');out[k][name]=raw[k][name]}
    }
    for(const k of ['cutaway','roof','allFloors','foundation','reference','framing','snap','ortho','landscape','autoDimensions'])if(raw[k]!=null){if(typeof raw[k]!=='boolean')throw Error('视图开关无效');out[k]=raw[k]}
    for(const [k,min,max] of [['cutHeight',.3,4],['sectionY',-500,500],['scale',1,10000]])if(raw[k]!=null)out[k]=numeric(raw[k],min,max);
    out.cutHeight=Math.round(out.cutHeight*1000)/1000;
    for(const [k,values] of [['sectionAxis',['x','y']],['daylight',['day','golden','overcast']],['style',['material','clay','wire']],['elevation',['front','back','left','right']],['schedule',['materials','openings','objects','cabinets']]])if(raw[k]!=null){if(!values.includes(raw[k]))throw Error('视图选项无效');out[k]=raw[k]}
    if(raw.frame){out.frame={x:numeric(raw.frame.x,-10000,10000),y:numeric(raw.frame.y,-10000,10000),width:numeric(raw.frame.width,.01,10000)}}
    out.camera=camera(raw.camera);return out;
  }
  function normalizeViews(raw,p){
    if(raw==null)return [];
    if(!Array.isArray(raw)||raw.length>60)throw Error('最多保存 60 个视图');
    const ids=new Set();return raw.map(v=>{
      if(!v||typeof v.id!=='string'||!/^[A-Za-z0-9_.:-]{1,200}$/.test(v.id)||ids.has(v.id))throw Error('保存视图 ID 无效');ids.add(v.id);
      if(typeof v.name!=='string'||!v.name.trim()||v.name.length>100)throw Error('请输入 1–100 字的视图名称');
      return {id:v.id,name:v.name.trim(),state:normalizeState(v.state,p)};
    });
  }
  function layerFor(type,item){if(type==='mepNode'||type==='mepRun')return M.layer(item.system);return type==='object'?(E.catalog[item?.kind]?.group==='电气'?'electrical':'objects'):({penetration:'penetrations',wall:'walls',opening:'openings',room:'rooms',slabOpening:'rooms',roof:'roofs',annotation:'annotations',floor:'rooms'})[type]}
  function available(s,layer){return !!layer&&s.layers?.[layer]!==false&&!s.locks?.[layer]}
  function canSelect(p,s,type,id){
    let item;
    if(type==='mepNode'||type==='mepRun')item=M.item(p,type,id);
    else if(type==='room')item=p.floors.flatMap(f=>E.detectRooms(p,f.id)).find(v=>v.id===id);
    else item=p[({penetration:'penetrations',wall:'walls',opening:'openings',object:'objects',roof:'roofs',annotation:'annotations',slabOpening:'slabOpenings',floor:'floors'})[type]]?.find(v=>v.id===id);
    return !!item&&available(s,layerFor(type,item))&&(type!=='object'||s.layers?.objects!==false);
  }
  function assertEditable(before,after,s){
    const requireLayer=layer=>{if(!available(s,layer))throw Error('请先显示并解锁图层：'+labels[layer])};
    const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
    const types={penetrations:'penetration',walls:'wall',openings:'opening',objects:'object',roofs:'roof',annotations:'annotation',slabOpenings:'slabOpening'};
    for(const [key,type] of Object.entries(types)){
      const a=new Map((before[key]||[]).map(v=>[v.id,v])),b=new Map((after[key]||[]).map(v=>[v.id,v]));
      for(const id of new Set([...a.keys(),...b.keys()])){
        const old=a.get(id),next=b.get(id);if(same(old,next))continue;
        requireLayer(layerFor(type,old||next));if(old&&next)requireLayer(layerFor(type,next));
        if(type==='object'&&s.layers?.objects===false)requireLayer('objects');
        if(type==='object'&&(before.slabOpenings||[]).some(h=>h.sourceStair===id))requireLayer('rooms');
        if(type==='penetration'){for(const h of [old,next].filter(Boolean))requireLayer(h.kind==='wall'?'walls':'rooms')}
        if(type==='wall'&&P.data(before).concat(P.data(after)).some(h=>h.kind==='wall'&&h.host===id))requireLayer('penetrations');
        // Openings edit their host; moving a host also moves unchanged opening records.
        if(type==='opening'&&next)requireLayer('walls');
        if(type==='wall'&&[...before.openings,...after.openings].some(o=>o.wall===id))requireLayer('openings');
        // Room lock protects the derived floor shape, including indirect wall edits.
        if(type==='wall'&&s.locks?.rooms)requireLayer('rooms');
      }
    }
    for(const key of ['nodes','runs']){
      const a=new Map(M.data(before)[key].map(v=>[v.id,v])),b=new Map(M.data(after)[key].map(v=>[v.id,v]));
      for(const id of new Set([...a.keys(),...b.keys()])){const old=a.get(id),next=b.get(id);let changed=!same(old,next);
        if(old&&next)changed=changed||!same(key==='nodes'?M.position(before,old):M.path(before,old),key==='nodes'?M.position(after,next):M.path(after,next));
        if(changed){if(old)requireLayer(M.layer(old.system));if(next)requireLayer(M.layer(next.system))}
      }
    }
    if(!same(before.rooms,after.rooms))requireLayer('rooms');
    if(!same(before.floors,after.floors)){
      for(const key of ['walls','rooms','objects','openings','roofs','electrical','annotations','penetrations']){
        // Floor elevation/height changes move every hosted element.
        const floorsChanged=before.floors.some(f=>{const n=after.floors.find(v=>v.id===f.id);return !n||!same(f,n)});
        if(floorsChanged)requireLayer(key);
      }
    }
  }
  const validate=E.validate;
  E.validate=function(raw){const p=validate(raw);p.savedViews=normalizeViews(p.savedViews,p);p.cameras=(p.cameras||[]).flatMap(c=>{try{return[camera(c)]}catch{return[]}});return p};
  const api={labels,modes,defaults,normalizeState,normalizeViews,camera,layerFor,available,canSelect,assertEditable};
  root.WorkspaceModel=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
