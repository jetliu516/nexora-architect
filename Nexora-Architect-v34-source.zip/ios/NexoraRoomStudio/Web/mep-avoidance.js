(function(root){
  'use strict';
  const E=root.BIM||require('./geometry.js'),M=typeof module!=='undefined'?require('./mep-clashes.js'):root.MEP;
  const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z),lerp=(a,b,t)=>({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t,z:a.z+(b.z-a.z)*t});
  const bounds=points=>({lo:Object.fromEntries(['x','y','z'].map(k=>[k,Math.min(...points.map(q=>q[k]))])),hi:Object.fromEntries(['x','y','z'].map(k=>[k,Math.max(...points.map(q=>q[k]))]))});
  const intersects=(a,b,r=0)=>['x','y','z'].every(k=>a.lo[k]-r<=b.hi[k]&&a.hi[k]+r>=b.lo[k]);
  function scene(p,r,clearance){
    const radius=r.diameter/2+clearance,solids=[],slabs=[],pipes=[],anchors=[];
    const endpoints=[r.a,r.b].map(id=>M.item(p,'mepNode',id)),hosts=endpoints.map(n=>n.fixtureId).filter(Boolean);
    function solid(local,world,lo,hi){const corners=[];for(const x of [lo.x,hi.x])for(const y of [lo.y,hi.y])for(const z of [lo.z,hi.z])corners.push(world({x,y,z}));const box=bounds(corners);solids.push({local,lo,hi,box});anchors.push(box)}
    for(const w of p.walls){const f=p.floors.find(f=>f.id===w.floor),len=E.dist(w.a,w.b),ux=(w.b.x-w.a.x)/len,uy=(w.b.y-w.a.y)/len;
      const local=q=>({x:(q.x-w.a.x)*ux+(q.y-w.a.y)*uy,y:-(q.x-w.a.x)*uy+(q.y-w.a.y)*ux,z:q.z-f.elevation}),world=q=>({x:w.a.x+q.x*ux-q.y*uy,y:w.a.y+q.x*uy+q.y*ux,z:f.elevation+q.z});
      for(const panel of E.wallPanels(p,w)){const depth=panel.depth??w.thickness,offset=panel.y||0;solid(local,world,{x:panel.x,y:offset-depth/2,z:panel.z},{x:panel.x+panel.w,y:offset+depth/2,z:panel.z+panel.h})}
    }
    for(const o of p.objects){if(hosts.includes(o.id))continue;const f=p.floors.find(f=>f.id===o.floor),c=Math.cos(o.angle*Math.PI/180),s=Math.sin(o.angle*Math.PI/180),cx=o.x+o.w/2,cy=o.y+o.d/2;
      solid(q=>({x:(q.x-cx)*c+(q.y-cy)*s,y:-(q.x-cx)*s+(q.y-cy)*c,z:q.z-f.elevation-o.z}),q=>({x:cx+q.x*c-q.y*s,y:cy+q.x*s+q.y*c,z:f.elevation+o.z+q.z}),{x:-o.w/2,y:-o.d/2,z:0},{x:o.w/2,y:o.d/2,z:o.h});
    }
    if(root.Penetrations)for(const h of root.Penetrations.data(p))for(const b of root.Penetrations.parts(p,h)){const c=Math.cos(b.angle),s=Math.sin(b.angle);solid(q=>({x:(q.x-b.x)*c+(q.y-b.y)*s,y:-(q.x-b.x)*s+(q.y-b.y)*c,z:q.z-b.z}),q=>({x:b.x+q.x*c-q.y*s,y:b.y+q.x*s+q.y*c,z:b.z+q.z}),{x:-b.w/2,y:-b.d/2,z:-b.h/2},{x:b.w/2,y:b.d/2,z:b.h/2})}
    for(const f of p.floors)for(const room of E.detectRooms(p,f.id)){slabs.push({f,geometry:room.surfaceGeometry});for(const poly of room.surfaceGeometry)for(const ring of poly){const points=ring.map(([x,y])=>({x,y,z:f.elevation})),b=bounds(points);b.lo.z=f.elevation-f.slab;anchors.push(b)}}
    for(const other of M.data(p).runs){if(other.id===r.id)continue;const ps=M.path(p,other),shared=[r.a,r.b].filter(id=>id===other.a||id===other.b).map(id=>M.position(p,M.item(p,'mepNode',id)));
      for(let i=1;i<ps.length;i++){const a=ps[i-1],b=ps[i],box=bounds([a,b]);pipes.push({a,b,box,diameter:other.diameter,shared});anchors.push({lo:Object.fromEntries(['x','y','z'].map(k=>[k,box.lo[k]-other.diameter/2])),hi:Object.fromEntries(['x','y','z'].map(k=>[k,box.hi[k]+other.diameter/2]))})}
    }
    function blocked(a,b){const box=bounds([a,b]);for(const solid of solids)if(intersects(box,solid.box,radius)&&M.boxHit(solid.local(a),solid.local(b),solid.lo,solid.hi,Math.max(0,radius-1e-8)))return true;
      for(const {f,geometry}of slabs)if(box.hi.z+radius>=f.elevation-f.slab&&box.lo.z-radius<=f.elevation&&M.slabHit(a,b,f,geometry,Math.max(0,radius-1e-8)))return true;
      for(const pipe of pipes){const sum=radius+pipe.diameter/2;if(!intersects(box,pipe.box,sum))continue;const q=M.closestSegments(a,b,pipe.a,pipe.b);if(q.distance>=sum-1e-7)continue;const overlap=M.collinearOverlap(a,b,pipe.a,pipe.b);
        if(overlap<sum*2&&pipe.shared.some(n=>distance(q.a,n)<=sum*2&&distance(q.b,n)<=sum*2))continue;return true;
      }return false;
    }
    return{blocked,anchors,radius};
  }
  const clean=points=>{const out=[];for(const q of points){if(out.length&&distance(out.at(-1),q)<1e-7)continue;while(out.length>1){const a=out.at(-2),b=out.at(-1);if(Math.abs(distance(a,b)+distance(b,q)-distance(a,q))>1e-7)break;out.pop()}out.push({...q})}return out};
  function setRoute(raw,id,points){const p=E.clone(raw),r=M.item(p,'mepRun',id);if(!r)throw Error('请选择管线');r.routing='waypoints';r.waypoints=E.clone(points);return E.validate(p)}
  function search(raw,id,{clearance=.05,detour=2}={}){
    if(!Number.isFinite(clearance)||clearance<0||clearance>1||!Number.isFinite(detour)||detour<.1||detour>20)throw Error('机电参数超出范围');
    const r=M.item(raw,'mepRun',id);if(!r)throw Error('请选择管线');const original=M.path(raw,r),a=original[0],b=original.at(-1),isDrain=r.system==='drain',space=scene(raw,r,clearance),area=bounds([a,b]);
    for(const k of ['x','y','z']){area.lo[k]=Math.max(-500,area.lo[k]-detour);area.hi[k]=Math.min(500,area.hi[k]+detour)}
    const axes=['x','y','z'],coords=axes.map(k=>{const values=[a[k],b[k],(a[k]+b[k])/2,area.lo[k],area.hi[k]];for(const box of space.anchors)if(intersects(area,box,space.radius))values.push(box.lo[k]-space.radius-.005,box.hi[k]+space.radius+.005,(box.lo[k]+box.hi[k])/2);
      const options=[...new Set(values.filter(v=>v>=area.lo[k]&&v<=area.hi[k]))];const score=v=>Math.abs(v-a[k])+Math.abs(v-b[k]);const chosen=[...new Set([a[k],b[k],...options.sort((u,v)=>score(u)-score(v)).slice(0,16)])];return chosen.sort((u,v)=>u-v)});
    const candidates=[],accept=ps=>{if(ps.some(q=>axes.some(k=>q[k]<area.lo[k]-1e-8||q[k]>area.hi[k]+1e-8)))return;ps=clean(ps);if(isDrain){const horizontal=ps.reduce((v,q,i)=>v+(i?Math.hypot(q.x-ps[i-1].x,q.y-ps[i-1].y):0),0),drop=a.z-b.z;if(drop<-1e-7||drop+1e-7<horizontal*r.slope)return;
        if(horizontal>1e-7){let traveled=0;ps=ps.map((q,i)=>{if(i)traveled+=Math.hypot(q.x-ps[i-1].x,q.y-ps[i-1].y);return{...q,z:a.z-drop*traveled/horizontal}});ps=clean(ps)}
      }
      if(ps.length>66||ps.some((q,i)=>i&&space.blocked(ps[i-1],q)))return;const length=ps.reduce((v,q,i)=>v+(i?distance(q,ps[i-1]):0),0);candidates.push({points:ps,length});
    };
    accept(original);accept([a,b]);
    for(const axis of axes)for(const v of coords[axes.indexOf(axis)])for(const order of [[0,1,2],[1,0,2]]){const one={...a,[axis]:v},two={...b,[axis]:v},middle={...one};const path=[a,one];for(const k of order.map(i=>axes[i])){middle[k]=two[k];path.push({...middle})}path.push(b);accept(path)}
    // A* on a bounded rectilinear visibility lattice; edge tests use full 3D solids.
    const [nx,ny,nz]=coords.map(c=>c.length),size=nx*ny*nz,encode=(x,y,z)=>(x*ny+y)*nz+z,decode=id=>[Math.floor(id/(ny*nz)),Math.floor(id/nz)%ny,id%nz],point=id=>Object.fromEntries(decode(id).map((i,k)=>[axes[k],coords[k][i]]));
    const start=encode(...axes.map((k,i)=>coords[i].indexOf(a[k]))),end=encode(...axes.map((k,i)=>coords[i].indexOf(b[k]))),cost=new Float64Array(size).fill(Infinity),parent=new Int32Array(size).fill(-1),closed=new Uint8Array(size),heap=[],edgeCache=new Map();
    const push=(id,f)=>{let i=heap.length;heap.push({id,f});while(i){const p=(i-1)>>1;if(heap[p].f<=f)break;heap[i]=heap[p];i=p;heap[i]={id,f}}};
    const pop=()=>{const first=heap[0],last=heap.pop();if(heap.length){heap[0]=last;let i=0;for(;;){let c=i*2+1;if(c>=heap.length)break;if(c+1<heap.length&&heap[c+1].f<heap[c].f)c++;if(heap[i].f<=heap[c].f)break;[heap[i],heap[c]]=[heap[c],heap[i]];i=c}}return first};
    cost[start]=0;push(start,distance(a,b));let visited=0;
    while(heap.length&&visited<6000){const {id}=pop();if(closed[id])continue;closed[id]=1;visited++;if(id===end){const path=[];for(let n=end;n!==-1;n=parent[n])path.push(point(n));path.reverse();path[0]=a;path[path.length-1]=b;accept(path);break}
      const indices=decode(id),q=point(id);for(let axis=0;axis<3;axis++)for(const delta of [-1,1]){const next=[...indices];next[axis]+=delta;if(next[axis]<0||next[axis]>=coords[axis].length)continue;const n=encode(...next);if(closed[n])continue;const v=point(n);if(isDrain&&v.z>q.z+1e-7)continue;const key=id<n?id+':'+n:n+':'+id;let blocked=edgeCache.get(key);if(blocked===undefined){blocked=space.blocked(q,v);edgeCache.set(key,blocked)}if(blocked)continue;const candidate=cost[id]+distance(q,v);if(candidate+1e-9<cost[n]){cost[n]=candidate;parent[n]=id;push(n,candidate+distance(v,b))}}
    }
    if(!candidates.length)return{ok:false,reason:'在当前范围和净距下未找到可行路线',visited,limited:visited>=6000};
    candidates.sort((a,b)=>a.length-b.length||a.points.length-b.points.length);const best=candidates[0],elevation=raw.floors.find(f=>f.id===r.floor).elevation,waypoints=best.points.slice(1,-1).map(q=>({...q,z:q.z-elevation})),next=setRoute(raw,id,waypoints);
    const collisions=M.clashes(next,{onlyRunIds:[id]});if(collisions.truncated||collisions.issues.length)return{ok:false,reason:'候选路线复查仍有碰撞，请调整范围或手工编辑',visited};
    return{ok:true,next,points:best.points,beforeLength:M.runLength(raw,r),length:best.length,beforeIssues:M.clashes(raw,{onlyRunIds:[id]}).issues.length,visited,clearance,detour};
  }
  Object.assign(M,{routeScene:scene,setRoute,avoid:search});root.MEP=M;if(typeof module!=='undefined')module.exports=M;
})(typeof window!=='undefined'?window:globalThis);
