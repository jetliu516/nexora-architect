(function(root){'use strict';
function independentCopy(raw,{validate,id}){
 const next=validate(JSON.parse(JSON.stringify(raw)));const previous=next.id;next.id=id();
 if(!next.id||next.id===previous)throw Error('Could not create an independent project ID');
 next.name=String(next.name).slice(0,80)+' · Imported copy';
 next.updatedAt=new Date().toISOString();return next;
}
const api={independentCopy};root.ProjectImport=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
