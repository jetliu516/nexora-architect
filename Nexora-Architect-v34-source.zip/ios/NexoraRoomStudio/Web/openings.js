(function(root){
  'use strict';
  // Local coordinates: x follows the host wall, y is perpendicular, z is height.
  const types={
    hinged:{kind:'door',label:'平开门',motion:'angle'},
    doorway:{kind:'opening',label:'门洞'},
    sliding:{kind:'door',label:'推拉门',motion:'ratio'},
    pocket:{kind:'door',label:'暗藏推拉门',motion:'ratio'},
    bifold:{kind:'door',label:'折叠门',motion:'ratio'},
    garage:{kind:'door',label:'车库门',motion:'ratio'},
    fixed:{kind:'door',label:'固定门'},
    barn:{kind:'door',label:'谷仓移门',motion:'ratio'},
    shower:{kind:'door',label:'淋浴门',motion:'angle'},
    standard:{kind:'window',label:'普通窗'},
    bay:{kind:'window',label:'斜角凸窗',projection:true},
    box:{kind:'window',label:'矩形凸窗',projection:true},
    bow:{kind:'window',label:'弧形凸窗',projection:true},
    passThrough:{kind:'opening',label:'传递窗'},
    niche:{kind:'opening',label:'壁龛',recess:true}
  };
  const fallback=kind=>kind==='door'?'hinged':kind==='window'?'standard':'doorway';
  function style(o){return !o.style||['single','double'].includes(o.style)?fallback(o.kind):o.style;}
  function definition(o){return types[style(o)];}
  function defaults(key){const d=types[key];if(!d)throw Error('门窗样式无效');return {kind:d.kind,style:key,width:key==='garage'?2.7:d.kind==='window'?1.5:.9,height:d.kind==='window'?1.2:key==='niche'?.6:2.1,sill:key==='passThrough'?.9:key==='niche'?1:d.kind==='window'?.9:0,flip:false,hingeRight:false,openAngle:90,openRatio:.5,projection:.5,recessDepth:.08,frameMaterial:'white',panelMaterial:key==='shower'?'glass':'oak'};}
  function normalize(o,w){
    const key=style(o),d=types[key];if(!d||d.kind!==o.kind)throw Error('门窗样式与类型不匹配');
    const seed=defaults(key);o.style=key;
    for(const k of ['flip','hingeRight']){if(o[k]!=null&&typeof o[k]!=='boolean')throw Error('门窗方向无效');o[k]=o[k]??seed[k];}
    for(const [k,min,max] of [['openAngle',0,150],['openRatio',0,1],['projection',.05,3],['recessDepth',.01,1.48]]){
      if(o[k]==null)o[k]=k==='recessDepth'?Math.min(seed[k],w.thickness-.02):seed[k];
      if(typeof o[k]!=='number'||!Number.isFinite(o[k])||o[k]<min||o[k]>max)throw Error('门窗参数超出允许范围：'+k);
    }
    if(d.recess&&o.recessDepth>w.thickness-.02+1e-8)throw Error('壁龛深度必须保留至少 20 mm 背墙');
    for(const k of ['frameMaterial','panelMaterial']){o[k]=o[k]??seed[k];if(!['white','oak','walnut','charcoal','glass','metal'].includes(o[k]))throw Error('门窗材质无效');}
    return o;
  }
  function profile(o){const w=o.width,d=o.projection||.5,side=o.flip?1:-1,key=style(o);
    if(key==='box')return [[0,0],[0,side*d],[w,side*d],[w,0]];
    if(key==='bay')return [[0,0],[w*.25,side*d],[w*.75,side*d],[w,0]];
    if(key==='bow')return Array.from({length:7},(_,i)=>{const t=i/6;return [w*t,side*d*4*t*(1-t)];});
    return [[0,0],[w,0]];
  }
  function parts(o,thickness=.2){
    const key=style(o),d=types[key],w=o.width,h=o.height,z=o.sill,side=o.flip?-1:1,frame=o.frameMaterial||'white',panel=o.panelMaterial||'oak',out=[];
    function beam(a,b,bottom,height,depth,material,role){if(Math.hypot(b[0]-a[0],b[1]-a[1])>.00001&&height>0)out.push({a,b,bottom,height,depth,material,role});}
    function post(x,y,bottom,height){beam([x-.025,y],[x+.025,y],bottom,height,.055,frame,'frame');}
    if(key==='doorway'||key==='passThrough')return out;
    if(key==='niche'){
      const face=side*thickness/2,back=face-side*(o.recessDepth||.08),depth=Math.abs(face-back),middle=(face+back)/2;
      beam([0,middle],[w,middle],z,.025,depth,frame,'sill');return out;
    }
    post(0,0,z,h+.025);post(w,0,z,h+.025);beam([0,0],[w,0],z+h-.025,.05,thickness+.025,frame,'frame');
    if(d.kind==='window'){
      const points=profile(o);
      for(let i=0;i<points.length-1;i++){
        const a=points[i],b=points[i+1];
        beam(a,b,z+.025,h-.05,.025,'glass','glazing');
        beam(a,b,z,.05,.07,frame,'frame');beam(a,b,z+h-.05,.05,.07,frame,'frame');
        if(i>0)post(a[0],a[1],z,h);
      }
      if(key==='standard')post(w/2,0,z,h);
      // Horizontal top and sill close the projected window enclosure.
      if(d.projection){const q=o.flip?1:-1,steps=24,dx=w/steps;
        for(let i=0;i<steps;i++){const x=(i+.5)*dx;let depth;
          if(key==='box')depth=o.projection;
          else if(key==='bay')depth=o.projection*Math.min(1,x/(w*.25),(w-x)/(w*.25));
          else{const index=Math.min(5,Math.floor(x/w*6)),a=points[index],b=points[index+1];depth=Math.abs(a[1]+(b[1]-a[1])*(x-a[0])/(b[0]-a[0]));}
          beam([i*dx,q*depth/2],[(i+1)*dx,q*depth/2],z-.025,.025,depth,frame,'sill');
          beam([i*dx,q*depth/2],[(i+1)*dx,q*depth/2],z+h,.025,depth,frame,'head');
        }
      }
      return out;
    }
    const hand=o.hingeRight?-1:1,origin=o.hingeRight?w:0,r=o.openRatio??.5;
    if(d.motion==='angle'){
      const angle=(o.openAngle??90)*Math.PI/180;
      const a=[origin,0],b=[origin+hand*(w-.05)*Math.cos(angle),side*(w-.05)*Math.sin(angle)];
      beam(a,b,z+.015,h-.04,.04,key==='shower'?'glass':panel,'leaf');
      const t=.88,p=[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t];post(p[0],p[1],z+Math.min(1,h*.5),.025);
    }else if(key==='sliding'){
      const mirror=x=>o.hingeRight?w-x:x;
      beam([mirror(w/2),-side*.035],[mirror(w),-side*.035],z,h,.035,panel,'fixedLeaf');
      beam([mirror(r*w/2),side*.035],[mirror(w/2+r*w/2),side*.035],z,h,.035,panel,'leaf');
    }else if(key==='pocket'||key==='barn'){
      const y=key==='barn'?side*(thickness/2+.055):0,shift=hand*r*w;
      beam([shift,y],[shift+w,y],z,h,.04,panel,'leaf');
      if(key==='barn')beam([hand<0?-w:0,y],[hand<0?w:w*2,y],z+h+.06,.035,.035,'metal','track');
    }else if(key==='bifold'){
      const a=r*Math.PI/2,l=(w-.04)/2,mid=[origin+hand*l*Math.cos(a),side*l*Math.sin(a)];
      beam([origin,0],mid,z,h,.035,panel,'leaf');beam(mid,[origin+hand*2*l*Math.cos(a),0],z,h,.035,panel,'leaf');
    }else if(key==='garage'){
      const count=8,sh=h/count,travel=r*h;
      for(let i=0;i<count;i++){const bottom=i*sh+travel;
        if(bottom<h){const height=Math.min(sh-.01,h-bottom);beam([.025,0],[w-.025,0],z+bottom,height,.04,panel,'section');}
        if(bottom+sh>h){const offset=Math.max(0,bottom-h),depth=Math.min(sh,bottom+sh-h);beam([.025,side*(offset+depth/2)],[w-.025,side*(offset+depth/2)],z+h-.04,.04,Math.max(.005,depth-.01),panel,'overheadSection');}
      }
    }else beam([.025,0],[w-.025,0],z+.015,h-.04,.04,panel,'leaf');
    return out;
  }
  function plan(o,thickness,selected=false){
    const key=style(o),d=types[key],w=o.width,side=o.flip?-1:1,color=selected?'#c08548':'#667e87',coords=n=>+n.toFixed(5);
    let out=`<g data-opening-style="${key}" stroke="${color}" stroke-width=".024" fill="none">`;
    if(key==='niche'){const a=side*thickness/2,b=a-side*o.recessDepth;out+=`<rect x="0" y="${Math.min(a,b)}" width="${w}" height="${o.recessDepth}" fill="#fcfdf9"/><path d="M0 ${b}H${w}"/>`;}
    else out+=`<rect x="0" y="${-thickness/2-.015}" width="${w}" height="${thickness+.03}" fill="#fcfdf9" stroke="none"/>`;
    for(const p of parts(o,thickness).filter(p=>!['sill','head'].includes(p.role))){
      if(p.role==='frame'&&p.bottom>o.sill+o.height*.5)continue;
      const dx=p.b[0]-p.a[0],dy=p.b[1]-p.a[1],L=Math.hypot(dx,dy),nx=-dy/L*p.depth/2,ny=dx/L*p.depth/2;
      const points=[[p.a[0]+nx,p.a[1]+ny],[p.b[0]+nx,p.b[1]+ny],[p.b[0]-nx,p.b[1]-ny],[p.a[0]-nx,p.a[1]-ny]];
      out+=`<polygon points="${points.map(a=>a.map(coords).join(',')).join(' ')}" fill="${p.material==='glass'?'#c6e2e9':'#ede4d5'}"/>`;
    }
    if(d.motion==='angle'&&(o.openAngle??90)>0){const a=(o.openAngle??90)*Math.PI/180,hand=o.hingeRight?-1:1,x=o.hingeRight?w:0;
      out+=`<path d="M${x+hand*w} 0 A${w} ${w} 0 0 ${side*hand>0?1:0} ${x+hand*w*Math.cos(a)} ${side*w*Math.sin(a)}" stroke-dasharray=".06 .04"/>`;
    }
    if(key==='pocket'){const x=o.hingeRight?-w:w;out+=`<rect x="${x}" y="${-thickness*.3}" width="${w}" height="${thickness*.6}" stroke-dasharray=".08 .05"/>`;}
    return out+`<path d="M0 ${-thickness/2}v${thickness}M${w} ${-thickness/2}v${thickness}"/></g>`;
  }
  const api={types,style,definition,defaults,normalize,profile,parts,plan};root.Openings=api;
  if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
