(function(root){
  'use strict';
  const clone=value=>JSON.parse(JSON.stringify(value));
  const stamp=()=>new Date().toISOString();
  // A failed project must never discard the other projects or its own original data.
  function load(raw,{validate,createEmpty,createDemo=createEmpty}){
    let parsed,db={projects:[],trash:[],recovery:[]};const ids=new Set(),archiveIds=new Set();let serial=0;
    const quarantine=(value,source,reason,exact=false)=>{
      let id;do{id='recovery-'+Date.now().toString(36)+'-'+serial++}while(archiveIds.has(id));archiveIds.add(id);
      db.recovery.push({id,source,reason:String(reason),name:typeof value?.name==='string'?value.name:'',createdAt:stamp(),raw:exact?value:JSON.stringify(value)});
    };
    const finish=()=>{if(!db.projects.length)db.projects.push(createEmpty());if(!db.projects.some(p=>p.id===db.active))db.active=db.projects[0].id;return db;};
    if(raw==null){const p=createDemo();return {active:p.id,projects:[p],trash:[],recovery:[]};}
    try{parsed=JSON.parse(raw);if(!parsed||typeof parsed!=='object'||Array.isArray(parsed)||!Array.isArray(parsed.projects))throw Error('项目库格式无效');}
    catch{quarantine(raw,'library','项目库格式无效',true);return finish();}
    db={...parsed,projects:[],trash:[],recovery:[]};
    for(const entry of Array.isArray(parsed.recovery)?parsed.recovery:[]){
      if(entry&&typeof entry.id==='string'&&!archiveIds.has(entry.id)&&typeof entry.raw==='string'&&['project','trash','library','recovery','legacy'].includes(entry.source)){
        archiveIds.add(entry.id);db.recovery.push(clone(entry));
      }else quarantine(entry,'recovery','恢复记录格式无效');
    }
    if(parsed.recovery!=null&&!Array.isArray(parsed.recovery))quarantine(parsed.recovery,'recovery','恢复记录格式无效');
    const checked=value=>{const p=validate(clone(value));if(typeof p.id!=='string'||!p.id||ids.has(p.id))throw Error('项目编号重复或无效');name(p.name);ids.add(p.id);return p;};
    for(const value of parsed.projects){try{db.projects.push(checked(value))}catch(e){quarantine(value,'project',e.message)}}
    if(parsed.trash!=null&&!Array.isArray(parsed.trash))quarantine(parsed.trash,'trash','回收站格式无效');
    else for(const entry of parsed.trash||[]){try{db.trash.push({...entry,project:checked(entry?.project)})}catch(e){quarantine(entry,'trash',e.message)}}
    return finish();
  }
  function retryRecovery(db,id,validate){
    const next=clone(db),at=(next.recovery||[]).findIndex(e=>e.id===id),entry=next.recovery?.[at];
    if(!entry||!['project','trash','legacy'].includes(entry.source))throw Error('请导出原始数据，修复后导入项目');
    const raw=JSON.parse(entry.raw),project=validate(entry.source==='trash'?raw.project:raw);name(project.name);
    if(next.projects.some(p=>p.id===project.id)||next.trash.some(e=>e.project.id===project.id))throw Error('项目编号重复，未覆盖已有项目');
    if(entry.source==='trash')next.trash.push({...raw,project});else next.projects.push(project);
    next.recovery.splice(at,1);return next;
  }
  function merge(db,incoming,newId){
    const next=clone(db),ids=new Set([...next.projects.map(p=>p.id),...(next.trash||[]).map(e=>e.project.id)]);
    next.trash=next.trash||[];next.recovery=next.recovery||[];
    const fresh=set=>{for(let i=0;i<100;i++){const id=newId();if(typeof id==='string'&&id&&!set.has(id))return id;}throw Error('无法生成独立项目编号');};
    const copyProject=source=>{const p=clone(source);if(ids.has(p.id))p.id=fresh(ids);ids.add(p.id);return p;};
    for(const p of incoming.projects)next.projects.push(copyProject(p));
    for(const e of incoming.trash||[])next.trash.push({...clone(e),project:copyProject(e.project)});
    const recoveryIds=new Set(next.recovery.map(e=>e.id));
    for(const entry of incoming.recovery||[]){const e=clone(entry);if(recoveryIds.has(e.id))e.id=fresh(recoveryIds);recoveryIds.add(e.id);next.recovery.push(e);}
    return next;
  }
  function name(value){
    const result=String(value??'').trim();
    if(!result||result.length>100)throw Error('项目名称须为 1–100 个字符');
    return result;
  }
  function find(db,id){
    const project=db.projects.find(p=>p.id===id);
    if(!project)throw Error('项目不存在，请重新打开项目库');
    return project;
  }
  function upsert(db,project){
    const next=clone(db),copy=clone(project),at=next.projects.findIndex(p=>p.id===copy.id);
    copy.name=name(copy.name);
    if(at<0)next.projects.push(copy);else next.projects[at]=copy;
    next.active=copy.id;
    return next;
  }
  function rename(db,id,value){
    const next=clone(db),project=find(next,id);
    project.name=name(value);project.updatedAt=stamp();return next;
  }
  function duplicate(db,id,newId){
    if(!newId||db.projects.some(p=>p.id===newId)||(db.trash||[]).some(e=>e.project.id===newId))throw Error('项目编号重复');
    const project=clone(find(db,id));project.id=newId;
    project.name=project.name.slice(0,94)+' · 副本';project.createdAt=project.updatedAt=stamp();
    return project;
  }
  function remove(db,id,createEmpty){
    const next=clone(db),project=find(next,id);
    next.trash=next.trash||[];
    if(next.trash.some(e=>e.project.id===id))throw Error('项目已经在回收站中');
    next.trash.push({project,deletedAt:stamp()});
    next.projects=next.projects.filter(p=>p.id!==id);
    if(!next.projects.length)next.projects.push(createEmpty());
    if(next.active===id)next.active=next.projects[0].id;
    return next;
  }
  function restore(db,id){
    const next=clone(db),at=(next.trash||[]).findIndex(e=>e.project.id===id);
    if(at<0)throw Error('回收站中没有这个项目');
    if(next.projects.some(p=>p.id===id))throw Error('同名编号的项目已存在，未覆盖已有项目');
    const [entry]=next.trash.splice(at,1);
    entry.project.updatedAt=stamp();next.projects.push(entry.project);return next;
  }
  function list(db,query='',sort='recent',trash=false){
    const rows=trash?(db.trash||[]).map(e=>({...e.project,deletedAt:e.deletedAt})):db.projects.slice();
    const needle=String(query).trim().toLocaleLowerCase();
    return rows.filter(p=>p.name.toLocaleLowerCase().includes(needle)).sort((a,b)=>sort==='name'?a.name.localeCompare(b.name):String(trash?b.deletedAt:b.updatedAt).localeCompare(String(trash?a.deletedAt:a.updatedAt)));
  }
  // Persist before publishing the new state, so a quota failure cannot silently delete a project.
  function persist(storage,key,next){storage.setItem(key,JSON.stringify(next));return next;}
  // localStorage has no atomic compare-and-swap. Reject stale snapshots and keep
  // an independent write-ahead checkpoint per save for the remaining race window.
  // A competing write is recovered as a whole library, never silently merged over geometry.
  function session(storage,key){
    const uid=()=>globalThis.crypto?.randomUUID?.()||Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);
    const prefix=key+':checkpoint:';let expected,acknowledged=[];
    const conflict=()=>Object.assign(Error('项目库已在其他标签页更新。请导出当前项目，再重新加载；未覆盖其他页面的数据。'),{code:'LIBRARY_CONFLICT'});
    const checkpoints=()=>{
      const rows=[];for(let i=0;i<storage.length;i++){const k=storage.key(i);if(!k?.startsWith(prefix))continue;const raw=storage.getItem(k);try{const v=JSON.parse(raw);if(v?.revision&&Array.isArray(v.next?.projects))rows.push({key:k,raw,...v})}catch{}}
      return rows;
    };
    function read(){
      acknowledged=[];expected=storage.getItem(key);let value;try{value=JSON.parse(expected)}catch{}
      const rows=checkpoints();if(!rows.length)return expected;
      if(!value||!Array.isArray(value.projects)){value={projects:[],trash:[],recovery:[]};if(expected!=null)value.recovery.push({id:'storage-'+uid(),source:'library',reason:'原项目库无法读取',createdAt:stamp(),raw:expected})}
      const known=new Set([value._persistence?.revision,...(value._persistence?.ancestors||[])]);
      const recovery=Array.isArray(value.recovery)?value.recovery:[];
      for(const row of rows){acknowledged.push(row.revision);if(known.has(row.revision)||recovery.some(r=>r.id==='checkpoint-'+row.revision))continue;
        const branch=clone(row.next);branch.recovery=(branch.recovery||[]).filter(entry=>!recovery.some(existing=>JSON.stringify(existing)===JSON.stringify(entry)));
        recovery.push({id:'checkpoint-'+row.revision,source:'library',name:'Recovered concurrent save',reason:'同时保存的独立版本；请导出原始数据，再导入项目库以恢复。',createdAt:row.createdAt,raw:JSON.stringify({...branch,format:'nexora-library-v1'})});
      }
      value.recovery=recovery;return JSON.stringify(value);
    }
    function write(next){
      if(expected===undefined)throw Error('Project storage must be read before writing');
      if(storage.getItem(key)!==expected)throw conflict();
      let previous;try{previous=JSON.parse(expected)}catch{}
      const rows=checkpoints(),live=new Set(rows.map(r=>r.revision));
      const ancestors=[...new Set([previous?._persistence?.revision,...(previous?._persistence?.ancestors||[]),...acknowledged])].filter(r=>r&&live.has(r));
      const revision=uid(),own=prefix+revision,result={...next,_persistence:{revision,ancestors}},raw=JSON.stringify(result);
      const checkpoint=JSON.stringify({revision,createdAt:stamp(),next:result});
      storage.setItem(own,checkpoint);
      try{if(storage.getItem(key)!==expected)throw conflict();storage.setItem(key,raw)}catch(error){try{if(storage.getItem(own)===checkpoint)storage.removeItem(own)}catch{}throw error}
      expected=raw;acknowledged=[];
      // Only remove versions already represented in the saved library or its recovery list.
      for(const row of rows)if(row.key!==own&&ancestors.includes(row.revision)){try{if(storage.getItem(row.key)===row.raw)storage.removeItem(row.key)}catch{}}
      return result;
    }
    return {read,write};
  }
  const api={name,find,upsert,rename,duplicate,remove,restore,list,persist,session,load,retryRecovery,merge};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.ProjectLibrary=api;
})(typeof globalThis!=='undefined'?globalThis:this);
