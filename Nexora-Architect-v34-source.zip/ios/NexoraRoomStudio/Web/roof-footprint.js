(function(root){
'use strict';
const E=root.BIM||require('./geometry.js'),R=root.RoofModel||require('./roof-model.js');
// Exact maximal-rectangle cover of an orthogonal polygon grid. Rectangles
// overlap where wings meet so the plane solver can construct real valley lines.
function rectangles(geometry){
 const points=geometry.flatMap(poly=>poly.flat()),unique=values=>[...new Set(values.map(n=>Math.round(n*1e7)/1e7))].sort((a,b)=>a-b);
 if(!points.length)throw Error('请先用墙围出闭合空间，再生成屋顶');
 for(const poly of geometry)for(const ring of poly)for(let i=0;i<ring.length-1;i++)if(Math.abs(ring[i][0]-ring[i+1][0])>1e-7&&Math.abs(ring[i][1]-ring[i+1][1])>1e-7)throw Error('自动分区目前支持直角轮廓；斜边请使用独立屋顶调整');
 const xs=unique(points.map(p=>p[0])),ys=unique(points.map(p=>p[1]));
 if(xs.length>160||ys.length>160)throw Error('屋顶轮廓过于复杂，请分区建立独立屋顶');
 const inside=(x,y)=>geometry.some(poly=>E.pointIn({x,y},poly[0].map(([x,y])=>({x,y})))&&!poly.slice(1).some(r=>E.pointIn({x,y},r.map(([x,y])=>({x,y})))));
 const grid=ys.slice(1).map((y,j)=>xs.slice(1).map((x,i)=>inside((xs[i]+x)/2,(ys[j]+y)/2))),out=[];
 for(let start=0;start<grid.length;start++){
  const good=grid[start].map(()=>true);
  for(let end=start;end<grid.length;end++){
   for(let c=0;c<good.length;c++)good[c]&&=grid[end][c];
   for(let c=0;c<good.length;c++)if(good[c]){
    const left=c;while(c+1<good.length&&good[c+1])c++;const right=c;
    const above=start>0&&grid[start-1].slice(left,right+1).every(Boolean),below=end+1<grid.length&&grid[end+1].slice(left,right+1).every(Boolean);
    if(!above&&!below)out.push({x:xs[left],y:ys[start],w:xs[right+1]-xs[left],d:ys[end+1]-ys[start]});
   }
  }
 }
 if(out.length>100)throw Error('屋顶分区超过100个，请简化轮廓');
 return out.sort((a,b)=>b.w*b.d-a.w*a.d||a.x-b.x||a.y-b.y);
}
function generate(p,floor,options={}){
 const rooms=E.detectRooms(p,floor).filter(r=>r.roomType!=='deck'),shape=E.polygonUnion(rooms.flatMap(r=>r.boundaryGeometry)),parts=rectangles(shape);
 if(!parts.length)throw Error('请先用墙围出闭合空间，再生成屋顶');
 const roofs=parts.map(b=>({id:E.uid(),floor,...b,type:options.type||'gable',pitch:options.pitch??26.5650511771,overhang:options.overhang??.4572,material:options.material||'charcoal',axis:b.w>=b.d?'x':'y',elevationOffset:options.elevationOffset??0}));
 const candidate={...p,roofs:[...p.roofs.filter(r=>r.floor!==floor),...roofs]};
 R.build(candidate); // Fail atomically; never clear the previous roofs on error.
 p.roofs=candidate.roofs;return roofs;
}
function demo(){
 const p=E.newProject('Roof Study · L-shaped Craftsman'),f=p.floors[0];p.unit='ft';p.currency='USD';f.name='Main Floor';
 const points=[[0,0],[12,0],[12,6],[6,6],[6,10],[0,10]];
 points.forEach((q,i)=>{const b=points[(i+1)%points.length];E.wall(p,{x:q[0],y:q[1]},{x:b[0],y:b[1]},f.id)});
 generate(p,f.id);for(const r of E.detectRooms(p,f.id))E.roomMeta(p,r,{name:'Roof Study',roomType:'living'});return p;
}
const API={rectangles,generate,demo};root.RoofFootprint=API;if(typeof module!=='undefined')module.exports=API;
})(typeof window!=='undefined'?window:globalThis);
