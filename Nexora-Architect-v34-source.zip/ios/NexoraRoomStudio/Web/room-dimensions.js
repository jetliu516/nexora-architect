(function(root) {
  'use strict';
  const E = root.BIM || require('./geometry.js');
  const EPS = 0.001;
  const close = (a,b) => Math.abs(a-b) < EPS;

  // Only axis-aligned rectangular envelopes with uniform wall thickness are
  // dimension driven. Irregular rooms remain editable through wall endpoints.
  function measure(p, room) {
    if (!room?.points?.length) return null;
    const xs=room.points.map(q=>q.x), ys=room.points.map(q=>q.y);
    const x0=Math.min(...xs), x1=Math.max(...xs), y0=Math.min(...ys), y1=Math.max(...ys);
    if (Math.abs(Math.abs(E.area(room.points))-(x1-x0)*(y1-y0))>EPS) return null;
    if (room.points.some((q,i)=>{const b=room.points[(i+1)%room.points.length];return !close(q.x,b.x)&&!close(q.y,b.y)})) return null;
    const walls=p.walls.filter(w=>w.floor===room.floor && room.wallIds.includes(w.id));
    const on=(axis,value)=>walls.filter(w=>close(w.a[axis],value)&&close(w.b[axis],value));
    const sides={left:on('x',x0),right:on('x',x1),top:on('y',y0),bottom:on('y',y1)};
    for(const list of Object.values(sides)) if(!list.length||list.some(w=>!close(w.thickness,list[0].thickness))) return null;
    const left=x0+sides.left[0].thickness/2, right=x1-sides.right[0].thickness/2;
    const top=y0+sides.top[0].thickness/2, bottom=y1-sides.bottom[0].thickness/2;
    if(right<=left||bottom<=top) return null;
    return {x0,x1,y0,y1,left,right,top,bottom,width:right-left,depth:bottom-top,sides};
  }

  function moveSide(p, room, axis, requested) {
    const m=measure(p,room);
    if(!m) throw Error('此空间不是等厚直角矩形，请通过墙体端点调整。');
    if(!Number.isFinite(requested)||requested<0.5||requested>100) throw Error('房间净尺寸应在 0.5–100 m 之间。');
    const side=axis==='x'?'right':'bottom', current=axis==='x'?m.width:m.depth;
    const delta=requested-current, coordinate=axis==='x'?m.x1:m.y1, other=axis==='x'?'y':'x';
    if(Math.abs(delta)<0.000001) return;
    const all=p.walls.filter(w=>w.floor===room.floor);
    // Extend to every touching collinear segment: a shared continuous wall must
    // stay continuous. Move attached endpoints once, from an immutable snapshot.
    const support=new Set(m.sides[side].map(w=>w.id));
    let changed=true;
    while(changed){
      changed=false;
      for(const w of all){
        if(support.has(w.id)||!close(w.a[axis],coordinate)||!close(w.b[axis],coordinate)) continue;
        const lo=Math.min(w.a[other],w.b[other]),hi=Math.max(w.a[other],w.b[other]);
        if(all.some(v=>support.has(v.id)&&lo<=Math.max(v.a[other],v.b[other])+EPS&&hi>=Math.min(v.a[other],v.b[other])-EPS)) {support.add(w.id);changed=true;}
      }
    }
    const lines=all.filter(w=>support.has(w.id)).map(w=>({a:{...w.a},b:{...w.b}}));
    for(const w of all) for(const key of ['a','b']) {
      const q=w[key];
      if(lines.some(line=>E.projectPoint(q,line.a,line.b).distance<EPS)) w[key]={...q,[axis]:q[axis]+delta};
    }
  }

  function resize(p, roomId, width, depth) {
    const q=E.clone(p), room=q.floors.flatMap(f=>E.detectRooms(q,f.id)).find(r=>r.id===roomId);
    const m=measure(q,room);
    if(!m) throw Error('此空间暂不支持净尺寸驱动，请选择矩形房间。');
    const before=E.detectRooms(q,room.floor);
    // Match persistent boundary wall IDs one-to-one to preserve room labels.
    const labels=before.map(room=>({room}));
    moveSide(q,room,'x',width);
    let target=E.detectRooms(q,room.floor).find(r=>r.wallIds.length===room.wallIds.length&&r.wallIds.every(id=>room.wallIds.includes(id)));
    if(!target) throw Error('移动墙体会改变空间拓扑，请先调整相邻墙体。');
    moveSide(q,target,'y',depth);
    const after=E.detectRooms(q,room.floor);
    if(after.length!==before.length) throw Error('此尺寸会合并或破坏相邻房间，修改已取消。');
    const mapped=new Set();
    for(const {room:old} of labels){
      const match=after.find(r=>!mapped.has(r.id)&&r.wallIds.length===old.wallIds.length&&r.wallIds.every(id=>old.wallIds.includes(id)));
      if(!match) throw Error('此尺寸会改变相邻房间连接，修改已取消。');
      mapped.add(match.id);
      E.roomMeta(q,match,{name:old.name,material:old.material,roomType:old.roomType,includeLiving:old.includeLiving,anchor:match.center});
      if(old.id===room.id) target=match;
    }
    const final=measure(q,target);
    if(!final||Math.abs(final.width-width)>EPS||Math.abs(final.depth-depth)>EPS) throw Error('墙体约束不允许这个净尺寸，修改已取消。');
    // Hosted openings and linked stairwell footprints must remain valid.
    const valid=E.validate(q);
    Object.assign(p,valid);
    return E.detectRooms(p,room.floor).find(r=>r.id===target.id);
  }
  root.RoomDimensions={measure,resize};
  if(typeof module!=='undefined') module.exports=root.RoomDimensions;
})(typeof window!=='undefined'?window:globalThis);
