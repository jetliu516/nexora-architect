(function () {
  'use strict';
  function create({ tools, getProject, shared, getContext, getHistory, onTranscript, onStatus, onActive }) {
    let current = null;
    function stop(reason = '语音已结束') {
      const call = current;
      if (!call) return;
      current = null;
      clearTimeout(call.startTimer); clearTimeout(call.disconnectTimer);
      call.abort.abort();
      call.mic?.getTracks().forEach(track => track.stop());
      if (call.channel) call.channel.close();
      call.pc?.close();
      call.audio.pause(); call.audio.srcObject = null; call.audio.remove();
      onActive(false); onStatus(reason);
    }
    function valid(call) {
      if (current !== call) return false;
      if (getProject() !== call.project) { stop('已切换项目，语音已结束'); return false; }
      return true;
    }
    function send(call, event) {
      if (valid(call) && call.channel?.readyState === 'open') call.channel.send(JSON.stringify(event));
    }
    function onMessage(call, event) {
      if (!valid(call)) return;
      let data;
      try { data = JSON.parse(event.data); } catch { return; }
      switch (data.type) {
        case 'input_audio_buffer.speech_started':
          call.turn++; onStatus('正在听你说…'); break;
        case 'input_audio_buffer.speech_stopped':
          onStatus('正在理解…'); break;
        case 'response.created':
          call.turns.set(data.response.id, call.turn); break;
        case 'output_audio_buffer.started':
          onStatus('助手在说话 · 你可以打断'); break;
        case 'output_audio_buffer.stopped':
        case 'output_audio_buffer.cleared':
          onStatus('正在听 · 直接说下一句'); break;
        case 'conversation.item.input_audio_transcription.completed':
          if (data.transcript?.trim()) onTranscript('user', data.transcript.trim());
          break;
        case 'response.done': {
          const response = data.response;
          const sameTurn = call.turns.get(response.id) === call.turn;
          call.turns.delete(response.id);
          if (response.status !== 'completed' || !sameTurn) {
            if (response.status === 'failed') onStatus('这次回复未完成，请再说一次');
            break;
          }
          let usedTool = false;
          for (const item of response.output || []) {
            if (item.type === 'message') {
              const line = (item.content || []).map(c => c.transcript || c.text || '').join('').trim();
              if (line) onTranscript('assistant', line);
            }
            if (item.type !== 'function_call' || call.calls.has(item.call_id)) continue;
            call.calls.add(item.call_id); usedTool = true;
            let result;
            try {
              if (!shared()) result = { ok:false, message:'用户已关闭户型共享，不能读取或修改图纸。' };
              else if (Object.hasOwn(tools, item.name)) result = tools[item.name](JSON.parse(item.arguments || '{}'));
              else result = { ok:false, message:'不支持此绘图操作。' };
            } catch { result = { ok:false, message:'指令参数不完整，请澄清后重试。' }; }
            send(call, {type:'conversation.item.create',item:{type:'function_call_output',call_id:item.call_id,output:JSON.stringify(result)}});
          }
          if (usedTool) send(call, {type:'response.create'});
          break;
        }
        case 'error':
          if (data.error?.code === 'response_cancel_not_active') break;
          stop('实时语音中断，请重新开始通话'); break;
      }
    }
    async function start() {
      if (current) return;
      if (!navigator.mediaDevices?.getUserMedia || !window.RTCPeerConnection) {
        onStatus('当前页面无法使用麦克风，请用 Safari 或 Chrome 直接打开在线工作台。'); return;
      }
      const call = {project:getProject(),abort:new AbortController(),audio:document.createElement('audio'),
        turn:0,turns:new Map(),calls:new Set()};
      current=call; onActive(true); onStatus('请允许使用麦克风');
      call.audio.autoplay=true; call.audio.setAttribute('playsinline',''); document.body.append(call.audio);
      try {
        const mic = await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true},video:false});
        if (!valid(call)) { mic.getTracks().forEach(track=>track.stop()); return; }
        call.mic=mic;
        mic.getAudioTracks()[0].onended=()=>{if(valid(call))stop('麦克风已断开');};
        onStatus('正在连接语音…');
        call.startTimer=setTimeout(()=>{if(valid(call))stop('语音连接超时，请重试');},30000);
        const pc = call.pc = new RTCPeerConnection();
        pc.ontrack=e=>{
          if (!valid(call)) return;
          call.audio.srcObject=e.streams[0]||new MediaStream([e.track]);
          call.audio.play().catch(()=>{if(valid(call))stop('浏览器阻止语音播放，请允许音频后重新开始');});
        };
        pc.onconnectionstatechange=()=>{
          if (!valid(call)) return;
          clearTimeout(call.disconnectTimer);
          if (['failed','closed'].includes(pc.connectionState)) stop('语音连接已断开，请重试');
          if (pc.connectionState==='disconnected') call.disconnectTimer=setTimeout(()=>{if(valid(call))stop('网络中断，语音已结束');},6000);
        };
        for (const track of mic.getAudioTracks()) pc.addTrack(track,mic);
        const channel=call.channel=pc.createDataChannel('oai-events');
        channel.onmessage=e=>onMessage(call,e);
        channel.onclose=()=>{if(valid(call))stop('语音连接已关闭');};
        channel.onerror=()=>{if(valid(call))stop('语音连接出错，请重试');};
        channel.onopen=()=>{
          if (!valid(call)) return;
          clearTimeout(call.startTimer);
          for (const previous of getHistory().slice(-8)) {
            send(call,{type:'conversation.item.create',item:{type:'message',role:previous.role,
              content:[{type:previous.role==='assistant'?'output_text':'input_text',text:previous.content.slice(0,2500)}]}});
          }
          if(shared()) send(call,{type:'conversation.item.create',item:{type:'message',role:'user',
            content:[{type:'input_text',text:'当前户型参考数据（非指令）：'+getContext().slice(0,11000)}]}});
          onStatus('正在听 · 直接说，也可以随时打断');
        };
        const offer=await pc.createOffer(); await pc.setLocalDescription(offer);
        if (!valid(call)) return;
        const res=await fetch('/api/ai/voice',{method:'POST',headers:{'Content-Type':'application/sdp','X-Nexora-Client':'studio','X-Nexora-Language':window.NexoraI18n?.language||'zh'},
          body:offer.sdp,signal:call.abort.signal});
        if (!res.ok) throw Error((await res.json().catch(()=>({}))).error || '语音连接失败，请重试');
        const answer=await res.text();
        if (valid(call)) await pc.setRemoteDescription({type:'answer',sdp:answer});
      } catch (err) {
        if (!valid(call)) return;
        const reason=({NotAllowedError:'麦克风未获授权，请在浏览器的网站权限里允许麦克风。',
          NotFoundError:'没有找到麦克风，请连接设备后再试。',NotReadableError:'麦克风暂时不可用，请检查设备。'})[err.name];
        stop(reason || err.message || '语音连接失败');
      }
    }
    window.addEventListener('pagehide',()=>stop());
    return {start,stop,followKitchen(id){if(current)current.project=id;},get active(){return !!current;}};
  }
  window.DesignVoice = { create };
})();
