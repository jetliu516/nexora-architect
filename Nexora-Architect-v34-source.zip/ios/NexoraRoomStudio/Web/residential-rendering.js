(function(root){'use strict';
const T=root.THREE,skies=new Map(),previews=new Map();
const moods={day:{position:[-12,24,10],color:'#fff3dc',power:3.2,sky:['#6da8ce','#e2edf0']},golden:{position:[-22,8,18],color:'#ffd1a0',power:3.1,sky:['#739db8','#f4ddbf']},overcast:{position:[-10,30,8],color:'#f2f6ff',power:1.3,sky:['#9cabb8','#e5e9e9']}};
function sky(kind){if(!Object.hasOwn(moods,kind))kind='day';if(skies.has(kind))return skies.get(kind);const c=document.createElement('canvas');c.width=1024;c.height=512;const g=c.getContext('2d'),m=moods[kind].sky,gradient=g.createLinearGradient(0,0,0,512);gradient.addColorStop(0,m[0]);gradient.addColorStop(.5,m[1]);gradient.addColorStop(1,m[1]);g.fillStyle=gradient;g.fillRect(0,0,1024,512);g.filter='blur(14px)';g.fillStyle='rgba(255,255,255,.3)';for(const [x,y,w,h]of [[180,120,180,12],[620,170,240,16],[880,80,130,10]]){g.beginPath();g.ellipse(x,y,w,h,0,0,Math.PI*2);g.fill()}const t=new T.CanvasTexture(c);t.mapping=T.EquirectangularReflectionMapping;t.colorSpace=T.SRGBColorSpace;skies.set(kind,t);return t}
function siteFloor(p){return p.floors.filter(f=>f.elevation>=0).sort((a,b)=>a.elevation-b.elevation)[0]||p.floors.slice().sort((a,b)=>b.elevation-a.elevation)[0]}
function label(text,x,y,z,width=2,options={}){
 if(typeof document==='undefined')return null;
 const c=document.createElement('canvas');c.width=1024;c.height=224;const g=c.getContext('2d');g.fillStyle='#ffffff';g.fillRect(0,0,c.width,c.height);g.strokeStyle='#14251c';g.lineWidth=8;g.strokeRect(3,3,1018,218);g.font='900 104px Arial';g.textAlign='center';g.textBaseline='middle';g.fillStyle='#14251c';g.fillText(text,512,112,960);
 const map=new T.CanvasTexture(c);map.colorSpace=T.SRGBColorSpace;
 if(options.surface){const material=new T.MeshBasicMaterial({map,color:'#ffffff',toneMapped:false,transparent:false,side:T.DoubleSide,depthTest:true,depthWrite:true,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1});material.userData.ownsMap=true;const mesh=new T.Mesh(new T.PlaneGeometry(width,width*224/1024),material);mesh.rotation.x=-Math.PI/2;mesh.position.set(x,y,z);mesh.userData.label=text;return mesh;}
 const material=new T.SpriteMaterial({map,color:'#ffffff',toneMapped:false,fog:false,opacity:1,sizeAttenuation:true,depthTest:options.occlude===true,depthWrite:false,transparent:false});material.userData.ownsMap=true;
 const sprite=new T.Sprite(material);sprite.position.set(x,y,z);sprite.scale.set(width,width*224/1024,1);sprite.userData.label=text;sprite.renderOrder=20;return sprite;
}
function setup(view){if(view.residentialLightingReady)return;view.residentialLightingReady=true;view.scene.fog=new T.Fog('#d5e2e7',80,230);view.renderer.toneMappingExposure=1.05;view.sun.shadow.normalBias=.035;view.sun.shadow.radius=3}
// Lighting is independent of the existing, saved site landscape. Never build a
// second driveway/tree group or move it when the active floor changes.
function environment(view,p,s){const f=siteFloor(p),b=root.BIM.bounds(p,f.id),ground=view.ground.position.y,cx=b.x+b.w/2,cz=b.y+b.d/2,kind=Object.hasOwn(moods,s.daylight)?s.daylight:'day',m=moods[kind];view.sun.position.set(cx+m.position[0],ground+m.position[1],cz+m.position[2]);view.sun.target.position.set(cx,ground,cz);if(!view.sun.target.parent)view.scene.add(view.sun.target);view.sun.target.updateMatrixWorld();view.sun.color.set(m.color);view.sun.intensity=m.power*(s.style==='clay'?2/3.2:1);view.scene.background=sky(kind);view.scene.environment=s.style==='clay'||s.style==='wire'?null:view.scene.background;if(view.scene.fog)view.scene.fog.color.set(m.sky[1])}
// Preserve the material library's numeric UV API; this adapter also supports
// the material-gallery integration from the residential enhancement branch.
const material=(key,options)=>root.ResidentialMaterials.material(key,options);
function uv(geometry,value=.5){root.ResidentialMaterials.uv(geometry,typeof value==='number'?value:value?.userData?.textureScale??.5)}
function preview(kind){if(!previews.has(kind))previews.set(kind,root.ResidentialMaterials.texture(kind).image.toDataURL('image/png'));return previews.get(kind)}
root.ResidentialRendering={material,uv,setup,environment,preview,siteFloor,label};
})(typeof window!=='undefined'?window:globalThis);
