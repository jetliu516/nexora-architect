(function(root){
'use strict';const $=id=>document.getElementById(id),t=x=>root.NexoraI18n?.t(x)||x,esc=x=>root.Drawings.esc(String(x));let bridge,mode='starter',tour=-1,tourProject='',initialWalls=0,initialDoors=0;
function setMode(next){mode=next==='pro'?'pro':'starter';document.body.classList.toggle('starter-workspace',mode==='starter');try{localStorage.setItem('nexora-workspace-mode',mode)}catch{}$('workspaceMode').value=mode;bridge.resize()}
let templateFilters={},preview=null;
function openTemplates(options={}){preview?.close();templateFilters={...options};bridge.dialog('北美住宅样板',NorthAmerica.gallery(templateFilters))}
function filterTemplates(page=1){const next={page};for(const [key,id]of [['style','naStyle'],['bedrooms','naBedrooms'],['floors','naFloors'],['area','naArea'],['search','naSearch']])next[key]=$(id)?.value||'';openTemplates(next)}
function tourText(){return [['画一面墙','选择画墙工具，在空白处点击起点和终点。至少画 4 ft 长，Esc 结束。'],['放一扇门','选择门工具，在刚画的墙上点击。门会自动与墙体关联。'],['看看你的家','切到 3D。拖动旋转视角，开启 Cutaway View 查看室内。']][tour]}
function update(){if(!bridge||!$('starterGuide'))return;const {p}=bridge.state();if(tour<0){$('starterGuide').hidden=true;return}const text=tourText();$('starterGuide').hidden=false;$('starterGuide').innerHTML=`<div><small>3 MINUTE START · ${tour+1} / 3</small><strong>${esc(t(text[0]))}</strong><p>${esc(t(text[1]))}</p></div><button data-residential="tourNext">${esc(t(tour===2?'完成':'下一步'))}</button><button data-residential="tourClose" aria-label="${esc(t('关闭引导'))}">×</button>`;if(p.id!==tourProject){tour=-1;$('starterGuide').hidden=true}}
function tourStart(){const {p}=bridge.state();tour=0;tourProject=p.id;initialWalls=p.walls.length;initialDoors=p.openings.filter(o=>o.kind==='door').length;bridge.view('plan');bridge.tool('wall');update()}
function init(b){bridge=b;preview=root.TemplatePreview?.create(bridge);$('dialog').addEventListener?.('close',()=>preview?.close());new MutationObserver(()=>{if(preview?.active()&&!$('templatePreview'))preview.close()}).observe($('dialog'),{childList:true,subtree:true});try{mode=localStorage.getItem('nexora-workspace-mode')||'starter'}catch{}
 const controls=document.createElement('div');controls.className='residential-preferences';controls.innerHTML=`<select id="workspaceMode" aria-label="工作区模式"><option value="starter">新手模式</option><option value="pro">专业模式</option></select>`;document.querySelector('.header-end').prepend(controls);
 const ai=document.createElement('button');ai.id='aiAssistantEntry';ai.type='button';ai.className='ai-assistant-entry';ai.setAttribute('data-action','aiAssistant');ai.setAttribute('aria-controls','aiPanel');ai.setAttribute('aria-expanded',String($('aiPanel')?.hidden===false));ai.innerHTML='<span class="ai-entry-icon" aria-hidden="true">✦</span><span>AI 助手</span>';document.querySelector('.header-end').prepend(ai);
 const bar=document.createElement('nav');bar.className='starter-toolbar';bar.setAttribute('aria-label','住宅设计常用工具');bar.innerHTML=`<div class="starter-brandline"><small>MAKE ROOM FOR YOUR IDEAS</small><strong>设计一个像家的家</strong></div><div class="starter-tools"><button data-tool="wall"><b>╱</b><span>画墙</span></button><button data-tool="door"><b>◰</b><span>放门</span></button><button data-tool="window"><b>⊞</b><span>放窗</span></button><button data-mode="3d"><b>⌂</b><span>看 3D</span></button><button data-action="homeTemplates"><b>▧</b><span>选住宅样板</span></button><button data-action="export"><b>↗</b><span>导出</span></button><button data-action="structure"><b>⌖</b><span>结构设计</span></button><button data-residential="guide"><b>▷</b><span>3 分钟上手</span></button></div>`;document.querySelector('.project-actions').after(bar);
 const privacy=document.createElement('div');privacy.className='local-privacy';privacy.innerHTML=`<span>无需注册即可设计 · 项目保存在你的浏览器</span><button data-action="json">备份项目</button>`;bar.after(privacy);
 const guide=document.createElement('aside');guide.id='starterGuide';guide.hidden=true;guide.setAttribute('aria-live','polite');$('viewport').append(guide);
 $('workspaceMode').onchange=()=>setMode($('workspaceMode').value);setMode(mode);
 document.addEventListener('click',e=>{const button=e.target.closest('button');if(!button)return;const d=button.dataset,{p,s}=bridge.state();
 if(preview?.click(d))return;
 if(d.previewNorthAmerica){try{preview.open(d.previewNorthAmerica,()=>openTemplates(templateFilters))}catch(err){bridge.toast(err.message)}return}
 if(d.naPage){filterTemplates(Number(d.naPage));return}
 if(d.loadNorthAmerica){try{const q=NorthAmerica.build(d.loadNorthAmerica);if(bridge.open(q)){s.roof=true;s.allFloors=true;s.cutaway=false;s.mode='3d';s.selected=null;bridge.refresh();$('dialog').close()}}catch(err){bridge.toast(err.message)}return}
 if(d.doorWidth){const v=p.openings.find(o=>o.id===s.selected?.id);if(v)bridge.transact(()=>v.width=Number(d.doorWidth),'门宽已更新，可撤销');return}
 if(d.wallAssembly){const v=p.walls.find(w=>w.id===s.selected?.id);if(v)bridge.transact(()=>{v.thickness=d.wallAssembly==='2x4'?.1143:.1905;v.assembly=d.wallAssembly},'墙体组合厚度已更新，可撤销');return}
 if(d.floorHeight){bridge.transact(()=>{const f=p.floors.find(f=>f.id===s.floor);f.height=Number(d.floorHeight);p.walls.filter(w=>w.floor===f.id).forEach(w=>w.height=f.height)},'层高已更新，可撤销');return}
 if(d.residential==='guide'){bridge.dialog('3 分钟上手',`<p>跟着三个步骤练习：画墙、放门、查看 3D。当前项目保持打开；每一步都可以撤销。</p><button class="primary" data-residential="tourStart">开始引导</button>`)}
 if(d.residential==='tourStart'){$('dialog').close();tourStart()}
 if(d.residential==='tourClose'){tour=-1;update()}
 if(d.residential==='tourNext'){
 if(tour===0&&p.walls.length<=initialWalls){bridge.toast('先点击画布上的两个位置，完成一面墙。');return}
 if(tour===1&&p.openings.filter(o=>o.kind==='door').length<=initialDoors){bridge.toast('先在墙上点击放置一扇门，再继续。');return}
 tour++;if(tour===1)bridge.tool('door');if(tour===2)bridge.view('3d');if(tour>2){tour=-1;bridge.toast('已完成：继续设计，或导出 JSON 备份。')}update();
 }
 });
 document.addEventListener('change',e=>{if(preview?.change(e.target.id,e.target.value))return;if(['naStyle','naBedrooms','naFloors','naArea','naSearch','naPage'].includes(e.target.id))filterTemplates(e.target.id==='naPage'?Number(e.target.value):1)});
 document.addEventListener('keydown',e=>{if(e.target.id==='naSearch'&&e.key==='Enter'){e.preventDefault();filterTemplates(1)}});
 root.addEventListener('nexora-language-change',()=>{update();if($('dialog').open&&preview?.active()){preview.refresh();return}if($('dialog').open&&$('naStyle'))openTemplates(templateFilters)});
}
root.ResidentialUI={init,update,openTemplates};
})(window);
