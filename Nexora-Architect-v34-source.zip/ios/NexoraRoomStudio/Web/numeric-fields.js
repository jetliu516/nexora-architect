(function(root){
'use strict';
// Decimal text controls avoid native accessibility APIs exposing float32 values.
// Formatting changes the presentation only; no model write occurs on render.
const format=value=>{const n=Number(value);return Number.isFinite(n)?(Object.is(n,-0)?0:n).toFixed(3).replace(/(\.\d{2})0$/,'$1'):String(value??'')};
const originals=new WeakMap(),committed=new WeakMap();
const read=el=>{if(!el)return '';const rec=originals.get(el);if(rec&&!rec.dirty&&el.value===rec.display)return rec.raw;if(el.dataset?.numericSource!==undefined&&el.value===el.dataset.numericDisplay)return el.dataset.numericSource;return el.value};
const is=el=>el?.type==='number'||el?.dataset?.numericControl==='true';
function validate(el){
 if(!is(el))return true;
 const raw=el.value.trim(),n=Number(raw);let error='';
 if(!raw){if(el.required)error='Enter a number.'}
 else if(!/^[+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?$/i.test(raw)||!Number.isFinite(n))error='Enter a finite number.';
 else {const min=el.getAttribute('min'),max=el.getAttribute('max'),step=el.getAttribute('step');
 if(min!==null&&n<Number(min)-1e-9)error='Minimum: '+min;
 else if(max!==null&&n>Number(max)+1e-9)error='Maximum: '+max;
 else if(step&&step!=='any'&&Number(step)>0){const q=(n-Number(min||0))/Number(step);if(Math.abs(q-Math.round(q))>1e-7)error='Step: '+step}
 }
 el.setCustomValidity(error);return !error;
}
function prepare(el){
 if(el?.tagName!=='INPUT'||!is(el))return;
 if(el.type==='number'){el.dataset.numericControl='true';el.type='text';el.inputMode='decimal';el.setAttribute('inputmode','decimal')}
 // Retain integer counts; decimals use 2–3 places. Never add grouping in inputs.
 const step=el.getAttribute('step'),raw=el.value;
 if(raw!==''&&Number.isFinite(Number(raw))){const next=step==='1'&&Number.isInteger(Number(raw))?String(Number(raw)):format(raw);if(next!==raw)el.value=next;if(el.hasAttribute('value')&&el.getAttribute('value')!==next)el.setAttribute('value',next)}
 if(!originals.has(el)){originals.set(el,{raw,display:el.value});committed.set(el,el.value)}
 validate(el);
}
function scan(node){if(node?.nodeType!==1&&node!==document)return;prepare(node);node.querySelectorAll?.('input[type="number"],input[data-numeric-control]').forEach(prepare)}
root.NumericFields={format,is,read,prepare,scan,validate};
if(typeof document!=='undefined'){
 scan(document);
 new MutationObserver(records=>{for(const r of records)if(r.type==='childList')r.addedNodes.forEach(scan);else if(document.activeElement!==r.target)prepare(r.target)}).observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['value']});
 document.addEventListener('focusin',e=>{if(e.target.type==='number')prepare(e.target)},true);
 document.addEventListener('input',e=>{if(is(e.target)){const rec=originals.get(e.target);if(rec)rec.dirty=true;validate(e.target)}},true);
 document.addEventListener('change',e=>{if(is(e.target)){prepare(e.target);validate(e.target);committed.set(e.target,e.target.value)}},true);
 // Some engines suppress native change after converting number to text.
 document.addEventListener('focusout',e=>{const el=e.target;if(is(el)&&committed.has(el)&&el.value!==committed.get(el))el.dispatchEvent(new Event('change',{bubbles:true}))},true);
 document.addEventListener('submit',e=>{scan(e.target);const invalid=[...e.target.querySelectorAll('input[data-numeric-control]')].find(el=>!validate(el));if(invalid){e.preventDefault();e.stopImmediatePropagation();invalid.reportValidity()}},true);
}
if(typeof module!=='undefined')module.exports=root.NumericFields;
})(typeof window!=='undefined'?window:globalThis);
