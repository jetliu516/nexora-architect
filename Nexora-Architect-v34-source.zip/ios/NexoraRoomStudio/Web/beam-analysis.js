(function(root){
  'use strict';
  const method='rectangular-simple-span-v1',kinds=['beam','joist','header'],clone=x=>JSON.parse(JSON.stringify(x));
  const references=[{title:'USDA Wood Handbook (2021), Chapter 9: Structural Analysis Equations',url:'https://research.fs.usda.gov/download/treesearch/62251.pdf',sections:'Equations 9-2 to 9-4, 9-13 to 9-14; Table 9-1. Mechanics reference, not adopted local code.'}];
  function number(v,name,min,max,optional=false){if(optional&&(v===null||v===undefined))return null;if(typeof v!=='number'||!Number.isFinite(v)||v<min||v>max)throw Error('Invalid '+name);return v;}
  function text(v,name,max=2000){if(typeof v!=='string'||v.length>max)throw Error('Invalid '+name);return v.trim();}
  function geometry(m){if(!m||!kinds.includes(m.kind))throw Error('Select a beam, joist or header with a solid rectangular section');const g={id:text(m.id,'member ID',100),floor:text(m.floor,'floor ID',100),kind:m.kind,material:text(m.material,'material',500)};for(const key of ['x1','y1','x2','y2','z'])g[key]=number(m[key],key,-500,500);g.width=number(m.width,'width',.001,5);g.depth=number(m.depth,'depth',.001,10);const L=Math.hypot(g.x2-g.x1,g.y2-g.y1);number(L,'span',.05,100);return g;}
  function input(raw,L){if(!raw||raw.method!==method)throw Error('Unsupported analysis method');
    const out={method,dead:number(raw.dead,'permanent line load',0,1e7),variable:number(raw.variable,'variable line load',0,1e7),E:number(raw.E,'true bending modulus E',1e6,1e12),G:number(raw.G,'shear modulus G',1e5,1e12)};
    for(const key of ['Fb','Fv','Fc'])out[key]=number(raw[key],key,1,1e10,true);
    for(const key of ['leftBearing','rightBearing'])out[key]=number(raw[key],key,.001,5,true);
    for(const key of ['totalLimit','variableLimit'])out[key]=number(raw[key],key,1,10000,true);
    if(!Array.isArray(raw.points)||raw.points.length>12)throw Error('Use up to 12 point loads');
    out.points=raw.points.map(p=>{if(!p||typeof p!=='object')throw Error('Invalid point load');const x=number(p.x,'point position',0,L);if(x<=0||x>=L)throw Error('Point loads must lie between the support centers');return{x,dead:number(p.dead,'permanent point load',0,1e9),variable:number(p.variable,'variable point load',0,1e9)};});
    if(out.dead+out.variable+out.points.reduce((s,p)=>s+p.dead+p.variable,0)<=0)throw Error('Enter at least one downward load');
    for(const key of ['loadBasis','materialBasis','criteriaBasis'])out[key]=text(raw[key]??'',key);
    if(raw.supportsConfirmed!==true||raw.solidSectionConfirmed!==true||raw.selfWeightIncluded!==true)throw Error('Confirm simple supports, a solid uniform section and inclusion of self-weight');
    out.supportsConfirmed=out.solidSectionConfirmed=out.selfWeightIncluded=true;return out;
  }
  function response(L,b,h,E,G,w,points){
    const I=b*h**3/12,A=b*h,K=5/6*G*A;
    const left=w*L/2+points.reduce((s,p)=>s+p.load*(L-p.x)/L,0),right=w*L+points.reduce((s,p)=>s+p.load,0)-left;
    const at=(x,side='right')=>{
      let moment=left*x-w*x*x/2,shear=left-w*x,bending=w*x*(L**3-2*L*x*x+x**3)/(24*E*I),slope=w*(L**3-6*L*x*x+4*x**3)/(24*E*I);
      for(const p of points){const a=p.x,c=L-a,P=p.load;if(x>a||(x===a&&side==='right'))shear-=P;if(x>a)moment-=P*(x-a);
        if(x<=a){bending+=P*c*x*(L*L-c*c-x*x)/(6*L*E*I);slope+=P*c*(L*L-c*c-3*x*x)/(6*L*E*I)}
        else{const z=L-x;bending+=P*a*z*(L*L-a*a-z*z)/(6*L*E*I);slope-=P*a*(L*L-a*a-3*z*z)/(6*L*E*I)}
      }
      // Integrating V/(kGA) with zero displacement at both simple supports gives M/(kGA).
      const shearDeflection=moment/K;return{x,moment,shear,bending,shearDeflection,deflection:bending+shearDeflection,slope:slope+shear/K};
    };
    const breaks=[...new Set([0,L,...points.map(p=>p.x)])].sort((a,b)=>a-b),candidates=breaks.slice();
    for(let i=0;i<breaks.length-1;i++){const a=breaks[i],b=breaks[i+1],start=at(a),end=at(b,'left');
      if(w>0){const x=a+start.shear/w;if(x>a&&x<b)candidates.push(x)}
      if(start.slope>0&&end.slope<0){let lo=a,hi=b;for(let j=0;j<70;j++){const x=(lo+hi)/2;if(at(x).slope>0)lo=x;else hi=x}candidates.push((lo+hi)/2)}
    }
    const values=candidates.map(x=>at(x)),moment=values.reduce((best,v)=>v.moment>best.value?{value:v.moment,x:v.x}:best,{value:0,x:0});
    const peak=values.reduce((best,v)=>v.deflection>best.deflection?v:best,at(0));
    const shear=Math.max(...breaks.flatMap(x=>[Math.abs(at(x).shear),Math.abs(at(x,'left').shear)]));
    const xs=[...new Set([...breaks,...Array.from({length:81},(_,i)=>L*i/80),moment.x,peak.x])].sort((a,b)=>a-b);
    const diagram=xs.flatMap(x=>points.some(p=>p.x===x)?[at(x,'left'),at(x)]:[at(x)]).map(({slope,...v})=>v);
    return{reactionLeft:left,reactionRight:right,totalLoad:w*L+points.reduce((s,p)=>s+p.load,0),moment,shear,deflection:{value:peak.deflection,x:peak.x,bending:peak.bending,shear:peak.shearDeflection},diagram};
  }
  function calculate(member,raw){const g=geometry(member),L=Math.hypot(g.x2-g.x1,g.y2-g.y1),v=input(raw,L),A=g.width*g.depth,I=g.width*g.depth**3/12,Z=g.width*g.depth**2/6;
    const loadCase=(dead,variable)=>response(L,g.width,g.depth,v.E,v.G,v.dead*dead+v.variable*variable,v.points.map(p=>({x:p.x,load:p.dead*dead+p.variable*variable})));
    const total=loadCase(1,1),variable=loadCase(0,1),checks=[];
    // Equality can round a few ULPs above the entered limit; this is numerical tolerance, not a design allowance.
    const check=(id,demand,limit)=>{const equal=limit!=null&&Math.abs(demand-limit)<=32*Number.EPSILON*Math.max(Math.abs(demand),Math.abs(limit));checks.push({id,demand,limit,ratio:limit==null?null:equal?1:demand/limit,status:limit==null?'missing_limit':demand<=limit||equal?'within_entered_limit':'exceeds_entered_limit'});};
    check('bending',total.moment.value/Z,v.Fb);check('shear',1.5*total.shear/A,v.Fv);
    check('bearingLeft',v.leftBearing?total.reactionLeft/(g.width*v.leftBearing):null,v.leftBearing?v.Fc:null);
    check('bearingRight',v.rightBearing?total.reactionRight/(g.width*v.rightBearing):null,v.rightBearing?v.Fc:null);
    check('totalDeflection',total.deflection.value,v.totalLimit?L/v.totalLimit:null);check('variableDeflection',variable.deflection.value,v.variableLimit?L/v.variableLimit:null);
    return{method,status:'draft_not_certified',geometry:g,input:v,section:{span:L,area:A,I,Z,shearArea:5*A/6},cases:{total,variable},checks,
      missingBasis:['loadBasis','materialBasis','criteriaBasis'].filter(k=>!v[k]),
      limitations:['Simple supports at member endpoints; solid, prismatic rectangular section; downward static loads only.','D + Q and Q are unfactored user-defined service cases, not a complete code load-combination envelope.','E must exclude shear deformation; G is independent. Shear deformation uses k = 5/6. Do not double-count shear with an apparent E.','Enter already-adjusted allowable stresses and sourced deflection limits. No species, grade, duration or other adjustment factors are supplied.','No lateral stability, creep, vibration, uplift, axial/torsional interaction, connections, holes/notches, load-point bearing, foundations or whole-building load path checks.','Inputs and reference applicability require professional review. Results do not certify code compliance or permit approval.'],references:clone(references)};
  }
  function basisKey(p){return JSON.stringify({profile:p.codeReview?.profile||null,research:p.codeReview?.research||null,confirmation:p.codeReview?.confirmation||null,basis:p.structure?Object.fromEntries(['jurisdiction','code','amendments','reference','loads'].map(k=>[k,p.structure[k]])):null});}
  function member(p,id){const m=p.structure?.members.find(m=>m.id===id);if(!m)throw Error('Structural member no longer exists');return m;}
  function save(p,id,raw){const m=member(p,id),result=calculate(m,raw);m.analysis={version:1,snapshot:result.geometry,input:result.input,basisKey:basisKey(p),calculatedAt:new Date().toISOString()};return result;}
  function saved(p,id){const m=member(p,id),r=m.analysis;if(!r)return{state:'missing'};const stale=!kinds.includes(m.kind)||JSON.stringify(geometry(m))!==JSON.stringify(r.snapshot)||r.basisKey!==basisKey(p);return{state:stale?'stale':'current',calculatedAt:r.calculatedAt,result:calculate(r.snapshot,r.input)};}
  function validate(p){for(const m of p.structure?.members||[]){const r=m.analysis;if(r==null)continue;if(r.version!==1||typeof r.basisKey!=='string'||r.basisKey.length>1000000||!Number.isFinite(Date.parse(r.calculatedAt)))throw Error('Invalid beam calculation record');calculate(r.snapshot,r.input);}return p;}
  function report(p,id){const state=saved(p,id);if(state.state!=='current')throw Error('Recalculate the changed member or design basis before export');return{format:'nexora-beam-analysis-v1',projectId:p.id,projectName:p.name,memberId:id,calculatedAt:state.calculatedAt,exportedAt:new Date().toISOString(),basis:p.structure?Object.fromEntries(['jurisdiction','code','amendments','reference','loads'].map(k=>[k,p.structure[k]])):null,codeReview:root.CodeReview?.data(p)||p.codeReview||null,...state.result};}
  const api={method,kinds,geometry,input,calculate,save,saved,validate,report,basisKey,references};root.BeamAnalysis=api;if(typeof module==='object')module.exports=api;
  if(root.BIM){const original=root.BIM.validate;root.BIM.validate=raw=>{validate(raw);return validate(original(raw));};}
})(typeof globalThis!=='undefined'?globalThis:this);
