(function(root){
'use strict';
const E=root.BIM||(typeof require==='function'?require('./geometry.js'):null);
const C=root.polygonClipping||(typeof require==='function'?require('./vendor/polygon-clipping.min.js'):null);
const EPS=1e-8,EDGE_EPS=1e-7,AREA_EPS=1e-11,SNAP=1e-9;
const limits={roofs:100,vertices:12000,edgeComparisons:20000000,edgeParts:30000};
const cache=new WeakMap();
// Original Nexora implementation of an affine-plane upper envelope. No Chief
// code or model data is used. Polygon Boolean operations: bundled polygon-clipping
// (MIT; vendor/polygon-clipping-LICENSE.md). Hole triangulation: THREE.ShapeUtils
// (bundled Three.js/Earcut; vendor/three-LICENSE.txt). This is a surface model,
// not a roof-volume, structural, flashing, drainage or weatherproofing solver.
function fail(code,message,details={}){const e=new Error(message);e.code=code;e.diagnostics={code,...details};throw e}
function number(value,min,max,label){if(!Number.isFinite(value)||value<min||value>max)fail('INVALID_ROOF_INPUT','Invalid '+label,{field:label});return value}
function object(value){return value!=null&&Object.prototype.toString.call(value)==='[object Object]'}
function checkRoof(p,r){
 if(!object(r))fail('INVALID_ROOF_INPUT','Invalid roof record');
 if(typeof r.id!=='string'||!r.id||r.id.length>200||!/^[A-Za-z0-9_.:-]+$/.test(r.id))fail('INVALID_ROOF_INPUT','Invalid roof ID');
 const f=Array.isArray(p?.floors)?p.floors.find(f=>f?.id===r.floor):null;if(!f)fail('INVALID_ROOF_INPUT','Roof floor does not exist',{roofId:r.id});
 number(f.elevation,-50,200,'roof floor elevation');number(f.height,1,10,'roof floor height');
 for(const k of ['x','y'])number(r[k],-500,500,'roof '+k);
 for(const k of ['w','d'])number(r[k],.1,200,'roof '+k);
 number(r.pitch,0,75,'roof pitch');number(r.overhang,0,3,'roof overhang');
 if(!['gable','hip','shed','flat'].includes(r.type))fail('INVALID_ROOF_INPUT','Unsupported roof type',{roofId:r.id});
 if(r.axis!==undefined&&!['x','y'].includes(r.axis))fail('INVALID_ROOF_INPUT','Invalid roof axis');
 if(r.elevationOffset!==undefined)number(r.elevationOffset,-50,200,'roof elevationOffset');
 if(r.reverse!==undefined&&typeof r.reverse!=='boolean')fail('INVALID_ROOF_INPUT','Invalid roof reverse');
 return f;
}
function validate(input){
 if(!object(input))fail('INVALID_ROOF_INPUT','Invalid roof project');
 // The engine migrates v1 floor-name arrays after this raw-input guard.
 if(input.format!=='nexora-architect-v1'){
  if(!Array.isArray(input.floors)||input.floors.length>20)fail('INVALID_ROOF_INPUT','Invalid roof project floors');
  const floorIds=new Set();
  for(const f of input.floors){
   if(!object(f)||typeof f.id!=='string'||!f.id||floorIds.has(f.id))fail('INVALID_ROOF_INPUT','Invalid roof floor ID');
   number(f.elevation,-50,200,'roof floor elevation');number(f.height,1,10,'roof floor height');floorIds.add(f.id);
  }
 }
 if(input.roofSettings!==undefined){
  if(!object(input.roofSettings))fail('INVALID_ROOF_INPUT','Invalid roofSettings');
  if(input.roofSettings.join!==undefined&&typeof input.roofSettings.join!=='boolean')fail('INVALID_ROOF_INPUT','Invalid roofSettings.join');
 }
 const roofs=input.roofs===undefined?[]:input.roofs;
 if(!Array.isArray(roofs)||roofs.length>limits.roofs)fail('INVALID_ROOF_INPUT','Invalid roof count; maximum is '+limits.roofs);
 const ids=new Set();
 for(const r of roofs){checkRoof(input,r);if(ids.has(r.id))fail('INVALID_ROOF_INPUT','Duplicate roof ID');ids.add(r.id)}
 return input;
}
function rawFaces(p,r){
 const f=checkRoof(p,r),transpose=r.axis==='y';
 const base=f.elevation+f.height+.08+(r.elevationOffset||0);
 const x=(transpose?r.y:r.x)-r.overhang,z=(transpose?r.x:r.y)-r.overhang;
 const w=(transpose?r.d:r.w)+2*r.overhang,d=(transpose?r.w:r.d)+2*r.overhang;
 const slope=Math.tan(r.pitch*Math.PI/180),rise=slope*(r.type==='shed'?d:d/2);
 const A=[x,base,z],B=[x+w,base,z],D=[x,base,z+d],FAR=[x+w,base,z+d];
 let faces;
 if(r.type==='flat')faces=[[A,B,FAR,D]];
 else if(r.type==='shed')faces=r.reverse?[[[x,base+rise,z],[x+w,base+rise,z],FAR,D]]:[[A,B,[x+w,base+rise,z+d],[x,base+rise,z+d]]];
 else if(r.type==='hip'){
  const inset=Math.min(w/2,d/2),hipRise=slope*inset;
  if(w>=d){const U=[x+inset,base+hipRise,z+d/2],V=[x+w-inset,base+hipRise,z+d/2];faces=[[A,B,V,U],[B,FAR,V],[FAR,D,U,V],[D,A,U]]}
  else{const U=[x+w/2,base+hipRise,z+inset],V=[x+w/2,base+hipRise,z+d-inset];faces=[[A,B,U],[B,FAR,V,U],[FAR,D,V],[D,A,U,V]]}
 }else{const U=[x,base+rise,z+d/2],V=[x+w,base+rise,z+d/2];faces=[[A,B,V,U],[U,V,FAR,D]]}
 return transpose?faces.map(face=>face.map(([x,y,z])=>[z,y,x])):faces;
}
function signedArea(r){if(!r.length)return 0;const [x,z]=r[0];let area=0;for(let i=0,j=r.length-1;i<r.length;j=i++)area+=(r[j][0]-x)*(r[i][1]-z)-(r[i][0]-x)*(r[j][1]-z);return area/2}
// Fixed-precision vector coordinates reconcile the same analytic intersection
// reached from adjacent faces. This is nanometre rounding, not raster geometry.
function snapRing(r){return cleanRing(r.map(q=>q.map(v=>Math.round(v/SNAP)*SNAP)))}
function cleanRing(r,diagnostics){
 const out=[];
 for(const q of r)if(!out.length||Math.hypot(q[0]-out[out.length-1][0],q[1]-out[out.length-1][1])>EPS)out.push([q[0],q[1]]);
 if(out.length>1&&Math.hypot(out[0][0]-out[out.length-1][0],out[0][1]-out[out.length-1][1])<=EPS)out.pop();
 // Boolean operations on coincident cuts can return a zero-width A-B-A spur.
 // Remove the cancelling excursion, never a positive-area polygon or a hole.
 let changed=true;
 while(changed&&out.length>=3){
  changed=false;
  for(let i=0;i<out.length;i++){
   const a=out[(i+out.length-1)%out.length],c=out[(i+1)%out.length];
   if(Math.hypot(a[0]-c[0],a[1]-c[1])<=EPS){
    out.splice(i,1);out.splice(i%out.length,1);changed=true;
    if(diagnostics)diagnostics.removedBoundarySpikes++;
    break;
   }
  }
 }
 return out;
}
function polygonArea(poly){return poly.reduce((sum,r,i)=>sum+(i?-1:1)*Math.abs(signedArea(r)),0)}
function multiArea(multi){return multi.reduce((sum,p)=>sum+polygonArea(p),0)}
function bounds(r){return{minX:Math.min(...r.map(q=>q[0])),maxX:Math.max(...r.map(q=>q[0])),minZ:Math.min(...r.map(q=>q[1])),maxZ:Math.max(...r.map(q=>q[1]))}}
function overlap(a,b){return a.minX<b.maxX-EPS&&b.minX<a.maxX-EPS&&a.minZ<b.maxZ-EPS&&b.minZ<a.maxZ-EPS}
function height(plane,q){return plane.a*q[0]+plane.b*q[1]+plane.c}
function planeOf(face){
 const A=face[0];
 for(let i=1;i<face.length-1;i++){
  const B=face[i],D=face[i+1],dx=B[0]-A[0],dz=B[2]-A[2],ex=D[0]-A[0],ez=D[2]-A[2],det=dx*ez-ex*dz;
  if(Math.abs(det)<=AREA_EPS)continue;
  const a=((B[1]-A[1])*ez-(D[1]-A[1])*dz)/det,b=(dx*(D[1]-A[1])-ex*(B[1]-A[1]))/det,c=A[1]-a*A[0]-b*A[2];
  if(![a,b,c].every(Number.isFinite))fail('INVALID_ROOF_PLANE','Nonfinite roof plane');
  return{a,b,c};
 }
 fail('DEGENERATE_ROOF_PLANE','Roof face has no projected area');
}
function coplanar(a,b){return Math.abs(a.a-b.a)<=1e-11&&Math.abs(a.b-b.b)<=1e-11&&Math.abs(a.c-b.c)<=EPS}
// Exact linear half-plane clipping of the other face's convex plan domain.
function higherDomain(other,self){
 const d={a:other.plane.a-self.plane.a,b:other.plane.b-self.plane.b,c:other.plane.c-self.plane.c},out=[];
 for(let i=0;i<other.domain.length;i++){
  const a=other.domain[i],b=other.domain[(i+1)%other.domain.length],ha=height(d,a),hb=height(d,b),insideA=ha>=0,insideB=hb>=0;
  if(insideA)out.push(a);
  if(insideA!==insideB){const t=ha/(ha-hb);out.push([a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t])}
 }
 return snapRing(out);
}
function triangulator(){
 const T=root.THREE||(typeof require==='function'?require('./vendor/three.min.js'):null);
 if(!T?.ShapeUtils?.triangulateShape||!T.Vector2)fail('ROOF_TRIANGULATOR_UNAVAILABLE','Roof triangulation requires the bundled THREE.ShapeUtils');
 return T;
}
function triangleArea(points){const [a,b,c]=points,u=b.map((v,i)=>v-a[i]),v=c.map((n,i)=>n-a[i]);return Math.hypot(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])/2}
function triangulate(surface,T){
 const rings=surface.rings.map(r=>r.map(q=>new T.Vector2(q[0],q[2]))),flat=surface.rings.flat();
 let indices;try{indices=T.ShapeUtils.triangulateShape(rings[0],rings.slice(1))}catch(e){fail('ROOF_TRIANGULATION_FAILED',e.message,{roofId:surface.roofId})}
 const triangles=[];
 for(const ids of indices){
  const points=ids.map(i=>flat[i].slice());
  if(points.some(p=>!p))fail('ROOF_TRIANGULATION_FAILED','Invalid triangulation index');
  const cross=(points[1][0]-points[0][0])*(points[2][2]-points[0][2])-(points[1][2]-points[0][2])*(points[2][0]-points[0][0]);
  if(Math.abs(cross)<=AREA_EPS)continue;
  if(cross>0)[points[1],points[2]]=[points[2],points[1]]; // Up-facing normal in X/Y-height/Z coordinates.
  triangles.push({roofId:surface.roofId,floor:surface.floor,material:surface.material,points});
 }
 const expected=polygonArea(surface.rings.map(r=>r.map(q=>[q[0],q[2]])))*Math.hypot(1,surface.plane.a,surface.plane.b),actual=triangles.reduce((sum,t)=>sum+triangleArea(t.points),0);
 if(Math.abs(actual-expected)>Math.max(1,expected)*1e-7)fail('ROOF_TRIANGULATION_FAILED','Triangulation area does not match the clipped roof surface',{roofId:surface.roofId,expected,actual});
 return triangles;
}
function edgeModel(surfaces,join,diagnostics){
 const vertices=[],cells=new Map(),segments=[];
 function vertex(q){
  const ix=Math.floor(q[0]/EDGE_EPS),iz=Math.floor(q[1]/EDGE_EPS);
  for(let dx=-1;dx<=1;dx++)for(let dz=-1;dz<=1;dz++)for(const id of cells.get((ix+dx)+','+(iz+dz))||[]){const v=vertices[id];if(Math.hypot(v.q[0]-q[0],v.q[1]-q[1])<=EDGE_EPS)return id}
  const id=vertices.length,key=ix+','+iz;vertices.push({id,q:[q[0],q[1]]});if(!cells.has(key))cells.set(key,[]);cells.get(key).push(id);return id;
 }
 for(let s=0;s<surfaces.length;s++)for(const ring of surfaces[s].rings)for(let i=0;i<ring.length;i++){
  const a=ring[i],b=ring[(i+1)%ring.length],u=vertex([a[0],a[2]]),v=vertex([b[0],b[2]]);
  if(u!==v)segments.push({u,v,s});
 }
 const sorted=vertices.slice().sort((a,b)=>a.q[0]-b.q[0]),groups=new Map();let comparisons=0,parts=0;
 const lowerBound=x=>{let lo=0,hi=sorted.length;while(lo<hi){const m=(lo+hi)>>1;if(sorted[m].q[0]<x)lo=m+1;else hi=m}return lo};
 for(const seg of segments){
  const a=vertices[seg.u].q,b=vertices[seg.v].q,dx=b[0]-a[0],dz=b[1]-a[1],length=Math.hypot(dx,dz),length2=length*length;
  const cuts=[{t:0,id:seg.u},{t:1,id:seg.v}],minX=Math.min(a[0],b[0])-EDGE_EPS,maxX=Math.max(a[0],b[0])+EDGE_EPS,minZ=Math.min(a[1],b[1])-EDGE_EPS,maxZ=Math.max(a[1],b[1])+EDGE_EPS;
  for(let j=lowerBound(minX);j<sorted.length&&sorted[j].q[0]<=maxX;j++){
   if(++comparisons>limits.edgeComparisons)fail('ROOF_COMPLEXITY_LIMIT','Roof boundary comparison limit exceeded',limits);
   const v=sorted[j],q=v.q;if(v.id===seg.u||v.id===seg.v||q[1]<minZ||q[1]>maxZ)continue;
   const t=((q[0]-a[0])*dx+(q[1]-a[1])*dz)/length2;
   if(t>EDGE_EPS/length&&t<1-EDGE_EPS/length&&Math.abs((q[0]-a[0])*dz-(q[1]-a[1])*dx)/length<=EDGE_EPS)cuts.push({t,id:v.id});
  }
  cuts.sort((a,b)=>a.t-b.t);
  for(let i=0;i<cuts.length-1;i++){
   const u=cuts[i].id,v=cuts[i+1].id;if(u===v)continue;
   if(++parts>limits.edgeParts)fail('ROOF_COMPLEXITY_LIMIT','Roof boundary part limit exceeded',limits);
   const surface=surfaces[seg.s],key=(join?'':surface.roofId+'|')+Math.min(u,v)+':'+Math.max(u,v);
   if(!groups.has(key))groups.set(key,{u,v,entries:[]});
   const group=groups.get(key);if(!group.entries.some(e=>e.s===seg.s))group.entries.push({s:seg.s,nx:-dz/length,nz:dx/length});
  }
 }
 const edges=[];
 for(const group of groups.values()){
  const entries=group.entries,a=vertices[group.u].q,b=vertices[group.v].q,owners=[...new Set(entries.map(e=>surfaces[e.s].roofId))].sort();
  const emit=(kind,e)=>{const s=surfaces[e.s];edges.push({a:[a[0],height(s.plane,a),a[1]],b:[b[0],height(s.plane,b),b[1]],kind,roofIds:owners,floors:[...new Set(entries.map(e=>surfaces[e.s].floor))]})};
  if(entries.length===1){emit('eave',entries[0]);continue}
  if(entries.length>2)fail('NON_MANIFOLD_ROOF_EDGE','More than two visible roof surfaces share an edge',{roofIds:owners});
  const one=surfaces[entries[0].s],two=surfaces[entries[1].s];
  if(Math.abs(height(one.plane,a)-height(two.plane,a))>EDGE_EPS||Math.abs(height(one.plane,b)-height(two.plane,b))>EDGE_EPS){emit('step',entries[0]);emit('step',entries[1]);continue}
  if(coplanar(one.plane,two.plane))continue;
  const slope=entries.reduce((sum,e)=>sum+surfaces[e.s].plane.a*e.nx+surfaces[e.s].plane.b*e.nz,0);
  if(Math.abs(slope)<=1e-10)continue;
  emit(slope<0?'ridge':'valley',entries[0]);
 }
 diagnostics.edgeComparisons=comparisons;diagnostics.edgeParts=parts;
 return edges;
}
function freeze(value){if(value&&typeof value==='object'&&!Object.isFrozen(value)){Object.freeze(value);Object.values(value).forEach(freeze)}return value}
function signature(p){return JSON.stringify([
 p.roofSettings?.join!==false,
 (p.floors||[]).map(f=>[f.id,f.elevation,f.height]).sort((a,b)=>a[0].localeCompare(b[0])),
 (p.roofs||[]).map(r=>[r.id,r.floor,r.x,r.y,r.w,r.d,r.type,r.pitch,r.overhang,r.axis||'x',r.elevationOffset||0,r.reverse||false,r.material]).sort((a,b)=>a[0].localeCompare(b[0]))
])}
function build(p){
 validate(p);if(!C)fail('ROOF_CLIPPER_UNAVAILABLE','Roof joining requires bundled polygon-clipping');
 const sig=signature(p),cached=cache.get(p);if(cached?.signature===sig)return cached.result;
 const join=p.roofSettings?.join!==false,raw=[],surfaces=[],triangles=[];
 const diagnostics={algorithm:'affine-upper-envelope-v1',join,rawFaces:0,broadPhasePairs:0,clippingOperations:0,occlusionDomains:0,coplanarComparisons:0,coverageArea:0,projectedArea:0,rawProjectedArea:0,rawSurfaceArea:0,triangulatedArea:0,discardedDegenerateRings:0,discardedProjectedArea:0,removedBoundarySpikes:0,coordinateSnap:SNAP,tolerance:EPS,edgeTolerance:EDGE_EPS,warnings:join?[]:['Joining is disabled; raw roof surfaces may overlap.'],limits:{...limits}};
 const roofs=(p.roofs||[]).slice().sort((a,b)=>a.id.localeCompare(b.id));
 for(const r of roofs)rawFaces(p,r).forEach((face,index)=>{
  const domain=snapRing(face.map(v=>[v[0],v[2]]));
  if(domain.length<3||Math.abs(signedArea(domain))<=AREA_EPS)fail('DEGENERATE_ROOF_PLANE','Degenerate raw roof face',{roofId:r.id,index});
  if(signedArea(domain)<0)domain.reverse();
  const plane=planeOf(face),area=Math.abs(signedArea(domain));
  raw.push({roofId:r.id,floor:r.floor,material:r.material,index,plane,domain,bounds:bounds(domain)});
  diagnostics.rawProjectedArea+=area;diagnostics.rawSurfaceArea+=area*Math.hypot(1,plane.a,plane.b);
 });
 diagnostics.rawFaces=raw.length;
 if(raw.length){try{diagnostics.coverageArea=multiArea(C.union(...raw.map(f=>[f.domain])))}catch(e){fail('ROOF_CLIP_FAILED',e.message,{operation:'footprint union'})}}
 let vertexCount=0;
 for(let i=0;i<raw.length;i++){
  const self=raw[i],cuts=[];let visible=[[self.domain]];
  if(join)for(let j=0;j<raw.length;j++){
   if(i===j||!overlap(self.bounds,raw[j].bounds))continue;
   const other=raw[j];diagnostics.broadPhasePairs++;
   let cut;
   if(coplanar(self.plane,other.plane)){diagnostics.coplanarComparisons++;if(j>i)continue;cut=other.domain}
   else cut=higherDomain(other,self);
   if(cut.length<3||Math.abs(signedArea(cut))<=AREA_EPS||!overlap(self.bounds,bounds(cut)))continue;
   cuts.push([cut]);
  }
  // One Boolean operation per face avoids feeding a rounded intermediate seam
  // back into a second clipping pass. The clips still represent exact affine
  // half-planes, not a sampled height field or pixel mask.
  if(cuts.length){
   try{visible=C.difference(visible,...cuts);diagnostics.clippingOperations++;diagnostics.occlusionDomains+=cuts.length}catch(e){fail('ROOF_CLIP_FAILED',e.message,{roofId:self.roofId})}
  }
  for(const polygon of visible){
   // Coincident intersection lines can leave roundoff-only slivers. Account for
   // their area explicitly rather than rejecting otherwise valid roof junctions.
   if(polygonArea(polygon)<=AREA_EPS){diagnostics.discardedDegenerateRings+=polygon.length;diagnostics.discardedProjectedArea+=Math.abs(polygonArea(polygon));continue}
   const rings=polygon.filter((r,k)=>{if(k&&Math.abs(signedArea(r))<=AREA_EPS){diagnostics.discardedDegenerateRings++;diagnostics.discardedProjectedArea+=Math.abs(signedArea(r));return false}return true}).map(r=>cleanRing(r,diagnostics));
   if(rings.some(r=>r.length<3)||polygonArea(rings)<=AREA_EPS)fail('DEGENERATE_ROOF_SURFACE','Clipping produced a degenerate roof surface',{roofId:self.roofId});
   rings.forEach((r,k)=>{if((signedArea(r)>0)!==(k===0))r.reverse()});
   vertexCount+=rings.reduce((sum,r)=>sum+r.length,0);
   if(vertexCount>limits.vertices)fail('ROOF_COMPLEXITY_LIMIT','Clipped roof vertex limit exceeded',limits);
   diagnostics.projectedArea+=polygonArea(rings);
   surfaces.push({roofId:self.roofId,floor:self.floor,material:self.material,sourceFace:self.index,plane:{...self.plane},rings:rings.map(r=>r.map(q=>[q[0],height(self.plane,q),q[1]]))});
  }
 }
 if(join&&Math.abs(diagnostics.projectedArea-diagnostics.coverageArea)>Math.max(1,diagnostics.coverageArea)*1e-7)fail('ROOF_COVERAGE_MISMATCH','Joined roof coverage differs from footprint union',{coverage:diagnostics.coverageArea,projected:diagnostics.projectedArea});
 const T=surfaces.length?triangulator():null;
 for(const surface of surfaces)triangles.push(...triangulate(surface,T));
 const area=surfaces.reduce((sum,s)=>sum+polygonArea(s.rings.map(r=>r.map(q=>[q[0],q[2]])))*Math.hypot(1,s.plane.a,s.plane.b),0);
 diagnostics.triangulatedArea=triangles.reduce((sum,t)=>sum+triangleArea(t.points),0);
 diagnostics.removedProjectedArea=diagnostics.rawProjectedArea-diagnostics.projectedArea;
 diagnostics.surfaces=surfaces.length;diagnostics.triangles=triangles.length;
 const edges=edgeModel(surfaces,join,diagnostics);
 const result=freeze({surfaces,triangles,edges,area,diagnostics});cache.set(p,{signature:sig,result});return result;
}
// Rings are open XYZ arrays: outer ring counterclockwise in plan, holes clockwise.
// build() is immutable and cached; faces() returns independent triangle arrays.
function faces(p,r){const id=typeof r==='string'?r:r?.id;if(!(p.roofs||[]).some(v=>v.id===id))fail('INVALID_ROOF_INPUT','Requested roof does not exist');return build(p).triangles.filter(t=>t.roofId===id).map(t=>t.points.map(q=>q.slice()))}
const baseValidate=E.validate;
E.validate=function(input){validate(input);return baseValidate(input)};
const api={build,faces,rawFaces,validate};root.RoofModel=api;if(typeof module==='object')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
