(function(root){
  'use strict';
  const E=root.BIM||require('./geometry.js');
  const systems={
    electric:{label:'电气网络',color:'#b77900',code:'E',source:'electricMeter',diameter:.02,level:2.4},
    cold:{label:'冷水网络',color:'#087ac2',code:'CW',source:'waterMeter',diameter:.025,level:2.3},
    hot:{label:'热水网络',color:'#d84a43',code:'HW',source:'heater',diameter:.02,level:2.2},
    drain:{label:'排水网络',color:'#795548',code:'DW',source:'drainOutlet',diameter:.1,level:-.25},
    gas:{label:'燃气网络',color:'#927000',code:'G',source:'gasMeter',diameter:.025,level:2.1},
    fire:{label:'消防喷淋网络',color:'#a02a9c',code:'FP',source:'fireRiser',diameter:.032,level:2.5}
  };
  const kinds={electricMeter:'电表',panel:'配电箱',waterMeter:'水表',heater:'热水器',drainOutlet:'排水出口',gasMeter:'燃气表',fireRiser:'消防进水',junction:'分支节点',light:'照明点',outlet:'插座点',switch:'开关点',inlet:'给水端口',waste:'排水端口',gasPoint:'燃气端口',sprinkler:'消防喷头'};
  const allowed={electric:['electricMeter','panel','junction','light','outlet','switch'],cold:['waterMeter','junction','inlet'],hot:['heater','junction','inlet'],drain:['drainOutlet','junction','waste'],gas:['gasMeter','junction','gasPoint'],fire:['fireRiser','junction','sprinkler']};
  const data=p=>p.mep||{schema:1,nodes:[],runs:[]};
  const layer=system=>'mep_'+system;
  const item=(p,type,id)=>data(p)[type==='mepNode'?'nodes':'runs'].find(n=>n.id===id);
  const escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function number(v,min,max){if(typeof v!=='number'||!Number.isFinite(v)||v<min||v>max)throw Error('机电参数超出范围');return v}
  function position(p,n){
    const f=p.floors.find(f=>f.id===n.floor),o=n.fixtureId&&p.objects.find(o=>o.id===n.fixtureId);
    if(o){const a=o.angle*Math.PI/180;return{x:o.x+o.w/2+n.x*Math.cos(a)-n.y*Math.sin(a),y:o.y+o.d/2+n.x*Math.sin(a)+n.y*Math.cos(a),z:f.elevation+o.z+n.z}}
    return{x:n.x,y:n.y,z:f.elevation+n.z};
  }
  const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
  function path(p,r){
    const a=position(p,item(p,'mepNode',r.a)),b=position(p,item(p,'mepNode',r.b));
    if(r.routing==='waypoints'){const elevation=p.floors.find(f=>f.id===r.floor).elevation;return[a,...r.waypoints.map(q=>({...q,z:q.z+elevation})),b].filter((q,i,arr)=>!i||distance(q,arr[i-1])>1e-6)}
    if(r.routing==='direct')return distance(a,b)<.000001?[a]:[a,b];
    const level=p.floors.find(f=>f.id===r.floor).elevation+r.level;
    const elbow=r.routing==='yx'?{x:a.x,y:b.y}:{x:b.x,y:a.y};
    const l1=Math.hypot(a.x-elbow.x,a.y-elbow.y),l2=Math.hypot(b.x-elbow.x,b.y-elbow.y);
    const drop=r.system==='drain'?r.slope:0;
    const points=[a,{...a,z:level},{...elbow,z:level-l1*drop},{...b,z:level-(l1+l2)*drop},b];
    return points.filter((q,i)=>!i||distance(q,points[i-1])>.000001);
  }
  const runLength=(p,r)=>path(p,r).reduce((sum,q,i,arr)=>sum+(i?distance(q,arr[i-1]):0),0);
  function validate(p){
    if(p.mep==null)return p;
    const d=p.mep,ids=new Set(['floors','walls','objects','openings','roofs','annotations','slabOpenings'].flatMap(k=>(p[k]||[]).map(n=>n.id)));
    if(d.schema!==1||!Array.isArray(d.nodes)||!Array.isArray(d.runs)||d.nodes.length>2000||d.runs.length>4000)throw Error('机电网络格式或数量无效');
    const id=v=>{if(typeof v!=='string'||!/^[A-Za-z0-9_.:-]{1,200}$/.test(v)||ids.has(v))throw Error('机电对象编号重复或无效');ids.add(v)};
    for(const n of d.nodes){
      if(!n||!allowed[n.system]?.includes(n.kind)||!p.floors.some(f=>f.id===n.floor))throw Error('机电节点类型或楼层无效');id(n.id);
      for(const k of ['x','y','z'])number(n[k],-500,500);
      if(typeof n.label!=='string'||n.label.length>100)throw Error('机电名称无效');
      for(const k of ['loadW','flowLpm','gasKW'])number(n[k]??0,0,1000000);
      if(n.fixtureId&&!p.objects.some(o=>o.id===n.fixtureId&&o.floor===n.floor))throw Error('机电端口的宿主构件不存在或楼层不一致');
    }
    const nodes=new Map(d.nodes.map(n=>[n.id,n])),pairs=new Set();
    for(const r of d.runs){
      if(!r||!systems[r.system])throw Error('机电系统无效');id(r.id);
      const a=nodes.get(r.a),b=nodes.get(r.b);
      if(!a||!b||a===b||a.system!==r.system||b.system!==r.system||r.floor!==a.floor)throw Error('机电连接端点、系统或楼层无效');
      const key=[r.a,r.b].sort().join('|');if(pairs.has(key))throw Error('同一对端口不能重复连接');pairs.add(key);
      number(r.diameter,.001,2);number(r.level,-500,500);number(r.slope,0,.2);
      if(!['xy','yx','direct','waypoints'].includes(r.routing))throw Error('机电走向无效');
      if(r.routing==='waypoints'||r.waypoints!=null){if(!Array.isArray(r.waypoints)||r.waypoints.length>64)throw Error('路点数量不能超过 64');for(const q of r.waypoints){if(!q||typeof q!=='object')throw Error('机电参数超出范围');for(const k of ['x','y','z'])number(q[k],-500,500)}}
      if(typeof r.label!=='string'||r.label.length>100)throw Error('机电名称无效');
    }
    return p;
  }
  function node(p,system,kind,floor,x,y,z,extra={}){
    p.mep=p.mep||data(p);const n={id:E.uid(),system,kind,floor,x,y,z,label:kinds[kind],loadW:0,flowLpm:0,gasKW:0,...extra};p.mep.nodes.push(n);return n;
  }
  function connect(p,aId,bId,extra={}){
    const a=item(p,'mepNode',aId),b=item(p,'mepNode',bId);
    if(!a||!b||a.system!==b.system||a.id===b.id)throw Error('请选择同一系统的两个不同端口');
    if(data(p).runs.some(r=>[r.a,r.b].includes(aId)&&[r.a,r.b].includes(bId)))throw Error('同一对端口不能重复连接');
    const r={id:E.uid(),system:a.system,floor:a.floor,a:a.id,b:b.id,diameter:systems[a.system].diameter,level:systems[a.system].level,slope:a.system==='drain'?.02:0,routing:'xy',label:'管线',...extra};
    p.mep.runs.push(r);return r;
  }
  function remove(p,type,id){
    if(!p.mep)return;
    if(type==='mepNode'){p.mep.nodes=p.mep.nodes.filter(n=>n.id!==id);p.mep.runs=p.mep.runs.filter(r=>r.a!==id&&r.b!==id)}
    else p.mep.runs=p.mep.runs.filter(r=>r.id!==id);
  }
  // Only explicit model transactions reconcile removed hosts. Imports reject dangling references.
  function reconcile(p){
    if(!p.mep)return;
    p.mep.nodes=p.mep.nodes.filter(n=>p.floors.some(f=>f.id===n.floor)&&(!n.fixtureId||p.objects.some(o=>o.id===n.fixtureId)));
    p.mep.nodes.forEach(n=>{if(n.fixtureId)n.floor=p.objects.find(o=>o.id===n.fixtureId).floor});
    const nodes=new Map(p.mep.nodes.map(n=>[n.id,n]));p.mep.runs=p.mep.runs.filter(r=>nodes.has(r.a)&&nodes.has(r.b));p.mep.runs.forEach(r=>r.floor=nodes.get(r.a).floor);
  }
  function roomPoints(room,spacing){
    const poly=room.netGeometry,all=poly.flat(2),xs=all.map(p=>p[0]),ys=all.map(p=>p[1]);if(!xs.length)return[];
    const x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys),nx=Math.ceil((x1-x0)/spacing),ny=Math.ceil((y1-y0)/spacing);
    if(nx*ny>1500)throw Error('生成数量过大，请增大间距或缩小模型');
    const result=[];for(let x=0;x<nx;x++)for(let y=0;y<ny;y++){const q={x:x0+(x+.5)*(x1-x0)/nx,y:y0+(y+.5)*(y1-y0)/ny};if(E.containsGeometry(poly,q))result.push(q)}
    // Every disconnected usable floor polygon gets a point even when its grid samples miss it.
    for(const part of poly)if(!result.some(q=>E.containsGeometry([part],q))){const ring=part[0];let found;for(let i=0;i<ring.length-1&&!found;i++){const a=ring[i],b=ring[i+1],m={x:(a[0]+b[0])/2,y:(a[1]+b[1])/2};for(const d of [.02,.1,.25])for(const sign of [-1,1]){const L=Math.hypot(b[0]-a[0],b[1]-a[1]);if(!L)continue;const q={x:m.x-sign*(b[1]-a[1])/L*d,y:m.y+sign*(b[0]-a[0])/L*d};if(E.containsGeometry([part],q)){found=q;break}}}if(found)result.push(found)}
    return result;
  }
  function outletPoints(p,room,spacing){
    const result=[];for(const poly of room.netGeometry)for(const ring of poly)for(let i=0;i<ring.length-1;i++){
      const a={x:ring[i][0],y:ring[i][1]},b={x:ring[i+1][0],y:ring[i+1][1]},L=E.dist(a,b),count=Math.ceil(L/spacing);if(count>200)throw Error('生成数量过大，请增大间距或缩小模型');
      for(let j=0;j<count;j++){const m=E.lerp(a,b,(j+.5)/count);let q;for(const sign of [-1,1]){const v={x:m.x-sign*(b.y-a.y)/L*.07,y:m.y+sign*(b.x-a.x)/L*.07};if(E.containsGeometry(room.netGeometry,v))q=v}if(!q)continue;
        const opening=p.openings.some(o=>{const w=p.walls.find(w=>w.id===o.wall);if(w.floor!==room.floor)return false;const hit=E.projectPoint(q,w.a,w.b),t=hit.t*E.dist(w.a,w.b);return hit.distance<w.thickness/2+.25&&t>o.offset-.15&&t<o.offset+o.width+.15});
        const nearWall=p.walls.some(w=>w.floor===room.floor&&E.projectPoint(q,w.a,w.b).distance<w.thickness/2+.12);
        if(nearWall&&!opening&&result.every(v=>E.dist(v,q)>.25))result.push(q);
      }
    }return result;
  }
  function generate(raw,{selected=Object.keys(systems),replace=false,outletSpacing=3,sprinklerSpacing=3,drainSlope=.02}={}){
    if(!Array.isArray(selected)||!selected.length||new Set(selected).size!==selected.length||selected.some(k=>!systems[k]))throw Error('请选择有效机电系统');
    number(outletSpacing,1,10);number(sprinklerSpacing,1,10);number(drainSlope,.001,.1);
    const p=E.clone(raw),old=data(p);if(!replace&&old.nodes.some(n=>selected.includes(n.system)))throw Error('所选系统已有数据，请选择替换或取消该系统');
    p.mep={schema:1,nodes:old.nodes.filter(n=>!selected.includes(n.system)),runs:old.runs.filter(r=>!selected.includes(r.system))};
    const floors=[...p.floors].sort((a,b)=>a.elevation-b.elevation),first=floors[0],b=E.bounds(p),baseX=b.x-.65,baseY=b.y;
    const rooms=new Map(floors.map(f=>[f.id,E.detectRooms(p,f.id).filter(r=>r.netArea>.1&&!['openBelow','deck','porch'].includes(r.roomType))]));
    if(![...rooms.values()].some(v=>v.length))throw Error('请先绘制至少一个闭合房间');
    for(const system of selected){
      const spec=systems[system],targets=[];
      for(const f of floors){
        const add=(kind,q,z,extra={})=>{const n=node(p,system,kind,f.id,q.x,q.y,z,{generated:true,...extra});targets.push(n);return n};
        const objects=p.objects.filter(o=>o.floor===f.id);
        if(system==='electric'){
          for(const o of objects.filter(o=>['light','socket','switch'].includes(o.kind)))add({light:'light',socket:'outlet',switch:'switch'}[o.kind],{x:0,y:0},o.h/2,{fixtureId:o.id});
          for(const r of rooms.get(f.id)){
            const existing=targets.filter(n=>n.floor===f.id&&E.containsGeometry(r.netGeometry,position(p,n)));
            if(!existing.some(n=>n.kind==='light')){const q=E.containsGeometry(r.netGeometry,r.center)?r.center:roomPoints(r,3)[0];if(q)add('light',q,Math.max(.2,f.height-.15))}
            for(const q of outletPoints(p,r,outletSpacing))if(existing.every(n=>n.kind!=='outlet'||E.dist(position(p,n),q)>.5))add('outlet',q,.3);
          }
        }else if(system==='fire'){
          for(const r of rooms.get(f.id))for(const q of roomPoints(r,sprinklerSpacing))add('sprinkler',q,Math.max(.2,f.height-.15));
        }else{
          const wet=['sink','vanity','toilet','bath','shower','dishwasher'];
          for(const o of objects.filter(o=>system==='gas'?o.kind==='stove':wet.includes(o.kind)&&(system!=='hot'||o.kind!=='toilet')))
            add(system==='gas'?'gasPoint':system==='drain'?'waste':'inlet',{x:system==='cold'?-Math.min(.08,o.w*.2):system==='hot'?Math.min(.08,o.w*.2):0,y:system==='drain'?Math.min(.08,o.d*.2):0},system==='drain'?.1:.5,{fixtureId:o.id});
        }
      }
      if(!targets.length)continue;
      const offset=Object.keys(systems).indexOf(system)*.45;
      const rootNode=node(p,system,spec.source,first.id,baseX,baseY+offset,system==='drain'?-1:1,{generated:true});
      let supply=rootNode;
      if(system==='electric'){supply=node(p,system,'panel',first.id,baseX+.2,baseY+offset+.2,1.5,{generated:true});connect(p,rootNode.id,supply.id,{generated:true})}
      for(const f of floors){
        const endpoints=targets.filter(n=>n.floor===f.id);if(!endpoints.length)continue;
        const points=endpoints.map(n=>position(p,n));
        const maxDistance=Math.max(...points.map(q=>Math.abs(q.x-baseX)+Math.abs(q.y-baseY-offset)));
        const level=system==='drain'?-.25:Math.min(spec.level,f.height-.2);
        const j=node(p,system,'junction',f.id,baseX,baseY+offset,system==='drain'?level-maxDistance*drainSlope-.05:level,{generated:true});
        if(system==='drain'){
          rootNode.z=Math.min(rootNode.z,f.elevation+j.z-first.elevation-.25);
          connect(p,j.id,rootNode.id,{level:j.z,slope:drainSlope,generated:true});
          for(const n of endpoints)connect(p,n.id,j.id,{level,slope:drainSlope,generated:true});
        }else{
          connect(p,supply.id,j.id,{level:supply.z,generated:true});
          for(const n of endpoints)connect(p,j.id,n.id,{level,generated:true});
        }
      }
    }
    return E.validate(p);
  }
  function checks(p){
    const d=data(p),issues=[],push=(code,text,n,type='mepNode')=>issues.push({code,text,id:n?.id,type});
    for(const [system,spec]of Object.entries(systems)){
      const nodes=d.nodes.filter(n=>n.system===system);if(!nodes.length)continue;
      const roots=nodes.filter(n=>n.kind===spec.source),edges=d.runs.filter(r=>r.system===system),seen=new Set(roots.map(n=>n.id)),queue=[...seen];
      for(let i=0;i<queue.length;i++)for(const r of edges){let next=system==='drain'?(r.b===queue[i]?r.a:null):(r.a===queue[i]?r.b:r.b===queue[i]?r.a:null);if(next&&!seen.has(next)){seen.add(next);queue.push(next)}}
      for(const n of nodes){if(!seen.has(n.id))push('disconnected','端口未连接到系统源点',n);if(n.fixtureId&&system==='gas')push('fuel','燃气设备燃料类型和额定负荷待确认',n);if(system==='electric'&&['light','outlet'].includes(n.kind)&&!n.loadW)push('load','用电负荷尚未输入',n);if(['cold','hot','fire'].includes(system)&&['inlet','sprinkler'].includes(n.kind)&&!n.flowLpm)push('flow','设计流量尚未输入',n)}
      if(!roots.length)push('source','缺少系统源点',nodes[0]);
      for(const r of edges){const ps=path(p,r);if(system==='drain'){if(ps.some((q,i)=>i&&q.z>ps[i-1].z+.00001))push('uphill','排水线路存在逆坡，请调整端口或管线高度',r,'mepRun');else if(ps.some((q,i)=>i&&ps[i-1].z-q.z+1e-6<Math.hypot(q.x-ps[i-1].x,q.y-ps[i-1].y)*r.slope))push('slope','排水线路未达到设定最小坡度',r,'mepRun')}}
    }
    return issues;
  }
  function schedule(p){return Object.entries(systems).map(([key,spec])=>{const nodes=data(p).nodes.filter(n=>n.system===key),runs=data(p).runs.filter(r=>r.system===key);return{system:key,label:spec.label,nodes:nodes.length,runs:runs.length,length:runs.reduce((v,r)=>v+runLength(p,r),0),loadW:nodes.reduce((v,n)=>v+(n.loadW||0),0),flowLpm:nodes.reduce((v,n)=>v+(n.flowLpm||0),0),gasKW:nodes.reduce((v,n)=>v+(n.gasKW||0),0)}}).filter(r=>r.nodes||r.runs)}
  function floorAtZ(p,z){const floors=[...p.floors].sort((a,b)=>a.elevation-b.elevation);return (floors.filter(f=>z>=f.elevation-f.slab-1e-7).at(-1)||floors[0]).id}
  // Keep same-floor underground runs visible, but clip risers to the active floor.
  function floorPaths(p,r,floor){
    const ps=path(p,r);if(!floor)return[ps];
    const a=item(p,'mepNode',r.a),b=item(p,'mepNode',r.b);if(a.floor===floor&&b.floor===floor)return[ps];
    const f=p.floors.find(f=>f.id===floor);if(!f)return[];const lo=f.elevation-f.slab,hi=f.elevation+f.height,parts=[];
    for(let i=1;i<ps.length;i++){const a=ps[i-1],b=ps[i],dz=b.z-a.z;let start=0,end=1;
      if(Math.abs(dz)<1e-12){if(a.z<lo||a.z>hi)continue}else{const u=(lo-a.z)/dz,v=(hi-a.z)/dz;start=Math.max(0,Math.min(u,v));end=Math.min(1,Math.max(u,v));if(start>end)continue}
      const at=t=>({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t,z:a.z+dz*t});parts.push([at(start),at(end)]);
    }return parts;
  }
  function visiblePaths(p,r,visible){
    const ps=path(p,r),a=item(p,'mepNode',r.a),b=item(p,'mepNode',r.b);
    if(visible.size===p.floors.length||(a.floor===b.floor&&visible.has(a.floor)))return[ps];
    const parts=[];for(let i=1;i<ps.length;i++){const a=ps[i-1],b=ps[i],dz=b.z-a.z,intervals=[];
      for(const f of p.floors.filter(f=>visible.has(f.id))){const lo=f.elevation-f.slab,hi=f.elevation+f.height;if(Math.abs(dz)<1e-12){if(a.z>=lo&&a.z<=hi)intervals.push([0,1])}else{const u=(lo-a.z)/dz,v=(hi-a.z)/dz,start=Math.max(0,Math.min(u,v)),end=Math.min(1,Math.max(u,v));if(start<=end)intervals.push([start,end])}}
      intervals.sort((a,b)=>a[0]-b[0]);const merged=[];for(const v of intervals){const last=merged.at(-1);if(last&&v[0]<=last[1]+1e-9)last[1]=Math.max(last[1],v[1]);else merged.push([...v])}
      for(const [start,end]of merged){const at=t=>({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t,z:a.z+dz*t});parts.push([at(start),at(end)])}
    }return parts;
  }
  function bounds(p,floor){const b=E.bounds(p,floor),points=data(p).nodes.filter(n=>!floor||n.floor===floor).map(n=>position(p,n));for(const r of data(p).runs)points.push(...floorPaths(p,r,floor).flat());let x=b.x,y=b.y,x1=x+b.w,y1=y+b.d;for(const q of points){x=Math.min(x,q.x-.25);y=Math.min(y,q.y-.25);x1=Math.max(x1,q.x+.25);y1=Math.max(y1,q.y+.25)}return{x,y,w:x1-x,d:y1-y}}
  function plan(p,s){
    let out='';const visible=system=>s.layers?.[layer(system)]!==false;
    for(const r of data(p).runs.filter(r=>visible(r.system))){const parts=floorPaths(p,r,s.floor);if(!parts.length)continue;const selected=s.selected?.id===r.id,color=selected?'#ff6b00':systems[r.system].color;
      const d=parts.map(a=>a.map((q,i)=>(i?'L':'M')+q.x+' '+q.y).join('')).join('');
      const risers=parts.filter(a=>a.length>1&&Math.hypot(a.at(-1).x-a[0].x,a.at(-1).y-a[0].y)<.000001&&Math.abs(a.at(-1).z-a[0].z)>.000001);
      out+=`<g data-entity="mepRun" data-id="${escape(r.id)}"><path d="${d}" fill="none" stroke="transparent" stroke-width=".2"/><path d="${d}" fill="none" stroke="${color}" stroke-width="${selected?.065:.035}" ${r.system==='electric'?'stroke-dasharray=".14 .07"':''}/>${risers.map(a=>`<circle cx="${a[0].x}" cy="${a[0].y}" r=".09" fill="white" stroke="${color}" stroke-width=".025"/>`).join('')}</g>`;
    }
    for(const n of data(p).nodes.filter(n=>n.floor===s.floor&&visible(n.system))){const q=position(p,n),color=s.selected?.id===n.id?'#ff6b00':systems[n.system].color;out+=`<g data-entity="mepNode" data-id="${escape(n.id)}" transform="translate(${q.x},${q.y})"><circle r=".14" fill="white" stroke="${color}" stroke-width=".03"/><text text-anchor="middle" y=".052" font-size=".15" fill="${color}" pointer-events="none">${n.kind==='sprinkler'?'✳':systems[n.system].code}</text><title>${escape(n.label)}</title></g>`}
    if(s.mepClash?.floor===s.floor&&s.mepClash?.signature===JSON.stringify(p)){const q=s.mepClash.point;out+=`<g pointer-events="none"><circle cx="${q.x}" cy="${q.y}" r=".24" fill="#ff5d3322" stroke="#f34e20" stroke-width=".04"/><path d="M${q.x-.34} ${q.y}h.68M${q.x} ${q.y-.34}v.68" stroke="#f34e20" stroke-width=".025"/></g>`}
    return out;
  }
  function csv(p,t=x=>x){const rows=[[t('系统'),t('类型'),t('编号'),t('名称'),t('楼层'),t('起点'),t('终点'),p.unit==='ft'?'Length ft':'Length m',p.unit==='ft'?'Diameter in':'Diameter mm','Load W','Flow L/min','Gas kW']];for(const n of data(p).nodes)rows.push([t(systems[n.system].label),t(kinds[n.kind]),n.id,n.label,p.floors.find(f=>f.id===n.floor).name,'','','','',n.loadW||0,n.flowLpm||0,n.gasKW||0]);for(const r of data(p).runs)rows.push([t(systems[r.system].label),t('管线'),r.id,r.label,p.floors.find(f=>f.id===r.floor).name,r.a,r.b,(runLength(p,r)*(p.unit==='ft'?1/.3048:1)).toFixed(3),(r.diameter*(p.unit==='ft'?1/.0254:1000)).toFixed(3),'','','']);return '\uFEFF'+rows.map(row=>row.map(v=>'"'+String(v).replace(/^(?:\s*[=+@-]|[\t\r\n])/,"'$&").replace(/"/g,'""')+'"').join(',')).join('\r\n')}
  const oldValidate=E.validate,oldDXF=E.dxfExport;
  E.validate=raw=>validate(oldValidate(raw));
  E.dxfExport=(p,floor)=>{let lines=[];for(const r of data(p).runs)for(const ps of floorPaths(p,r,floor)){for(let i=1;i<ps.length;i++){const a=ps[i-1],b=ps[i];lines.push('0','LINE','8','MEP_'+systems[r.system].code,'10',String(a.x),'20',String(-a.y),'30',String(a.z),'11',String(b.x),'21',String(-b.y),'31',String(b.z))}}return oldDXF(p,floor).replace('0\nENDSEC\n0\nEOF',lines.join('\n')+(lines.length?'\n':'')+'0\nENDSEC\n0\nEOF')};
  const api={systems,kinds,allowed,data,layer,item,position,path,floorPaths,visiblePaths,floorAtZ,runLength,validate,node,connect,remove,reconcile,roomPoints,generate,checks,schedule,bounds,plan,csv};
  root.MEP=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
