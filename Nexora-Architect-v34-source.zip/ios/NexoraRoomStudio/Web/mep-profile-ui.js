(function(root){
  'use strict';
  const M=root.MEP,U=root.Units,esc=root.Drawings.esc,t=x=>root.NexoraI18n?.t(x)||x,txt=x=>esc(t(x));
  let bridge,snapshot;
  const current=()=>bridge.state();
  const button=id=>`<button data-mep-profile="${esc(id||'')}">${txt('排水纵剖面')}</button>`;
  function form(){
    const {p}=current(),d=M.data(p),nodes=d.nodes.filter(n=>n.system==='drain'),runs=d.runs.filter(r=>r.system==='drain');
    if(!runs.length){bridge.toast('请先创建排水管线');return}
    const start=nodes.find(n=>n.kind==='waste')||nodes.find(n=>!runs.some(r=>r.b===n.id))||nodes[0];
    const seen=new Set([start.id]),queue=[start.id];for(let i=0;i<queue.length;i++)for(const r of runs)if(r.a===queue[i]&&!seen.has(r.b)){seen.add(r.b);queue.push(r.b)}
    const end=nodes.find(n=>seen.has(n.id)&&n.id!==start.id&&n.kind==='drainOutlet')||nodes.find(n=>seen.has(n.id)&&n.id!==start.id&&!runs.some(r=>r.a===n.id))||nodes.find(n=>n.id!==start.id);
    const options=id=>nodes.map(n=>`<option value="${esc(n.id)}" ${n.id===id?'selected':''}>${esc(n.label)} · ${esc(p.floors.find(f=>f.id===n.floor).name)} · ${esc(n.id.slice(-5))}</option>`).join('');
    bridge.dialog('排水纵剖面',`<form id="mepProfileForm"><p>${txt('沿排水流向读取已有连接；存在多条路径时选择三维长度最短的一条。')}</p><label class="field">${txt('起点')}<select name="start" data-no-translate>${options(start.id)}</select></label><label class="field">${txt('终点')}<select name="end" data-no-translate>${options(end?.id)}</select></label><p class="note">${txt('纵剖面只分析所选路径，不代表整个排水网络已通过检查。')}</p><button class="primary">${txt('生成纵剖面')}</button></form>`);
  }
  function show(options){
    const {p}=current(),report=M.drainProfile(p,options);snapshot={before:JSON.stringify(p),report};const L=v=>U.length(v,p.unit,4),percent=v=>(v*100).toFixed(3)+'%';
    bridge.dialog('排水展开纵剖面',`<p><span data-no-translate>${esc(report.markers[0].label)}</span> → <span data-no-translate>${esc(report.markers.at(-1).label)}</span></p><p>${txt('管线')} ${report.runIds.length} · ${txt('管段')} ${report.segments.length} · ${txt('问题管段')} ${report.issues}</p><p>${txt('累计水平长度')} ${L(report.horizontal)} · ${txt('三维实际长度')} ${L(report.length)} · ${txt('落差')} ${L(report.drop)}</p><p class="note">${txt('纵剖面只分析所选路径，不代表整个排水网络已通过检查。')}${report.branchNodes.length?' '+txt('路径含分叉，未选中的分支不在此图中。'):''}</p><div class="dialog-actions"><button data-profile-action="choose">${txt('选择起止节点')}</button><button data-profile-action="svg">${txt('导出纵剖面 SVG')}</button><button data-profile-action="csv">${txt('导出逐段数据 CSV')}</button></div><div class="table-scroll mep-profile-chart">${M.profileSVG(p,report,t)}</div><p>${txt('实线：中心线；灰虚线：中心标高减外径一半；红色：坡度或零长度问题。')}</p><p>${txt('管外底不是管内底；未包含壁厚、水力或规范校核。')}</p><div class="table-scroll"><table class="schedule-table"><thead><tr>${['管段','名称','起始累计水平长度','终止累计水平长度','起点中心标高','终点中心标高','起点管外底标高','终点管外底标高','实际坡度 %','设定最小坡度 %','检查结果','定位'].map(k=>`<th>${txt(k)}</th>`).join('')}</tr></thead><tbody>${report.segments.map((s,i)=>`<tr><td>${i+1}</td><td data-no-translate>${esc(s.label)} / ${s.index}</td><td>${L(s.stationStart)}</td><td>${L(s.stationEnd)}</td><td>${L(s.a.z)}</td><td>${L(s.b.z)}</td><td>${L(s.bottomStart)}</td><td>${L(s.bottomEnd)}</td><td>${s.slope===null?txt('竖向管段'):percent(s.slope)}</td><td>${percent(s.minimumSlope)}</td><td>${txt(M.profileStatus[s.status])}</td><td><button data-profile-locate="${i}">${txt('定位管线')}</button></td></tr>`).join('')}</tbody></table></div>`);
  }
  function ensure(){if(!snapshot||snapshot.before!==JSON.stringify(current().p))throw Error('模型已变化，请重新生成纵剖面')}
  function init(b){bridge=b;
    document.addEventListener('click',e=>{const el=e.target.closest('button');if(!el)return;const d=el.dataset;try{
      if(d.mepProfile!=null){if(d.mepProfile)show({runId:d.mepProfile});else form();return}
      if(d.profileAction==='choose'){form();return}
      if(d.profileAction==='svg'||d.profileAction==='csv'){ensure();const {p}=current();bridge.exportFile('Nexora-Drain-Profile.'+d.profileAction,d.profileAction==='svg'?M.profileSVG(p,snapshot.report,t):M.profileCSV(p,snapshot.report,t),d.profileAction==='svg'?'image/svg+xml;charset=utf-8':'text/csv;charset=utf-8');return}
      if(d.profileLocate!=null){ensure();const {p,s}=current(),segment=snapshot.report.segments[Number(d.profileLocate)];if(!segment)return;s.layers[M.layer('drain')]=true;
        if(!root.WorkspaceModel.canSelect(p,s,'mepRun',segment.runId)){bridge.toast('请先显示并解锁图层：'+t(M.systems.drain.label));return}
        const location=M.profileLocation(p,segment);bridge.close();s.mode='plan';bridge.select(location.type,location.id);s.floor=location.floor;s.center={x:location.point.x,y:location.point.y};s.zoom=2;bridge.refresh();if(location.type==='mepNode')bridge.toast('定位起点');
      }
    }catch(error){bridge.toast(error.message)}});
    document.addEventListener('submit',e=>{if(e.target.id!=='mepProfileForm')return;e.preventDefault();try{const d=new FormData(e.target);show({start:String(d.get('start')),end:String(d.get('end'))})}catch(error){bridge.toast(error.message)}});
  }
  root.MEPProfileUI={init,button};
})(window);
