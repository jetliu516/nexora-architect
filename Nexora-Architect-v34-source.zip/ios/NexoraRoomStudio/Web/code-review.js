(function(root){
  'use strict';
  const fields=['address','city','region','postal','country','scope','use','filingDate'];
  const scopes=['new','addition','alteration','repair','change_of_use'];
  const topics=['jurisdiction','adoption','zoning','structural','loads','foundation','fire','egress','energy','mep','submission'];
  const clone=x=>JSON.parse(JSON.stringify(x));
  function str(v,max=2000){if(typeof v!=='string'||v.length>max)throw Error('Invalid code review text');return v.trim();}
  function profile(raw={}){if(!raw||typeof raw!=='object'||Array.isArray(raw))throw Error('Invalid project information');const p=Object.fromEntries(fields.map(k=>[k,str(raw[k]??'',k==='address'?300:k==='use'?500:100)]));if(p.scope&&!scopes.includes(p.scope))throw Error('Unknown project scope');if(p.filingDate&&(!/^\d{4}-\d{2}-\d{2}$/.test(p.filingDate)||!Number.isFinite(Date.parse(p.filingDate))||new Date(p.filingDate).toISOString().slice(0,10)!==p.filingDate))throw Error('Invalid filing date');return p;}
  const profileKey=p=>JSON.stringify(profile(p));
  // A change detector, not a cryptographic signature or approval stamp.
  function designKey(p){const {codeReview,createdAt,updatedAt,id,name,unit,cameras,rates,...design}=p;const value=JSON.stringify(design);let h=2166136261;for(let i=0;i<value.length;i++)h=Math.imul(h^value.charCodeAt(i),16777619);return 'draft-v1-'+(h>>>0).toString(16)+'-'+value.length;}
  function officialUrl(value){try{const u=new URL(value),h=u.hostname.toLowerCase();if(u.protocol!=='https:'||u.username||u.password||u.port)return null;if(!(h.endsWith('.gov')||h.endsWith('.gc.ca')||h==='canada.ca'||h.endsWith('.canada.ca')||h==='ladbs.org'||h.endsWith('.ladbs.org')))return null;u.hash='';return u.href;}catch{return null;}}
  function research(raw){
    if(!raw||raw.status!=='candidate'||!Array.isArray(raw.sources)||raw.sources.length>30||!Array.isArray(raw.requirements)||raw.requirements.length>40||!Array.isArray(raw.unresolved)||raw.unresolved.length>30)throw Error('Invalid code research');
    if(!Number.isFinite(Date.parse(raw.queriedAt))||Date.parse(raw.queriedAt)>Date.now()+300000)throw Error('Invalid research timestamp');const ids=new Set(),sources=raw.sources.map(s=>{if(!s||typeof s!=='object')throw Error('Invalid official source');const id=str(s.id,100),url=officialUrl(s.url);if(!id||ids.has(id)||!url)throw Error('Invalid official source');ids.add(id);return{id,url,title:str(s.title,300),summary:str(s.summary,2000)};});
    const reqIDs=new Set(),requirements=raw.requirements.map(r=>{if(!r||typeof r!=='object')throw Error('Invalid requirement');const id=str(r.id,100);if(!id||reqIDs.has(id)||!topics.includes(r.topic)||!str(r.requirement)||!Array.isArray(r.sourceIds)||!r.sourceIds.length||r.sourceIds.some(id=>!ids.has(id)))throw Error('Requirement lacks official evidence');reqIDs.add(id);return{id,topic:r.topic,requirement:str(r.requirement),section:str(r.section,300),edition:str(r.edition,200),effectiveDate:str(r.effectiveDate,200),applicability:str(r.applicability),sourceIds:[...new Set(r.sourceIds)]};});
    const a=raw.authority;if(!a||typeof a.name!=='string'||!Array.isArray(a.sourceIds)||(a.name.trim()&&!a.sourceIds.length)||a.sourceIds.some(id=>!ids.has(id)))throw Error('Invalid authority evidence');
    return{status:'candidate',queriedAt:str(raw.queriedAt,100),profile:profile(raw.profile),model:str(raw.model,100),authority:{name:str(a.name,300),jurisdiction:str(a.jurisdiction,500),sourceIds:[...new Set(a.sourceIds)]},sources,requirements,unresolved:raw.unresolved.map(s=>str(s,2000))};
  }
  function data(p){return p.codeReview||{version:1,profile:profile(),research:null,confirmation:null,notes:[]};}
  function validate(p){if(p.codeReview==null)return p;const c=p.codeReview;if(c.version!==1||!Array.isArray(c.notes)||c.notes.length>100)throw Error('Invalid code review record');c.profile=profile(c.profile);if(c.research)c.research=research(c.research);
    if(c.confirmation){const x=c.confirmation;for(const k of ['profileKey','by','date','note'])str(x[k],k==='profileKey'?3000:2000);if(!x.by.trim()||!x.note.trim()||!Number.isFinite(Date.parse(x.date))||!c.research?.authority.name||!c.research.authority.sourceIds.length||x.profileKey!==profileKey(c.profile)||profileKey(c.research.profile)!==profileKey(c.profile))throw Error('Record reviewer and jurisdiction evidence');}
    const seen=new Set();for(const n of c.notes){for(const k of ['id','by','note','date'])str(n[k]);if(n.designKey!=null)str(n.designKey,100);if(seen.has(n.id)||!['documented','not_applicable'].includes(n.status)||!n.by.trim()||!n.note.trim()||!c.research?.requirements.some(r=>r.id===n.id))throw Error('Invalid review evidence');seen.add(n.id);}
    return p;
  }
  function setProfile(p,input){const next=profile(input),c=clone(data(p));if(profileKey(next)!==profileKey(c.profile)){c.research=null;c.confirmation=null;c.notes=[];}c.profile=next;p.codeReview=c;return next;}
  function saveResearch(p,raw){const r=research(raw);if(profileKey(r.profile)!==profileKey(data(p).profile))throw Error('Project address or scope changed; run research again');p.codeReview={...clone(data(p)),research:r,confirmation:null,notes:[]};}
  function confirm(p,by,note){const c=clone(data(p));if(!c.research?.authority.name||!c.research.authority.sourceIds.length||profileKey(c.profile)!==profileKey(c.research.profile))throw Error('Confirm an authority supported by current research first');c.confirmation={profileKey:profileKey(c.profile),by:str(by,200),note:str(note),date:new Date().toISOString()};validate({...p,codeReview:c});p.codeReview=c;}
  function record(p,input){const c=clone(data(p)),item={id:input.id,status:input.status,by:str(input.by,200),note:str(input.note),designKey:designKey(p),date:new Date().toISOString()};c.notes=c.notes.filter(n=>n.id!==item.id).concat(item);validate({...p,codeReview:c});p.codeReview=c;}
  function checklist(p,now=Date.now()){
    const c=data(p),r=c.research,issues=[];const add=(id,text)=>issues.push({id,status:'missing',text});
    if(!c.profile.address||!c.profile.city||!c.profile.region||!c.profile.country)add('address','Complete address, city, state/province and country');
    if(!c.profile.scope||!c.profile.use||!c.profile.filingDate)add('scope','Confirm use, work scope and intended filing date');
    if(!r)add('research','Query the local building authority and adopted codes');
    else{
      if(profileKey(r.profile)!==profileKey(c.profile))add('stale_address','Address or scope changed; repeat official research');
      if(!Number.isFinite(Date.parse(r.queriedAt))||now-Date.parse(r.queriedAt)>30*86400000)add('stale_sources','Official research is over 30 days old or undated; refresh before filing');
      if(!c.confirmation||c.confirmation.profileKey!==profileKey(c.profile))add('authority','Reviewer must confirm jurisdiction and applicability');
      for(const topic of ['jurisdiction','adoption','structural','loads','foundation','submission'])if(!r.requirements.some(q=>q.topic===topic))add('topic_'+topic,'Missing official requirements: '+topic);
      for(const q of r.requirements){const n=c.notes.find(n=>n.id===q.id);if(!n)add(q.id,q.requirement);else if(n.designKey!==designKey(p))add('model_'+q.id,'Design changed since review: '+q.requirement);}
      for(const [i,q]of r.unresolved.entries())add('unresolved_'+i,q);
    }
    if(!p.structure?.loads?.trim())add('load_basis','Document site-specific wind, snow, seismic, live loads and soil data');
    if(!p.structure?.members?.length)add('members','Structural members and load paths have not been documented');
    add('engineering','Structural calculations, connections, foundation design and professional review are not verified by this software');
    return {status:'not_certified',checkedAt:new Date(now).toISOString(),issues,documented:c.notes.length,scope:'Document readiness checks only; no code-compliance or permit approval certification'};
  }
  function report(p){return {format:'nexora-code-review-v1',projectId:p.id,projectName:p.name,record:clone(data(p)),checklist:checklist(p),structure:clone(p.structure||null)};}
  const api={fields,scopes,topics,profile,profileKey,designKey,officialUrl,research,data,validate,setProfile,saveResearch,confirm,record,checklist,report};root.CodeReview=api;if(typeof module==='object')module.exports=api;
  if(root.BIM){const original=root.BIM.validate;root.BIM.validate=raw=>validate(original(raw));}
})(typeof globalThis!=='undefined'?globalThis:this);
