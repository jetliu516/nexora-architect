(function (root) {
  "use strict";
  const E = root.BIM || require("./engine.js");
  const C = root.polygonClipping || require("./vendor/polygon-clipping.min.js");
  const original = {
    detectRooms: E.detectRooms,
    validate: E.validate,
    estimate: E.estimate,
    duplicateFloor: E.duplicateFloor,
  };
  const ring = (points) => points.map((p) => [p.x, p.y]);
  const polygon = (points) => [ring(points)];
  const polygonArea = (geometry) =>
    geometry.reduce(
      (total, poly) =>
        total +
        poly.reduce(
          (sum, r, i) =>
            sum +
            (i ? -1 : 1) * Math.abs(E.area(r.map(([x, y]) => ({ x, y })))),
          0,
        ),
      0,
    );
  const union = (polygons) => (polygons.length ? C.union(...polygons) : []);
  const difference = (a, b) =>
    !a.length ? [] : !b.length ? a : C.difference(a, b);
  function wallFootprint(w) {
    const length = E.dist(w.a, w.b),
      dx = (w.b.x - w.a.x) / length,
      dy = (w.b.y - w.a.y) / length,
      t = w.thickness / 2;
    return [
      { x: w.a.x - dy * t, y: w.a.y + dx * t },
      { x: w.b.x - dy * t, y: w.b.y + dx * t },
      { x: w.b.x + dy * t, y: w.b.y - dx * t },
      { x: w.a.x + dy * t, y: w.a.y - dx * t },
    ];
  }
  function nextFloor(p, id) {
    const f = p.floors.find((v) => v.id === id);
    return (
      f &&
      p.floors
        .filter((v) => v.elevation > f.elevation + 0.01)
        .sort((a, b) => a.elevation - b.elevation)[0]
    );
  }
  function worldPoint(o, x, y) {
    const a = (o.angle * Math.PI) / 180,
      cx = o.x + o.w / 2,
      cy = o.y + o.d / 2;
    x -= o.w / 2;
    y -= o.d / 2;
    return {
      x: cx + x * Math.cos(a) - y * Math.sin(a),
      y: cy + x * Math.sin(a) + y * Math.cos(a),
    };
  }
  function stairLayout(o) {
    const count = Math.max(3, o.steps || 17),
      shape = o.stairShape || "straight",
      width = o.flightWidth || 1.05,
      parts = [];
    const part = (x, y, w, d, h, landing = false) =>
      parts.push({
        x,
        y,
        w,
        d,
        h,
        landing,
        points: [
          [x, y],
          [x + w, y],
          [x + w, y + d],
          [x, y + d],
        ].map(([x, y]) => worldPoint(o, x, y)),
      });
    if (shape === "straight")
      for (let i = 0; i < count; i++)
        part(0, (o.d * i) / count, o.w, o.d / count, (o.h * (i + 1)) / count);
    else {
      const n1 = Math.floor(count / 2),
        n2 = count - n1,
        run = o.d - width;
      for (let i = 0; i < n1; i++)
        part(0, (run * i) / n1, width, run / n1, (o.h * (i + 1)) / count);
      if (shape === "l") {
        part(0, run, width, width, (o.h * n1) / count, true);
        for (let i = 0; i < n2; i++)
          part(
            width + ((o.w - width) * i) / n2,
            run,
            (o.w - width) / n2,
            width,
            (o.h * (n1 + i + 1)) / count,
          );
      } else {
        part(0, run, o.w, width, (o.h * n1) / count, true);
        for (let i = 0; i < n2; i++)
          part(
            o.w - width,
            run - ((i + 1) * run) / n2,
            width,
            run / n2,
            (o.h * (n1 + i + 1)) / count,
          );
      }
    }
    return parts;
  }
  function stairFootprint(o) {
    return union(stairLayout(o).map((t) => polygon(t.points)));
  }
  function stairPanels(o){
    const count=o.steps||17, riser=o.h/count, panels=[];
    const add=(x,y,w,d,top,h)=>panels.push({x,y,w,d,top,h,points:[[x,y],[x+w,y],[x+w,y+d],[x,y+d]].map(([x,y])=>worldPoint(o,x,y))});
    for(const t of stairLayout(o)){
      add(t.x,t.y,t.w,t.d,t.h,t.landing?.12:.045);
      if(!t.landing){
        const second=t.h>o.h*Math.floor(count/2)/count;
        if(o.stairShape==='l'&&second) add(t.x,t.y,.035,t.d,t.h,riser);
        else add(t.x,t.y+(o.stairShape==='u'&&second?t.d-.035:0),t.w,.035,t.h,riser);
      }
    }
    return panels;
  }
  function stairStatus(p, o) {
    const f = p.floors.find((v) => v.id === o.floor),
      above = nextFloor(p, o.floor),
      rise = above ? above.elevation - f.elevation - o.z : null;
    const layout = stairLayout(o),
      treads = layout.filter((v) => !v.landing),
      depth = Math.min(
        ...treads.map((v) =>
          o.stairShape === "l" && v.y === o.d - (o.flightWidth || 1.05)
            ? v.w
            : v.d,
        ),
      );
    return {
      above,
      rise,
      reaches: above && Math.abs(o.h - rise) < 0.01,
      riser: o.h / (o.steps || 17),
      tread: depth,
      slope: (Math.atan2(o.h, o.d) * 180) / Math.PI,
    };
  }
  function fitStair(p, o) {
    const info = stairStatus(p, o);
    if (!info.above) throw Error("当前楼梯上方没有更高的楼层，请先创建上层。");
    if (info.rise < 0.3) throw Error("楼梯起点与上层的高差不足 0.3 m。");
    o.h = info.rise;
    o.steps = Math.max(3, Math.ceil(o.h / 0.175));
    if ((o.stairShape || "straight") === "straight") o.d = o.steps * 0.28;
    else {
      o.flightWidth = o.flightWidth || 1.05;
      o.d = Math.ceil(o.steps / 2) * 0.28 + o.flightWidth;
      o.w =
        o.stairShape === "l"
          ? Math.ceil(o.steps / 2) * 0.28 + o.flightWidth
          : 2 * o.flightWidth + 0.15;
    }
    return o;
  }
  function openingGeometry(p, opening) {
    if (opening.sourceStair) {
      const o = p.objects.find((o) => o.id === opening.sourceStair);
      return o ? stairFootprint(o) : [];
    }
    return [polygon(opening.points)];
  }
  function floorVoids(p, id, rawRooms) {
    const rooms = rawRooms || original.detectRooms(p, id);
    const shapes = (p.slabOpenings || [])
      .filter((o) => o.floor === id)
      .map((o) => openingGeometry(p, o));
    for (const h of (p.penetrations || []).filter(h=>h.kind==='slab'&&h.floor===id)) shapes.push([polygon([{x:h.u,y:h.v},{x:h.u+h.width,y:h.v},{x:h.u+h.width,y:h.v+h.height},{x:h.u,y:h.v+h.height}])]);
    for (const r of rooms)
      if (r.roomType === "openBelow") shapes.push(polygon(r.points));
    return union(shapes);
  }
  function detectRooms(p, id) {
    const rooms = original.detectRooms(p, id),
      voids = floorVoids(p, id, rooms),
      wallGeometry = union(
        p.walls
          .filter((w) => w.floor === id)
          .map((w) => polygon(wallFootprint(w))),
      );
    for (const r of rooms) {
      // Separate disconnected nested enclosures instead of counting the inner region twice.
      const children = rooms.filter(
        (c) =>
          c !== r &&
          c.area < r.area - 0.001 &&
          c.points.every((pt) => E.pointIn(pt, r.points)),
      );
      r.boundaryGeometry = difference(
        [polygon(r.points)],
        union(children.map((c) => polygon(c.points))),
      );
      r.area = polygonArea(r.boundaryGeometry);
      r.surfaceGeometry = difference(r.boundaryGeometry, voids);
      r.netGeometry = difference(r.surfaceGeometry, wallGeometry);
      r.floorArea = polygonArea(r.surfaceGeometry);
      r.netArea = polygonArea(r.netGeometry);
      r.roomType = r.roomType || "living";
      r.includeLiving =
        typeof r.includeLiving === "boolean"
          ? r.includeLiving
          : !["garage", "porch", "deck", "openBelow"].includes(r.roomType);
      const pts = r.netGeometry[0]?.[0];
      if (pts && !containsGeometry(r.netGeometry, r.center)) {
        const bounds = pts.reduce(
          (b, [x, y]) => ({
            x0: Math.min(b.x0, x),
            x1: Math.max(b.x1, x),
            y0: Math.min(b.y0, y),
            y1: Math.max(b.y1, y),
          }),
          { x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity },
        );
        let found;
        for (let i = 1; i < 20 && !found; i++)
          for (let j = 1; j < 20 && !found; j++) {
            const pt = {
              x: bounds.x0 + ((bounds.x1 - bounds.x0) * i) / 20,
              y: bounds.y0 + ((bounds.y1 - bounds.y0) * j) / 20,
            };
            if (containsGeometry(r.netGeometry, pt)) found = pt;
          }
        if (found) r.center = found;
      }
    }
    return rooms;
  }
  function containsGeometry(geometry, q) {
    return geometry.some(
      (poly) =>
        E.pointIn(
          q,
          poly[0].map(([x, y]) => ({ x, y })),
        ) &&
        !poly.slice(1).some((r) =>
          E.pointIn(
            q,
            r.map(([x, y]) => ({ x, y })),
          ),
        ),
    );
  }
  function addStairwell(p, o) {
    const info = stairStatus(p, o);
    if (!info.above) throw Error("上方没有楼层，无法创建楼梯洞口。");
    if (!info.reaches)
      throw Error("楼梯尚未到达上层，请先点击「适配上层高度」。");
    const footprint = stairFootprint(o),
      rooms = original
        .detectRooms(p, info.above.id)
        .filter((r) => r.roomType !== "openBelow");
    const cover = union(rooms.map((r) => polygon(r.points)));
    if (polygonArea(difference(footprint, cover)) > 0.005)
      throw Error(
        "上层的闭合房间必须完整覆盖楼梯范围。请移动楼梯或补齐上层墙体。",
      );
    const existing = (p.slabOpenings || []).find((v) => v.sourceStair === o.id);
    if (existing) {
      existing.floor = info.above.id;
      return existing;
    }
    const hole = {
      id: E.uid(),
      floor: info.above.id,
      name: "楼梯间",
      sourceStair: o.id,
      guard: true,
      guardHeight: 1.05,
    };
    p.slabOpenings = p.slabOpenings || [];
    p.slabOpenings.push(hole);
    return hole;
  }
  function sectionIntervals(geometry, y) {
    const intervals = [];
    for (const poly of geometry) {
      const hits = [];
      for (const ring of poly)
        for (let i = 0; i < ring.length; i++) {
          const a = ring[i],
            b = ring[(i + 1) % ring.length];
          if ((a[1] <= y && b[1] > y) || (b[1] <= y && a[1] > y))
            hits.push(a[0] + ((b[0] - a[0]) * (y - a[1])) / (b[1] - a[1]));
        }
      hits.sort((a, b) => a - b);
      for (let i = 0; i + 1 < hits.length; i += 2)
        if (hits[i + 1] - hits[i] > 0.00001)
          intervals.push([hits[i], hits[i + 1]]);
    }
    return intervals;
  }
  function estimate(p, floor) {
    const e = original.estimate(p, floor),
      ids = floor ? [floor] : p.floors.map((f) => f.id),
      rooms = ids.flatMap((id) => detectRooms(p, id));
    e.area = rooms.reduce((a, r) => a + r.area, 0);
    e.netArea = rooms.reduce((a, r) => a + r.netArea, 0);
    e.livingNetArea = rooms
      .filter((r) => r.includeLiving && r.roomType !== "openBelow")
      .reduce((a, r) => a + r.netArea, 0);
    e.slab = rooms.reduce(
      (a, r) => a + r.floorArea * p.floors.find((f) => f.id === r.floor).slab,
      0,
    );
    e.voidArea = ids.reduce(
      (a, id) =>
        a +
        polygonArea(
          C.intersection(
            union(original.detectRooms(p, id).map((r) => polygon(r.points))),
            floorVoids(p, id),
          ),
        ),
      0,
    );
    const floorRow = e.rows.find((r) => r.key === "floor");
    floorRow.quantity = e.netArea * (1 + p.rates.waste / 100);
    floorRow.name = "室内净地面（含损耗）";
    e.rows.find((r) => r.key === "concrete").quantity = e.slab;
    e.total = e.rows.reduce((a, r) => a + r.quantity * r.rate, 0);
    return e;
  }
  function validate(raw) {
    const p = original.validate(raw);
    p.rooms = Object.fromEntries(
      Object.entries(p.rooms)
        .filter(([key, value]) => value && typeof value === "object")
        .map(([key, m]) => [
          key,
          {
            name: String(m.name || (p.language==='zh'?"空间":"Room")).slice(0, 100),
            material: E.materials[m.material] ? m.material : "oak",
            ...(m.anchor &&
            Number.isFinite(m.anchor.x) &&
            Number.isFinite(m.anchor.y)
              ? { anchor: { x: m.anchor.x, y: m.anchor.y } }
              : {}),
            roomType: [
              "living",
              "bedroom",
              "kitchen",
              "bath",
              "garage",
              "porch",
              "deck",
              "openBelow",
            ].includes(m.roomType)
              ? m.roomType
              : "living",
            ...(typeof m.includeLiving === "boolean"
              ? { includeLiving: m.includeLiving }
              : {}),
          },
        ]),
    );
    const ids = new Set(
      [
        ...p.floors,
        ...p.walls,
        ...p.openings,
        ...p.objects,
        ...p.roofs,
        ...p.annotations,
      ].map((o) => o.id),
    );
    p.slabOpenings = p.slabOpenings || [];
    if (!Array.isArray(p.slabOpenings) || p.slabOpenings.length > 200)
      throw Error("楼板洞口数据无效或超过 200 个");
    for (const o of p.objects)
      if (o.kind === "stairs") {
        o.stairShape = o.stairShape || "straight";
        o.flightWidth = o.flightWidth || 1.05;
        if (
          !["straight", "l", "u"].includes(o.stairShape) ||
          o.steps < 3 ||
          !Number.isFinite(o.flightWidth) ||
          o.flightWidth < 0.4 ||
          o.flightWidth > 5
        )
          throw Error("楼梯类型、梯段宽或踏步数无效");
        if (
          o.stairShape !== "straight" &&
          (o.d <= o.flightWidth + 0.2 ||
            o.w < o.flightWidth * (o.stairShape === "u" ? 2 : 1) + 0.04)
        )
          throw Error("转角楼梯的总宽、总深必须大于平台和梯段宽度");
      }
    for (const o of p.slabOpenings) {
      if (
        typeof o.id !== "string" ||
        !o.id || o.id.length > 200 || !/^[A-Za-z0-9_.:-]+$/.test(o.id) ||
        ids.has(o.id) ||
        !p.floors.some((f) => f.id === o.floor)
      )
        throw Error("楼板洞口 ID 或楼层无效");
      ids.add(o.id);
      o.name = String(o.name || "楼板洞口").slice(0, 80);
      o.guard = !!o.guard;
      o.guardHeight = o.guardHeight ?? 1.05;
      if (
        !Number.isFinite(o.guardHeight) ||
        o.guardHeight < 0.5 ||
        o.guardHeight > 2
      )
        throw Error("护栏高度超出范围");
      if (o.sourceStair) {
        const stair = p.objects.find(
          (v) => v.id === o.sourceStair && v.kind === "stairs",
        );
        if (!stair || nextFloor(p, stair.floor)?.id !== o.floor)
          throw Error("楼梯间关联失效，请删除洞口后重新建立");
        if (!stairStatus(p, stair).reaches)
          throw Error("关联楼梯必须到达上层标高；请先移除洞口，再调整楼层或楼梯高度并重新适配。");
        const rooms = original
            .detectRooms(p, o.floor)
            .filter((r) => r.roomType !== "openBelow"),
          cover = union(rooms.map((r) => polygon(r.points)));
        if (polygonArea(difference(stairFootprint(stair), cover)) > 0.005)
          throw Error("移动后的楼梯超出上层房间，楼板洞口无法保持关联");
      } else {
        if (
          !Array.isArray(o.points) ||
          o.points.length < 3 ||
          o.points.length > 64 ||
          o.points.some(
            (q) =>
              !Number.isFinite(q.x) ||
              !Number.isFinite(q.y) ||
              Math.abs(q.x) > 500 ||
              Math.abs(q.y) > 500,
          ) ||
          Math.abs(E.area(o.points)) < 0.04
        )
          throw Error("楼板洞口至少需要 3 个有效顶点及 0.04 m² 面积");
        for (let i = 0; i < o.points.length; i++)
          for (let j = i + 2; j < o.points.length; j++) {
            if (i === 0 && j === o.points.length - 1) continue;
            if (
              E.intersections(
                o.points[i],
                o.points[(i + 1) % o.points.length],
                o.points[j],
                o.points[(j + 1) % o.points.length],
              )
            )
              throw Error("楼板洞口边界不能自相交");
          }
      }
    }
    p.underlays = p.underlays || [];
    if (!Array.isArray(p.underlays) || p.underlays.length > 20)
      throw Error("每个项目最多 20 张参考底图");
    for (const u of p.underlays) {
      if (
        !p.floors.some((f) => f.id === u.floor) ||
        typeof u.data !== "string" ||
        !/^data:image\/(png|jpeg|webp);base64,/.test(u.data) ||
        u.data.length > 4000000
      )
        throw Error("参考底图必须为内嵌 PNG/JPEG/WebP，单张不超过 3 MB");
      for (const k of ["x", "y", "w", "d", "angle", "opacity"])
        if (!Number.isFinite(u[k])) throw Error("底图参数无效");
      if (
        u.w <= 0 ||
        u.d <= 0 ||
        u.w > 500 ||
        u.d > 500 ||
        u.opacity < 0.05 ||
        u.opacity > 1
      )
        throw Error("底图尺寸或透明度超出范围");
    }
    return p;
  }
  function demoDuplex() {
    const p = E.newProject("双层住宅 · 楼梯与净面积示例"),
      f = p.floors[0];
    E.addRectangle(p, 0, 0, 10, 8, f.id);
    const hall=E.wall(p, { x: 6, y: 0 }, { x: 6, y: 8 }, f.id, "interior");
    const divider=E.wall(p, { x: 0, y: 4 }, { x: 6, y: 4 }, f.id, "interior");
    E.opening(p,hall.id,.1,"door");
    E.opening(p,hall.id,.77,"door");
    E.opening(p,divider.id,.45,"opening");
    const outer=p.walls.filter(w=>w.floor===f.id&&w.kind==='exterior');
    for(const w of outer){
      E.opening(p,w.id,.25,"window");
      if(w.a.x===10&&w.b.x===10) E.opening(p,w.id,.83,"door");
      else E.opening(p,w.id,.75,"window");
    }
    const first = original.detectRooms(p, f.id);
    for (const r of first)
      E.roomMeta(p, r, {
        name:
          r.center.x > 6 ? "楼梯厅" : r.center.y < 4 ? "厨房与餐厅" : "起居室",
        roomType: r.center.x < 6 && r.center.y < 4 ? "kitchen" : "living",
      });
    E.object(p, "sofa", 0.6, 6.4, f.id);
    E.object(p, "table", 1.7, 1.3, f.id);
    ["sink","stove","baseCabinet"].forEach((kind,i)=>E.object(p,kind,.4+i*.95,.3,f.id));
    const upper = E.duplicateFloor(p, f.id);
    upper.name = "2F 二层";
    p.openings=p.openings.filter(o=>{const w=p.walls.find(w=>w.id===o.wall);return !(w.floor===upper.id&&w.kind==='exterior'&&o.kind==='door')});
    for(const o of p.openings){const w=p.walls.find(w=>w.id===o.wall);if(w.floor===upper.id&&o.kind==='opening'){o.kind='door';o.style='hinged';o.width=.9;}}

    p.objects = p.objects.filter((o) => o.floor !== upper.id);
    const bathWall=E.wall(p,{x:4,y:0},{x:4,y:4},upper.id,"interior");
    E.opening(p,bathWall.id,.65,"door");
    E.object(p,"toilet",4.4,.4,upper.id);
    E.object(p,"shower",4.5,1.4,upper.id);
    E.object(p,"vanity",4.4,3.1,upper.id);
    E.object(p, "bed", 1, 1, upper.id);
    E.object(p, "bed", 1.2, 5, upper.id);
    const stair = E.object(p, "stairs", 6.6, 1.1, f.id);
    stair.stairShape = "u";
    stair.flightWidth = 1.05;
    fitStair(p, stair);
    addStairwell(p, stair);
    for (const r of original.detectRooms(p, upper.id))
      E.roomMeta(p, r, {
        name: r.center.x > 6 ? "二层楼梯厅" : r.center.y < 4 ? (r.center.x>4?"卫浴":"主卧") : "次卧",
        roomType:r.center.x>4&&r.center.x<6&&r.center.y<4?"bath":"living",
      });
    E.autoRoof(p, upper.id, "hip");
    return validate(p);
  }
  function duplicateFloor(p,id){
    const sourceRooms=detectRooms(p,id), f=original.duplicateFloor(p,id);
    for(const r of detectRooms(p,f.id)){
      const old=sourceRooms.find(v=>E.pointIn(r.center,v.points));
      if(old) E.roomMeta(p,r,{name:old.name,material:old.material,roomType:old.roomType,includeLiving:old.includeLiving});
    }
    // Structural coordinates and z are relative to the owning floor.
    for(const member of [...(p.structure?.members||[])])
      if(member.floor===id) p.structure.members.push({...E.clone(member),id:E.uid(),floor:f.id});
    // Manual voids are copied. Linked voids belong to the stair on the floor
    // below and must be created explicitly for the new stair/floor pair.
    for(const hole of [...(p.slabOpenings||[])])
      if(hole.floor===id&&!hole.sourceStair) p.slabOpenings.push({...E.clone(hole),id:E.uid(),floor:f.id});
    return f;
  }
  Object.assign(E, {
    roomMeta: (p, r, values) => {
      p.rooms[r.id] = {
        ...p.rooms[r.id],
        name: r.name,
        material: r.material,
        anchor: r.center,
        roomType: r.roomType || "living",
        includeLiving: r.includeLiving,
        ...values,
      };
    },
    polygonArea,
    polygonUnion: union,
    polygonDifference: difference,
    wallFootprint,
    nextFloor,
    worldPoint,
    stairLayout,
    stairFootprint,
    stairPanels,
    stairStatus,
    fitStair,
    openingGeometry,
    floorVoids,
    detectRooms,
    containsGeometry,
    addStairwell,
    sectionIntervals,
    estimate,
    validate,
    demoDuplex,
    duplicateFloor,
  });
  // Shared site footprint for the 2D plan and the existing 3D landscape.
  E.siteFloor = p => p.floors.filter(f=>f.elevation>=0).sort((a,b)=>a.elevation-b.elevation)[0] || p.floors.slice().sort((a,b)=>b.elevation-a.elevation)[0];
  E.siteDriveway = p => {const f=E.siteFloor(p),b=E.bounds(p,f.id);return {...(p.site?.driveway || (p.usHome?{x:b.x,y:b.y-10,w:Math.min(6.1,b.w*.4),d:10}:{x:b.x+b.w*.65,y:b.y+b.d+.2,w:Math.min(5,b.w*.35),d:8}))}};
  E.sitePlanBounds = (p,floor,base=E.bounds(p,floor)) => {if(floor!==E.siteFloor(p)?.id||!p.walls.some(w=>w.floor===floor))return base;const d=E.siteDriveway(p),x=Math.min(base.x,d.x),y=Math.min(base.y,d.y);return {x,y,w:Math.max(base.x+base.w,d.x+d.w)-x,d:Math.max(base.y+base.d,d.y+d.d)-y}};
  if (typeof module !== "undefined") module.exports = E;
})(typeof window !== "undefined" ? window : globalThis);
