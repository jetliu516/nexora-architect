(function (root) {
  'use strict';
  const kinds = ['baseCabinet', 'drawerCabinet', 'wallCabinet', 'tallCabinet', 'island', 'sink', 'stove', 'vanity'];
  const layouts = { double: '双门', single: '单门', drawers: '抽屉组', mixed: '上抽下双门', open: '开放层板' };
  const styles = { slab: '平板', shaker: '框式门板' };
  const handles = { bar: '条形拉手', knob: '方形拉手', none: '无拉手' };
  const isCabinet = o => !!o && kinds.includes(o.kind);
  function defaults(o) {
    const wall = o.kind === 'wallCabinet', tall = o.kind === 'tallCabinet';
    return { layout: o.kind === 'drawerCabinet' ? 'drawers' : 'double', style: 'slab', handle: 'bar',
      drawerCount: 3, toeHeight: wall ? 0 : Math.min(.1, o.h * .25), toeDepth: Math.min(.06, o.d * .15),
      countertop: !wall && !tall && (o.h >= .2 || ['sink','stove','vanity'].includes(o.kind)), topThickness: Math.min(.03, o.h * .2), overhang: .02, topMaterial: 'stone' };
  }
  const config = o => ({ ...defaults(o), ...o.cabinet });
  function validate(o, materials) {
    if (!isCabinet(o)) return o;
    const c = config(o), numeric = (key, min, max) => {
      if (typeof c[key] !== 'number' || !Number.isFinite(c[key]) || c[key] < min || c[key] > max)
        throw Error('柜体参数超出范围：' + ({ toeHeight: '踢脚高', toeDepth: '踢脚退进', topThickness: '台面厚', overhang: '台面外挑', drawerCount: '抽屉数量' })[key]);
    };
    if (![o.w, o.d, o.h].every(v => Number.isFinite(v) && v >= .02)) throw Error('柜体宽、深、高至少为 0.02 m');
    if (!Object.hasOwn(layouts, c.layout) || !Object.hasOwn(styles, c.style) || !Object.hasOwn(handles, c.handle)) throw Error('柜体面板类型无效');
    if (typeof c.countertop !== 'boolean') throw Error('台面设置无效');
    if (['sink', 'stove', 'vanity'].includes(o.kind) && !c.countertop) throw Error('水槽、灶台与浴室柜需要保留台面');
    numeric('toeHeight', 0, .3); numeric('toeDepth', 0, Math.min(.2, o.d * .8));
    numeric('topThickness', .001, .12); numeric('overhang', 0, .15); numeric('drawerCount', 2, 6);
    if (!Number.isInteger(c.drawerCount)) throw Error('抽屉数量必须为整数');
    const usable = o.h - c.toeHeight - (c.countertop ? c.topThickness : 0) - Math.min(.008, o.h * .1);
    if (usable < Math.min(.12, o.h * .35) || (c.layout === 'drawers' && usable / c.drawerCount < Math.min(.06, o.h / 12))) throw Error('柜体高度不足，请减少踢脚高、台面厚或抽屉数量');
    if (!Object.hasOwn(materials, c.topMaterial)) throw Error('台面材质无效');
    o.cabinet = Object.fromEntries(Object.keys(defaults(o)).map(k => [k, c[k]]));
    return o;
  }
  // Local coordinates: X width, Y height, Z depth; cabinet front faces +Z.
  // Both the 3D mesh and front drawing consume this same geometry.
  function geometry(o) {
    const c = config(o), w = o.w, d = o.d, h = o.h, t = Math.min(.018, w / 8, d / 8, h / 8), gap = Math.min(.004, w / 20, h / 20);
    const bottom = c.toeHeight, top = h - (c.countertop ? c.topThickness : 0), bodyHeight = top - bottom;
    const parts = [], fronts = [];
    const part = (role, W, H, D, x, y, z, material = o.material) => parts.push({ role, w: W, h: H, d: D, x, y, z, material });
    part('side', t, bodyHeight, d - Math.min(.022,d/4), -w / 2 + t / 2, bottom + bodyHeight / 2, -.011);
    part('side', t, bodyHeight, d - Math.min(.022,d/4), w / 2 - t / 2, bottom + bodyHeight / 2, -.011);
    part('bottom', w - 2 * t, t, d - Math.min(.022,d/4), 0, bottom + t / 2, -.011);
    part('case-top', w - 2 * t, t, d - Math.min(.022,d/4), 0, top - t / 2, -.011);
    part('back', w - 2 * t, bodyHeight - 2 * t, t, 0, bottom + bodyHeight / 2, -d / 2 + t / 2);
    if (bottom > 0) part('toe', w - Math.min(.02,w/4), bottom, d - c.toeDepth, 0, bottom / 2, -c.toeDepth / 2, 'charcoal');
    if (c.countertop) part('countertop', w + 2 * c.overhang, c.topThickness, d + c.overhang, 0, h - c.topThickness / 2, c.overhang / 2, c.topMaterial);
    function face(kind, x, y, W, H, hinge) {
      const f = { kind, x, y, w: W, h: H, hinge, handle: null };
      if (c.style === 'shaker') {
        const rail = Math.min(.055, W / 5, H / 5);
        part('panel', W - 2 * rail, H - 2 * rail, .01, x, y, d / 2 - .016);
        part('rail', W, rail, .022, x, y - H / 2 + rail / 2, d / 2 - .011);
        part('rail', W, rail, .022, x, y + H / 2 - rail / 2, d / 2 - .011);
        for (const sign of [-1, 1]) part('rail', rail, H - 2 * rail, .022, x + sign * (W - rail) / 2, y, d / 2 - .011);
        f.rail = rail;
      } else part('panel', W, H, .022, x, y, d / 2 - .011);
      if (c.handle !== 'none') {
        const horizontal = kind === 'drawer';
        const hx = horizontal ? x : x + (hinge === 'left' ? 1 : -1) * (W / 2 - Math.min(.06, W / 4));
        const hy = horizontal ? y + H / 2 - Math.min(.045, H / 4) : y;
        const hw = c.handle === 'knob' ? Math.min(.026,W/3,H/3) : horizontal ? Math.min(.16, W * .55) : Math.min(.018,W/3);
        const hh = c.handle === 'knob' ? Math.min(.026,W/3,H/3) : horizontal ? Math.min(.018,H/3) : Math.min(.14, H * .55);
        part('handle', hw, hh, .03, hx, hy, d / 2 + .015, 'charcoal');
        f.handle = { x: hx, y: hy, w: hw, h: hh };
      }
      fronts.push(f);
    }
    function doors(y0, y1, count) {
      for (let i = 0; i < count; i++) face('door', -w / 2 + (i + .5) * w / count,
        (y0 + y1) / 2, w / count - gap * 2, y1 - y0 - gap * 2, i === 0 ? 'left' : 'right');
    }
    if (c.layout === 'open') {
      const count = Math.max(1, Math.min(5, Math.floor(bodyHeight / .32)));
      for (let i = 1; i <= count; i++) part('shelf', w - 2 * t, t, d - Math.min(.04,d/4), 0, bottom + bodyHeight * i / (count + 1), -.01);
    } else if (c.layout === 'drawers') {
      for (let i = 0; i < c.drawerCount; i++) face('drawer', 0, bottom + (i + .5) * bodyHeight / c.drawerCount, w - gap * 2, bodyHeight / c.drawerCount - gap * 2);
    } else if (c.layout === 'mixed') {
      const drawerH = Math.min(.18, bodyHeight * .3);
      doors(bottom, top - drawerH, 2);
      face('drawer', 0, top - drawerH / 2, w - gap * 2, drawerH - gap * 2);
    } else doors(bottom, top, c.layout === 'single' ? 1 : 2);
    return { parts, fronts, config: c, bodyBottom: bottom, bodyTop: top };
  }
  function schedule(project, floor) {
    return project.objects.filter(o => isCabinet(o) && (!floor || o.floor === floor)).map((o, i) => {
      const g = geometry(o), c = g.config;
      return { object: o, number: 'C' + String(i + 1).padStart(2, '0'),
        doors: g.fronts.filter(f => f.kind === 'door').length, drawers: g.fronts.filter(f => f.kind === 'drawer').length,
        countertopArea: c.countertop ? (o.w + 2 * c.overhang) * (o.d + c.overhang) : 0,
        countertopMaterial: c.countertop ? c.topMaterial : null, layout: layouts[c.layout], style: styles[c.style] };
    });
  }
  // Reject the entire run before touching the project if a cabinet would intersect an opening.
  function planRun(project, wall, options) {
    const { count, width, offset = 0, side = 1, kind = 'baseCabinet' } = options;
    if (!isCabinet({ kind }) || !Number.isInteger(count) || count < 1 || count > 30 || !Number.isFinite(width) || width < .2 || width > 2 || !Number.isFinite(offset) || offset < 0 || ![1, -1].includes(side)) throw Error('连续橱柜的数量、尺寸或布置侧无效');
    const L = Math.hypot(wall.b.x - wall.a.x, wall.b.y - wall.a.y), end = offset + count * width;
    if (end > L + 1e-6) throw Error('橱柜总长加起点距离超过墙长');
    const depth = kind === 'wallCabinet' ? .35 : .6, height = kind === 'wallCabinet' ? .75 : kind === 'tallCabinet' ? 2.4 : .9, z = kind === 'wallCabinet' ? 1.5 : 0;
    if (z + height > wall.height + 1e-6) throw Error('柜体顶部超出选中墙高');
    const dir = { x: (wall.b.x - wall.a.x) / L, y: (wall.b.y - wall.a.y) / L }, normal = { x: -dir.y, y: dir.x };
    const placements = [];
    for (let i = 0; i < count; i++) {
      const start = offset + i * width, finish = start + width;
      if (project.openings.some(o => o.wall === wall.id && start < o.offset + o.width - 1e-6 && finish > o.offset + 1e-6 && z < o.sill + o.height - 1e-6 && z + height > o.sill + 1e-6)) throw Error('第 ' + (i + 1) + ' 个柜体与墙上门窗相交，请调整起点、柜宽或类型');
      const along = start + width / 2, away = (wall.thickness / 2 + depth / 2) * side;
      placements.push({ kind, w: width, d: depth, h: height, z,
        x: wall.a.x + dir.x * along + normal.x * away - width / 2,
        y: wall.a.y + dir.y * along + normal.y * away - depth / 2,
        angle: Math.atan2(dir.y, dir.x) * 180 / Math.PI + (side < 0 ? 180 : 0) });
    }
    return placements;
  }
  const api = { kinds, layouts, styles, handles, isCabinet, defaults, config, validate, geometry, schedule, planRun };
  root.Cabinets = api;
  if (typeof module !== 'undefined') module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
