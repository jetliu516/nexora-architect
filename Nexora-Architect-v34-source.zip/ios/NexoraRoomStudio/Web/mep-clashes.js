(function(root){
  'use strict';
  const E=root.BIM||require('./geometry.js'),M=typeof module!=='undefined'?require('./mep-routing.js'):root.MEP,EPS=1e-8;
  const sub=(a,b)=>({x:a.x-b.x,y:a.y-b.y,z:a.z-b.z}),dot=(a,b)=>a.x*b.x+a.y*b.y+a.z*b.z;
  const at=(a,b,t)=>({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t,z:a.z+(b.z-a.z)*t}),dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z),clamp=x=>Math.max(0,Math.min(1,x));
  // Closest points on finite segments, including zero-length and parallel cases.
  function closest(a,b,c,d){
    const u=sub(b,a),v=sub(d,c),w=sub(a,c),aa=dot(u,u),bb=dot(u,v),cc=dot(v,v),dd=dot(u,w),ee=dot(v,w);let s=0,t=0;
    if(aa<1e-20&&cc<1e-20)return{a,b:c,distance:dist(a,c)};
    if(aa<1e-20)t=clamp(ee/cc);
    else if(cc<1e-20)s=clamp(-dd/aa);
    else {const den=aa*cc-bb*bb;s=den>1e-12*aa*cc?clamp((bb*ee-cc*dd)/den):0;t=(bb*s+ee)/cc;if(t<0){t=0;s=clamp(-dd/aa)}else if(t>1){t=1;s=clamp((bb-dd)/aa)}}
    const p=at(a,b,s),q=at(c,d,t);return{a:p,b:q,distance:dist(p,q)};
  }
  function boxHit(a,b,lo,hi,r=0){let enter=0,exit=1;for(const k of ['x','y','z']){const delta=b[k]-a[k],min=lo[k]-r,max=hi[k]+r;if(Math.abs(delta)<EPS){if(a[k]<min||a[k]>max)return null}else{const t0=(min-a[k])/delta,t1=(max-a[k])/delta;enter=Math.max(enter,Math.min(t0,t1));exit=Math.min(exit,Math.max(t0,t1));if(enter>exit)return null}}return{enter,exit,point:at(a,b,(enter+exit)/2)}}
  function extent(a,b,r=0){return{lo:{x:Math.min(a.x,b.x)-r,y:Math.min(a.y,b.y)-r,z:Math.min(a.z,b.z)-r},hi:{x:Math.max(a.x,b.x)+r,y:Math.max(a.y,b.y)+r,z:Math.max(a.z,b.z)+r}}}
  const overlap=(a,b)=>['x','y','z'].every(k=>a.lo[k]<=b.hi[k]&&a.hi[k]>=b.lo[k]);
  function collinearOverlap(a,b,c,d){
    const u=sub(b,a),v=sub(d,c),len=Math.sqrt(dot(u,u));if(len<EPS)return 0;
    const cross=Math.hypot(u.y*v.z-u.z*v.y,u.z*v.x-u.x*v.z,u.x*v.y-u.y*v.x);if(cross>1e-6*len*Math.max(EPS,Math.sqrt(dot(v,v))))return 0;
    const w=sub(c,a),cross2=Math.hypot(u.y*w.z-u.z*w.y,u.z*w.x-u.x*w.z,u.x*w.y-u.y*w.x);if(cross2>1e-6*len)return 0;
    const t0=dot(w,u)/len,t1=dot(sub(d,a),u)/len;return Math.max(0,Math.min(len,Math.max(t0,t1))-Math.max(0,Math.min(t0,t1)));
  }
  function slabHit(a,b,f,geometry,r){
    const hit=boxHit(a,b,{x:-10000,y:-10000,z:f.elevation-f.slab},{x:10000,y:10000,z:f.elevation},r);if(!hit)return null;
    const start=at(a,b,hit.enter),end=at(a,b,hit.exit),cuts=[0,1];
    for(const poly of geometry)for(const ring of poly)for(let i=1;i<ring.length;i++){
      const c={x:ring[i-1][0],y:ring[i-1][1],z:0},d={x:ring[i][0],y:ring[i][1],z:0};
      const crossing=E.intersections(start,end,c,d);if(crossing)cuts.push(crossing.t);
      if(closest({...start,z:0},{...end,z:0},c,d).distance<r)return hit.point;
    }
    cuts.sort((a,b)=>a-b);for(let i=1;i<cuts.length;i++){const q=at(start,end,(cuts[i]+cuts[i-1])/2);if(E.containsGeometry(geometry,q))return q}
    return null;
  }
  function clashes(p,{limit=1000,onlyRunIds=null}={}){
    const issues=[],seen=new Set,segments=[],runs=new Map(M.data(p).runs.map(r=>[r.id,r])),nodes=new Map(M.data(p).nodes.map(n=>[n.id,n]));let truncated=false;
    const add=(code,text,r,other,type,point,floor=M.floorAtZ(p,point.z))=>{const key=code+':'+[r.id,other].sort().join(':');if(seen.has(key))return;seen.add(key);if(issues.length>=limit){truncated=true;return}issues.push({code,text,id:r.id,type:'mepRun',otherId:other,otherType:type,point,floor})};
    for(const r of runs.values()){const ps=M.path(p,r);for(let i=1;i<ps.length;i++)if(dist(ps[i-1],ps[i])>EPS)segments.push({r,index:i,a:ps[i-1],b:ps[i],box:extent(ps[i-1],ps[i],r.diameter/2)})}
    const sorted=[...segments].sort((a,b)=>a.box.lo.x-b.box.lo.x);
    for(let i=0;i<sorted.length&&!truncated;i++)for(let j=i+1;j<sorted.length;j++){
      const a=sorted[i],b=sorted[j];if(b.box.lo.x>a.box.hi.x)break;if((a.r.id===b.r.id&&Math.abs(a.index-b.index)<=1&&collinearOverlap(a.a,a.b,b.a,b.b)<(a.r.diameter+b.r.diameter))||!overlap(a.box,b.box)||(onlyRunIds&&!onlyRunIds.includes(a.r.id)&&!onlyRunIds.includes(b.r.id)))continue;
      const near=closest(a.a,a.b,b.a,b.b),radius=(a.r.diameter+b.r.diameter)/2;if(near.distance>=radius-1e-7)continue;
      const duplicate=collinearOverlap(a.a,a.b,b.a,b.b),shared=[a.r.a,a.r.b].filter(id=>id===b.r.a||id===b.r.b);
      if(duplicate<radius*2&&shared.some(id=>dist(near.a,M.position(p,nodes.get(id)))<=radius*2&&dist(near.b,M.position(p,nodes.get(id)))<=radius*2))continue;
      add(duplicate>radius*2?'overlap':'pipe',duplicate>radius*2?'管线存在重复重合段':'管线之间存在几何碰撞',a.r,b.r.id,'mepRun',at(near.a,near.b,.5));if(truncated)break;
    }
    const walls=p.walls.map(w=>{const L=E.dist(w.a,w.b),ux=(w.b.x-w.a.x)/L,uy=(w.b.y-w.a.y)/L,f=p.floors.find(f=>f.id===w.floor);return{w,f,local:q=>({x:(q.x-w.a.x)*ux+(q.y-w.a.y)*uy,y:-(q.x-w.a.x)*uy+(q.y-w.a.y)*ux,z:q.z-f.elevation}),panels:E.wallPanels(p,w),box:extent({...w.a,z:f.elevation},{...w.b,z:f.elevation+w.height},w.thickness/2)}});
    const objects=p.objects.map(o=>{const f=p.floors.find(f=>f.id===o.floor),a=-o.angle*Math.PI/180,c=Math.cos(a),s=Math.sin(a),cx=o.x+o.w/2,cy=o.y+o.d/2;return{o,local:q=>({x:(q.x-cx)*c-(q.y-cy)*s,y:(q.x-cx)*s+(q.y-cy)*c,z:q.z-f.elevation-o.z})}});
    const slabs=p.floors.map(f=>({f,rooms:E.detectRooms(p,f.id)}));
    for(const segment of segments){if(truncated)break;const {r,a,b}=segment,radius=Math.max(0,r.diameter/2-1e-8);if(onlyRunIds&&!onlyRunIds.includes(r.id))continue;
      for(const item of walls){if(!overlap(segment.box,item.box))continue;const x=item.local(a),y=item.local(b);
        for(const panel of item.panels){const depth=panel.depth??item.w.thickness,offset=panel.y||0,hit=boxHit(x,y,{x:panel.x,y:offset-depth/2,z:panel.z},{x:panel.x+panel.w,y:offset+depth/2,z:panel.z+panel.h},radius);if(hit){add('wall','管线穿过墙体实体，需确认套管或调整路线',r,item.w.id,'wall',at(a,b,(hit.enter+hit.exit)/2),item.w.floor);break}}
      }
      if(segment.index===1&&root.Penetrations)for(const h of root.Penetrations.data(p)){const hit=root.Penetrations.sleeveHit(p,h,r);if(hit)add('sleeve','管线与套管实体碰撞，需调整净空或路线',r,h.id,'penetration',hit,h.floor)}
      const hosts=[nodes.get(r.a)?.fixtureId,nodes.get(r.b)?.fixtureId].filter(Boolean);
      for(const item of objects){if(hosts.includes(item.o.id))continue;const o=item.o,hit=boxHit(item.local(a),item.local(b),{x:-o.w/2,y:-o.d/2,z:0},{x:o.w/2,y:o.d/2,z:o.h},radius);if(hit)add('object','管线进入构件外包体，需检查净距',r,o.id,'object',at(a,b,(hit.enter+hit.exit)/2),o.floor)}
      for(const {f,rooms}of slabs){if(segment.box.hi.z<f.elevation-f.slab||segment.box.lo.z>f.elevation)continue;for(const room of rooms){const hit=slabHit(a,b,f,room.surfaceGeometry,radius);if(hit)add('slab','管线穿过楼板实体，需设置洞口或调整路线',r,room.id,'room',hit,f.id)}}
    }
    return{issues,truncated,segments:segments.length};
  }
  Object.assign(M,{closestSegments:closest,boxHit,collinearOverlap,slabHit,clashes});root.MEP=M;if(typeof module!=='undefined')module.exports=M;
})(typeof window!=='undefined'?window:globalThis);
