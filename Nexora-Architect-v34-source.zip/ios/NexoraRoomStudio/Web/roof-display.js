(function(root){
'use strict';
const E=root.BIM||require('./geometry.js'), R=root.RoofModel||require('./roof-model.js');
const eps=1e-7, xyz=(q,h)=>[q.x,h,q.y];
// Cut the actual polygon rings, including holes; never the triangulation diagonals.
function slice(p,a,b,floor){
 const dx=b.x-a.x,dy=b.y-a.y,len=Math.hypot(dx,dy);if(len<eps)return [];
 const result=[];
 for(const s of R.build(p).surfaces){
  if(floor!=null&&s.floor!==floor)continue;
  const cuts=[0,1],parameter=(x,y)=>((x-a.x)*dx+(y-a.y)*dy)/(len*len);
  for(const ring of s.rings)for(let i=0;i<ring.length;i++){
   const q=ring[i],v=ring[(i+1)%ring.length],qa=(q[0]-a.x)*dy-(q[2]-a.y)*dx,va=(v[0]-a.x)*dy-(v[2]-a.y)*dx;
   if(Math.abs(qa)<eps&&Math.abs(va)<eps){cuts.push(parameter(q[0],q[2]),parameter(v[0],v[2]));continue}
   if((qa<=0&&va>=0)||(va<=0&&qa>=0)){const t=qa/(qa-va);if(Number.isFinite(t))cuts.push(parameter(q[0]+(v[0]-q[0])*t,q[2]+(v[2]-q[2])*t))}
  }
  const boundary=(q,ring)=>ring.some((v,i)=>{const b=ring[(i+1)%ring.length],dx=b[0]-v[0],dy=b[2]-v[2],L=Math.hypot(dx,dy);return L>eps&&Math.abs((q.x-v[0])*dy-(q.y-v[2])*dx)<eps*L&&(q.x-v[0])*(q.x-b[0])+(q.y-v[2])*(q.y-b[2])<=eps});
  const inside=q=>(boundary(q,s.rings[0])||E.pointIn(q,s.rings[0].map(v=>({x:v[0],y:v[2]}))))&&!s.rings.slice(1).some(r=>!boundary(q,r)&&E.pointIn(q,r.map(v=>({x:v[0],y:v[2]}))));
  const values=cuts.filter(t=>t>=-eps&&t<=1+eps).map(t=>Math.max(0,Math.min(1,t))).sort((x,y)=>x-y).filter((v,i,ar)=>!i||v-ar[i-1]>eps);
  for(let i=0;i+1<values.length;i++){
   const u=values[i],v=values[i+1],mid=(u+v)/2;if(v-u<eps||!inside({x:a.x+dx*mid,y:a.y+dy*mid}))continue;
   const point=t=>{const x=a.x+dx*t,y=a.y+dy*t;return[x,s.plane.a*x+s.plane.b*y+s.plane.c,y]};
   result.push({roofId:s.roofId,floor:s.floor,a:point(u),b:point(v)});
  }
 }
 // Deduplicate a cut exactly coinciding with a ridge shared by two surfaces.
 const seen=new Set();return result.filter(v=>{const k=[...v.a,...v.b].map(n=>Math.round(n/eps)).join(',');if(seen.has(k))return false;seen.add(k);return true});
}
function closures(p){
 const out=[];
 for(const w of p.walls.filter(w=>w.kind==='exterior')){
  const f=p.floors.find(f=>f.id===w.floor),base=f.elevation+w.height;
  // A same-floor roof may cap this wall. An upper-story roof must not extend
  // a lower wall through the intermediate story merely because its XY overlaps.
  for(const s of slice(p,w.a,w.b,w.floor)){
   let a=s.a,b=s.b;
   if(Math.max(a[1],b[1])<=base+eps)continue;
   if(Math.min(a[1],b[1])<base){const t=(base-a[1])/(b[1]-a[1]),q=a.map((v,i)=>v+(b[i]-v)*t);if(a[1]<base)a=q;else b=q;}
   const points=[[a[0],base,a[2]],[b[0],base,b[2]],b,a];
   out.push({roofId:s.roofId,floor:w.floor,wallId:w.id,material:w.material,points});
  }
 }
 return out;
}
function section(p,y,axis='y'){const model=R.build(p);if(!model.surfaces.length)return[];const vertices=model.surfaces.flatMap(s=>s.rings.flat()),coords=vertices.map(v=>v[axis==='x'?2:0]);return axis==='x'?slice(p,{x:y,y:Math.min(...coords)-1},{x:y,y:Math.max(...coords)+1}):slice(p,{x:Math.min(...coords)-1,y},{x:Math.max(...coords)+1,y});}
const API={slice,closures,section};root.RoofDisplay=API;if(typeof module!=='undefined')module.exports=API;
})(typeof window!=='undefined'?window:globalThis);
