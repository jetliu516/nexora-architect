(function(root){
  'use strict';
  const E=root.BIM||(typeof require==='function'?require('./geometry.js'):null),
    N=root.NorthAmerica||(typeof require==='function'?require('./north-america.js'):null),
    D=root.Drawings||(typeof require==='function'?require('./drawings.js'):null),
    U=root.Units||(typeof require==='function'?require('./units.js'):null),
    W=root.WorkspaceModel||(typeof require==='function'?require('./workspace-model.js'):null);
  const copy=x=>JSON.parse(JSON.stringify(x)), esc=D.esc;
  const messages={
    en:{title:'Explore this home',back:'Back to results',load:'Create my project',plan:'Floor plan',exterior:'Exterior 3D',inside:'Inside this floor',floor:'Floor',units:'Units',living:'Net living area',garage:'Garage',basement:'Basement',outdoor:'Porches and decks',rooms:'Rooms on this floor',room:'Room',area:'Net area',included:'Living area',excluded:'Excluded',yes:'Included',floorLiving:'This floor · living area',fit:'Fit',zoom:'Zoom in',out:'Zoom out',controls:'Drag to orbit · Shift + drag to pan · scroll or pinch to zoom',basis:'Net living area uses inside wall faces, excluding garage, basement, porches, decks and stair openings. Outdoor areas are shown separately as platform footprints.',safe:'Previewing does not change your current project. Create my project opens an independent, editable copy.',webgl:'3D could not start on this device. You can still inspect every floor plan and create an editable project.',limit:'Schematic starting point. Construction, structure and local code approval remain to be completed.',openError:'The project could not be saved. The preview and your current project are still available.'},
    zh:{title:'查看住宅样板',back:'返回筛选结果',load:'创建我的项目',plan:'楼层平面',exterior:'外观 3D',inside:'查看本层室内',floor:'楼层',units:'单位',living:'净居住面积',garage:'车库',basement:'地下室',outdoor:'前廊与露台',rooms:'本层房间',room:'房间',area:'净面积',included:'居住面积口径',excluded:'不计入',yes:'计入',floorLiving:'本层净居住面积',fit:'适应窗口',zoom:'放大',out:'缩小',controls:'拖动旋转 · Shift + 拖动平移 · 滚轮或双指缩放',basis:'净居住面积按墙体内表面计算，排除车库、地下室、前廊、露台及楼梯洞口。室外面积单列为平台轮廓面积。',safe:'预览不会改动当前项目。点击“创建我的项目”后生成独立、可编辑的副本。',webgl:'当前设备无法启动 3D。你仍可查看各层平面，并创建可编辑项目。',limit:'方案设计起点；施工、结构和当地规范审查尚未完成。',openError:'项目未能保存，预览和当前项目均保留。'},
    es:{title:'Explora esta vivienda',back:'Volver a resultados',load:'Crear mi proyecto',plan:'Plano de planta',exterior:'Exterior 3D',inside:'Interior de esta planta',floor:'Planta',units:'Unidades',living:'Superficie habitable neta',garage:'Garaje',basement:'Sótano',outdoor:'Porches y terrazas',rooms:'Habitaciones de esta planta',room:'Habitación',area:'Superficie neta',included:'Cómputo habitable',excluded:'Excluida',yes:'Incluida',floorLiving:'Superficie habitable de esta planta',fit:'Ajustar',zoom:'Acercar',out:'Alejar',controls:'Arrastra para orbitar · Mayús + arrastrar para desplazar · rueda o pellizco para zoom',basis:'La superficie habitable se mide entre las caras interiores de los muros; excluye garaje, sótano, porches, terrazas y huecos de escalera. Las áreas exteriores se muestran por separado como huellas de plataformas.',safe:'La vista previa no modifica tu proyecto. Crear mi proyecto abre una copia independiente y editable.',webgl:'No se pudo iniciar 3D en este dispositivo. Puedes revisar todas las plantas y crear un proyecto editable.',limit:'Esquema inicial. La revisión de construcción, estructura y normativa local sigue pendiente.',openError:'No se pudo guardar el proyecto. La vista previa y el proyecto actual siguen disponibles.'}
  };
  const text=()=>messages[root.NexoraI18n?.language]||messages.en;
  function inspect(p){
    const floors=p.floors.map(f=>{const rooms=E.detectRooms(p,f.id).map(r=>({id:r.id,name:r.name,area:r.netArea,roomType:r.roomType,included:r.includeLiving&&r.roomType!=='openBelow'}));
      return {id:f.id,name:f.name,elevation:f.elevation,rooms,living:rooms.filter(r=>r.included).reduce((n,r)=>n+r.area,0)};});
    return {floors,living:floors.reduce((n,f)=>n+f.living,0),garage:floors.flatMap(f=>f.rooms).filter(r=>r.roomType==='garage').reduce((n,r)=>n+r.area,0),
      basement:floors.filter(f=>f.elevation<0).flatMap(f=>f.rooms).reduce((n,r)=>n+r.area,0),outdoor:p.objects.filter(o=>o.kind==='deck').reduce((n,o)=>n+o.w*o.d,0)};
  }
  function state(p,floor,mode='plan'){
    if(!p.floors.some(f=>f.id===floor))throw Error('Unknown preview floor');
    return {...W.defaults(),floor,mode:mode==='plan'?'plan':'3d',selected:null,roof:mode==='exterior',allFloors:mode==='exterior',landscape:mode==='exterior',foundation:false,cutaway:mode==='inside',cutHeight:1.35,autoDimensions:false};
  }
  function plan(p,floor,unit){
    const view={...p,unit},b=E.sitePlanBounds(p,floor),padding=Math.max(b.w,b.d)*.025+.25;
    // Draw the same walls, openings, furniture and slab holes used by the editor.
    // Its print path omits selection hit targets and editor-only handles.
    return D.svg(D.plan(view,state(view,floor),{print:true}),{x:b.x-padding,y:b.y-padding,w:b.w+2*padding,h:b.d+2*padding});
  }
  function create(bridge){
    let project=null,info=null,floor=null,unit='ft',mode='plan',zoom=1,renderer=null,returnTo=null,host=null;
    const $=id=>document.getElementById(id);
    function release(){const old=renderer;renderer=null;old?.dispose();}
    function close(){release();project=null;info=null;host=null;}
    function fit(){renderer?.fit(project,mode==='exterior'?project.floors.find(f=>f.elevation>=0)?.id||floor:floor,{singleFloor:mode==='inside'});}
    function render(preserveCamera=false){
      if(!project)return;const camera=preserveCamera?renderer?.captureCamera?.():null;release();const t=text(),f=info.floors.find(f=>f.id===floor),fmt=n=>U.area(n,unit);
      bridge.dialog(t.title,`<section id="templatePreview" class="template-preview" data-no-translate data-template-id="${esc(project.template.id)}"><div class="template-preview-heading"><button data-preview-action="back">← ${t.back}</button><small>${esc(project.template.id)} · ${esc(project.template.style)}</small><h3>${esc(project.name)}</h3><p>${t.safe}</p></div><div class="template-area-cards">${[['living',info.living],['garage',info.garage],['basement',info.basement],['outdoor',info.outdoor]].map(([key,n])=>`<div><small>${t[key]}</small><strong data-preview-area="${key}">${fmt(n)}</strong></div>`).join('')}</div><div class="template-preview-controls"><label>${t.floor}<select id="previewFloor">${info.floors.map(f=>`<option value="${esc(f.id)}"${f.id===floor?' selected':''}>${esc(f.name)}</option>`).join('')}</select></label><label>${t.units}<select id="previewUnit"><option value="ft"${unit==='ft'?' selected':''}>ft / in · sq ft</option><option value="m"${unit==='m'?' selected':''}>m · m²</option></select></label><div class="template-preview-modes">${['plan','exterior','inside'].map(v=>`<button data-preview-mode="${v}" aria-pressed="${mode===v}">${t[v]}</button>`).join('')}</div></div><div class="template-preview-viewport" id="previewViewport" role="region" aria-label="${esc(f.name+' · '+t[mode])}">${mode==='plan'?plan(project,floor,unit):''}</div><div class="template-preview-navigation">${mode==='plan'?`<button data-preview-action="out" aria-label="${t.out}">−</button><span id="previewZoom">${Math.round(zoom*100)}%</span><button data-preview-action="zoom" aria-label="${t.zoom}">+</button>`:`<small>${t.controls}</small>`}<button data-preview-action="fit">${t.fit}</button></div><p><strong>${t.floorLiving}: ${fmt(f.living)}</strong></p><details class="template-preview-rooms"><summary>${t.rooms} · ${f.rooms.length}</summary><table><thead><tr><th>${t.room}</th><th>${t.area}</th><th>${t.included}</th></tr></thead><tbody>${f.rooms.map(r=>`<tr data-preview-room="${esc(r.id)}"><td>${esc(r.name)}</td><td>${fmt(r.area)}</td><td>${r.included?t.yes:t.excluded}</td></tr>`).join('')}</tbody></table></details><p class="template-preview-basis">${t.basis}</p><p class="template-preview-basis">${t.limit}</p><div class="template-preview-load"><button class="primary" data-preview-action="load">${t.load}</button></div></section>`);
      host=$('previewViewport');if(mode==='plan'){applyZoom();return;}
      try{renderer=new root.BuildingView(host,()=>false);renderer.rebuild(project,state(project,floor,mode));if(mode==='inside'){renderer.ground.visible=false;renderer.landscape.visible=false;}fit();if(camera)renderer.restoreCamera?.(camera);}
      catch(err){release();host.textContent=t.webgl;host.setAttribute('role','status');}
    }
    function applyZoom(){const svg=host?.querySelector('svg');if(svg){svg.style.width=zoom*100+'%';svg.style.height=zoom*100+'%';svg.style.maxWidth='none';}if($('previewZoom'))$('previewZoom').textContent=Math.round(zoom*100)+'%';}
    function open(id,back){const next=N.build(id),details=inspect(next);close();project=next;info=details;floor=project.floors.find(f=>f.elevation>=0)?.id||project.floors[0].id;unit='ft';mode='plan';zoom=1;returnTo=back;render();}
    function click(d){
      if(!project)return false;
      if(d.previewMode){if(!['plan','exterior','inside'].includes(d.previewMode))return false;mode=d.previewMode;render();return true;}
      if(!d.previewAction)return false;
      if(d.previewAction==='back'){const back=returnTo;close();back?.();}
      else if(d.previewAction==='load'){
        const candidate=copy(project);candidate.unit=unit;let opened;
        try{opened=bridge.open(candidate);}catch(err){bridge.toast(err.message||text().openError);return true;}
        if(opened){const {s}=bridge.state();s.mode='3d';s.roof=true;s.allFloors=true;s.cutaway=false;s.selected=null;bridge.refresh();close();$('dialog').close();}
        else bridge.toast(text().openError);
      }else if(d.previewAction==='fit'){zoom=1;if(renderer)fit();else{applyZoom();host.scrollTop=host.scrollLeft=0;}}
      else if(d.previewAction==='zoom'||d.previewAction==='out'){zoom=Math.max(1,Math.min(4,zoom+(d.previewAction==='zoom'?.5:-.5)));applyZoom();}
      return true;
    }
    function change(id,value){if(!project)return false;if(id==='previewFloor'){if(!project.floors.some(f=>f.id===value))return false;floor=value;zoom=1;render();return true;}if(id==='previewUnit'){if(!['ft','m'].includes(value))return false;unit=value;render(true);return true;}return false;}
    return {open,close,click,change,refresh:()=>render(true),active:()=>!!project};
  }
  root.TemplatePreview={create,inspect,plan,state};
  if(typeof module==='object')module.exports=root.TemplatePreview;
})(typeof globalThis!=='undefined'?globalThis:this);
