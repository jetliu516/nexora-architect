(function(root){
'use strict';
const E=root.BIM||(typeof require==='function'?require('./geometry.js'):null),FT=3.280839895013123,SF=FT*FT,CY=1.307950619314392;
const codes=['USD','CAD','CNY'],canonicalKeys=['floor','wall','concrete','door','window','cabinet'],legacyKeys=[...canonicalKeys,'countertop','backsplash'];
const areaKeys=['floor','wall','window','countertop','backsplash'];
const samples={USD:{floor:12*SF,wall:3.5*SF,concrete:175*CY,door:350,window:48*SF,cabinet:220*FT,waste:10},CAD:{floor:16*SF,wall:4.8*SF,concrete:240*CY,door:480,window:65*SF,cabinet:300*FT,waste:10},CNY:{floor:160,wall:42,concrete:650,door:1800,window:700,cabinet:1800,waste:10}};
function currency(p){return codes.includes(p.currency)?p.currency:p.pricing?.currency==='USD'?'USD':'CNY'}
function legacyUSD(p){return currency(p)==='USD'&&p.pricing?.currency==='USD'}
function imperialFactor(key){return areaKeys.includes(key)?SF:key==='concrete'?CY:key==='cabinet'?FT:1}
function factor(p,key){return p.unit==='ft'?imperialFactor(key):1}
function quantityUnit(p,key,fallback){return p.unit==='ft'?(areaKeys.includes(key)?'sq ft':key==='concrete'?'cu yd':key==='cabinet'?'ft':key==='door'?'each':fallback):fallback}
function metricUnit(key){return areaKeys.includes(key)?'m²':key==='concrete'?'m³':key==='cabinet'?'m':'each'}
function record(value){return value!=null&&Object.prototype.toString.call(value)==='[object Object]'}
function validRate(value,max=1e6){return Number.isFinite(value)&&value>=0&&value<=max}
// Inspect raw numbers before the engine's JSON clone can turn Infinity/NaN into null.
function validatePricing(p){
 if(p?.currency!=null&&!codes.includes(p.currency))throw Error('Unsupported project currency');
 if(p?.rates!=null){
  if(!record(p.rates))throw Error('Invalid project rates');
  for(const [key,value]of Object.entries(p.rates))if(!validRate(value,key==='waste'?100:1e6))throw Error('Invalid project unit price');
 }
 if(p?.pricing!=null){
  if(!record(p.pricing)||p.pricing.currency!=='USD'||!record(p.pricing.rates))throw Error('Invalid USD pricing');
  for(const [key,value]of Object.entries(p.pricing.rates))if(!legacyKeys.includes(key)||!validRate(value))throw Error('Invalid USD unit price');
 }
}
function estimate(p,floor){
 validatePricing(p);
 const legacy=legacyUSD(p);
 const U=legacy?(root.USPricing||(typeof require==='function'?require('./us-pricing.js'):null)):null;
 if(legacy&&!U)throw Error('USD pricing support is unavailable');
 // Legacy prices are per imperial unit and retain their original finish-area and
 // countertop/backsplash allowances. New projects continue using canonical rates.
 const base=legacy?U.estimate(p,floor):E.estimate(p,floor);
 const rows=base.rows.map(r=>{
  const scale=factor(p,r.key)/(legacy?imperialFactor(r.key):1);
  const quantity=r.quantity*scale,rate=r.rate/scale;
  return{...r,quantity,rate,unit:quantityUnit(p,r.key,legacy?metricUnit(r.key):r.unit),amount:quantity*rate};
 });
 return{...base,rows,total:rows.reduce((sum,r)=>sum+r.amount,0),currency:currency(p)};
}
function rows(p,floor){return estimate(p,floor).rows}
function money(p,n){return new Intl.NumberFormat('en-US',{style:'currency',currency:currency(p),minimumFractionDigits:2,maximumFractionDigits:2}).format(n)}
function setRate(p,key,displayValue){
 validatePricing(p);
 const legacy=legacyUSD(p),keys=legacy?legacyKeys:canonicalKeys;
 if(key!=='waste'&&!keys.includes(key))throw Error('Unsupported price category');
 if(!validRate(displayValue,key==='waste'?100:1e6))throw Error('Invalid displayed unit price');
 const value=key==='waste'?displayValue:displayValue*factor(p,key)/(legacy?imperialFactor(key):1);
 if(!validRate(value,key==='waste'?100:1e6))throw Error('Invalid stored unit price');
 if(legacy&&key!=='waste')p.pricing={...p.pricing,rates:{...p.pricing.rates,[key]:value}};
 else p.rates={...p.rates,[key]:value};
 return p;
}
function setCurrency(p,code){
 if(!codes.includes(code))throw Error('Unsupported currency');
 p.currency=code;p.rates={...samples[code]};
 // An explicit preset replaces the active price source, including same-USD resets.
 delete p.pricing;return p;
}
function newDefaults(p){p.unit='ft';setCurrency(p,'USD');p.floors[0].height=2.7432;p.floors[0].name='Main Floor';return p}
const base=E.validate;
E.validate=function(input){
 validatePricing(input);
 if(input?.site?.driveway!=null){const d=input.site.driveway;if(!d||!['x','y','w','d'].every(k=>Number.isFinite(d[k]))||Math.abs(d.x)>500||Math.abs(d.y)>500||d.w<.1||d.w>100||d.d<.1||d.d>100)throw Error('Invalid driveway dimensions')}
 const p=base(input);
 if(typeof input.site?.landscape==='boolean')p.site.landscape=input.site.landscape;
 if(input.site?.driveway!=null){const d=input.site.driveway;p.site.driveway={x:d.x,y:d.y,w:d.w,d:d.d}}
 return p;
};
root.ProjectRegion={currency,factor,quantityUnit,estimate,rows,money,newDefaults,setCurrency,setRate,samples,codes};
if(typeof module==='object')module.exports=root.ProjectRegion;
})(typeof window!=='undefined'?window:globalThis);
