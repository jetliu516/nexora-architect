(function(root){
 'use strict';
 const E=root.BIM||require('./geometry.js'),W=root.WorkspaceModel||require('./workspace-model.js'),D=root.Drawings||require('./drawings.js'),M=root.MEP,P=root.Penetrations;
 const esc=D.esc,clone=E.clone;
 const papers={A4:[297,210],A3:[420,297],A2:[594,420],A1:[841,594],'ANSI B':[431.8,279.4],'ANSI D':[914.4,609.6]};
 const kinds={plan:'平面图',elevation:'立面',section:'剖面',profile:'排水展开纵剖面',mepSchedule:'机电管线表',penetrationSchedule:'预留清单',index:'图纸目录'};
 const data=p=>p.sheets||[],item=(p,id)=>data(p).find(x=>x.id===id),geometric=v=>['plan','elevation','section'].includes(v.source.kind);
 const dims=s=>s.orientation==='portrait'?[papers[s.paper][1],papers[s.paper][0]]:papers[s.paper];
 const area=s=>{const [w,h]=dims(s);return{x:10,y:10,w:w-20,h:h-47}};
 const num=(x,a,b)=>{if(typeof x!=='number'||!Number.isFinite(x)||x<a||x>b)throw Error('图纸参数超出范围');return x};
 const str=(x,n)=>{if(typeof x!=='string'||x.length>n)throw Error('图纸文字格式无效');return x};
 const id=x=>typeof x==='string'&&/^[A-Za-z0-9_-]{1,120}$/.test(x),ref=x=>typeof x==='string'&&/^[A-Za-z0-9_.:-]{1,200}$/.test(x);
 function validate(p){
  if(p.sheets==null)return p;if(!Array.isArray(p.sheets)||p.sheets.length>100)throw Error('图册最多100页');
  const ids=new Set([p.id,...['floors','walls','openings','objects','roofs','annotations','slabOpenings','penetrations','savedViews'].flatMap(k=>(p[k]||[]).map(x=>x.id)),...M.data(p).nodes.map(x=>x.id),...M.data(p).runs.map(x=>x.id)]),numbers=new Set();
  const unique=x=>{if(!id(x)||ids.has(x))throw Error('图纸或视口编号重复或无效');ids.add(x)};
  for(const s of p.sheets){unique(s.id);if(!Object.hasOwn(papers,s.paper)||!['landscape','portrait'].includes(s.orientation))throw Error('图幅无效');
   str(s.number,32);if(!s.number.trim()||numbers.has(s.number.trim().toLowerCase()))throw Error('图号必须唯一');numbers.add(s.number.trim().toLowerCase());
   for(const [k,n]of Object.entries({title:100,revision:40,date:40,author:100,notes:500}))str(s[k],n);
   if(!Array.isArray(s.views)||s.views.length>20)throw Error('每页最多20个视口');const a=area(s);
   for(const v of s.views){unique(v.id);str(v.title,100);for(const k of ['x','y','w','h'])num(v[k],0,1000);if(v.w<25||v.h<25||v.x<a.x||v.y<a.y||v.x+v.w>a.x+a.w+1e-7||v.y+v.h>a.y+a.h+1e-7)throw Error('视口超出图框可用区域');
    num(v.scale,1,10000);num(v.cx,-10000,10000);num(v.cy,-10000,10000);if(![0,90,180,270].includes(v.rotation))throw Error('视口旋转无效');
    const q=v.source;if(!q||!Object.hasOwn(kinds,q.kind))throw Error('图纸来源无效');if(q.floor!=null&&!ref(q.floor))throw Error('源楼层编号无效');
    if(q.kind==='plan'&&!ref(q.floor))throw Error('缺少源楼层');
    if(q.kind==='elevation'&&!['front','back','left','right'].includes(q.direction))throw Error('立面方向无效');
    if(q.kind==='section'){num(q.sectionY,-500,500);if(q.sectionAxis!=null&&!['x','y'].includes(q.sectionAxis))throw Error('Invalid section axis')}
    if(q.kind==='profile'&&!(ref(q.runId)||(ref(q.start)&&ref(q.end))))throw Error('缺少排水路径来源');
    if(q.kind==='plan'){if(!q.layers||typeof q.layers!=='object'||Array.isArray(q.layers))throw Error('视口图层无效');for(const [k,b]of Object.entries(q.layers))if(!Object.hasOwn(W.labels,k)||typeof b!=='boolean')throw Error('视口图层无效');}
    if(['mepSchedule','penetrationSchedule','index'].includes(q.kind)){num(q.rowStart,0,100000);num(q.rowCount,1,60);if(!Number.isInteger(q.rowStart)||!Number.isInteger(q.rowCount))throw Error('清单行范围无效');}
   }
  }return p;
 }
 function create(p){const used=new Set(data(p).map(x=>x.number.toLowerCase()));let n=101;while(used.has('a-'+n))n++;const s={id:E.uid(),number:'A-'+n,title:'',paper:'A3',orientation:'landscape',revision:'',date:new Date().toISOString().slice(0,10),author:'',notes:'',views:[]};(p.sheets||(p.sheets=[])).push(s);return s}
 function duplicate(p,s){const out=create(p),number=out.number;Object.assign(out,clone(s),{id:out.id,number});out.views.forEach(v=>v.id=E.uid());return out}
 function source(p,v,t=x=>x){
  const q=v.source,state={...W.defaults(),floor:q.floor,selected:null,autoDimensions:true,layers:{...W.defaults().layers,...q.layers},allFloors:false};
  if(q.floor&&!['elevation','section'].includes(q.kind)&&!p.floors.some(f=>f.id===q.floor))throw Error('源楼层已删除，请重新关联视口');
  if(q.kind==='plan'){const b=M.bounds(p,q.floor);return{markup:D.plan(p,state,{print:true}),box:{x:b.x-1,y:b.y-1,w:b.w+2,h:b.d+2}}}
  if(q.kind==='elevation')return D.elevation(p,state,q.direction);
  if(q.kind==='section')return D.section(p,{...state,sectionAxis:q.sectionAxis||'y'},q.sectionY);
  if(q.kind==='profile'){const svg=M.profileSVG(p,M.drainProfile(p,q),t);return{markup:svg.replace(/^<svg[^>]*>/,'').replace(/<\/svg>\s*$/,''),box:{x:0,y:0,w:1280,h:720}}}
  const unit=p.unit==='ft'?'ft':'m',factor=unit==='ft'?1/.3048:1,n=x=>(x*factor).toFixed(3);let headers,rows;
  if(q.kind==='mepSchedule'){headers=[t('名称'),t('系统'),t('楼层'),t('长度')+' / '+unit,t('管径')+' / '+unit];rows=M.data(p).runs.map(r=>[r.label,t(M.systems[r.system].label),p.floors.find(f=>f.id===r.floor)?.name||'',n(M.path(p,r).reduce((sum,b,i,ps)=>sum+(i?Math.hypot(b.x-ps[i-1].x,b.y-ps[i-1].y,b.z-ps[i-1].z):0),0)),n(r.diameter)])}
  else if(q.kind==='penetrationSchedule'){headers=[t('编号'),t('楼层'),t('类型'),t('开孔宽')+' / '+unit,t('开孔高或深')+' / '+unit,t('世界标高')+' / '+unit];rows=P.data(p).map(h=>[h.name,p.floors.find(f=>f.id===h.floor)?.name||'',t(h.kind==='wall'?'穿墙预留':'穿楼板预留'),n(h.width),n(h.height),n(P.frame(p,h).center.z)])}
  else{headers=[t('页序'),t('图号'),t('图名'),t('修订'),t('日期')];rows=data(p).map((s,i)=>[i+1,s.number,s.title,s.revision,s.date])}
  if(q.floor&&q.kind!=='index')rows=rows.filter((_,i)=>q.kind==='mepSchedule'?M.data(p).runs[i].floor===q.floor:P.data(p)[i].floor===q.floor);
  const shown=rows.slice(q.rowStart,q.rowStart+q.rowCount),rowH=26,width=1000,cols=headers.length,all=[headers,...shown];
  const markup=all.map((row,i)=>`<rect x="0" y="${i*rowH}" width="1000" height="26" fill="${i===0?'#edf2ed':'white'}" stroke="#bac7be"/>`+row.map((cell,j)=>`<svg x="${j*width/cols+5}" y="${i*rowH}" width="${width/cols-10}" height="26" overflow="hidden"><text x="0" y="18" font-size="13">${esc(String(cell).length>26?String(cell).slice(0,25)+'…':cell)}</text><title>${esc(cell)}</title></svg>`).join('')).join('')+`<text x="0" y="${all.length*rowH+22}" font-size="13">${esc(t('行范围'))} ${rows.length?Math.min(rows.length,q.rowStart+1):0}–${Math.min(rows.length,q.rowStart+q.rowCount)} / ${rows.length}</text>`;
  return{markup,box:{x:0,y:0,w:width,h:all.length*rowH+35},total:rows.length,more:q.rowStart+q.rowCount<rows.length};
 }
 function fit(p,v){const b=source(p,v).box;v.cx=b.x+b.w/2;v.cy=b.y+b.h/2;if(geometric(v)){const swap=v.rotation%180!==0,w=swap?b.h:b.w,h=swap?b.w:b.h;v.scale=Math.max(1,Math.ceil(Math.max(w*1000/(v.w-4),h*1000/(v.h-12))*100)/100)}return v}
 function add(p,s,q){if(s.views.length>=20)throw Error('每页最多20个视口');const a=area(s),v={id:E.uid(),title:'',x:a.x,y:a.y,w:a.w,h:a.h,scale:100,cx:0,cy:0,rotation:0,source:clone(q)};fit(p,v);s.views.push(v);return v}
 function namespace(markup,prefix){return markup.replace(/\bid="([^"]+)"/g,(_,x)=>`id="${prefix}-${x}"`).replace(/url\(#([^)]+)\)/g,(_,x)=>`url(#${prefix}-${x})`)}
 function inspect(p,s){const issues=[];for(const v of s.views)try{const d=source(p,v);if(d.more)issues.push({view:v.id,level:'note',message:'清单尚有后续行，请添加续表'});if(geometric(v)){const b=d.box,swap=v.rotation%180!==0,w=(swap?b.h:b.w)*1000/v.scale,h=(swap?b.w:b.h)*1000/v.scale;if(w>v.w||h>v.h-8)issues.push({view:v.id,level:'note',message:'视口按指定比例裁切显示'})}}catch(e){issues.push({view:v.id,level:'error',message:e.message})}return issues}
 function svg(p,s,{t=x=>x,interactive=false}={}){
  const [w,h]=dims(s),tr=x=>esc(t(x));let body=`<rect width="${w}" height="${h}" fill="white"/><rect x="10" y="10" width="${w-20}" height="${h-20}" fill="none" stroke="#344d46" stroke-width=".35"/>`;
  for(const v of s.views){let content;try{const d=source(p,v,t),markup=namespace(d.markup,'sheet-'+s.id+'-'+v.id);
   content=geometric(v)?`<svg x="0" y="0" width="${v.w}" height="${v.h-8}" viewBox="${-v.w/2} ${-(v.h-8)/2} ${v.w} ${v.h-8}" overflow="hidden"><g transform="scale(${1000/v.scale}) rotate(${v.rotation}) translate(${-v.cx} ${-v.cy})">${markup}</g></svg>`:`<svg x="2" y="2" width="${v.w-4}" height="${v.h-12}" viewBox="${d.box.x} ${d.box.y} ${d.box.w} ${d.box.h}" preserveAspectRatio="xMidYMid meet" overflow="hidden">${markup}</svg>`;
  }catch(e){content=`<text x="3" y="10" font-size="3" fill="#a92828">${esc(t(e.message))}</text>`}
   body+=`<g ${interactive?`data-sheet-view="${esc(v.id)}" tabindex="0" role="button" aria-label="${esc(v.title||t(kinds[v.source.kind]))}"`:''} transform="translate(${v.x} ${v.y})"><rect width="${v.w}" height="${v.h}" fill="white" stroke="#bdc8c3" stroke-width=".2"/>${content}<path d="M0 ${v.h-8}H${v.w}" stroke="#bdc8c3" stroke-width=".2"/><text x="2" y="${v.h-3}" font-size="3">${esc(v.title||t(kinds[v.source.kind]))} · ${geometric(v)?'1:'+v.scale:tr('不按比例')}</text>${interactive?`<rect width="${v.w}" height="${v.h}" fill="transparent" class="sheet-view-hit"/>`:''}</g>`;
  }
  const page=data(p).findIndex(x=>x.id===s.id)+1;
  body+=`<path d="M10 ${h-35}H${w-10}" stroke="#344d46" stroke-width=".35"/><svg x="14" y="${h-32}" width="${w-100}" height="21" overflow="hidden"><text x="0" y="4" font-size="3.5">${esc(p.name)}</text><text x="0" y="10" font-size="4">${esc(s.title)}</text><text x="0" y="15" font-size="2.5">${tr('修订')}: ${esc(s.revision)} · ${tr('日期')}: ${esc(s.date)} · ${tr('制图')}: ${esc(s.author)}</text><text x="0" y="20" font-size="2.5">${esc(s.notes)}</text></svg><text x="${w-80}" y="${h-26}" font-size="5">${esc(s.number)}</text><text x="${w-80}" y="${h-19}" font-size="3">${page} / ${data(p).length} · ${esc(s.paper)}</text><text x="${w-80}" y="${h-13}" font-size="2.5">NEXORA ARCHITECT</text>`;
  return`<svg xmlns="http://www.w3.org/2000/svg" width="${w}mm" height="${h}mm" viewBox="0 0 ${w} ${h}" role="img" aria-label="${esc(s.number+' '+s.title)}" style="font-family:Arial,PingFang SC,sans-serif">${body}</svg>`;
 }
 function printHTML(p,sheets=data(p),t=x=>x){if(!sheets.length)throw Error('请先新建图纸');validate(p);const errors=sheets.flatMap(s=>inspect(p,s).filter(x=>x.level==='error'));if(errors.length)throw Error('图纸存在失联视口，请修复后导出');
  return'<!doctype html><html><head><meta charset="utf-8"><title>'+esc(p.name)+'</title><style>body{margin:0;background:#dce3df}.print-sheet{margin:10px auto;background:white;overflow:hidden}.print-sheet>svg{display:block}'+sheets.map((s,i)=>{const [w,h]=dims(s);return`@page sheet${i}{size:${w}mm ${h}mm;margin:0}.print-sheet:nth-child(${i+1}){page:sheet${i};width:${w}mm;height:${h}mm}`}).join('')+'@media print{body{background:white}.print-sheet{margin:0;break-after:page;break-inside:avoid}.print-sheet:last-child{break-after:auto}}</style></head><body>'+sheets.map(s=>'<section class="print-sheet">'+svg(p,s,{t})+'</section>').join('')+'</body></html>';
 }
 const base=E.validate;E.validate=raw=>validate(base(raw));
 root.Sheets={papers,kinds,data,item,area,dims,geometric,validate,create,duplicate,source,fit,add,inspect,svg,printHTML};if(typeof module!=='undefined')module.exports=root.Sheets;
})(typeof window!=='undefined'?window:globalThis);
