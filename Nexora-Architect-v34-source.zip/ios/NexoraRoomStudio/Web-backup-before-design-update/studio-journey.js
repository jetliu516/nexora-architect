(() => {
'use strict';
const KEY='nexora-workflows-v1';
let workflow;try{workflow=JSON.parse(localStorage.getItem(KEY))||{}}catch{workflow={}}
function pendingScan(){try{return JSON.parse(sessionStorage.getItem('nexora-pending-scan'))}catch{return null}}
window.nexoraScanCancelled=function(){sessionStorage.removeItem('nexora-pending-scan')};
window.nexoraScanContext=function(){const pending=pendingScan();return{projectId:project.sample?'':project.id,projectName:project.sample?'现场量房':project.name,name:pending?.projectId===project.id?pending.name:'实测房间',floor:pending?.projectId===project.id?pending.floor:'1'}};
function currentMeta(){return workflow[project.id]||(workflow[project.id]=JourneyCore.initialMeta('住宅',1,false))}
function keepMeta(){try{localStorage.setItem(KEY,JSON.stringify(workflow));return true}catch{toast('量房记录无法保存，请导出备份后清理存储空间。');return false}}
const priorSave=save;
save=function(){priorSave();if(project.sample)return;const m=currentMeta();let changed=false;for(const r of project.rooms){if(!m.roomMeta[r.id]){m.roomMeta[r.id]={floor:'1',reviewed:false};changed=true}}const ids=new Set(project.rooms.map(r=>r.id));for(const id of Object.keys(m.roomMeta)){if(!ids.has(id)){delete m.roomMeta[id];changed=true}}if(changed)m.confirmed=false;keepMeta()};
const bar=document.createElement('section');bar.className='journey-return';bar.innerHTML='<div><a href="index.html#overview">← 全屋户型与房间清单</a><span>设计修改单独保存 · 原始量房记录保留</span></div><div><a href="index.html#designers">需要设计师帮助</a><a href="index.html#brief">整理报价需求 →</a></div>';
document.querySelector('.project-bar').before(bar);
if(window.webkit?.messageHandlers?.roomplan){const button=document.createElement('button');button.type='button';button.className='text-button';button.dataset.action='scan-library';button.textContent='扫描记录';bar.lastElementChild.prepend(button)}
const originalReceive=window.nexoraReceiveScan;
window.nexoraReceiveScan=function(raw){
 const previous=new Set(project.rooms.map(r=>r.id));originalReceive(raw);
 const r=project.rooms.find(r=>!previous.has(r.id));if(!r)return false;
 const pending=pendingScan(),m=currentMeta();
 if(pending?.projectId===project.id)r.name=C.safeName(pending.name,r.name);
 m.roomMeta[r.id]={floor:pending?.projectId===project.id?pending.floor:'1',reviewed:false};
 m.measurements[r.id]=C.clone(r);m.confirmed=false;update();
 const stored=keepMeta()&&persistenceOK;
 sessionStorage.removeItem('nexora-pending-scan');
 if(!stored)return false;
 modal('扫描已保存，先复核这一间',`<p class="modal-lead">${esc(r.name)} · ${r.polygon?'请核对墙线、门窗和尺寸，再回到全屋户型确认。':'边界尚未闭合。已保留原始墙线，需要重新扫描后再确认。'}</p><div class="modal-buttons"><button class="button primary" data-action="close-modal">查看本次扫描</button><a class="button subtle" href="index.html#overview">返回全屋户型</a></div>`);
 return true;
};
if(!project.sample){save()}
if(new URLSearchParams(location.search).get('scan')==='1'){
 let pending;try{pending=JSON.parse(sessionStorage.getItem('nexora-pending-scan'))}catch{}
 window.history.replaceState({},'',location.pathname);
 if(pending?.projectId===project.id)scan();
}
})();
