/* Install the web app through browser-supported UI. No native package is implied. */
(function () {
  'use strict';
  const native = Boolean(window.webkit?.messageHandlers?.roomplan);
  const mode = window.matchMedia('(display-mode: standalone)');
  const isStandalone = () => mode.matches || navigator.standalone === true;
  const ua = navigator.userAgent;
  const isIOS = /iPad|iPhone|iPod/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
  const defaultPlatform = isIOS ? 'ios' : /Android/.test(ua) ? 'android' : 'desktop';
  let platform = defaultPlatform;
  let installPrompt = null;
  let dialogActive = false;
  let browserReportedInstalled = false;
  const siteURL = new URL('./', location.href).href;
  const shareIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M12 15V3m-4 4 4-4 4 4M4 13v8h16v-8"/></svg>';
  const phoneIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><rect x="6" y="2" width="12" height="20" rx="3"/><path d="M10 5h4M11 19h2"/></svg>';

  function installed() { return browserReportedInstalled || isStandalone(); }
  function updateEntrypoints() {
    document.querySelectorAll('[data-install-entry]').forEach(button => {
      button.hidden = native;
      button.setAttribute('aria-label', installed() ? '网页版 App 使用说明' : '安装网页版 App');
      button.innerHTML = phoneIcon + '<span>' + (installed() ? 'App 说明' : '安装 App') + '</span>';
    });
    const banner = document.querySelector('#installBanner');
    if (banner) banner.hidden = native || installed();
  }
  function step(n, title, description) {
    return `<li><span class="install-step-number">${n}</span><div><b>${title}</b><p>${description}</p></div></li>`;
  }
  function renderInstall() {
    dialogActive = true;
    const ios = platform === 'ios';
    const android = platform === 'android';
    let instructions;
    if (ios) {
      instructions = step(1, '用 Safari 打开这个网址', '如果正在 ChatGPT、微信或其他 App 内浏览，请复制下方链接，粘贴到 Safari。') +
        step(2, '打开分享菜单', `轻点 Safari 的分享按钮 ${shareIcon}；部分布局需先打开页面菜单，再点「分享」。`) +
        step(3, '添加到主屏幕', '向下找到「添加到主屏幕」。如果出现「作为网页 App 打开」，将它开启，再点「添加」。');
    } else if (android) {
      instructions = step(1, '用 Chrome 打开这个网址', '在浏览器中打开并登录当前有权访问此项目的账号。') +
        step(2, '确认安装或添加到主屏幕', '如有「立即安装」按钮，点按后在浏览器弹窗中确认；否则打开右上角 ⋮ 菜单，选择「安装应用」或「添加到主屏幕」。') +
        step(3, '从桌面打开 Nexora设计', '图标出现后即可打开。不同浏览器可能添加网页快捷方式，具体以浏览器提示为准。');
    } else {
      instructions = step(1, '使用 Chrome、Edge 或 Safari', '在电脑浏览器打开这个网址，并登录有权访问此项目的账号。') +
        step(2, '通过浏览器安装', 'Chrome / Edge 可使用地址栏的安装图标或浏览器应用菜单；Mac Safari 可选择「文件 → 添加到程序坞」。') +
        step(3, '从应用图标继续设计', '支持的浏览器会用独立窗口打开。当前浏览器不支持安装时，可以继续使用网页版。');
    }
    modal(installed() ? '网页版 App 使用说明' : '安装网页版 App', `
      <div class="install-app-heading"><img src="icons/app-192.png" width="62" height="62" alt="Nexora App 图标"><div><b>Nexora 房屋设计</b><span>把你的空间工作室，放到主屏幕。</span><small>${installed() ? '已在 App 模式打开，或浏览器已报告安装完成' : '网页版 App · 无需通过应用商店'}</small></div></div>
      ${installed() ? '<div class="install-success" role="status">可以从设备上的 Nexora设计 图标继续使用。</div>' : ''}
      <div class="install-platforms" role="group" aria-label="选择安装设备">
        <button type="button" data-install-platform="ios" aria-pressed="${ios}" class="${ios ? 'active' : ''}">iPhone / iPad</button>
        <button type="button" data-install-platform="android" aria-pressed="${android}" class="${android ? 'active' : ''}">安卓手机</button>
        <button type="button" data-install-platform="desktop" aria-pressed="${!ios && !android}" class="${!ios && !android ? 'active' : ''}">电脑</button>
      </div>
      <ol class="install-steps">${instructions}</ol>
      <div class="install-link-row"><label for="installURL">本页安装网址</label><div><input id="installURL" aria-label="安装网址" type="url" readonly value="${esc(siteURL)}"><button class="button subtle" data-install-copy>复制链接</button></div></div>
      ${installPrompt && !isIOS && !installed() ? '<button type="button" class="button primary install-now" data-install-now>立即安装网页版 App</button>' : ''}
      <p id="installFeedback" class="install-feedback" role="status" aria-live="polite">${ios ? 'iPhone 需在 Safari 的分享菜单中完成添加。' : '安装由浏览器完成；未出现安装入口时，请按上面的菜单步骤操作。'}</p>
      <div class="install-capabilities"><b>安装后可以使用</b><p>户型编辑 · 家具布置 · 材料估算 · 设计导出</p><p><strong>激光扫描仍需原生 App。</strong>原生扫描版尚未签名发布，目前没有可直接安装的 IPA / APK。安装这个网页版不会开启 LiDAR。</p></div>
      <p class="install-data-note">打开时需要联网。设计保存在当前设备；更换浏览器或安装后若未显示原项目，请先在原浏览器导出项目 JSON，再在 App 中导入。网站访问权限继续适用。</p>
      <details class="native-source"><summary>开发者：原生扫描端源码</summary><p>此 ZIP 是 Xcode 工程源码，不能在手机上直接安装。需要在 Mac 上签名编译并完成真机验证。</p><a href="Nexora_Room_Studio_iOS.zip" download>下载 iOS 工程源码 ZIP</a></details>
    `);
  }

  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault();
    installPrompt = event;
    if (dialogActive && document.querySelector('#modal').open) renderInstall();
  });
  window.addEventListener('appinstalled', () => {
    installPrompt = null;
    browserReportedInstalled = true;
    updateEntrypoints();
    if (dialogActive && document.querySelector('#modal').open) renderInstall();
    else toast('浏览器已报告安装完成，请查看设备上的 Nexora设计 图标');
  });
  mode.addEventListener('change', () => {
    updateEntrypoints();
    if (dialogActive && document.querySelector('#modal').open) renderInstall();
  });
  document.querySelector('#modal').addEventListener('close', () => { dialogActive = false; });
  document.addEventListener('click', async event => {
    const button = event.target.closest('button');
    if (!button) return;
    if (button.hasAttribute('data-install-entry')) {
      platform = defaultPlatform;
      renderInstall();
    } else if (button.dataset.installPlatform) {
      platform = button.dataset.installPlatform;
      renderInstall();
    } else if (button.hasAttribute('data-install-copy')) {
      const field = document.querySelector('#installURL');
      const status = document.querySelector('#installFeedback');
      try {
        await navigator.clipboard.writeText(siteURL);
        status.textContent = '链接已复制。在 Safari 或 Chrome 中粘贴打开。';
      } catch (_) {
        field.focus();
        field.select();
        status.textContent = '请长按或选择上方网址，复制到 Safari 或 Chrome 打开。';
      }
    } else if (button.hasAttribute('data-install-now')) {
      const prompt = installPrompt;
      const status = document.querySelector('#installFeedback');
      if (!prompt) { renderInstall(); return; }
      installPrompt = null;
      button.disabled = true;
      try {
        // Called directly from a user gesture; never infer installation from a click.
        await prompt.prompt();
        const choice = await prompt.userChoice;
        if (document.contains(status)) status.textContent = choice.outcome === 'accepted'
          ? '已接受安装，请在设备的应用列表或主屏幕查看 Nexora设计。'
          : '安装已取消，可以继续使用网页版，或从浏览器菜单再次安装。';
      } catch (_) {
        if (document.contains(status)) status.textContent = '当前浏览器未能打开安装窗口，请使用上方菜单步骤。';
      }
      if (document.contains(button)) button.hidden = true;
    } else if (button.dataset.action) {
      dialogActive = false;
    }
  });
  updateEntrypoints();
})();
