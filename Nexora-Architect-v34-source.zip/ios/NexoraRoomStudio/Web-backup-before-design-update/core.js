(function(root){
'use strict';
const uid=()=>globalThis.crypto?.randomUUID?.()||('r'+Date.now().toString(36)+Math.random().toString(36).slice(2));
const clone=o=>JSON.parse(JSON.stringify(o));
const safeName=(s,fallback='未命名')=>typeof s==='string'&&s.trim()?s.trim().slice(0,80):fallback;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const round=(v,n=2)=>Number(v.toFixed(n));
const finishes={oak:{name:'自然橡木',color:'#e9dec6',pattern:'oak'},walnut:{name:'烟熏胡桃',color:'#b7a18a',pattern:'walnut'},stone:{name:'浅灰石材',color:'#e3e4df',pattern:'stone'},cream:{name:'奶油微水泥',color:'#eee9dc',pattern:'cream'}};
const furniture={sofa:{name:'沙发',w:2.3,d:.9},bed:{name:'双人床',w:1.8,d:2.1},table:{name:'餐桌',w:1.4,d:.85},chair:{name:'单椅',w:.65,d:.65},cabinet:{name:'储物柜',w:1.4,d:.5},bath:{name:'浴缸',w:.8,d:1.7}};
function polygonArea(points){return Math.abs(points.reduce((s,p,i)=>{let q=points[(i+1)%points.length];return s+p[0]*q[1]-q[0]*p[1]},0))/2}
function roomArea(r){return r.walls?r.polygon?.length>=3?polygonArea(r.polygon):null:r.w*r.d}
function perimeter(r){return r.walls?r.walls.reduce((s,w)=>s+Math.hypot(w.b[0]-w.a[0],w.b[1]-w.a[1]),0):2*(r.w+r.d)}
function closedBoundary(walls,tolerance=.2){
 const nodes=[],edges=[];
 const node=p=>{let i=nodes.findIndex(n=>Math.hypot(n[0]-p[0],n[1]-p[1])<tolerance);if(i<0){nodes.push([...p]);i=nodes.length-1}return i};
 for(const w of walls){const a=node(w.a),b=node(w.b);if(a===b)return null;edges.push([a,b])}
 if(nodes.length<3||edges.length!==nodes.length)return null;
 if(nodes.some((_,i)=>edges.filter(e=>e.includes(i)).length!==2))return null;
 let prev=-1,cur=0;const path=[];
 do{if(path.includes(cur))return null;path.push(cur);const next=edges.filter(e=>e.includes(cur)).map(e=>e[0]===cur?e[1]:e[0]).find(n=>n!==prev);prev=cur;cur=next}while(cur!==0&&path.length<=nodes.length);
 if(path.length!==nodes.length)return null;
 const p=path.map(i=>nodes[i]);
 const orient=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
 for(let i=0;i<p.length;i++)for(let j=i+1;j<p.length;j++)if(j!==i+1&&!(i===0&&j===p.length-1)){
 const a=p[i],b=p[(i+1)%p.length],c=p[j],d=p[(j+1)%p.length];if(orient(a,b,c)*orient(a,b,d)<0&&orient(c,d,a)*orient(c,d,b)<0)return null;
 }
 return polygonArea(p)>.04?p:null;
}
function createRoom(name='新房间',w=4,d=3){return{id:uid(),name,w,d,h:2.7,x:0,y:0,finish:'oak',type:'room',source:'manual',furniture:[],openings:[]}}
function demo(){let p={version:1,id:uid(),name:'纽约住宅 · 设计方案',sample:true,unit:'m',updatedAt:new Date().toISOString(),rates:{floor:5.5,paint:2,waste:10},rooms:[]};
 const specs=[['客餐厅',6.4,4.6,0,3.4,'oak','sofa'],['主卧室',4.2,4.6,6.4,3.4,'oak','bed'],['厨房',3.2,3.4,0,0,'stone','cabinet'],['餐厅',3.2,3.4,3.2,0,'cream','table'],['卫生间',2,3.4,6.4,0,'stone','bath'],['书房',2.2,3.4,8.4,0,'oak','table']];
 for(const [name,w,d,x,y,finish,kind]of specs){let r=createRoom(name,w,d);Object.assign(r,{x,y,finish,source:'sample'});const f=furniture[kind];r.furniture=[{id:uid(),kind,w:f.w,d:f.d,x:round((w-f.w)/2),y:round((d-f.d)/2),angle:0}];r.openings=[{kind:'window',side:'top',offset:w*.25,width:Math.min(1.5,w*.5)},{kind:'door',side:'bottom',offset:.25,width:.8}];p.rooms.push(r)}
 p.rooms[0].furniture.push({id:uid(),kind:'table',w:1.2,d:.6,x:2.6,y:3,angle:0});return p;
}
function point(v){if(!Array.isArray(v)||v.length!==2||v.some(x=>typeof x!=='number'||!Number.isFinite(x)||Math.abs(x)>200))throw Error('扫描坐标无效');return[...v]}
function surfaces(v){if(!Array.isArray(v)||v.length>250)throw Error('墙体数据格式无效');return v.map(s=>({a:point(s.a),b:point(s.b),height:typeof s.height==='number'?clamp(s.height,.1,10):2.7}))}
function fromScan(raw){
 if(!raw||raw.format!=='nexora-roomplan-v1'||!Array.isArray(raw.walls)||raw.walls.length<3)throw Error('请使用 Nexora 扫描端导出的量房 JSON 文件');
 if(raw.units && raw.units!=='meters')throw Error('量房数据单位必须为 meters');
 const walls=surfaces(raw.walls),windows=surfaces(raw.windows||[]),doors=surfaces(raw.doors||[]),openings=surfaces(raw.openings||[]);
 const points=walls.flatMap(w=>[w.a,w.b]);const minX=Math.min(...points.map(p=>p[0])),minY=Math.min(...points.map(p=>p[1]));const w=Math.max(...points.map(p=>p[0]))-minX,d=Math.max(...points.map(p=>p[1]))-minY;
 if(w<.2||d<.2||w>60||d>60)throw Error('扫描范围异常，请检查量房数据');
 const norm=ss=>ss.map(s=>({...s,a:[s.a[0]-minX,s.a[1]-minY],b:[s.b[0]-minX,s.b[1]-minY]}));
 let r=createRoom(safeName(raw.name,'实测房间'),round(w,4),round(d,4));Object.assign(r,{source:'lidar',h:round(walls.reduce((s,v)=>s+v.height,0)/walls.length),walls:norm(walls),scanWindows:norm(windows),scanDoors:norm(doors),scanOpenings:norm(openings),capturedAt:typeof raw.capturedAt==='string'?raw.capturedAt:new Date().toISOString()});r.polygon=closedBoundary(r.walls);return r;
}
function validateProject(raw){
 if(!raw||raw.version!==1||!Array.isArray(raw.rooms)||raw.rooms.length>100)throw Error('不是有效的 Nexora 项目文件（最多 100 个房间）');
 const num=(v,a,b)=>{if(typeof v!=='number'||!Number.isFinite(v)||v<a||v>b)throw Error('项目尺寸或位置无效');return v};
 const p={version:1,id:uid(),name:safeName(raw.name,'导入项目'),sample:raw.sample===true,unit:raw.unit==='ft'?'ft':'m',updatedAt:new Date().toISOString(),rates:{floor:num(raw.rates?.floor??5.5,0,1000),paint:num(raw.rates?.paint??2,0,1000),waste:num(raw.rates?.waste??10,0,50)},rooms:[]};
 for(const r of raw.rooms){const n=createRoom(safeName(r.name),num(r.w,.2,60),num(r.d,.2,60));Object.assign(n,{h:num(r.h,1,10),x:num(r.x,-100,100),y:num(r.y,-100,100),finish:finishes[r.finish]?r.finish:'oak',source:['sample','manual','lidar'].includes(r.source)?r.source:'manual'});
 if(r.walls){n.walls=surfaces(r.walls);n.polygon=closedBoundary(n.walls);n.scanWindows=surfaces(r.scanWindows||[]);n.scanDoors=surfaces(r.scanDoors||[]);n.scanOpenings=surfaces(r.scanOpenings||[]);if(n.walls.length<3||n.walls.some(s=>[s.a,s.b].some(p=>p[0]<-.01||p[1]<-.01||p[0]>n.w+.05||p[1]>n.d+.05)))throw Error('扫描边界与房间尺寸不符')}
 if(r.furniture&&!Array.isArray(r.furniture))throw Error('家具数据格式无效');if((r.furniture?.length||0)>100)throw Error('房间家具数量过多');
 n.furniture=(r.furniture||[]).map(f=>{if(!furniture[f.kind])throw Error('家具类型无效');return{id:uid(),kind:f.kind,w:num(f.w,.1,15),d:num(f.d,.1,15),x:num(f.x,-15,60),y:num(f.y,-15,60),angle:[0,90,180,270].includes(f.angle)?f.angle:0}});
 if(r.openings&&!Array.isArray(r.openings))throw Error('门窗格式无效');n.openings=(r.openings||[]).slice(0,30).map(o=>{if(!['door','window'].includes(o.kind)||!['top','bottom'].includes(o.side))throw Error('门窗类型无效');return{kind:o.kind,side:o.side,offset:num(o.offset,0,n.w),width:num(o.width,.2,Math.min(6,n.w))}});p.rooms.push(n)}return p;
}
function bounds(rooms){if(!rooms.length)return{x:0,y:0,w:10,d:8};let x=Math.min(...rooms.map(r=>r.x)),y=Math.min(...rooms.map(r=>r.y));return{x,y,w:Math.max(...rooms.map(r=>r.x+r.w))-x,d:Math.max(...rooms.map(r=>r.y+r.d))-y}}
function estimate(p){let area=0,wall=0,unknown=0;for(const r of p.rooms){const a=roomArea(r);if(a===null)unknown++;else area+=a;wall+=perimeter(r)*r.h}const purchase=area*(1+p.rates.waste/100);return{area,wall,unknown,purchase,floorCost:purchase*10.7639104*p.rates.floor,paintCost:wall*10.7639104*p.rates.paint}}
const api={uid,clone,clamp,round,safeName,finishes,furniture,polygonArea,roomArea,perimeter,closedBoundary,createRoom,demo,fromScan,validateProject,bounds,estimate};if(typeof module!=='undefined')module.exports=api;else root.RoomCore=api;
})(globalThis);
