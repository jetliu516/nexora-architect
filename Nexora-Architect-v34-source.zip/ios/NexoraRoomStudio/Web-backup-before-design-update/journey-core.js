(function(root) {
  'use strict';
  const R = typeof module !== 'undefined' ? require('./core.js') : root.RoomCore;
  function newProject(name, unit) {
    return {version:1,id:R.uid(),name:R.safeName(name,'我的全屋装修'),sample:false,unit:unit==='m'?'m':'ft',updatedAt:new Date().toISOString(),rates:{floor:5.5,paint:2,waste:10},rooms:[]};
  }
  function initialMeta(kind,floors,basement) {
    return {kind,floors:Number(floors),basement:!!basement,roomMeta:{},measurements:{},brief:{},photos:[],quotes:[],appointments:[],confirmed:false};
  }
  function addMeasuredRoom(project, meta, values) {
    const factor = project.unit === 'ft' ? 3.280839895 : 1;
    const w=Number(values.w)/factor,d=Number(values.d)/factor,h=Number(values.h)/factor;
    if(![w,d,h].every(Number.isFinite)||w<.2||d<.2||w>60||d>60||h<1||h>10) throw Error('请输入有效净尺寸：宽深 0.2–60 米，层高 1–10 米。');
    if(project.rooms.length>=100) throw Error('每个项目最多保存 100 个房间。');
    const r=R.createRoom(R.safeName(values.name,'新房间'),R.round(w,4),R.round(d,4));
    r.h=R.round(h,4);const b=R.bounds(project.rooms);r.x=project.rooms.length?b.x+b.w+.5:0;
    project.rooms.push(r);meta.roomMeta[r.id]={floor:String(values.floor),reviewed:true};
    meta.measurements[r.id]=R.clone(r);meta.confirmed=false;return r;
  }
  function packet(project,meta) {
    // Explicit allowlist: no address, contact details, appointments, GC data or quotes.
    const b=meta.brief||{};
    return {format:'nexora-quote-brief-v1',createdAt:new Date().toISOString(),status:'业主资料包；未发送；不是正式施工报价',project:R.clone(project),property:{kind:meta.kind,floors:meta.floors,basement:meta.basement,postalCode:b.zip||''},requirements:{budget:b.budget||'',style:b.style||'',start:b.start||'',scope:b.scope||''},rooms:project.rooms.map(r=>({id:r.id,name:r.name,floor:meta.roomMeta?.[r.id]?.floor||'1',measurement:meta.measurements?.[r.id]||null})),photos:(meta.photos||[]).map(p=>({name:p.name,room:p.room,data:p.data})),limits:['测量尺寸需复核；不同房间位置需人工核对','包含原始测量与当前设计；不等同于施工图','不包含业主详细地址、电话或预约资料']};
  }
  function quote(values) {
    const total=Number(values.total);if(!Number.isFinite(total)||total<=0||total>100000000)throw Error('请填写大于零的有效报价金额。');
    if(!String(values.company||'').trim()||!String(values.includes||'').trim())throw Error('请填写商家名称和报价包含范围。');
    return {id:R.uid(),company:R.safeName(values.company),total,type:['商家初步报价','商家正式书面报价'].includes(values.type)?values.type:'商家初步报价',includes:String(values.includes).slice(0,3000),excludes:String(values.excludes||'').slice(0,3000),duration:String(values.duration||'待商家确认').slice(0,100),source:String(values.source||'').slice(0,200),recordedAt:new Date().toISOString(),verification:'用户自行录入，平台未核验'};
  }
  const api={newProject,initialMeta,addMeasuredRoom,packet,quote};
  if(typeof module!=='undefined')module.exports=api;else root.JourneyCore=api;
})(globalThis);
