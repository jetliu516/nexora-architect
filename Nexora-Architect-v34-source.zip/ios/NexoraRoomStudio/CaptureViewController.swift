import UIKit
import RoomPlan

final class CaptureViewController: UIViewController, RoomCaptureViewDelegate, RoomCaptureSessionDelegate {
    var onComplete: ((CapturedRoom) -> Void)?
    var onCancel: (() -> Void)?
    private let captureView = RoomCaptureView(frame: .zero)
    private let statusLabel = UILabel()
    private var running = false
    private var finished = false
    private var cancelled = false
    private var delivered = false

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "扫描房间"
        view.backgroundColor = .black
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "取消", style: .plain, target: self, action: #selector(cancel))
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "完成扫描", style: .done, target: self, action: #selector(finish))
        captureView.delegate = self
        captureView.captureSession.delegate = self
        captureView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(captureView)
        NSLayoutConstraint.activate([
            captureView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            captureView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            captureView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            captureView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        statusLabel.text = "缓慢移动手机，让墙面、门窗进入画面"
        statusLabel.textColor = .white
        statusLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        statusLabel.textAlignment = .center
        statusLabel.numberOfLines = 0
        statusLabel.font = .systemFont(ofSize: 14)
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(statusLabel)
        NSLayoutConstraint.activate([
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 18),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -18),
            statusLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -18),
            statusLabel.heightAnchor.constraint(greaterThanOrEqualToConstant: 50)
        ])
        NotificationCenter.default.addObserver(self, selector: #selector(backgrounded), name: UIApplication.didEnterBackgroundNotification, object: nil)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        guard !running && !finished && !cancelled else { return }
        running = true
        var configuration = RoomCaptureSession.Configuration()
        configuration.isCoachingEnabled = true
        captureView.captureSession.run(configuration: configuration)
    }

    @objc private func finish() {
        guard running && !finished else { return }
        finished = true
        running = false
        navigationItem.rightBarButtonItem?.isEnabled = false
        statusLabel.text = "正在处理墙体与门窗，请稍候…"
        captureView.captureSession.stop()
    }

    @objc private func cancel() {
        guard !cancelled else { return }
        cancelled = true
        if running { running = false; captureView.captureSession.stop() }
        dismiss(animated: true) { [weak self] in self?.onCancel?() }
    }

    @objc private func backgrounded() {
        // A fresh scan is safer than accepting interrupted tracking as a complete room.
        cancel()
    }

    func captureView(shouldPresent roomDataForProcessing: CapturedRoomData, error: Error?) -> Bool {
        if cancelled || delivered { return false }
        if let error = error { fail(error.localizedDescription); return false }
        return true
    }

    func captureView(didPresent processedResult: CapturedRoom, error: Error?) {
        guard !cancelled && !delivered else { return }
        if let error = error { fail(error.localizedDescription); return }
        guard processedResult.walls.count >= 3 else { fail("识别到的墙面不足，请重新扫描房间。") ; return }
        delivered = true
        DispatchQueue.main.async { [weak self] in
            self?.dismiss(animated: true) { [weak self] in self?.onComplete?(processedResult) }
        }
    }

    func captureSession(_ session: RoomCaptureSession, didEndWith data: CapturedRoomData, error: Error?) {
        if let error = error, !cancelled && !delivered { fail(error.localizedDescription) }
    }

    private func fail(_ message: String) {
        guard !delivered && !cancelled else { return }
        delivered = true
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.statusLabel.text = "扫描未完成"
            let alert = UIAlertController(title: "扫描未完成", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "返回重试", style: .default) { [weak self] _ in self?.cancel() })
            self.present(alert, animated: true)
        }
    }

    deinit { NotificationCenter.default.removeObserver(self) }
}
