import Foundation
import RoomPlan
import simd

// Preserves every original wall segment. The editor only computes floor area
// when those segments form a single closed, non-self-intersecting loop.
enum ScanExport {
    static func payload(_ room: CapturedRoom) -> [String: Any] {
        return [
            "format": "nexora-roomplan-v1",
            "name": "实测房间",
            "units": "meters",
            "source": "Apple RoomPlan",
            "capturedAt": ISO8601DateFormatter().string(from: Date()),
            "walls": room.walls.map(surface),
            "windows": room.windows.map(surface),
            "doors": room.doors.map(surface),
            "openings": room.openings.map(surface)
        ]
    }

    private static func surface(_ value: CapturedRoom.Surface) -> [String: Any] {
        let center = value.transform.columns.3
        let localX = value.transform.columns.0
        let halfWidth = value.dimensions.x / 2
        let a = center - localX * halfWidth
        let b = center + localX * halfWidth
        return [
            "a": [Double(a.x), Double(a.z)],
            "b": [Double(b.x), Double(b.z)],
            "height": Double(value.dimensions.y)
        ]
    }
}
