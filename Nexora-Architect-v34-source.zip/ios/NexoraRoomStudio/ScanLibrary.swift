import Foundation
import UIKit
import QuickLook

struct ScanInfo: Codable {
    let id: String
    let name: String
    let projectName: String
    let projectID: String
    let floor: String
    let createdAt: Date

    init(id: String, context: [String: Any], createdAt: Date = Date()) {
        func text(_ key: String, fallback: String = "") -> String {
            let value = (context[key] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            return value.isEmpty ? fallback : String(value.prefix(100))
        }
        self.id = id
        self.name = text("name", fallback: "实测房间")
        self.projectName = text("projectName", fallback: "未命名项目")
        self.projectID = text("projectId")
        self.floor = text("floor", fallback: "1")
        self.createdAt = createdAt
    }
}

struct SavedScan {
    let folder: URL
    let info: ScanInfo

    func file(_ name: String) -> URL? {
        let url = folder.appendingPathComponent(name)
        guard let values = try? url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey]),
              values.isRegularFile == true, values.isSymbolicLink != true,
              (values.fileSize ?? 0) > 0 else { return nil }
        return url
    }

    var files: [URL] {
        ["Nexora-Scan.json", "RoomPlan-Raw.json", "Room.usdz", "Scan-Info.json"].compactMap { file($0) }
    }
}

enum ScanStore {
    static func root() throws -> URL {
        try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            .appendingPathComponent("Scans", isDirectory: true)
    }

    static func records() throws -> [SavedScan] {
        let directory = try root()
        guard FileManager.default.fileExists(atPath: directory.path) else { return [] }
        let folders = try FileManager.default.contentsOfDirectory(at: directory,
            includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey, .creationDateKey], options: [.skipsHiddenFiles])
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return folders.compactMap { folder -> SavedScan? in
            guard let values = try? folder.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey, .creationDateKey]),
                  values.isDirectory == true, values.isSymbolicLink != true else { return nil }
            let info: ScanInfo
            if let data = try? Data(contentsOf: folder.appendingPathComponent("Scan-Info.json")),
               let decoded = try? decoder.decode(ScanInfo.self, from: data) {
                info = decoded
            } else {
                // Older scans and scans with interrupted metadata writes stay recoverable.
                info = ScanInfo(id: folder.lastPathComponent,
                    context: ["name": "扫描 " + String(folder.lastPathComponent.prefix(8))],
                    createdAt: values.creationDate ?? .distantPast)
            }
            let record = SavedScan(folder: folder, info: info)
            guard record.file("Nexora-Scan.json") != nil || record.file("RoomPlan-Raw.json") != nil || record.file("Room.usdz") != nil else { return nil }
            return record
        }.sorted { lhs, rhs in
            lhs.info.createdAt == rhs.info.createdAt ? lhs.info.id < rhs.info.id : lhs.info.createdAt > rhs.info.createdAt
        }
    }
}

final class ScanLibraryViewController: UITableViewController, QLPreviewControllerDataSource {
    private var records: [SavedScan] = []
    private var previewURL: URL?
    private let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "扫描记录"
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(close))
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 90
        do {
            records = try ScanStore.records()
            if records.isEmpty { showMessage("还没有保存的扫描。\n完成一间房的扫描后，会自动出现在这里。") }
        } catch { showMessage("扫描记录暂时无法读取。\n" + error.localizedDescription) }
        tableView.reloadData()
    }

    private func showMessage(_ text: String) {
        let label = UILabel()
        label.text = text
        label.textAlignment = .center
        label.numberOfLines = 0
        label.textColor = .secondaryLabel
        tableView.backgroundView = label
    }

    @objc private func close() { dismiss(animated: true) }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { records.count }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        let record = records[indexPath.row]
        var content = cell.defaultContentConfiguration()
        content.text = record.info.name
        let floor = ["B", "B1"].contains(record.info.floor) ? "地下层" : record.info.floor + " 层"
        let model = record.file("Room.usdz") == nil ? "无 3D 模型 · 可导出已保存数据" : "查看 3D / 导出文件"
        content.secondaryText = "\(record.info.projectName) · \(floor)\n\(dateFormatter.string(from: record.info.createdAt))\n\(model)"
        content.secondaryTextProperties.numberOfLines = 0
        cell.contentConfiguration = content
        cell.accessoryType = .disclosureIndicator
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let record = records[indexPath.row]
        let menu = UIAlertController(title: record.info.name,
            message: "这是本机保存的原始扫描。设计页修改不会覆盖这些文件。", preferredStyle: .actionSheet)
        if let model = record.file("Room.usdz") {
            menu.addAction(UIAlertAction(title: "查看 3D 模型", style: .default) { [weak self] _ in
                guard let self = self else { return }
                self.previewURL = model
                let preview = QLPreviewController()
                preview.dataSource = self
                self.navigationController?.pushViewController(preview, animated: true)
            })
        }
        menu.addAction(UIAlertAction(title: "导出已保存文件", style: .default) { [weak self] _ in
            guard let self = self else { return }
            let share = UIActivityViewController(activityItems: record.files, applicationActivities: nil)
            share.popoverPresentationController?.sourceView = self.tableView
            share.popoverPresentationController?.sourceRect = self.tableView.rectForRow(at: indexPath)
            self.present(share, animated: true)
        })
        menu.addAction(UIAlertAction(title: "取消", style: .cancel))
        menu.popoverPresentationController?.sourceView = tableView
        menu.popoverPresentationController?.sourceRect = tableView.rectForRow(at: indexPath)
        present(menu, animated: true)
    }

    func numberOfPreviewItems(in controller: QLPreviewController) -> Int { previewURL == nil ? 0 : 1 }

    func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
        // Quick Look only requests an item when numberOfPreviewItems is one.
        previewURL! as NSURL
    }
}
